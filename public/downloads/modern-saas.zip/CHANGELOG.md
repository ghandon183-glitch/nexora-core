# Changelog

## 1.1.0
- Security: Next.js **16.3.6 → 16.4.6**, which closes the critical advisories
  that affected 16.0.0–16.4.0 (`GHSA-3w37-wq28-93x7`, `GHSA-4jqv-mc3x-m676`,
  `GHSA-39w2-rjm5-chcv`, `GHSA-f87g-xv8r-7p7x`, `GHSA-mcj8-r9mp-w47p`,
  `GHSA-cjq9-62q9-8jv4`, `GHSA-2464-fhr4-w9xw`, `GHSA-p3m5-59mp-jv5r`,
  `GHSA-h694-7cp9-m8p3`, `GHSA-673q-mjm6-r5xr`). `npm audit --omit=dev` is
  now clean; React/React DOM stay on 19.2.4.
- Dev-only: pinned `minimatch` for `@typescript-eslint/typescript-estree` so
  the lint toolchain no longer reports its moderate advisory.
- Pinned `turbopack.root` so the project builds correctly when its folder sits
  inside another repository that has its own lockfile.
- Added a mobile navigation menu below the `lg` breakpoint. The section links
  were previously unreachable on phones and tablets (they only existed in the
  desktop bar). The menu uses `aria-expanded`/`aria-controls`, closes on link
  click and on <kbd>Escape</kbd> (returning focus to the toggle).
- Documented optional `NEXT_PUBLIC_BASE_PATH`, the Node.js requirement, and the
  template's demo-only boundaries (trial dialog, theme storage, placeholder
  content) in `README.md`.

## 1.0.0
- Customer-ready commercial package.
- Standard license and support documentation.
- Installation and production checklist included.
