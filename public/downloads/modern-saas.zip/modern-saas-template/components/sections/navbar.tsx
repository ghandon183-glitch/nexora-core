import Container from "@/components/ui/container";
import Button from "@/components/ui/button";
import ThemeToggle from "@/components/ui/theme-toggle";

const links = [
  { label: "Product", href: "#product" },
  { label: "How it works", href: "#how-it-works" },
  { label: "Pricing", href: "#pricing" },
  { label: "FAQ", href: "#faq" },
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-line bg-bg/85 backdrop-blur-xl">
      <Container className="flex h-20 items-center justify-between">

        <a href="#top" className="flex items-center gap-2">
          <span className="font-display text-xl font-semibold italic text-text">
            Signoff
          </span>
        </a>

        <nav className="hidden items-center gap-8 lg:flex">
          {links.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm text-text-muted transition hover:text-text"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Button variant="primary" className="hidden sm:inline-flex">
            Start free
          </Button>
        </div>

      </Container>
    </header>
  );
}
