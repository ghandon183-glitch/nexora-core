"use client";

import { useEffect, useRef, useState } from "react";
import Container from "@/components/ui/container";
import StartTrialButton from "@/components/trial/start-trial-button";
import ThemeToggle from "@/components/ui/theme-toggle";

const links = [
  { label: "Product", href: "#product" },
  { label: "How it works", href: "#how-it-works" },
  { label: "Pricing", href: "#pricing" },
  { label: "FAQ", href: "#faq" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const toggleRef = useRef<HTMLButtonElement>(null);

  // Escape closes the menu and returns focus to the toggle button.
  useEffect(() => {
    if (!open) return;

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      setOpen(false);
      toggleRef.current?.focus();
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open]);

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-bg/85 backdrop-blur-xl">
      <Container className="flex h-20 items-center justify-between">

        <a href="#top" className="flex items-center gap-2">
          <span className="font-display text-xl font-semibold italic text-text">
            Signoff
          </span>
        </a>

        <nav aria-label="Main" className="hidden items-center gap-8 lg:flex">
          {links.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm text-text-muted transition hover:text-text"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <ThemeToggle />
          <StartTrialButton className="hidden sm:inline-flex">Start free</StartTrialButton>
          <button
            ref={toggleRef}
            type="button"
            onClick={() => setOpen((value) => !value)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? "Close navigation" : "Open navigation"}
            className="flex h-10 w-10 flex-col items-center justify-center gap-1.5 rounded-full border border-line text-text transition hover:border-moss hover:text-moss lg:hidden"
          >
            <span
              aria-hidden="true"
              className={`h-px w-4 bg-current transition-transform ${open ? "translate-y-[3.5px] rotate-45" : ""}`}
            />
            <span
              aria-hidden="true"
              className={`h-px w-4 bg-current transition-transform ${open ? "-translate-y-[3.5px] -rotate-45" : ""}`}
            />
          </button>
        </div>

      </Container>

      {open && (
        <div id="mobile-nav" className="border-t border-line bg-bg lg:hidden">
          <Container className="flex flex-col py-3">
            <nav aria-label="Mobile">
              {links.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block border-b border-line py-3 text-sm text-text-muted transition hover:text-text"
                >
                  {link.label}
                </a>
              ))}
            </nav>
            <StartTrialButton className="mt-4 sm:hidden">Start free</StartTrialButton>
          </Container>
        </div>
      )}
    </header>
  );
}
