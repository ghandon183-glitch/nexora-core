import Container from "@/components/ui/container";

const studios = [
  "Northfield Studio",
  "Paper Crane Co.",
  "Wren & Idle",
  "Fieldnote Design",
  "Harbor & Co.",
  "Kettle Creative",
];

export default function LogoStrip() {
  return (
    <section className="border-y border-line py-10">
      <Container>

        <p className="text-center font-mono text-xs tracking-[0.3em] text-text-muted uppercase">
          Trusted by independent studios
        </p>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-x-12 gap-y-4">
          {studios.map((name) => (
            <span
              key={name}
              className="font-display text-lg italic text-text-muted/70"
            >
              {name}
            </span>
          ))}
        </div>

      </Container>
    </section>
  );
}
