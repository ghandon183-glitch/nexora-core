import Container from "@/components/ui/container";

const features = [
  {
    title: "One-tap approval",
    body: "Clients review and stamp work from any device — no login, no app to install, no more \"looks good, ship it\" buried in an email thread.",
  },
  {
    title: "A real paper trail",
    body: "Every version, comment, and stamp is timestamped and kept. When a client says \"I never approved that,\" you have the receipt.",
  },
  {
    title: "Reminders that aren't awkward",
    body: "Signoff nudges the client for you, on a schedule you set — so you're never the one sending a third follow-up email.",
  },
  {
    title: "Invoice on approval",
    body: "The moment a piece of work is stamped, a draft invoice is ready to send. No more waiting a week to remember to bill it.",
  },
  {
    title: "Built for small teams",
    body: "No seats to manage, no admin console to configure. Signoff is sized for a studio of one to ten, not an enterprise IT rollout.",
  },
  {
    title: "Client-side clarity",
    body: "Clients see exactly what's being approved and what happens next — fewer \"wait, what am I signing off on?\" replies.",
  },
];

export default function Features() {
  return (
    <section id="product" className="py-28">
      <Container>

        <div className="max-w-xl">
          <p className="font-mono text-xs tracking-[0.3em] text-moss-bright uppercase">
            Product
          </p>

          <h2 className="mt-4 font-display text-4xl text-text">
            Everything approval-chasing shouldn&apos;t require
          </h2>
        </div>

        <div className="mt-16 grid gap-x-8 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div key={feature.title}>
              <h3 className="font-display text-xl text-text">
                {feature.title}
              </h3>

              <p className="mt-3 text-sm leading-6 text-text-muted">
                {feature.body}
              </p>
            </div>
          ))}
        </div>

      </Container>
    </section>
  );
}
