import Container from "@/components/ui/container";

const steps = [
  {
    number: "01",
    title: "Send",
    body: "Upload the work and send a review link. No client account required.",
  },
  {
    number: "02",
    title: "Review",
    body: "The client comments directly on the file and marks what needs changes.",
  },
  {
    number: "03",
    title: "Approve",
    body: "One tap stamps it \u2014 official, timestamped, and impossible to walk back.",
  },
  {
    number: "04",
    title: "Get paid",
    body: "A draft invoice is generated the moment the stamp lands.",
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="border-y border-line bg-bg-raised py-28">
      <Container>

        <div className="max-w-xl">
          <p className="font-mono text-xs tracking-[0.3em] text-moss-bright uppercase">
            How it works
          </p>

          <h2 className="mt-4 font-display text-4xl text-text">
            The same four steps, every time
          </h2>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step, index) => (
            <div key={step.number} className="relative">

              <span className="font-display text-5xl italic text-text-muted/30">
                {step.number}
              </span>

              <h3 className="mt-4 font-display text-xl text-text">
                {step.title}
              </h3>

              <p className="mt-2 text-sm leading-6 text-text-muted">
                {step.body}
              </p>

              {index < steps.length - 1 && (
                <span className="absolute top-6 -right-4 hidden font-mono text-text-muted/40 lg:block">
                  →
                </span>
              )}

            </div>
          ))}
        </div>

      </Container>
    </section>
  );
}
