import Container from "@/components/ui/container";

const faqs = [
  {
    question: "Does my client need to create an account?",
    answer:
      "No. Clients open a review link and can comment or approve without signing up for anything.",
  },
  {
    question: "What happens if a client never responds?",
    answer:
      "Signoff sends reminders on the schedule you set, and you can see exactly when a link was opened and last viewed.",
  },
  {
    question: "Can I use my own invoices?",
    answer:
      "Yes. Signoff drafts an invoice on approval, but you can edit it, use your own numbering, or export the details to your existing invoicing tool.",
  },
  {
    question: "Is there a limit on file size or file types?",
    answer:
      "You can upload images, PDFs, and design file exports up to 200MB per file on every plan.",
  },
];

export default function Faq() {
  return (
    <section id="faq" className="py-28">
      <Container className="max-w-3xl">

        <p className="font-mono text-xs tracking-[0.3em] text-moss-bright uppercase">
          FAQ
        </p>

        <h2 className="mt-4 font-display text-4xl text-text">
          Questions, answered
        </h2>

        <div className="mt-12 divide-y divide-line border-t border-line">
          {faqs.map((faq) => (
            <details key={faq.question} className="group py-6">

              <summary className="flex cursor-pointer list-none items-center justify-between font-display text-lg text-text">
                {faq.question}

                <span className="ml-4 shrink-0 text-text-muted transition group-open:rotate-45">
                  +
                </span>
              </summary>

              <p className="mt-3 text-sm leading-6 text-text-muted">
                {faq.answer}
              </p>

            </details>
          ))}
        </div>

      </Container>
    </section>
  );
}
