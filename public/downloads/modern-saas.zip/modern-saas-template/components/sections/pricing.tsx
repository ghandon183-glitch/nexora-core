import Container from "@/components/ui/container";
import Button from "@/components/ui/button";
import Stamp from "@/components/ui/stamp";

const plans = [
  {
    name: "Freelancer",
    price: "$19",
    cadence: "/month",
    description: "For solo freelancers sending a handful of approvals a month.",
    features: ["Up to 10 active projects", "Unlimited client approvals", "Basic reminders", "Email support"],
  },
  {
    name: "Studio",
    price: "$49",
    cadence: "/month",
    description: "For small studios juggling several clients at once.",
    features: ["Unlimited projects", "Custom reminder schedules", "Branded review links", "Priority support", "Invoice automation"],
    recommended: true,
  },
  {
    name: "Agency",
    price: "$99",
    cadence: "/month",
    description: "For agencies with multiple people sending work for approval.",
    features: ["Everything in Studio", "Up to 10 team members", "Shared approval history", "Dedicated onboarding"],
  },
];

export default function Pricing() {
  return (
    <section id="pricing" className="py-28">
      <Container>

        <div className="max-w-xl">
          <p className="font-mono text-xs tracking-[0.3em] text-moss-bright uppercase">
            Pricing
          </p>

          <h2 className="mt-4 font-display text-4xl text-text">
            Simple pricing, no per-approval fees
          </h2>
        </div>

        <div className="mt-16 grid gap-8 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative flex flex-col rounded-3xl border p-8 ${
                plan.recommended
                  ? "border-moss bg-bg-raised"
                  : "border-line"
              }`}
            >

              {plan.recommended && (
                <div className="absolute -top-6 -right-4 rotate-6">
                  <Stamp label="Popular" size="sm" />
                </div>
              )}

              <h3 className="font-display text-2xl text-text">
                {plan.name}
              </h3>

              <p className="mt-2 text-sm text-text-muted">
                {plan.description}
              </p>

              <div className="mt-6 flex items-baseline gap-1">
                <span className="font-display text-4xl text-text">
                  {plan.price}
                </span>
                <span className="text-sm text-text-muted">
                  {plan.cadence}
                </span>
              </div>

              <ul className="mt-8 flex-1 space-y-3 text-sm text-text-muted">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2">
                    <span className="mt-0.5 text-moss-bright">✓</span>
                    {feature}
                  </li>
                ))}
              </ul>

              <Button
                variant={plan.recommended ? "primary" : "ghost"}
                className="mt-8 w-full"
              >
                Start free trial
              </Button>

            </div>
          ))}
        </div>

      </Container>
    </section>
  );
}
