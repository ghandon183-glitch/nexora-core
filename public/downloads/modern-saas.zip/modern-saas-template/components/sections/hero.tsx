import Container from "@/components/ui/container";
import Button from "@/components/ui/button";
import Stamp from "@/components/ui/stamp";

export default function Hero() {
  return (
    <section id="top" className="paper-texture relative overflow-hidden pt-20 pb-28">

      <Container className="grid items-center gap-16 lg:grid-cols-[1.1fr_0.9fr]">

        <div>
          <p className="font-mono text-xs tracking-[0.3em] text-text-muted uppercase">
            For freelancers &amp; small studios
          </p>

          <h1 className="mt-6 font-display text-5xl leading-[1.05] text-text sm:text-6xl">
            Send it.
            <br />
            <span className="italic text-moss-bright">Get a real answer.</span>
            <br />
            Get paid.
          </h1>

          <p className="mt-6 max-w-md text-lg text-text-muted">
            Signoff turns &ldquo;just following up&rdquo; into a habit of the
            past. Clients approve work with one tap, you get a timestamped
            paper trail, and invoices go out the second the stamp lands.
          </p>

          <div className="mt-10 flex flex-wrap items-center gap-4">
            <Button variant="primary">Start free — no card needed</Button>
            <Button variant="ghost">See how it works</Button>
          </div>

          <p className="mt-6 text-sm text-text-muted">
            14-day trial · cancel anytime · built for solo studios
          </p>
        </div>

        <div className="relative">

          <div className="absolute -top-10 -right-6 z-10 hidden rotate-6 sm:block">
            <Stamp label="Approved" size="lg" />
          </div>

          <div className="rounded-3xl border border-line bg-bg-raised p-6 shadow-2xl shadow-black/10">

            <div className="flex items-center justify-between border-b border-line pb-4">
              <div>
                <p className="text-sm font-semibold text-text">
                  Homepage redesign — v3
                </p>
                <p className="font-mono text-xs text-text-muted">
                  Sent to client · 2 min ago
                </p>
              </div>

              <span className="rounded-full border border-clay/40 px-3 py-1 font-mono text-[11px] tracking-wide text-clay uppercase">
                Pending
              </span>
            </div>

            <div className="mt-5 space-y-3">
              {["Hero section", "Pricing table", "Footer + legal"].map((item) => (
                <div
                  key={item}
                  className="flex items-center justify-between rounded-xl bg-bg px-4 py-3 text-sm text-text"
                >
                  <span>{item}</span>
                  <span className="font-mono text-xs text-moss-bright">
                    ✓ reviewed
                  </span>
                </div>
              ))}
            </div>

            <div className="mt-6 flex items-center justify-between rounded-xl border border-moss/30 bg-moss/10 px-4 py-3">
              <span className="text-sm font-medium text-text">
                Client approval
              </span>
              <span className="font-mono text-xs text-moss-bright">
                stamped 0:04:12
              </span>
            </div>

          </div>

        </div>

      </Container>
    </section>
  );
}
