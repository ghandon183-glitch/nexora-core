import Container from "@/components/ui/container";

const quotes = [
  {
    quote:
      "I used to lose a week waiting for a client to just say the word. Now the stamp lands and the invoice is already half-drafted.",
    name: "Priya Nair",
    role: "Freelance brand designer",
  },
  {
    quote:
      "Our studio stopped having the \u2018did you actually approve this\u2019 argument entirely. The paper trail settles it every time.",
    name: "Marcus Webb",
    role: "Founder, Paper Crane Co.",
  },
  {
    quote:
      "Clients like it more than we do, honestly. One tap instead of digging through an email thread from three weeks ago.",
    name: "Elena Torres",
    role: "Creative director, Wren & Idle",
  },
];

export default function Testimonials() {
  return (
    <section className="border-y border-line bg-bg-raised py-28">
      <Container>

        <div className="grid gap-10 lg:grid-cols-3">
          {quotes.map((item) => (
            <figure key={item.name}>

              <blockquote className="font-display text-xl leading-relaxed text-text italic">
                &ldquo;{item.quote}&rdquo;
              </blockquote>

              <figcaption className="mt-6 font-mono text-xs tracking-wide text-text-muted uppercase">
                {item.name} — {item.role}
              </figcaption>

            </figure>
          ))}
        </div>

      </Container>
    </section>
  );
}
