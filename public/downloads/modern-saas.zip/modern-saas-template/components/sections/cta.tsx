import Container from "@/components/ui/container";
import Button from "@/components/ui/button";
import Stamp from "@/components/ui/stamp";

export default function Cta() {
  return (
    <section className="py-28">
      <Container>

        <div className="relative overflow-hidden rounded-3xl border border-line bg-bg-raised px-10 py-16 text-center">

          <div className="absolute -top-8 left-10 hidden -rotate-12 sm:block">
            <Stamp label="Approved" size="md" />
          </div>

          <h2 className="font-display text-4xl text-text sm:text-5xl">
            Stop chasing.
            <br />
            <span className="italic text-moss-bright">Start stamping.</span>
          </h2>

          <p className="mx-auto mt-6 max-w-md text-text-muted">
            Free for 14 days. No card required. Cancel whenever you like.
          </p>

          <div className="mt-10 flex justify-center">
            <Button variant="primary">Start free trial</Button>
          </div>

        </div>

      </Container>
    </section>
  );
}
