import Container from "@/components/ui/container";

const columns = [
  {
    title: "Product",
    links: ["Features", "Pricing", "How it works", "Changelog"],
  },
  {
    title: "Company",
    links: ["About", "Contact", "Privacy", "Terms"],
  },
];

export default function Footer() {
  return (
    <footer className="border-t border-line py-16">
      <Container className="flex flex-col gap-12 sm:flex-row sm:justify-between">

        <div className="max-w-xs">
          <span className="font-display text-xl font-semibold italic text-text">
            Signoff
          </span>

          <p className="mt-4 text-sm text-text-muted">
            Approval workflows for freelancers and small studios who&apos;d
            rather be doing the work than chasing a reply.
          </p>
        </div>

        <div className="flex gap-16">
          {columns.map((column) => (
            <div key={column.title}>
              <h3 className="font-mono text-xs tracking-[0.2em] text-text-muted uppercase">
                {column.title}
              </h3>

              <ul className="mt-4 space-y-3 text-sm text-text-muted">
                {column.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="transition hover:text-text">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

      </Container>

      <Container className="mt-16 flex flex-col gap-2 border-t border-line pt-8 text-xs text-text-muted sm:flex-row sm:justify-between">
        <p>© 2026 Signoff. All rights reserved.</p>
        <p>This is placeholder demo content for the Modern SaaS template.</p>
      </Container>
    </footer>
  );
}
