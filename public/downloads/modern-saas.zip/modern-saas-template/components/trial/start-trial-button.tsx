"use client";

import Button from "@/components/ui/button";
import { useTrial } from "@/components/trial/trial-provider";

export default function StartTrialButton({
  plan,
  variant = "primary",
  className = "",
  children,
}: {
  plan?: string;
  variant?: "primary" | "ghost" | "stamp";
  className?: string;
  children: React.ReactNode;
}) {
  const { openTrial } = useTrial();

  return (
    <Button variant={variant} className={className} onClick={() => openTrial(plan)}>
      {children}
    </Button>
  );
}
