"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useId,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";

type TrialContextValue = {
  openTrial: (plan?: string) => void;
};

const TrialContext = createContext<TrialContextValue | null>(null);

export function useTrial() {
  const context = useContext(TrialContext);

  if (!context) {
    throw new Error("useTrial must be used inside <TrialProvider>");
  }

  return context;
}

/**
 * Owns the trial signup dialog so every "Start free" control on the page can
 * open the same, real, keyboard-accessible flow instead of being a dead button.
 *
 * The template ships without a backend: the form validates input and shows an
 * explicit demo confirmation, and it never claims an account was created.
 */
export function TrialProvider({ children }: { children: ReactNode }) {
  const [plan, setPlan] = useState<string | null>(null);
  const [studio, setStudio] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null);
  const titleId = useId();
  const descriptionId = useId();

  const openTrial = useCallback((nextPlan?: string) => {
    setPlan(nextPlan ?? "Studio");
    setSubmitted(false);
    setError("");
  }, []);

  const close = useCallback(() => setPlan(null), []);

  useEffect(() => {
    if (!plan) return;

    closeRef.current?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") close();
    };

    window.addEventListener("keydown", onKeyDown);

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    return () => {
      window.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [plan, close]);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setError("Enter a valid email address.");
      return;
    }

    setError("");
    setSubmitted(true);
  }

  return (
    <TrialContext.Provider value={{ openTrial }}>
      {children}

      {plan !== null && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
          onClick={close}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            aria-describedby={descriptionId}
            onClick={(event) => event.stopPropagation()}
            className="relative w-full max-w-md rounded-3xl border border-line bg-bg-raised p-8 shadow-2xl"
          >
            <button
              ref={closeRef}
              type="button"
              onClick={close}
              aria-label="Close trial signup"
              className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full border border-line text-text-muted transition hover:border-moss hover:text-text"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <path d="M18 6 6 18M6 6l12 12" />
              </svg>
            </button>

            {submitted ? (
              <div className="text-center">
                <p className="font-mono text-xs tracking-[0.3em] text-moss-bright uppercase">
                  Demo complete
                </p>
                <h2 id={titleId} className="mt-3 font-display text-2xl text-text">
                  Trial request staged
                </h2>
                <p id={descriptionId} className="mt-3 text-sm leading-6 text-text-muted">
                  This is the template&apos;s demonstration flow. No account was created and no
                  email was sent — connect this form to your own auth or billing endpoint to
                  finish the signup.
                </p>
                <button
                  type="button"
                  onClick={close}
                  className="mt-6 inline-flex items-center justify-center rounded-full bg-moss px-6 py-3 text-sm font-semibold text-white transition hover:brightness-95"
                >
                  Back to the page
                </button>
              </div>
            ) : (
              <>
                <p className="font-mono text-xs tracking-[0.3em] text-moss-bright uppercase">
                  {plan} plan
                </p>
                <h2 id={titleId} className="mt-3 font-display text-2xl text-text">
                  Start your 14-day trial
                </h2>
                <p id={descriptionId} className="mt-2 text-sm leading-6 text-text-muted">
                  No card required. Cancel whenever you like.
                </p>

                <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                  <div>
                    <label htmlFor="trial-studio" className="block font-mono text-xs tracking-wide text-text-muted uppercase">
                      Studio name
                    </label>
                    <input
                      id="trial-studio"
                      value={studio}
                      onChange={(event) => setStudio(event.target.value)}
                      placeholder="Paper Crane Co."
                      className="mt-2 w-full rounded-xl border border-line bg-bg px-4 py-3 text-sm text-text placeholder:text-text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-moss"
                    />
                  </div>

                  <div>
                    <label htmlFor="trial-email" className="block font-mono text-xs tracking-wide text-text-muted uppercase">
                      Work email
                    </label>
                    <input
                      id="trial-email"
                      type="email"
                      required
                      value={email}
                      onChange={(event) => {
                        setEmail(event.target.value);
                        if (error) setError("");
                      }}
                      placeholder="you@studio.com"
                      className="mt-2 w-full rounded-xl border border-line bg-bg px-4 py-3 text-sm text-text placeholder:text-text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-moss"
                    />
                  </div>

                  {error && (
                    <p role="alert" className="text-sm text-clay">
                      {error}
                    </p>
                  )}

                  <button
                    type="submit"
                    className="w-full rounded-full bg-moss px-6 py-3 text-sm font-semibold text-white transition hover:brightness-95"
                  >
                    Create trial workspace
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </TrialContext.Provider>
  );
}
