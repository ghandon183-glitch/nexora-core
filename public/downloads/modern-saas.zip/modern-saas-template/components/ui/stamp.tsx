interface StampProps {
  label: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const sizes = {
  sm: "h-16 w-16 text-[9px] border-2",
  md: "h-24 w-24 text-[10px]",
  lg: "h-36 w-36 text-xs",
};

export default function Stamp({ label, size = "md", className = "" }: StampProps) {
  return (
    <div className={`stamp aspect-square ${sizes[size]} ${className}`}>
      {label}
    </div>
  );
}
