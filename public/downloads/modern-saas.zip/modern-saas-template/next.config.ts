import type { NextConfig } from "next";

// Pin the Turbopack workspace root to this project. Without it, Next.js walks up
// looking for a lockfile and can pick a *parent* project's root when this folder
// is extracted inside another repository — which then builds the parent's files
// instead of this one. `process.cwd()` is the project directory for both
// `next dev` and `next build`, so this also works after moving or renaming the
// folder.
const projectRoot = process.cwd();

const nextConfig: NextConfig = {
  // Optional. Only needed when the site is served from a sub-path, e.g. a
  // marketplace demo at /demo/modern-saas. Leave empty for a normal
  // domain-root deployment.
  basePath: process.env.NEXT_PUBLIC_BASE_PATH || undefined,
  turbopack: {
    root: projectRoot,
  },
};

export default nextConfig;
