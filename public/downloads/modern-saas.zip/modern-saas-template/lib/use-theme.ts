"use client";

import { useEffect, useState } from "react";

export function useTheme() {
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  useEffect(() => {
    const current = document.documentElement.getAttribute("data-theme");

    if (current === "light" || current === "dark") {
      // eslint-disable-next-line react-hooks/set-state-in-effect -- one-time hydration from the data-theme attribute set by the inline init script, not a synchronization loop
      setTheme(current);
    }
  }, []);

  function toggle() {
    const next = theme === "dark" ? "light" : "dark";

    setTheme(next);
    document.documentElement.setAttribute("data-theme", next);

    try {
      localStorage.setItem("signoff-theme", next);
    } catch {
      // ignore storage failures (e.g. private browsing)
    }
  }

  return { theme, toggle };
}
