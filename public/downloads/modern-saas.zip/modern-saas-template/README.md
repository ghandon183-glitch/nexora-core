# Modern SaaS — Nexora Core Template

A one-page SaaS landing template built with Next.js (App Router), Tailwind
CSS v4, and TypeScript. Ships with a working light/dark theme toggle and a
full set of standard landing sections.

## What's inside

- `app/page.tsx` — assembles the full landing page
- `app/layout.tsx` — fonts, metadata, and the theme init script
- `components/sections/` — Navbar, Hero, Logo strip, Features, How it works,
  Pricing, Testimonials, FAQ, CTA, Footer
- `components/ui/` — Button, Container, Stamp (the signature badge element),
  ThemeToggle
- `lib/use-theme.ts` — the light/dark theme hook

## Getting started

```bash
npm install
npm run dev
```

Open `http://localhost:3000` to see it running.

## Customizing

1. **Copy**: All section copy lives directly inside each file in
   `components/sections/`. It currently ships with placeholder content for a
   fictional product called "Signoff" — replace it with your own product's
   name, features, pricing, and testimonials.
2. **Colors & fonts**: All design tokens (colors for both themes, fonts) are
   defined in `app/globals.css` under `:root`, `[data-theme="dark"]`, and
   `[data-theme="light"]`. Change the hex values there to re-theme the whole
   site at once.
3. **Fonts**: Loaded via `next/font/google` in `app/layout.tsx` — swap
   `Fraunces`, `IBM_Plex_Sans`, or `IBM_Plex_Mono` for any other Google Font.
4. **Sections**: Add, remove, or reorder sections by editing the list in
   `app/page.tsx`.

## License

This template is licensed for use in your own personal or commercial
projects, including client work. You may not resell or redistribute the
source code itself as a standalone template or product.
