# Modern SaaS — Nexora Core Template

A one-page SaaS landing template built with Next.js (App Router), Tailwind
CSS v4, and TypeScript. Ships with a working light/dark theme toggle and a
full set of standard landing sections.

## What's inside

- `app/page.tsx` — assembles the full landing page
- `app/layout.tsx` — fonts, metadata, and the theme init script
- `components/sections/` — Navbar, Hero, Logo strip, Features, How it works,
  Pricing, Testimonials, FAQ, CTA, Footer
- `components/ui/` — Button, Container, Stamp (the signature badge element),
  ThemeToggle
- `lib/use-theme.ts` — the light/dark theme hook

## Requirements

- Node.js **20.9 or newer** (the package is tested on Node.js 22 LTS).
- npm 10 or newer — the included `package-lock.json` is what `npm ci` uses.

## Getting started

```bash
npm ci
npm run dev
```

`npm ci` installs the exact, tested dependency tree from the included
`package-lock.json`. Open `http://localhost:3000` to see it running.

### Optional environment variable

| Variable | Default | Purpose |
|---|---|---|
| `NEXT_PUBLIC_BASE_PATH` | empty | Only for sites served from a sub-path, e.g. `/demo/modern-saas`. Leave empty for a normal domain-root deployment. |

No API keys, accounts, or third-party services are required.

## Demo limitations (read before launch)

This is a front-end landing template. **It has no backend**, and nothing in it
creates accounts, sends email, charges cards, or stores data:

- **The “Start free”/trial dialog is a demo.** It validates the email in the
  browser, then shows an explicit “no account was created and no email was
  sent” confirmation. Wire `components/trial/trial-provider.tsx` to your own
  auth or billing endpoint before going live.
- **The theme toggle is real and client-side only** — it stores the choice in
  `localStorage` under `signoff-theme`. No cookie or server session is used.
- **All copy, logos, testimonials, prices, and metrics are placeholder
  content** for a fictional product (“Signoff”). Replace them.
- The FAQ uses native `<details>` elements, so it works without JavaScript.

## Customizing

1. **Copy**: All section copy lives directly inside each file in
   `components/sections/`. It currently ships with placeholder content for a
   fictional product called "Signoff" — replace it with your own product's
   name, features, pricing, and testimonials.
2. **Colors & fonts**: All design tokens (colors for both themes, fonts) are
   defined in `app/globals.css` under `:root`, `[data-theme="dark"]`, and
   `[data-theme="light"]`. Change the hex values there to re-theme the whole
   site at once.
3. **Fonts**: Loaded via `next/font/google` in `app/layout.tsx` — swap
   `Fraunces`, `IBM_Plex_Sans`, or `IBM_Plex_Mono` for any other Google Font.
4. **Sections**: Add, remove, or reorder sections by editing the list in
   `app/page.tsx`.

## License

This template is licensed for use in your own personal or commercial
projects, including client work. You may not resell or redistribute the
source code itself as a standalone template or product.
