# Asset & Third-Party License Manifest

This manifest lists what ships in `premium-portfolio.zip` and the license that
covers each item. It is a review aid, not a grant of rights from Nexora Core.

## Imagery (included, generated)

`public/images/hero.jpg`, `hero-depth.png`, `project-1..4.jpg`, `about.jpg` are
**procedurally generated abstract artwork** created by
`scripts/gen-assets.py` for this template. They contain no stock photography,
no third-party logos, no people and no scanned material, so no external
attribution is required.

You may replace or regenerate them (`pip install pillow` then
`python3 scripts/gen-assets.py`). If you swap in your own photography, its
rights are your responsibility.

## Fonts (bundled via npm, self-hosted at build time)

| Font | Package | License |
| --- | --- | --- |
| Space Grotesk | `@fontsource/space-grotesk` | SIL Open Font License 1.1 |
| Inter | `@fontsource/inter` | SIL Open Font License 1.1 |

No font is requested from an external CDN at runtime; the woff2 files are
emitted into `out/_next/static`.

`--font-mono` falls back to the system monospace font — no monospace webfont is
bundled.

## Icons

`lucide-react` — ISC License. Icons are rendered as inline SVG components.

## Code libraries (all permissively licensed)

| Package | License |
| --- | --- |
| Next.js | MIT |
| React / React DOM | MIT |
| three | MIT |
| @react-three/fiber | MIT |
| @react-three/drei | MIT |
| Tailwind CSS | MIT |
| TypeScript, ESLint and tooling | MIT / Apache-2.0 as published by their authors |

The full dependency list, including transitive packages, is in
`package-lock.json`. Every installed package carries its own license file under
`node_modules/<package>/LICENSE`.

## External links

`lib/data.ts` contains demo social links on `example.com` and the email address
`hello@studionorth.example`. They are placeholders marked `(demo)` in the UI and
resolve to nothing meaningful. Replace them with your own destinations.

## Customer responsibility

Before launch, confirm that your final copy, imagery, trademarks, fonts and
third-party services are licensed for your intended commercial use. Keep any
attribution notices your chosen assets require.
