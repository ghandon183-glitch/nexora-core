# Support & Updates

## Covered
- Installation with `npm ci` and the documented Node.js version.
- Running `npm run dev`, `npm run build`, `npm run preview`,
  `npm run lint` and `npm run typecheck`.
- Documented behaviour of the static export, `NEXT_PUBLIC_BASE_PATH` and
  `NEXT_PUBLIC_SITE_URL`.
- Reproducible bugs in the supplied source (with the steps that reproduce
  them).
- Package updates while this template is maintained.

## Not covered
- Custom design work, new pages, case-study or CMS integrations.
- Connecting the contact form to an email service, CRM or backend.
- Hosting, domains, DNS, CDN configuration or paid third-party services.
- Copywriting, photography, logo design or other content production.
- Dependency upgrades beyond the versions shipped in this package.

## Before you write
Please include:
1. Package version (`1.1.0`).
2. Operating system and Node.js version (`node -v`), npm version (`npm -v`).
3. The exact command that failed and its full output.
4. Whether you built at the root or with `NEXT_PUBLIC_BASE_PATH`, and the
   sub-path used.
5. Browser and viewport size for visual issues, plus a screenshot if possible.

## Known behaviour (not bugs)
- `npm start` is not provided. This is a static export; serve `out/` with
  `npm run preview` or your own static server.
- The contact form does not send email. It composes a `mailto:` draft and says
  so on screen.
- `sitemap.xml` is empty until `NEXT_PUBLIC_SITE_URL` is set at build time.
- The hero shows a still image when WebGL is unavailable or reduced motion is
  enabled.
- Project cards link to the contact section; no case-study pages are included.
