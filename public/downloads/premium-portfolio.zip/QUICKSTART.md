# Quick Start

## 1. Unpack and install

```bash
unzip premium-portfolio.zip
cd premium-portfolio/premium-portfolio
npm ci
```

`npm ci` uses the shipped `package-lock.json` and installs exactly the tested
dependency versions. Use `npm install` only when you change dependencies.

Node.js 20.9 or newer is required.

## 2. Run it locally

```bash
npm run dev
```

Open <http://localhost:3000>. Edit `lib/data.ts` for copy, projects, services
and links; `app/globals.css` for colors and type.

## 3. Build the static site

```bash
npm run build
```

The finished site is written to `out/`. Preview it with:

```bash
npm run preview
```

## 4. Build for a sub-path (optional)

```bash
NEXT_PUBLIC_BASE_PATH=/demo/premium-portfolio \
NEXT_PUBLIC_SITE_URL=https://your-domain.example \
npm run build
```

Upload the contents of `out/` to that sub-path. Both variables are optional;
see `.env.example`.

## 5. Before you launch

- Replace `studio`, `projects`, `services`, `techStack` and `socials` in
  `lib/data.ts` (the email address and social links are placeholders).
- Replace `public/images/*` with your own images. `hero.jpg` and
  `hero-depth.png` are a pair — replace both together.
- Update the metadata in `app/layout.tsx` (title, description, Open Graph).
- Connect the contact form to a real endpoint if you want messages delivered;
  as shipped it only opens an email draft.
- Configure your host to serve `404.html` for unknown paths.
- Run `npm run lint` and `npm run typecheck` before deploying.

## Troubleshooting

| Symptom | Cause |
| --- | --- |
| Images 404 under a sub-path | Build with `NEXT_PUBLIC_BASE_PATH` set, and upload `out/` into that directory. |
| `next start` fails | This project is a static export; serve `out/` instead (`npm run preview`). |
| Hero is a still image | WebGL is disabled/unavailable, or reduced motion is enabled. |
| Empty `sitemap.xml` | `NEXT_PUBLIC_SITE_URL` was not set at build time. |
