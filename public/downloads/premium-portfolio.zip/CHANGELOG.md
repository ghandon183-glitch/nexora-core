# Changelog

## 1.1.0

Reliability and honesty pass on the delivered package.

### Added
- `package-lock.json` (lockfileVersion 3) and `.env.example`, so `npm ci`
  installs exactly the tested dependency graph.
- `.gitignore` for build output, dependencies and local env files.
- `npm run typecheck` (`tsc --noEmit`) and `npm run preview` (serves `out/`).
- Branded `404` page, `icon.svg` favicon, `robots.txt` and `sitemap.xml`
  (sitemap and robots sitemap link require `NEXT_PUBLIC_SITE_URL`).
- Canonical URL, Open Graph/Twitter image and URLs, `metadataBase` and a
  `theme-color` viewport export.
- `NEXT_PUBLIC_SITE_URL` support for absolute URLs (`lib/base-path.ts`).
- Skip link to the main landmark; `main` landmark with an id.
- `scroll-margin-top` on section anchors so the fixed header no longer covers
  headings after in-page navigation.
- Escape closes the mobile menu; the toggle reports `aria-expanded` and
  `aria-controls`; footer external links announce that they open a new tab.

### Fixed
- `next start` was advertised but cannot run a static export. Replaced with
  `npm run preview`, which serves the exported `out/` directory.
- Contact form displayed "Message received" although nothing was sent. It now
  states that the page has no backend and offers a pre-filled `mailto:` draft.
- Project cards advertised "View case study" but were not links. They are now
  real links to the contact section with an accurate label.
- Capability rows only reacted to the mouse and were not focusable. They are now
  links with the same hover treatment on keyboard focus.
- Scroll reveals used JS animation that left content invisible without
  JavaScript and ignored `prefers-reduced-motion`. Replaced with a CSS reveal
  driven by `IntersectionObserver`, gated on reduced motion, and visible by
  default in the server-rendered HTML.
- Hero animation ignored `prefers-reduced-motion`; it is now CSS-based and is
  disabled by the system preference (and still runs without JavaScript).
- `body` hid horizontal overflow, which masked layout bugs. Removed; layout is
  verified overflow-free down to 320px.
- Hero entrance and duplicate marquee text were read twice by screen readers;
  the duplicated marquee copy is now hidden from assistive tech.
- Unused `gallery-1..4.jpg` images (about 141 KB) and `scripts/gen-gallery.py`
  (which wrote to absolute paths outside the package) removed.
- `clsx`, `tailwind-merge`, `lib/utils.ts` and `framer-motion` removed after the
  animations moved to CSS; no behaviour was lost. `@react-three/drei` was also
  unused (the hero uses `@react-three/fiber` and `three` directly) and is gone.
- The 404 page's "Back to the studio" link double-prefixed the base path under a
  sub-path build; it now resolves to the site root at any base path.
- The duplicated marquee copy is hidden from assistive technology, matching the
  documented accessibility behaviour.

### Changed
- `next` and `eslint-config-next` upgraded to **16.4.5**; `react` and
  `react-dom` pinned to **19.2.4**.
- Added a scoped `minimatch` override (`@typescript-eslint/typescript-estree`)
  to clear a transitive advisory in the lint toolchain.
- `package.json` declares `engines.node >= 20.9.0`.
- Documentation rewritten around the real behaviour, with a requirements table,
  env-var table, deployment steps and explicit demo limits.

## 1.0.0
- Initial customer package: single-page studio portfolio with WebGL hero,
  static export, design tokens and demo content.
