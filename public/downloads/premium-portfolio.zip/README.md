# Premium Portfolio — Studio North

A single-page creative-studio portfolio with an interactive WebGL hero.
Next.js (App Router) + TypeScript + Tailwind CSS v4 + React Three Fiber,
exported as a static site.

Everything you receive is editable source. Read this file, then
`QUICKSTART.md`, then `premium-portfolio/README.md`.

## What's in this package

```
README.md            this file
QUICKSTART.md        step-by-step install and launch
CONTENTS.md          file-by-file map of the package
CHANGELOG.md         version history
LICENSE.md           license terms
SUPPORT.md           what support covers
ASSET-LICENSES.md    licenses for fonts, icons, code and imagery
premium-portfolio/   the Next.js project (source, lockfile, .env.example)
```

## Requirements

- Node.js **20.9 or newer** (built and tested on Node 22 and Node 26)
- npm 10 or newer
- No database, API key or account is required. The contact form needs no
  provider because it only composes an email draft.

## Quick start

```bash
cd premium-portfolio
npm ci
npm run dev
```

Open <http://localhost:3000>.

Production build (static export into `out/`):

```bash
npm run build
npm run preview     # serves out/ on http://localhost:3000
```

## Environment variables

Both are optional and both are read at build time. See
`premium-portfolio/.env.example`.

| Variable | Required | Purpose |
| --- | --- | --- |
| `NEXT_PUBLIC_BASE_PATH` | No | Serve the export from a sub-path, e.g. `/demo/premium-portfolio`. |
| `NEXT_PUBLIC_SITE_URL` | No | Public origin (no path) for canonical, Open Graph, `sitemap.xml` and `robots.txt`. |

Sub-path build example:

```bash
NEXT_PUBLIC_BASE_PATH=/demo/premium-portfolio \
NEXT_PUBLIC_SITE_URL=https://studio.example.com \
npm run build
```

## Deploy

The build output is static. Upload the contents of `premium-portfolio/out/` to
any static host (Cloudflare Pages, Netlify, Vercel static, S3/CDN, nginx).
Configure the host to serve `404.html` for unknown paths. No server-side
runtime is needed.

## Honest limits

- The contact form is a **demo**: it composes a `mailto:` draft and says so. No
  message is sent or stored by the page.
- Project cards and capability rows link to the contact section; the package
  includes no case-study or service detail pages.
- Social links are `example.com` placeholders marked `(demo)`.
- All studio names, projects, copy and imagery are demo content.
- The WebGL hero is progressive enhancement; without WebGL a static image is
  shown.

## License and support

`LICENSE.md` covers usage rights, `SUPPORT.md` explains what is included, and
`ASSET-LICENSES.md` lists every third-party asset and its license.
