# Premium Portfolio — Creative Developer

A polished, production-ready portfolio template for developers, designers, and
creative professionals. Built with Next.js (App Router), TypeScript, Tailwind
CSS v4, and Framer Motion.

## Features

- Premium animated hero with staggered reveals
- About, capabilities, experience timeline
- Selected-work grid with generated SVG project visuals
- Services, tech stack, testimonials
- Contact section with a validated form + success state
- Fully responsive, dark-mode-first design
- SEO metadata and Open Graph tags
- Reduced-motion friendly

## Tech stack

- Next.js 16 (App Router, static export)
- TypeScript
- Tailwind CSS v4
- Framer Motion
- lucide-react icons

## Getting started

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`.

## Build

```bash
npm run build
```

The template is configured for static export (`output: "export"`). A
`NEXT_PUBLIC_BASE_PATH` env var lets you host the export under a sub-path.

## Customization

- Content lives in `lib/data.ts` (profile, skills, timeline, projects,
  services, testimonials, tech stack).
- Theme tokens live in `app/globals.css` under `@theme inline`.
- Replace the generated SVG project visuals in `components/projects.tsx` with
  your own screenshots or imagery.
