# Premium Portfolio — Creative Studio

A polished, production-ready creative-studio portfolio template with an
interactive WebGL hero. Built with Next.js (App Router), TypeScript, Tailwind
CSS v4, Framer Motion, and React Three Fiber.

## Features

- Interactive WebGL depth-displaced hero with pointer parallax, bloom, and scan FX
- Graceful fallback to a static hero image when WebGL is unavailable
- Immersive selected-work showcase with hover motion
- Animated capabilities section with grow-line indicators
- Infinite marquee tech strip
- Studio (about) section with capability tags
- Contact section with a validated form + success state
- Fully responsive, dark-mode-first design
- SEO metadata and Open Graph tags
- Reduced-motion and touch aware

## Tech stack

- Next.js 16 (App Router, static export)
- TypeScript
- Tailwind CSS v4
- Framer Motion
- React Three Fiber + Three.js (hero scene)
- lucide-react icons

## Getting started

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`.

> A `.npmrc` with `legacy-peer-deps=true` is included for reproducible installs
> (resolves a react-dom peer dependency conflict).

## Build

```bash
npm run build
```

The template is configured for static export (`output: "export"`). A
`NEXT_PUBLIC_BASE_PATH` env var lets you host the export under a sub-path, e.g.:

```bash
NEXT_PUBLIC_BASE_PATH=/demo/premium-portfolio npm run build
```

## Customization

- Content lives in `lib/data.ts` (studio, projects, services, tech stack,
  navigation, socials).
- Theme tokens live in `app/globals.css` under `@theme inline`.
- Replace the images in `public/images/` with your own. The hero depth map
  (`hero-depth.png`) drives the 3D displacement — replace both `hero.jpg` and
  `hero-depth.png` together (the depth map's luminance controls vertex height).
- Social links in `lib/data.ts` are demo placeholders (`example.com`) — replace
  `href` values with your own profiles.

## Notes on the hero scene

The hero uses a single low-poly plane displaced by a luminance depth map and
lit by pointer-reactive lights. The "bloom" is faked with additive emissive
material plus CSS layers (no heavy post-processing pipeline), keeping the
bundle lean. All mutable animation state lives in refs to stay compatible with
the React Compiler.
