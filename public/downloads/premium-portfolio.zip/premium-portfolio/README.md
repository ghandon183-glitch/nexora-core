# Premium Portfolio — Studio North

A single-page creative-studio portfolio with an interactive WebGL hero, built
with Next.js (App Router), TypeScript, Tailwind CSS v4 and React Three Fiber.
It exports as a fully static site (`output: "export"`), so it can be hosted on
any static host or object store.

## Requirements

| Requirement | Notes |
| --- | --- |
| Node.js | **20.9 or newer** (`engines` is `>=20.9.0`; built and tested on Node 22 and Node 26) |
| npm | 10 or newer (the package ships a lockfileVersion 3 `package-lock.json`) |
| WebGL | Optional. The hero falls back to a static image when WebGL is unavailable. |

## Install and run

```bash
npm ci          # reproducible install from the shipped lockfile
npm run dev     # http://localhost:3000
```

If you add or change dependencies, use `npm install` instead of `npm ci` and
commit the updated lockfile in your own repository.

## Build

```bash
npm run build       # static export -> out/
npm run preview     # serves out/ on http://localhost:3000 (npx serve)
```

`npm start` is intentionally not provided: `next start` does not work with
`output: "export"`. Serve the generated `out/` directory instead.

## Environment variables

Both variables are optional. Copy `.env.example` to `.env.local` for local use.

| Variable | Required | What it does |
| --- | --- | --- |
| `NEXT_PUBLIC_BASE_PATH` | No | Serves the export from a sub-path, e.g. `/demo/premium-portfolio`. Must start with `/` and must not end with `/`. Affects pages, `/_next` assets, `public/` files and the Three.js textures. |
| `NEXT_PUBLIC_SITE_URL` | No | Public origin only, e.g. `https://studio.example.com` (no path). Used for the canonical URL, Open Graph/Twitter URLs, `sitemap.xml` and `robots.txt`. Without it, no canonical/OG URL is emitted and the sitemap is empty. |

Environment variables are read at build time for a static export — rebuild
after changing them.

### Building for a sub-path

```bash
NEXT_PUBLIC_BASE_PATH=/demo/premium-portfolio \
NEXT_PUBLIC_SITE_URL=https://studio.example.com \
npm run build
```

The exported `out/` then expects to be served at
`https://studio.example.com/demo/premium-portfolio/`. Upload the **contents of
`out/`** into that directory. Never mix a base-path build with a root deploy.

## Deploy

The export is plain HTML/CSS/JS plus `public/` assets:

1. `npm run build`
2. Upload the contents of `out/` to any static host (Cloudflare Pages, Netlify,
   Vercel static, S3 + CDN, nginx, GitHub Pages).
3. Configure the host to serve `404.html` for unknown paths so the bundled
   not-found page is used.
4. Optional: set long cache headers for `_next/static/*` (content-hashed) and
   short ones for `index.html`.

No server, database, API key or build-time secret is required.

## What is real and what is demo

- **Contact form** — demo only. There is no backend: submitting composes an
  email draft (`mailto:`) in the visitor's email client and states plainly that
  nothing was sent or stored. Replace `studio.email` in `lib/data.ts`, or wire
  the form to your own endpoint/provider.
- **Project cards** — each card links to the contact section. No case-study
  pages are included; point the card `href` at your own project pages.
- **Capability rows** — each row links to the contact section.
- **Social links** — placeholders on `example.com`, marked `(demo)` in the UI.
  Replace the `href` values in `lib/data.ts`. The email entry uses
  `hello@studionorth.example`.
- **Content** — studio name, projects, services and copy are fictional demo
  content. Replace everything before launch.
- **Hero scene** — real WebGL depth displacement with pointer parallax. It
  renders a static image first and is disabled for reduced-motion and coarse
  pointer (touch) devices.

## Customization

- `lib/data.ts` — studio copy, projects, services, tech strip, navigation and
  social links.
- `app/globals.css` — design tokens (`@theme inline`), textures, animation.
- `public/images/` — the demo imagery. `hero.jpg` and `hero-depth.png` are
  paired: the depth map's luminance drives the displacement, so replace both
  together and keep the same aspect ratio.
- `scripts/gen-assets.py` — regenerates the demo imagery procedurally
  (`pip install pillow`, then `python3 scripts/gen-assets.py` from the project
  root). Optional; the generated files are already included.

## Accessibility and motion

- Skip link to the main landmark, visible focus rings, labelled navigation and
  external links announce that they open a new tab.
- Section anchors clear the fixed header (`scroll-margin-top`).
- `prefers-reduced-motion` disables the hero entrance, marquee, scan beam,
  scroll reveals and the WebGL pointer drift.
- Scroll reveals are progressive: without JavaScript all content is visible.

## Project structure

```
app/            layout, page, not-found, icon.svg, robots.ts, sitemap.ts, globals.css
components/     nav, hero, hero-canvas, tech-strip, about, projects, services, contact, footer, reveal
lib/            data.ts (content), base-path.ts (BASE_PATH/SITE_URL helpers)
public/images/  hero, depth map, project and studio imagery
scripts/        gen-assets.py (optional demo asset generator)
```

The exported site is a single route (`/`). `404.html`, `robots.txt` and
`sitemap.xml` are generated at build time.
