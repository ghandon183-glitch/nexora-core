"use client";

import { Reveal } from "@/components/reveal";
import { services } from "@/lib/data";
import { ArrowUpRight } from "lucide-react";

export function Services() {
  return (
    <section id="capabilities" className="grid-texture border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-32">
        <Reveal>
          <p className="eyebrow">Capabilities</p>
          <h2 className="font-display mt-4 max-w-2xl text-balance text-3xl font-semibold leading-tight text-ink md:text-5xl">
            What the studio can do for your team.
          </h2>
        </Reveal>

        <div className="mt-12 border-t border-line">
          {services.map((service, i) => (
            <Reveal key={service.title} delay={i * 0.04}>
              <a
                href="#contact"
                aria-label={`Discuss ${service.title} with the studio`}
                className="service-row group relative block border-b border-line py-7 md:py-8"
              >
                <div className="grid items-center gap-4 md:grid-cols-[0.5fr_2fr_2fr] md:gap-10">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-sm text-ink-mute">0{i + 1}</span>
                    <span className="h-1.5 w-1.5 rounded-full bg-accent opacity-40 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100" />
                  </div>
                  <h3 className="service-title font-display text-2xl font-semibold tracking-tight text-ink transition-colors md:text-3xl">
                    {service.title}
                  </h3>
                  <div className="flex items-start justify-between gap-4">
                    <p className="max-w-md text-sm leading-relaxed text-ink-soft">
                      {service.description}
                    </p>
                    <ArrowUpRight
                      size={20}
                      className="service-arrow shrink-0 text-ink-mute transition-all"
                    />
                  </div>
                </div>

                {/* grow-line indicator */}
                <div className="grow-line absolute bottom-0 left-0 h-px w-full bg-accent/60" />
              </a>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.08}>
          <p className="mt-10 text-sm text-ink-mute">
            Every capability row opens the contact section — nothing here links
            to a separate service page.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
