"use client";

import { useState } from "react";
import { Reveal } from "@/components/reveal";
import { services } from "@/lib/data";
import { ArrowUpRight } from "lucide-react";

export function Services() {
  const [active, setActive] = useState<number | null>(null);

  return (
    <section id="capabilities" className="grid-texture border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-32">
        <Reveal>
          <p className="eyebrow">Capabilities</p>
          <h2 className="font-display mt-4 max-w-2xl text-balance text-3xl font-semibold leading-tight text-ink md:text-5xl">
            What the studio can do for your team.
          </h2>
        </Reveal>

        <div className="mt-12 border-t border-line">
          {services.map((service, i) => (
            <Reveal key={service.title} delay={i * 0.04}>
              <div
                className="group relative border-b border-line py-7 transition-colors md:py-8"
                onMouseEnter={() => setActive(i)}
                onMouseLeave={() => setActive(null)}
              >
                <div className="grid items-center gap-4 md:grid-cols-[0.5fr_2fr_2fr] md:gap-10">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-sm text-ink-mute">0{i + 1}</span>
                    <span
                      className={`h-1.5 w-1.5 rounded-full bg-accent transition-opacity ${
                        active === i ? "opacity-100" : "opacity-30"
                      }`}
                    />
                  </div>
                  <h3
                    className={`font-display text-2xl font-semibold tracking-tight transition-colors md:text-3xl ${
                      active === i ? "text-accent" : "text-ink"
                    }`}
                  >
                    {service.title}
                  </h3>
                  <div className="flex items-start justify-between gap-4">
                    <p className="max-w-md text-sm leading-relaxed text-ink-soft">
                      {service.description}
                    </p>
                    <ArrowUpRight
                      size={20}
                      className={`shrink-0 transition-all ${
                        active === i
                          ? "-translate-y-0.5 translate-x-0.5 text-accent"
                          : "text-ink-mute"
                      }`}
                    />
                  </div>
                </div>

                {/* grow-line indicator */}
                <div
                  className={`grow-line absolute bottom-0 left-0 h-px w-full bg-accent/60 ${
                    active === i ? "is-in" : ""
                  }`}
                />
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
