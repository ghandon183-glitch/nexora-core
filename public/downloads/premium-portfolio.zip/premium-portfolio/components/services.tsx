import { Reveal } from "@/components/reveal";
import { services } from "@/lib/data";
import { Check } from "lucide-react";

export function Services() {
  return (
    <section id="services" className="grid-texture border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28">
        <Reveal>
          <p className="eyebrow">Services</p>
          <h2 className="font-display mt-4 max-w-2xl text-3xl font-semibold leading-tight text-ink md:text-4xl">
            How I can help your team.
          </h2>
        </Reveal>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {services.map((service, i) => (
            <Reveal key={service.title} delay={i * 0.08}>
              <div className="group flex h-full flex-col rounded-2xl border border-line bg-surface p-7 transition-colors hover:border-accent/40">
                <span className="font-display text-5xl font-semibold text-line transition-colors group-hover:text-accent/30">
                  0{i + 1}
                </span>
                <h3 className="font-display mt-4 text-xl font-semibold text-ink">{service.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-ink-soft">{service.description}</p>
                <ul className="mt-6 space-y-2.5 border-t border-line pt-6">
                  {service.points.map((point) => (
                    <li key={point} className="flex items-center gap-2.5 text-sm text-ink">
                      <Check size={15} className="shrink-0 text-accent" />
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
