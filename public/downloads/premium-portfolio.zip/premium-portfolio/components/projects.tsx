import { Reveal } from "@/components/reveal";
import { projects } from "@/lib/data";
import { ArrowUpRight } from "lucide-react";

const accents = ["#d4ff4f", "#8b5cf6", "#60a5fa", "#f97316"];

export function Projects() {
  return (
    <section id="work" className="border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow">Selected work</p>
              <h2 className="font-display mt-4 text-3xl font-semibold leading-tight text-ink md:text-4xl">
                Projects I&apos;m proud to have shipped.
              </h2>
            </div>
            <p className="max-w-xs text-sm text-ink-mute">
              A small sample. Case studies available on request for active engagements.
            </p>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {projects.map((project, i) => (
            <Reveal key={project.title} delay={(i % 2) * 0.08}>
              <article className="group h-full overflow-hidden rounded-2xl border border-line bg-surface transition-colors hover:border-ink-soft/40">
                <div className="relative aspect-[16/10] overflow-hidden border-b border-line">
                  <ProjectVisual index={i} color={accents[i % accents.length]} />
                  <div className="absolute right-4 top-4 flex items-center gap-2 rounded-full bg-base/70 px-3 py-1.5 text-xs font-medium text-ink backdrop-blur">
                    {project.year}
                  </div>
                </div>
                <div className="p-6">
                  <p className="font-mono text-xs uppercase tracking-widest text-ink-mute">{project.category}</p>
                  <div className="mt-2 flex items-start justify-between gap-4">
                    <h3 className="font-display text-xl font-semibold text-ink">{project.title}</h3>
                    <ArrowUpRight
                      size={18}
                      className="shrink-0 text-ink-mute transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-accent"
                    />
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-ink-soft">{project.description}</p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-md border border-line bg-base px-2.5 py-1 font-mono text-[0.7rem] text-ink-soft"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProjectVisual({ index, color }: { index: number; color: string }) {
  // Distinct generated SVG visuals per project — abstract but on-brand.
  if (index % 2 === 0) {
    return (
      <div className="absolute inset-0 bg-base">
        <svg viewBox="0 0 400 250" className="h-full w-full" preserveAspectRatio="xMidYMid slice">
          <defs>
            <linearGradient id={`g${index}`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity="0.18" />
              <stop offset="100%" stopColor={color} stopOpacity="0.02" />
            </linearGradient>
          </defs>
          <rect width="400" height="250" fill={`url(#g${index})`} />
          {Array.from({ length: 8 }).map((_, r) => (
            <line key={r} x1="0" y1={r * 32 + 10} x2="400" y2={r * 32 + 10} stroke="#26262c" strokeWidth="1" />
          ))}
          <circle cx="300" cy="120" r="70" fill={color} fillOpacity="0.12" />
          <circle cx="300" cy="120" r="40" fill={color} fillOpacity="0.2" />
          <rect x="40" y="170" width="120" height="14" rx="3" fill="#26262c" />
          <rect x="40" y="194" width="80" height="10" rx="3" fill="#1a1a1e" />
          <rect x="40" y="40" width="180" height="24" rx="4" fill={color} fillOpacity="0.25" />
        </svg>
      </div>
    );
  }
  return (
    <div className="absolute inset-0 bg-base">
      <svg viewBox="0 0 400 250" className="h-full w-full" preserveAspectRatio="xMidYMid slice">
        <defs>
          <radialGradient id={`rg${index}`} cx="30%" cy="30%">
            <stop offset="0%" stopColor={color} stopOpacity="0.22" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width="400" height="250" fill="#121214" />
        <rect width="400" height="250" fill={`url(#rg${index})`} />
        <rect x="30" y="30" width="160" height="100" rx="8" fill="#1a1a1e" stroke="#26262c" />
        <rect x="210" y="30" width="160" height="100" rx="8" fill="#1a1a1e" stroke="#26262c" />
        <rect x="30" y="150" width="340" height="70" rx="8" fill="#1a1a1e" stroke="#26262c" />
        <rect x="46" y="46" width="60" height="8" rx="2" fill={color} fillOpacity="0.7" />
        <rect x="46" y="62" width="100" height="6" rx="2" fill="#3f3f46" />
        <rect x="226" y="46" width="80" height="8" rx="2" fill={color} fillOpacity="0.7" />
        <rect x="226" y="62" width="100" height="6" rx="2" fill="#3f3f46" />
        <rect x="46" y="166" width="120" height="8" rx="2" fill={color} fillOpacity="0.6" />
        <rect x="46" y="184" width="200" height="6" rx="2" fill="#3f3f46" />
      </svg>
    </div>
  );
}
