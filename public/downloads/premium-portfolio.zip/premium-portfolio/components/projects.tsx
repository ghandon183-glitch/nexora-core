"use client";

import Image from "next/image";
import { Reveal } from "@/components/reveal";
import { projects } from "@/lib/data";
import { assetPath } from "@/lib/base-path";
import { ArrowUpRight } from "lucide-react";

export function Projects() {
  return (
    <section id="work" className="border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-32">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow">Selected work</p>
              <h2 className="font-display mt-4 text-balance text-3xl font-semibold leading-tight text-ink md:text-5xl">
                A selection of recent studio work.
              </h2>
            </div>
            <p className="max-w-xs text-sm text-ink-mute">
              Fictional demo projects shown for presentation. Case studies are
              available on request for active engagements.
            </p>
          </div>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          {projects.map((project, i) => (
            <Reveal key={project.title} delay={(i % 2) * 0.08}>
              <article className="group relative h-full overflow-hidden rounded-2xl border border-line bg-surface transition-colors hover:border-ink-soft/40">
                <div className="relative aspect-[16/10] overflow-hidden border-b border-line">
                  <Image
                    src={assetPath(project.image)}
                    alt={`${project.title} — ${project.category}`}
                    fill
                    sizes="(min-width: 768px) 50vw, 100vw"
                    className="object-cover transition-transform duration-[1.1s] ease-out group-hover:scale-[1.06]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-base/80 via-transparent to-transparent opacity-70 transition-opacity group-hover:opacity-90" />
                  <div className="absolute left-5 top-5 font-display text-sm font-semibold text-ink/80">
                    {project.index}
                  </div>
                  <div className="absolute right-4 top-4 flex items-center gap-2 rounded-full bg-base/70 px-3 py-1.5 text-xs font-medium text-ink backdrop-blur">
                    {project.year}
                  </div>
                  <div className="absolute bottom-4 left-5 translate-y-2 opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                    <span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-3 py-1.5 text-xs font-semibold text-base">
                      View case study
                      <ArrowUpRight size={12} />
                    </span>
                  </div>
                </div>

                <div className="p-6 md:p-7">
                  <p className="font-mono text-xs uppercase tracking-widest text-ink-mute">
                    {project.category}
                  </p>
                  <div className="mt-2 flex items-start justify-between gap-4">
                    <h3 className="font-display text-2xl font-semibold tracking-tight text-ink transition-colors group-hover:text-accent">
                      {project.title}
                    </h3>
                    <ArrowUpRight
                      size={18}
                      className="shrink-0 text-ink-mute transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-accent"
                    />
                  </div>
                  <p className="mt-3 text-sm leading-relaxed text-ink-soft">
                    {project.description}
                  </p>
                  <div className="mt-5 flex flex-wrap gap-2">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="rounded-md border border-line bg-base px-2.5 py-1 font-mono text-[0.7rem] text-ink-soft"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
