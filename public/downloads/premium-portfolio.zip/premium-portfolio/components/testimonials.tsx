import { Reveal } from "@/components/reveal";
import { testimonials } from "@/lib/data";

export function Testimonials() {
  return (
    <section className="border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28">
        <Reveal>
          <p className="eyebrow">Kind words</p>
          <h2 className="font-display mt-4 max-w-2xl text-3xl font-semibold leading-tight text-ink md:text-4xl">
            What people I&apos;ve worked with say.
          </h2>
        </Reveal>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.08}>
              <figure className="flex h-full flex-col rounded-2xl border border-line bg-surface p-7">
                <span className="font-display text-5xl leading-none text-accent">&ldquo;</span>
                <blockquote className="mt-2 flex-1 text-sm leading-relaxed text-ink-soft">
                  {t.quote}
                </blockquote>
                <figcaption className="mt-6 border-t border-line pt-5">
                  <p className="font-semibold text-ink">{t.name}</p>
                  <p className="mt-0.5 text-xs text-ink-mute">{t.title}</p>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
