"use client";

import { useState } from "react";
import { Reveal } from "@/components/reveal";
import { studio } from "@/lib/data";
import { ArrowUpRight, Mail } from "lucide-react";

type Draft = {
  name: string;
  email: string;
  company: string;
  message: string;
};

function buildMailto(draft: Draft) {
  const subject = `New project enquiry — ${draft.name || "Website enquiry"}`;
  const body = [
    `Name: ${draft.name}`,
    `Email: ${draft.email}`,
    draft.company ? `Company: ${draft.company}` : null,
    "",
    draft.message,
  ]
    .filter((line) => line !== null)
    .join("\n");
  return `mailto:${studio.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

export function Contact() {
  const [draft, setDraft] = useState<Draft | null>(null);

  return (
    <section id="contact" className="noise relative border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-32">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-20">
          <Reveal className="min-w-0">
            <p className="eyebrow">Contact</p>
            <h2 className="font-display mt-4 text-balance text-4xl font-semibold leading-[1.05] text-ink md:text-6xl">
              Let&apos;s work together.
            </h2>
            <p className="mt-6 max-w-md leading-relaxed text-ink-soft">
              We take on a small number of engagements each quarter. Tell us what you&apos;re
              building and we&apos;ll reply within two business days.
            </p>

            <a
              href={`mailto:${studio.email}`}
              className="group mt-8 inline-flex max-w-full items-center gap-2 break-all font-display text-lg font-semibold text-ink sm:text-xl md:text-2xl"
            >
              {studio.email}
              <ArrowUpRight
                size={20}
                className="text-accent transition-transform group-hover:translate-x-1 group-hover:-translate-y-1"
              />
            </a>

            <div className="mt-6 flex items-center gap-2 text-sm text-ink-mute">
              <span className="h-2 w-2 animate-pulse rounded-full bg-accent" />
              {studio.availability}
            </div>
          </Reveal>

          <Reveal delay={0.1} className="min-w-0">
            <div className="rounded-2xl border border-line bg-surface p-7 md:p-8">
              {draft ? (
                <div role="status" className="flex min-h-[20rem] flex-col justify-center">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/15">
                    <Mail size={22} className="text-accent" />
                  </div>
                  <h3 className="font-display mt-5 text-xl font-semibold text-ink">
                    Nothing has been sent yet
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-ink-soft">
                    This package ships without a backend or email service, so the
                    form cannot deliver messages. Your details stay in this
                    browser tab. Open the pre-filled draft in your email app, or
                    write to{" "}
                    <a href={`mailto:${studio.email}`} className="link-underline text-accent">
                      {studio.email}
                    </a>{" "}
                    directly.
                  </p>

                  <a
                    href={buildMailto(draft)}
                    className="mt-6 inline-flex w-fit items-center justify-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-base transition-transform hover:scale-[1.02] focus-visible:scale-[1.02]"
                  >
                    Open draft in email app
                    <ArrowUpRight size={16} />
                  </a>

                  <button
                    type="button"
                    onClick={() => setDraft(null)}
                    className="link-underline mt-5 w-fit text-sm font-medium text-accent"
                  >
                    Back to the form
                  </button>
                </div>
              ) : (
                <form
                  onSubmit={(event) => {
                    event.preventDefault();
                    const data = new FormData(event.currentTarget);
                    setDraft({
                      name: String(data.get("name") ?? "").trim(),
                      email: String(data.get("email") ?? "").trim(),
                      company: String(data.get("company") ?? "").trim(),
                      message: String(data.get("message") ?? "").trim(),
                    });
                  }}
                  className="space-y-5"
                >
                  <Field label="Name" name="name" autoComplete="name" placeholder="Jordan Lee" />
                  <Field
                    label="Email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@company.com"
                  />
                  <Field
                    label="Company"
                    name="company"
                    autoComplete="organization"
                    placeholder="Acme Inc. (optional)"
                    required={false}
                  />
                  <div>
                    <label htmlFor="message" className="eyebrow">
                      Project
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={4}
                      placeholder="What are you building, and what's the timeline?"
                      className="mt-2 w-full resize-none rounded-xl border border-line bg-base px-4 py-3 text-sm text-ink placeholder:text-ink-mute focus:border-accent focus:outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-accent px-6 py-3.5 text-sm font-semibold text-base transition-transform hover:scale-[1.01] focus-visible:scale-[1.01]"
                  >
                    Compose message
                    <ArrowUpRight size={16} />
                  </button>
                  <p className="text-center text-xs text-ink-mute">
                    Demo form — this page sends and stores nothing. Submitting
                    prepares an email draft you send yourself.
                  </p>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
  autoComplete,
  required = true,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  autoComplete?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={name} className="eyebrow">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        autoComplete={autoComplete}
        placeholder={placeholder}
        className="mt-2 w-full rounded-xl border border-line bg-base px-4 py-3 text-sm text-ink placeholder:text-ink-mute focus:border-accent focus:outline-none"
      />
    </div>
  );
}
