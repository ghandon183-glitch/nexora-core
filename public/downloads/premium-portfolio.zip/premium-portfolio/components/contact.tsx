"use client";

import { useState } from "react";
import { Reveal } from "@/components/reveal";
import { studio } from "@/lib/data";
import { ArrowUpRight, Check } from "lucide-react";

export function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <section id="contact" className="noise relative border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-32">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-20">
          <Reveal>
            <p className="eyebrow">Contact</p>
            <h2 className="font-display mt-4 text-balance text-4xl font-semibold leading-[1.05] text-ink md:text-6xl">
              Let&apos;s work together.
            </h2>
            <p className="mt-6 max-w-md leading-relaxed text-ink-soft">
              We take on a small number of engagements each quarter. Tell us what you&apos;re
              building and we&apos;ll reply within two business days.
            </p>

            <a
              href={`mailto:${studio.email}`}
              className="group mt-8 inline-flex items-center gap-2 font-display text-xl font-semibold text-ink md:text-2xl"
            >
              {studio.email}
              <ArrowUpRight
                size={20}
                className="text-accent transition-transform group-hover:translate-x-1 group-hover:-translate-y-1"
              />
            </a>

            <div className="mt-6 flex items-center gap-2 text-sm text-ink-mute">
              <span className="h-2 w-2 animate-pulse rounded-full bg-accent" />
              {studio.availability}
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <div className="rounded-2xl border border-line bg-surface p-7 md:p-8">
              {sent ? (
                <div className="flex h-full min-h-[20rem] flex-col items-center justify-center text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent/15">
                    <Check size={26} className="text-accent" />
                  </div>
                  <h3 className="font-display mt-5 text-xl font-semibold text-ink">Message received</h3>
                  <p className="mt-2 max-w-xs text-sm text-ink-soft">
                    Thanks for reaching out. We&apos;ll get back to you shortly.
                  </p>
                  <button
                    onClick={() => setSent(false)}
                    className="link-underline mt-6 text-sm font-medium text-accent"
                  >
                    Send another
                  </button>
                </div>
              ) : (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    setSent(true);
                  }}
                  className="space-y-5"
                >
                  <Field label="Name" name="name" placeholder="Jordan Lee" />
                  <Field label="Email" name="email" type="email" placeholder="you@company.com" />
                  <Field label="Company" name="company" placeholder="Acme Inc. (optional)" required={false} />
                  <div>
                    <label htmlFor="message" className="eyebrow">
                      Project
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      required
                      rows={4}
                      placeholder="What are you building, and what's the timeline?"
                      className="mt-2 w-full resize-none rounded-xl border border-line bg-base px-4 py-3 text-sm text-ink placeholder:text-ink-mute focus:border-accent focus:outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-accent px-6 py-3.5 text-sm font-semibold text-base transition-transform hover:scale-[1.01] focus-visible:scale-[1.01]"
                  >
                    Send message
                    <ArrowUpRight size={16} />
                  </button>
                  <p className="text-center text-xs text-ink-mute">
                    Demo form — no data is sent or stored.
                  </p>
                </form>
              )}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
  required = true,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <div>
      <label htmlFor={name} className="eyebrow">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required={required}
        placeholder={placeholder}
        className="mt-2 w-full rounded-xl border border-line bg-base px-4 py-3 text-sm text-ink placeholder:text-ink-mute focus:border-accent focus:outline-none"
      />
    </div>
  );
}
