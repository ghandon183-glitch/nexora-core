import { Reveal } from "@/components/reveal";
import { timeline } from "@/lib/data";

export function Timeline() {
  return (
    <section className="border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28">
        <Reveal>
          <p className="eyebrow">Experience</p>
          <h2 className="font-display mt-4 text-3xl font-semibold leading-tight text-ink md:text-4xl">
            A decade building products people use.
          </h2>
        </Reveal>

        <div className="mt-12 space-y-0">
          {timeline.map((entry, i) => (
            <Reveal key={entry.company} delay={i * 0.05}>
              <div className="grid gap-4 border-t border-line py-8 md:grid-cols-[220px_1fr] md:gap-10">
                <div>
                  <p className="font-mono text-xs uppercase tracking-widest text-ink-mute">{entry.period}</p>
                  <p className="mt-2 text-sm font-semibold text-accent">{entry.company}</p>
                </div>
                <div>
                  <h3 className="font-display text-xl font-semibold text-ink md:text-2xl">{entry.role}</h3>
                  <p className="mt-3 max-w-2xl leading-relaxed text-ink-soft">{entry.description}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
