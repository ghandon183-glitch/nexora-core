"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useLoader, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { assetPath } from "@/lib/base-path";

/**
 * Hero centerpiece: a plane displaced by a luminance depth map, lit and
 * parallaxed by the pointer. Recreates the interaction principles of the
 * 21st.dev reference (depth displacement, pointer-reactive, bloom/glow,
 * scanning) using native React Three Fiber + Three.js.
 *
 * Performance: a single low-poly plane, no post-processing pipeline (the
 * "bloom" is faked with additive emissive + a CSS glow layer to avoid a
 * heavy EffectComposer bundle). Falls back to a static image on any
 * WebGL/WebGPU failure or reduced-motion preference.
 *
 * All mutable animation state lives in refs (not useMemo/useState) so the
 * scene mutates plain objects inside useFrame without tripping the React
 * Compiler's immutability rule.
 */

const PLANE_SEG = 96;

function DepthPlane({
  pointer,
  reduceMotion,
}: {
  pointer: React.RefObject<{ x: number; y: number }>;
  reduceMotion: boolean;
}) {
  const group = useRef<THREE.Group>(null!);
  const mesh = useRef<THREE.Mesh>(null!);
  const light = useRef<THREE.PointLight>(null!);
  const { size, camera } = useThree();

  const [colorMap, depthMap] = useLoader(THREE.TextureLoader, [
    assetPath("/images/hero.jpg"),
    assetPath("/images/hero-depth.png"),
  ]);

  const target = useRef({ x: 0, y: 0 });
  const auto = useRef({ t: 0 });
  const camTarget = useRef({ x: 0, y: 0 });

  // Configure textures once they load. Three.js textures are imperative
  // objects mutated outside React's state model — standard R3F practice.
  /* eslint-disable react-hooks/immutability */
  useEffect(() => {
    colorMap.colorSpace = THREE.SRGBColorSpace;
    colorMap.anisotropy = 4;
    depthMap.colorSpace = THREE.NoColorSpace;
  }, [colorMap, depthMap]);
  /* eslint-enable react-hooks/immutability */

  const emissiveColor = useMemo(() => new THREE.Color("#d4ff4f"), []);

  // useFrame mutates three.js objects (group/light/camera) every frame. This
  // imperative mutation is the core of React Three Fiber and is intentional.
  /* eslint-disable react-hooks/immutability */
  useFrame((_, delta) => {
    if (!group.current) return;

    if (reduceMotion) {
      group.current.rotation.y = THREE.MathUtils.lerp(group.current.rotation.y, 0, 0.1);
      group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, 0, 0.1);
      return;
    }

    // Smoothed pointer target (lerp for physical, jitter-free motion).
    if (pointer.current) {
      target.current.x = THREE.MathUtils.lerp(target.current.x, pointer.current.x, 0.06);
      target.current.y = THREE.MathUtils.lerp(target.current.y, pointer.current.y, 0.06);
    }

    const rotY = target.current.x * 0.28;
    const rotX = -target.current.y * 0.18;
    const k = 1 - Math.pow(0.001, delta);
    group.current.rotation.y = THREE.MathUtils.lerp(group.current.rotation.y, rotY, k);
    group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, rotX, k);

    // Subtle continuous drift so the scene never feels frozen.
    auto.current.t += delta * 0.25;
    group.current.position.x = Math.sin(auto.current.t) * 0.04;
    group.current.position.y = Math.cos(auto.current.t * 0.8) * 0.03;

    if (light.current) {
      light.current.position.x = target.current.x * 3.2;
      light.current.position.y = target.current.y * 2.0 + 1.5;
    }

    // Gentle camera parallax toward the pointer (mutable refs only).
    camTarget.current.x = target.current.x * 0.35;
    camTarget.current.y = target.current.y * 0.25;
    camera.position.x += (camTarget.current.x - camera.position.x) * 0.04;
    camera.position.y += (camTarget.current.y - camera.position.y) * 0.04;
    camera.lookAt(0, 0, 0);
  });
  /* eslint-enable react-hooks/immutability */

  // Fit the plane to the viewport while preserving aspect.
  const aspect = colorMap.image.width / colorMap.image.height || 1.6;
  const viewAspect = size.width / size.height;
  let planeW = 4.2;
  let planeH = planeW / aspect;
  if (viewAspect < aspect) {
    planeH = 3.2;
    planeW = planeH * aspect;
  }

  return (
    <group ref={group}>
      <mesh ref={mesh}>
        <planeGeometry args={[planeW, planeH, PLANE_SEG, PLANE_SEG]} />
        <meshStandardMaterial
          map={colorMap}
          displacementMap={depthMap}
          displacementScale={0.55}
          roughness={0.62}
          metalness={0.15}
          emissiveMap={colorMap}
          emissive={emissiveColor}
          emissiveIntensity={0.18}
          toneMapped
        />
      </mesh>
      <pointLight ref={light} position={[0, 1.5, 2]} intensity={6} distance={9} color="#d4ff4f" />
      <ambientLight intensity={0.5} />
      <directionalLight position={[-3, 2, 2]} intensity={0.7} color="#8b5cf6" />
    </group>
  );
}

export function HeroCanvas() {
  const pointer = useRef({ x: 0, y: 0 });
  const wrapRef = useRef<HTMLDivElement>(null);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduceMotion(mq.matches);
    update();
    mq.addEventListener("change", update);
    return () => mq.removeEventListener("change", update);
  }, []);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    // Pointer following scoped to the hero — strongest near the centerpiece.
    const onMove = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      const x = ((e.clientX - r.left) / r.width) * 2 - 1;
      const y = ((e.clientY - r.top) / r.height) * 2 - 1;
      pointer.current.x = x;
      pointer.current.y = y;
    };
    el.addEventListener("pointermove", onMove, { passive: true });
    return () => el.removeEventListener("pointermove", onMove);
  }, []);

  // Coarse pointer (touch) -> no pointer-follow; the scene uses auto drift only.
  const isTouch =
    typeof window !== "undefined" && window.matchMedia("(pointer: coarse)").matches;

  if (failed) {
    return (
      <div ref={wrapRef} className="relative h-full w-full" aria-hidden="true">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={assetPath("/images/hero.jpg")}
          alt=""
          className="h-full w-full object-cover opacity-80"
        />
        <div className="absolute inset-0 vignette" />
        <div className="absolute inset-0 hero-gradient" />
      </div>
    );
  }

  return (
    <div ref={wrapRef} className="relative h-full w-full" aria-hidden="true">
      {/* Static hero image is always rendered as the base layer so the hero
          looks premium even when WebGL is unavailable or still initializing.
          The React Three Fiber canvas renders on top as a progressive
          enhancement (depth displacement + pointer parallax). A raw <img> is
          intentional here: this is a decorative, always-painted backdrop that
          must not be deferred by next/image's lazy loading. */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={assetPath("/images/hero.jpg")}
        alt=""
        className="absolute inset-0 h-full w-full object-cover opacity-90"
      />
      <div className="absolute inset-0 scanlines">
        <div className="scan-beam" />
      </div>
      <Canvas
        className="!absolute !inset-0"
        dpr={[1, 1.8]}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
        camera={{ position: [0, 0, 5], fov: 38 }}
        onCreated={({ gl }) => {
          gl.setClearColor(0x000000, 0);
        }}
        onError={() => setFailed(true)}
      >
        <DepthPlane pointer={pointer} reduceMotion={reduceMotion || isTouch} />
      </Canvas>
      <div className="pointer-events-none absolute inset-0 vignette" />
      <div className="pointer-events-none absolute inset-0 hero-gradient" />
    </div>
  );
}
