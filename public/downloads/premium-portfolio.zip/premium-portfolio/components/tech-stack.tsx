import { Reveal } from "@/components/reveal";
import { techStack } from "@/lib/data";

export function TechStack() {
  return (
    <section className="border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-20">
        <Reveal>
          <p className="eyebrow text-center">Tools I reach for</p>
        </Reveal>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-x-8 gap-y-4">
          {techStack.map((tech, i) => (
            <Reveal key={tech} delay={i * 0.03}>
              <span className="font-display text-lg font-medium text-ink-soft transition-colors hover:text-ink md:text-xl">
                {tech}
              </span>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
