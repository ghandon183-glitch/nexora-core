import { studio, navLinks, socials } from "@/lib/data";
import { ArrowUpRight } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-base">
      <div className="mx-auto max-w-7xl px-5 py-14 md:px-8 md:py-20">
        {/* CTA band */}
        <div className="flex flex-col gap-6 border-b border-line pb-14 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="eyebrow text-accent">Available for new work</p>
            <h2 className="font-display mt-4 text-balance text-3xl font-semibold leading-tight text-ink md:text-5xl">
              Have a project in mind?
            </h2>
          </div>
          <a
            href={`mailto:${studio.email}`}
            className="group inline-flex w-fit items-center gap-2 rounded-full bg-accent px-6 py-3.5 text-sm font-semibold text-base transition-transform hover:scale-[1.03] focus-visible:scale-[1.03]"
          >
            {studio.email}
            <ArrowUpRight
              size={16}
              className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-1"
            />
          </a>
        </div>

        <div className="mt-12 flex flex-col justify-between gap-10 md:flex-row">
          <div className="max-w-sm">
            <a
              href="#top"
              className="font-display text-xl font-semibold uppercase tracking-[0.18em] text-ink"
            >
              {studio.wordmark}
              <span className="text-accent"> {studio.mark}</span>
            </a>
            <p className="mt-4 text-sm leading-relaxed text-ink-mute">
              {studio.intro}
            </p>
          </div>

          <div className="flex flex-col gap-8 sm:flex-row sm:gap-16">
            <nav className="flex flex-col gap-3" aria-label="Footer">
              <p className="eyebrow">Navigate</p>
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  className="link-underline text-sm text-ink-soft"
                >
                  {link.label}
                </a>
              ))}
            </nav>
            <div className="flex flex-col gap-3">
              <p className="eyebrow">Elsewhere</p>
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  className="group inline-flex items-center gap-1.5 text-sm text-ink-soft"
                  {...(s.href.startsWith("http")
                    ? { target: "_blank", rel: "noopener noreferrer" }
                    : {})}
                >
                  {s.label}
                  {s.demo ? (
                    <span className="text-[0.65rem] text-ink-mute">(demo)</span>
                  ) : null}
                  <ArrowUpRight
                    size={12}
                    className="opacity-0 transition-opacity group-hover:opacity-100"
                  />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-line pt-6 text-xs text-ink-mute md:flex-row">
          <p>
            © {new Date().getFullYear()} {studio.name}. Demo template — all
            content is fictional.
          </p>
          <p>Built with Next.js, Tailwind CSS, and React Three Fiber.</p>
        </div>
      </div>
    </footer>
  );
}
