import { profile, navLinks } from "@/lib/data";
import { Globe, Mail, MessageCircle, ArrowUpRight } from "lucide-react";

const socials = [
  { label: "GitHub", icon: Globe, href: "#" },
  { label: "LinkedIn", icon: MessageCircle, href: "#" },
  { label: "Email", icon: Mail, href: `mailto:${profile.email}` },
];

export function Footer() {
  return (
    <footer className="bg-base">
      <div className="mx-auto max-w-7xl px-5 py-14 md:px-8">
        <div className="flex flex-col justify-between gap-10 md:flex-row">
          <div className="max-w-sm">
            <a href="#top" className="font-display text-xl font-semibold tracking-tight text-ink">
              aria<span className="text-accent">.</span>mercer
            </a>
            <p className="mt-4 text-sm leading-relaxed text-ink-mute">
              {profile.role} based in {profile.location}. Available for product engineering,
              design systems, and interactive web work.
            </p>
          </div>

          <div className="flex flex-col gap-8 sm:flex-row sm:gap-16">
            <nav className="flex flex-col gap-3">
              <p className="eyebrow">Navigate</p>
              {navLinks.map((link) => (
                <a key={link.label} href={link.href} className="link-underline text-sm text-ink-soft">
                  {link.label}
                </a>
              ))}
            </nav>
            <div className="flex flex-col gap-3">
              <p className="eyebrow">Elsewhere</p>
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  className="group inline-flex items-center gap-1.5 text-sm text-ink-soft"
                >
                  <s.icon size={15} className="text-ink-mute" />
                  {s.label}
                  <ArrowUpRight size={12} className="opacity-0 transition-opacity group-hover:opacity-100" />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-line pt-6 text-xs text-ink-mute md:flex-row">
          <p>© {new Date().getFullYear()} Aria Mercer. All rights reserved.</p>
          <p>Built with Next.js, Tailwind CSS, and Framer Motion.</p>
        </div>
      </div>
    </footer>
  );
}
