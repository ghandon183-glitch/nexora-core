import { Reveal } from "@/components/reveal";
import { profile } from "@/lib/data";

export function About() {
  return (
    <section id="about" className="border-b border-line">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 md:px-8 md:py-28 lg:grid-cols-[0.8fr_1.2fr]">
        <Reveal>
          <p className="eyebrow">About</p>
          <h2 className="font-display mt-4 text-3xl font-semibold leading-tight text-ink md:text-4xl">
            Engineer by training, designer by instinct.
          </h2>
        </Reveal>

        <div className="space-y-6">
          <Reveal delay={0.05}>
            <p className="text-lg leading-relaxed text-ink-soft">
              {profile.summary}
            </p>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="leading-relaxed text-ink-soft">
              I came up through product teams rather than agencies, which means I think in shipping
              cadences: what lands this week, what de-risks next quarter, and what keeps the codebase
              kind to the people who inherit it. My favourite work sits exactly where performance,
              motion, and accessibility overlap — the parts of a product that feel inevitable once
              they&apos;re done.
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="flex flex-wrap gap-2 pt-2">
              {["Remote-friendly", "Async-first", "Open to advisory", "Mentor"].map((tag) => (
                <span
                  key={tag}
                  className="rounded-full border border-line bg-surface px-3.5 py-1.5 text-xs font-medium text-ink-soft"
                >
                  {tag}
                </span>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
