"use client";

import Image from "next/image";
import { Reveal } from "@/components/reveal";
import { studio } from "@/lib/data";
import { assetPath } from "@/lib/base-path";

const capabilities = [
  "Brand Identity",
  "Art Direction",
  "Digital Experiences",
  "Creative Development",
  "Motion Design",
  "Interactive Web",
];

export function About() {
  return (
    <section id="studio" className="relative border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-32">
        <div className="grid gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:gap-20">
          <div className="space-y-7">
            <Reveal>
              <p className="eyebrow">The studio</p>
              <h2 className="font-display mt-4 text-balance text-3xl font-semibold leading-[1.1] text-ink md:text-5xl">
                An independent studio for ambitious, design-led teams.
              </h2>
            </Reveal>

            <Reveal delay={0.06}>
              <p className="text-lg leading-relaxed text-ink-soft">{studio.description}</p>
            </Reveal>

            <Reveal delay={0.12}>
              <p className="leading-relaxed text-ink-soft">
                We take on a small number of engagements at a time, which means every project gets
                the full attention of the people doing the work. No hand-offs to a separate
                production team — the studio you meet is the studio that ships.
              </p>
            </Reveal>

            <Reveal delay={0.18}>
              <ul className="flex flex-wrap gap-2 pt-2">
                {capabilities.map((c) => (
                  <li
                    key={c}
                    className="rounded-full border border-line bg-surface px-3.5 py-1.5 text-xs font-medium text-ink-soft"
                  >
                    {c}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          <Reveal delay={0.1} className="relative">
            <div className="group relative overflow-hidden rounded-2xl border border-line">
              <div className="relative aspect-[4/5] w-full overflow-hidden">
                <Image
                  src={assetPath("/images/about.jpg")}
                  alt="Abstract studio visual — layered light and motion"
                  fill
                  sizes="(min-width: 1024px) 40vw, 100vw"
                  className="object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-[1.04]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-base/70 via-transparent to-transparent" />
              </div>
              <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between gap-4">
                <div>
                  <p className="eyebrow text-accent">Studio</p>
                  <p className="mt-1 font-display text-lg font-semibold text-ink">
                    {studio.location}
                  </p>
                </div>
                <span className="h-2 w-2 animate-pulse rounded-full bg-accent" />
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
