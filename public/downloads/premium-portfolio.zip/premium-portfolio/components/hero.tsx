"use client";

import { motion } from "framer-motion";
import { ArrowDown } from "lucide-react";
import { profile, stats } from "@/lib/data";

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08 } },
};
const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] as const } },
};

export function Hero() {
  return (
    <section id="top" className="noise relative overflow-hidden border-b border-line">
      <div className="mx-auto max-w-7xl px-5 pb-20 pt-16 md:px-8 md:pb-28 md:pt-24">
        <motion.div variants={container} initial="hidden" animate="show" className="grid gap-10 lg:grid-cols-[1.4fr_1fr]">
          <div>
            <motion.p variants={item} className="eyebrow flex items-center gap-2">
              <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-accent" />
              {profile.availability}
            </motion.p>

            <motion.h1
              variants={item}
              className="font-display mt-6 text-5xl font-semibold leading-[1.04] tracking-tight text-ink sm:text-6xl md:text-7xl lg:text-[5.25rem]"
            >
              {profile.name}
              <span className="text-accent">.</span>
              <br />
              <span className="text-ink-soft">{profile.role}</span>
            </motion.h1>

            <motion.p variants={item} className="mt-7 max-w-xl text-base leading-relaxed text-ink-soft md:text-lg">
              {profile.summary}
            </motion.p>

            <motion.div variants={item} className="mt-9 flex flex-wrap items-center gap-3">
              <a
                href="#work"
                className="inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-base transition-transform hover:scale-[1.02]"
              >
                View selected work
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 rounded-full border border-line px-6 py-3 text-sm font-medium text-ink transition-colors hover:border-ink-soft"
              >
                Start a project
              </a>
            </motion.div>
          </div>

          <motion.div variants={item} className="flex flex-col justify-end">
            <div className="rounded-2xl border border-line bg-surface p-6">
              <p className="eyebrow">Currently</p>
              <p className="mt-3 text-lg font-medium text-ink">
                Building the web platform at Northwind Labs and taking on a small number of independent engagements.
              </p>
              <div className="mt-5 flex items-center gap-3 border-t border-line pt-5 text-sm text-ink-soft">
                <span className="h-2 w-2 rounded-full bg-accent" />
                {profile.location}
              </div>
            </div>
          </motion.div>
        </motion.div>

        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="mt-16 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line md:grid-cols-4"
        >
          {stats.map((s) => (
            <motion.div key={s.label} variants={item} className="bg-surface p-6">
              <p className="font-display text-3xl font-semibold text-ink md:text-4xl">{s.value}</p>
              <p className="mt-1.5 text-sm text-ink-mute">{s.label}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>

      <a
        href="#about"
        aria-label="Scroll to about"
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 animate-bounce text-ink-mute md:block"
      >
        <ArrowDown size={18} />
      </a>
    </section>
  );
}
