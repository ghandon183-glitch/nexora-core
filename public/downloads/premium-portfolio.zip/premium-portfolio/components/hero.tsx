"use client";

import dynamic from "next/dynamic";
import { motion } from "framer-motion";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { studio } from "@/lib/data";

// The WebGL hero is client-only and lazily loaded so it never blocks first
// paint or the static export's initial HTML.
const HeroCanvas = dynamic(
  () => import("@/components/hero-canvas").then((m) => m.HeroCanvas),
  { ssr: false }
);

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.09, delayChildren: 0.15 } },
};
const item = {
  hidden: { opacity: 0, y: 22 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export function Hero() {
  return (
    <section id="top" className="relative h-[100svh] min-h-[640px] w-full overflow-hidden">
      {/* Interactive depth centerpiece */}
      <div className="absolute inset-0">
        <HeroCanvas />
      </div>

      {/* Cinematic text overlay */}
      <div className="relative z-10 mx-auto flex h-full max-w-7xl flex-col justify-end px-5 pb-16 md:px-8 md:pb-24">
        <motion.div variants={container} initial="hidden" animate="show" className="max-w-4xl">
          <motion.p variants={item} className="eyebrow flex items-center gap-2 text-accent">
            <span className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-accent" />
            {studio.availability}
          </motion.p>

          <motion.h1
            variants={item}
            className="font-display mt-5 text-balance text-[2.7rem] font-semibold leading-[1.02] tracking-tight text-ink sm:text-6xl md:text-7xl lg:text-[5.5rem]"
          >
            {studio.tagline}
          </motion.h1>

          <motion.p variants={item} className="mt-7 max-w-xl text-base leading-relaxed text-ink-soft md:text-lg">
            {studio.intro}
          </motion.p>

          <motion.div variants={item} className="mt-9 flex flex-wrap items-center gap-3">
            <a
              href="#work"
              className="group inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-base transition-transform hover:scale-[1.03] focus-visible:scale-[1.03]"
            >
              Explore selected work
              <ArrowDown
                size={15}
                className="transition-transform group-hover:translate-y-0.5"
              />
            </a>
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 rounded-full border border-ink/20 bg-base/30 px-6 py-3 text-sm font-medium text-ink backdrop-blur-sm transition-colors hover:border-ink/50 hover:bg-base/50"
            >
              Start a project
              <ArrowUpRight
                size={15}
                className="text-accent transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
              />
            </a>
          </motion.div>
        </motion.div>
      </div>

      <a
        href="#studio"
        aria-label="Scroll to studio section"
        className="absolute bottom-6 left-1/2 z-10 hidden -translate-x-1/2 text-ink-mute transition-colors hover:text-ink md:block"
      >
        <ArrowDown size={18} className="animate-bounce" />
      </a>
    </section>
  );
}

