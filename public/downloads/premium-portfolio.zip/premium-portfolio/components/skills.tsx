import { Reveal } from "@/components/reveal";
import { skills } from "@/lib/data";

export function Skills() {
  return (
    <section className="grid-texture border-b border-line">
      <div className="mx-auto max-w-7xl px-5 py-20 md:px-8 md:py-28">
        <Reveal>
          <p className="eyebrow">Capabilities</p>
          <h2 className="font-display mt-4 max-w-2xl text-3xl font-semibold leading-tight text-ink md:text-4xl">
            A focused toolkit, sharpened across a decade of shipping.
          </h2>
        </Reveal>

        <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-line bg-line md:grid-cols-3">
          {skills.map((group, gi) => (
            <Reveal key={group.group} delay={gi * 0.08}>
              <div className="h-full bg-surface p-7">
                <p className="font-mono text-xs uppercase tracking-widest text-accent">{group.group}</p>
                <ul className="mt-5 space-y-3">
                  {group.items.map((item) => (
                    <li key={item} className="flex items-center gap-3 text-ink">
                      <span className="h-1 w-1 rounded-full bg-ink-mute" />
                      <span className="text-sm font-medium">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
