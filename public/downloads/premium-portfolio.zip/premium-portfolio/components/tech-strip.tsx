import { techStack } from "@/lib/data";

export function TechStrip() {
  // Duplicated once for a seamless -50% marquee loop.
  const items = [...techStack, ...techStack];
  return (
    <section
      className="overflow-hidden border-b border-line py-7"
      aria-label="Tools the studio works with"
    >
      <div className="marquee gap-12">
        {items.map((tech, i) => (
          <span
            key={`${tech}-${i}`}
            className="font-display whitespace-nowrap text-xl font-medium text-ink-soft/70 md:text-2xl"
          >
            {tech}
            <span className="ml-12 text-ink-mute/40">/</span>
          </span>
        ))}
      </div>
    </section>
  );
}
