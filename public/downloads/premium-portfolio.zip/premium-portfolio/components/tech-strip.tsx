import { techStack } from "@/lib/data";

export function TechStrip() {
  // The list is rendered twice so the -50% marquee loops seamlessly. The second
  // copy is purely visual, so it is hidden from assistive technology instead of
  // being announced twice.
  return (
    <section
      className="overflow-hidden border-b border-line py-7"
      aria-label="Tools the studio works with"
    >
      <div className="marquee gap-12">
        {techStack.map((tech, i) => (
          <span
            key={`${tech}-${i}`}
            className="font-display whitespace-nowrap text-xl font-medium text-ink-soft/70 md:text-2xl"
          >
            {tech}
            <span className="ml-12 text-ink-mute/40">/</span>
          </span>
        ))}
        <span className="contents" aria-hidden="true">
          {techStack.map((tech, i) => (
            <span
              key={`dup-${tech}-${i}`}
              className="font-display whitespace-nowrap text-xl font-medium text-ink-soft/70 md:text-2xl"
            >
              {tech}
              <span className="ml-12 text-ink-mute/40">/</span>
            </span>
          ))}
        </span>
      </div>
    </section>
  );
}
