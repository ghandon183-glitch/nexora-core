export const studio = {
  name: "STUDIO NORTH",
  wordmark: "studio",
  mark: "north",
  tagline: "Crafting digital experiences that move people.",
  intro:
    "Independent creative studio creating bold identities, immersive digital products and experiences for ambitious brands.",
  description:
    "We are a small independent studio working at the intersection of brand, product, and motion. We partner with founders and teams who care about the craft — building identities, interfaces, and interactive moments that feel considered down to the last detail.",
  location: "Lisbon, PT — working worldwide",
  availability: "Booking projects for late 2026",
  email: "hello@studionorth.example",
};

export const projects = [
  {
    index: "01",
    title: "AETHER",
    category: "Brand Identity / Digital Experience",
    year: "2026",
    description:
      "A complete identity system and launch experience for an ambient computing startup — from the wordmark and motion language to a scroll-driven product narrative.",
    image: "/images/project-1.jpg",
    tags: ["Identity", "Motion", "Web"],
  },
  {
    index: "02",
    title: "MONO",
    category: "Editorial / Art Direction",
    year: "2025",
    description:
      "An editorial platform for an independent publication on craft and technology — a restrained typographic system built around long-form reading and a quiet, confident rhythm.",
    image: "/images/project-2.jpg",
    tags: ["Editorial", "Type", "Direction"],
  },
  {
    index: "03",
    title: "NORD",
    category: "Digital Product / Web Design",
    year: "2025",
    description:
      "A product marketing site and component system for a climate-data platform — clear, modular, and fast, with a configurable interface that scales across regions.",
    image: "/images/project-3.jpg",
    tags: ["Product", "System", "Web"],
  },
  {
    index: "04",
    title: "VELA",
    category: "Commerce / Brand Experience",
    year: "2024",
    description:
      "A boutique commerce experience for a design-led fragrance house — an immersive storefront with a guided product journey and a tactile, gallery-grade aesthetic.",
    image: "/images/project-4.jpg",
    tags: ["Commerce", "Brand", "Motion"],
  },
];

export const services = [
  {
    title: "Brand Identity",
    description:
      "Identity systems built to last — naming, wordmarks, type, and the motion language that brings them to life across every surface.",
    points: ["Naming & voice", "Wordmark & type", "Motion language"],
  },
  {
    title: "Art Direction",
    description:
      "A coherent visual direction across product, editorial, and campaign — the through-line that makes every touchpoint feel like one studio made it.",
    points: ["Editorial systems", "Campaign direction", "Asset frameworks"],
  },
  {
    title: "Digital Experiences",
    description:
      "Immersive, performance-minded sites and product surfaces — scroll narratives, interactive scenes, and interfaces that feel alive without getting in the way.",
    points: ["Launch sites", "Product surfaces", "Interactive scenes"],
  },
  {
    title: "Creative Development",
    description:
      "The engineering that makes the design real — design systems, motion engineering, and the front-end craft that keeps ambitious work fast and maintainable.",
    points: ["Design systems", "Motion engineering", "Front-end craft"],
  },
  {
    title: "Motion Design",
    description:
      "Motion as a design material — interface motion, scroll narratives, and identity animation that supports the story rather than performing for it.",
    points: ["Interface motion", "Scroll narratives", "Identity animation"],
  },
  {
    title: "Interactive Web",
    description:
      "WebGL and 3D moments used with restraint — depth, light, and interactivity that elevate a moment instead of becoming the whole experience.",
    points: ["WebGL scenes", "Depth & light", "Creative prototyping"],
  },
];

export const techStack = [
  "TypeScript",
  "React",
  "Next.js",
  "Three.js",
  "Tailwind CSS",
  "Framer Motion",
  "GSAP",
  "Figma",
];

export const navLinks = [
  { label: "Studio", href: "#studio" },
  { label: "Work", href: "#work" },
  { label: "Capabilities", href: "#capabilities" },
  { label: "Contact", href: "#contact" },
];

// Clearly-marked demo social destinations. These are intentional placeholders
// (not real profiles, not the marketplace). Customers replace `href` with
// their own. `demo` flags them so the UI can render a subtle "(demo)" hint.
export const socials = [
  { label: "Instagram", href: "https://example.com/studionorth", demo: true },
  { label: "Dribbble", href: "https://example.com/studionorth", demo: true },
  { label: "GitHub", href: "https://example.com/studionorth", demo: true },
  { label: "Email", href: "mailto:hello@studionorth.example", demo: false },
];
