export const profile = {
  name: "Aria Mercer",
  role: "Senior Product Engineer",
  location: "Lisbon, PT — working worldwide",
  availability: "Available for Q3 2026",
  email: "hello@ariamercer.dev",
  summary:
    "I build the interfaces that ambitious teams ship. Ten years turning complex product problems into fast, accessible, and genuinely pleasant software — from early-stage design systems to interactive 3D experiences used by millions.",
};

export const stats = [
  { value: "10+", label: "Years shipping" },
  { value: "60+", label: "Products launched" },
  { value: "4M", label: "Monthly users reached" },
  { value: "12", label: "Design systems built" },
];

export const skills = [
  {
    group: "Engineering",
    items: ["React", "Next.js", "TypeScript", "Node.js", "Edge runtimes", "WebGL"],
  },
  {
    group: "Craft",
    items: ["Design systems", "Motion", "Accessibility", "Performance", "Prototyping"],
  },
  {
    group: "Tooling",
    items: ["Tailwind", "Framer Motion", "GSAP", "Three.js", "Figma", "Storybook"],
  },
];

export const timeline = [
  {
    period: "2023 — Present",
    role: "Principal Product Engineer",
    company: "Northwind Labs",
    description:
      "Lead the web platform team. Rebuilt the core app shell, cutting first-contentful paint by 48% and standardizing a design system across six product surfaces.",
  },
  {
    period: "2020 — 2023",
    role: "Senior Frontend Engineer",
    company: "Vela Studio",
    description:
      "Shipped interactive marketing experiences and a component library adopted by forty engineers. Owned the migration from a legacy SPA to the App Router.",
  },
  {
    period: "2018 — 2020",
    role: "Product Engineer",
    company: "Kestrel",
    description:
      "Built the onboarding flow that lifted activation by 31%. Established the testing culture and the visual regression pipeline.",
  },
  {
    period: "2015 — 2018",
    role: "Frontend Developer",
    company: "Foundry & Co.",
    description:
      "Delivered client work across fintech and media. First exposure to design-systems thinking and motion as a product tool.",
  },
];

export const projects = [
  {
    title: "Helios Analytics",
    category: "Product · SaaS",
    year: "2025",
    description:
      "A real-time analytics dashboard rendering 200k live events with a sub-100ms interaction budget. Custom virtualized tables and a themeable charting layer.",
    tags: ["Next.js", "WebSockets", "Canvas"],
  },
  {
    title: "Atlas Design System",
    category: "Design Systems",
    year: "2024",
    description:
      "A token-driven system powering six products. 140+ components, automated accessibility checks, and zero-runtime theming across light and dark.",
    tags: ["React", "Tokens", "A11y"],
  },
  {
    title: "Driftwood",
    category: "Interactive · WebGL",
    year: "2024",
    description:
      "An immersive product launch site with GPU-accelerated transitions and a scroll-driven narrative. 96+ Lighthouse, no layout shift on any viewport.",
    tags: ["WebGL", "GSAP", "Edge"],
  },
  {
    title: "Quill Editor",
    category: "Product · Tooling",
    year: "2023",
    description:
      "A collaborative document editor with CRDT-based sync and a plugin architecture that lets teams extend the toolbar without forking the core.",
    tags: ["CRDT", "TypeScript", "Extensions"],
  },
];

export const services = [
  {
    title: "Product engineering",
    description:
      "End-to-end feature builds — from scoping and architecture to the shipping polish. I integrate into your team and ship.",
    points: ["App Router migrations", "Performance budgets", "Accessibility audits"],
  },
  {
    title: "Design systems",
    description:
      "Token-first systems that scale across teams without slowing anyone down. Documented, tested, and adoption-ready.",
    points: ["Component libraries", "Theming architecture", "Documentation sites"],
  },
  {
    title: "Interactive experiences",
    description:
      "Scroll-driven narratives, WebGL scenes, and motion that serves the story rather than the demo reel.",
    points: ["Launch sites", "Motion direction", "Prototyping"],
  },
];

export const testimonials = [
  {
    quote:
      "Aria is the rare engineer who cares about the pixel and the architecture. She rebuilt our shell and our metrics moved the same week.",
    name: "Sofia Reyes",
    title: "VP Engineering, Northwind Labs",
  },
  {
    quote:
      "The design system she delivered became the backbone of our whole org. Six teams ship faster because of work she did in a quarter.",
    name: "Daniel Okonkwo",
    title: "Head of Design, Vela Studio",
  },
  {
    quote:
      "Our launch site converted 2.3× the previous benchmark. Aria treats performance and craft as the same problem, and it shows.",
    name: "Mei Tanaka",
    title: "CMO, Driftwood",
  },
];

export const techStack = [
  "TypeScript",
  "React",
  "Next.js",
  "Node.js",
  "Tailwind CSS",
  "Framer Motion",
  "GSAP",
  "Three.js",
  "Vitest",
  "Playwright",
  "Figma",
  "Storybook",
];

export const navLinks = [
  { label: "About", href: "#about" },
  { label: "Work", href: "#work" },
  { label: "Services", href: "#services" },
  { label: "Contact", href: "#contact" },
];
