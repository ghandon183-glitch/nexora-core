/**
 * Optional deployment configuration.
 *
 * NEXT_PUBLIC_BASE_PATH — set when the export is served from a sub-path,
 * e.g. "/demo/premium-portfolio". Next.js applies it to pages and /_next
 * assets; `assetPath()` applies it to files in `public/` and to textures
 * loaded by Three.js.
 *
 * NEXT_PUBLIC_SITE_URL — the public origin only, e.g.
 * "https://studio.example.com" (no path). Used for canonical URLs, Open
 * Graph URLs, sitemap.xml and robots.txt. Leave it empty to skip those.
 */
export const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || "";

export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL || "").replace(/\/+$/, "");

export function assetPath(path: string): string {
  return `${BASE_PATH}${path}`;
}

export function sitePath(path: string): string {
  return `${SITE_URL}${BASE_PATH}${path}`;
}
