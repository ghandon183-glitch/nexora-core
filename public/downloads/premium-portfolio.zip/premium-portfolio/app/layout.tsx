import type { Metadata } from "next";
import "@fontsource/space-grotesk/500.css";
import "@fontsource/space-grotesk/600.css";
import "@fontsource/space-grotesk/700.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "STUDIO NORTH — Independent Creative Studio",
  description:
    "Independent creative studio crafting bold identities, immersive digital products and experiences for ambitious brands.",
  keywords: [
    "creative studio",
    "portfolio",
    "brand identity",
    "art direction",
    "digital experiences",
    "motion design",
    "Next.js",
  ],
  openGraph: {
    title: "STUDIO NORTH — Independent Creative Studio",
    description:
      "Crafting digital experiences that move people. Brand identity, art direction, and immersive digital products.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
