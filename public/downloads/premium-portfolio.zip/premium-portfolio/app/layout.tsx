import type { Metadata, Viewport } from "next";
import "@fontsource/space-grotesk/500.css";
import "@fontsource/space-grotesk/600.css";
import "@fontsource/space-grotesk/700.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import { SITE_URL, sitePath } from "@/lib/base-path";
import "./globals.css";

const title = "STUDIO NORTH — Independent Creative Studio";
const description =
  "Independent creative studio crafting bold identities, immersive digital products and experiences for ambitious brands.";
const socialDescription =
  "Crafting digital experiences that move people. Brand identity, art direction, and immersive digital products.";

// Only emit absolute social images when the public origin is configured,
// so the build never guesses a host (and never invents a canonical domain).
const ogImage = SITE_URL
  ? {
      url: sitePath("/images/hero.jpg"),
      width: 2560,
      height: 1440,
      alt: "STUDIO NORTH — abstract depth-displaced hero artwork",
    }
  : undefined;

export const metadata: Metadata = {
  metadataBase: SITE_URL ? new URL(SITE_URL) : undefined,
  title,
  description,
  applicationName: "STUDIO NORTH",
  keywords: [
    "creative studio",
    "portfolio",
    "brand identity",
    "art direction",
    "digital experiences",
    "motion design",
    "Next.js",
  ],
  alternates: SITE_URL ? { canonical: sitePath("/") } : undefined,
  openGraph: {
    type: "website",
    siteName: "STUDIO NORTH",
    title,
    description: socialDescription,
    url: SITE_URL ? sitePath("/") : undefined,
    images: ogImage ? [ogImage] : undefined,
  },
  twitter: {
    card: "summary_large_image",
    title,
    description: socialDescription,
    images: ogImage ? [ogImage.url] : undefined,
  },
};

export const viewport: Viewport = {
  themeColor: "#08080a",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
