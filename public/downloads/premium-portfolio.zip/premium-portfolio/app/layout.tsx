import type { Metadata } from "next";
import "@fontsource/space-grotesk/500.css";
import "@fontsource/space-grotesk/600.css";
import "@fontsource/space-grotesk/700.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "Aria Mercer — Senior Product Engineer & Creative Developer",
  description:
    "Portfolio of Aria Mercer, a senior product engineer crafting performant interfaces, design systems, and interactive web experiences for ambitious teams.",
  keywords: [
    "creative developer",
    "portfolio",
    "product engineer",
    "design systems",
    "frontend",
    "Next.js",
  ],
  openGraph: {
    title: "Aria Mercer — Senior Product Engineer & Creative Developer",
    description:
      "Crafting performant interfaces, design systems, and interactive web experiences.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
