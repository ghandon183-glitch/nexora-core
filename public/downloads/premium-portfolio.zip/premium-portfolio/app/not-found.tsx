import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Page not found",
  robots: { index: false, follow: false },
};

export default function NotFound() {
  return (
    <main
      id="main"
      className="flex min-h-[100svh] flex-col items-center justify-center px-5 text-center"
    >
      <p className="eyebrow text-accent">404</p>
      <h1 className="font-display mt-4 text-balance text-3xl font-semibold leading-tight text-ink md:text-5xl">
        This page isn&apos;t part of the portfolio.
      </h1>
      <p className="mt-4 max-w-md text-sm leading-relaxed text-ink-soft">
        The studio is a single-page site — work, capabilities and contact all
        live on the home page.
      </p>
      <Link
        href="/"
        className="mt-8 inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-semibold text-base transition-transform hover:scale-[1.03] focus-visible:scale-[1.03]"
      >
        Back to the studio
      </Link>
    </main>
  );
}
