import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  // Trailing slashes keep client-side navigation working on plain static
  // hosts: Next fetches `<route>/index.txt` for the RSC payload, which is the
  // file the static export actually writes. Without it a navigation to `/`
  // requests `/<base>.txt` and 404s in the console.
  trailingSlash: true,
  basePath: process.env.NEXT_PUBLIC_BASE_PATH || undefined,
  images: {
    unoptimized: true,
  },
};

export default nextConfig;
