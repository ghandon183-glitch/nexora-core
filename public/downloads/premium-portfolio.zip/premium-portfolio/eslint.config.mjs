import type { Config } from "eslint";
import next from "eslint-config-next";

const config: Config = {
  ...next(),
  rules: {
    ...((next().rules ?? {}) as Record<string, string>),
  },
};

export default config;
