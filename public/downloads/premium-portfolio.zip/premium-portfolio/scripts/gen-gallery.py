#!/usr/bin/env python3
"""Generate marketplace gallery images + thumbnail for the redesigned
premium-portfolio template. Each gallery image represents a section of the
new design (hero, work, capabilities, contact) at 2560x1440 with the dark
premium aesthetic. The thumbnail is a hero-style preview."""
import os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = "/tmp/portfolio-src/premium-portfolio/public/images"
OUT_GALLERY = "/workspace/project/nexora-core/public/templates/gallery/premium-portfolio"
OUT_THUMB = "/workspace/project/nexora-core/public/templates/premium-portfolio.jpg"

W, H = 2560, 1440
BASE = (8, 8, 10)
SURFACE = (16, 16, 19)
INK = (246, 246, 247)
INK_SOFT = (161, 161, 170)
INK_MUTE = (107, 107, 117)
ACCENT = (212, 255, 79)
LINE = (35, 35, 41)

FONT_DIR = "/usr/share/fonts"
FONT_PATHS = []


def find_font(bold=True):
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    return None


FONT_BOLD = find_font(True)
FONT_REG = find_font(False) or FONT_BOLD


def font(size, bold=True):
    p = FONT_BOLD if bold else FONT_REG
    if not p:
        return ImageFont.load_default()
    return ImageFont.truetype(p, size)


def text_w(draw, txt, f):
    bbox = draw.textbbox((0, 0), txt, font=f)
    return bbox[2] - bbox[0]


def vignette(img):
    grad = Image.new("L", (W, H), 0)
    d = ImageDraw.Draw(grad)
    for r in range(H // 2, 0, -1):
        alpha = int(255 * (1 - r / (H / 1.4)) ** 2)
        alpha = max(0, min(255, alpha))
        d.ellipse([-W * 0.3, -H * 0.2, W * 1.3, H * 1.2], fill=alpha)
    # simpler radial-ish: just darken edges
    overlay = Image.new("RGB", (W, H), BASE)
    mask = Image.new("L", (W, H), 0)
    md = ImageDraw.Draw(mask)
    md.ellipse([W * 0.1, H * 0.05, W * 0.9, H * 0.95], fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(300))
    return Image.composite(img, overlay, mask)


def gradient_top(img):
    """Darken the bottom for text legibility."""
    base = Image.new("RGB", (W, H), (8, 8, 10))
    mask = Image.new("L", (W, H), 0)
    md = ImageDraw.Draw(mask)
    for y in range(H):
        t = max(0, (y - H * 0.45) / (H * 0.55))
        md.line([(0, y), (W, y)], fill=int(220 * t))
    return Image.composite(img, base, mask)


def load(name, w, h):
    im = Image.open(os.path.join(ROOT, name)).convert("RGB")
    im = ImageOps_cover(im, (w, h))
    return im


def ImageOps_cover(im, size):
    w, h = size
    iw, ih = im.size
    scale = max(w / iw, h / ih)
    im = im.resize((int(iw * scale), int(ih * scale)), Image.LANCZOS)
    iw, ih = im.size
    left = (iw - w) // 2
    top = (ih - h) // 2
    return im.crop((left, top, left + w, top + h))


def base_canvas():
    return Image.new("RGB", (W, H), BASE)


def draw_browser_chrome(img, title="STUDIO NORTH — Live Preview"):
    d = ImageDraw.Draw(img)
    # top bar
    d.rectangle([0, 0, W, 90], fill=(14, 14, 16))
    d.line([(0, 90), (W, 90)], fill=LINE, width=2)
    # dots
    for i, c in enumerate([(255, 95, 86), (255, 189, 46), (39, 201, 63)]):
        d.ellipse([40 + i * 34, 34, 60 + i * 34, 54], fill=c)
    f = font(26, False)
    tw = text_w(d, title, f)
    d.text(((W - tw) // 2, 30), title, font=f, fill=INK_MUTE)
    return img


def label(d, txt, x, y, color=ACCENT, size=26, bold=False):
    f = font(size, bold)
    d.text((x, y), txt, font=f, fill=color)
    return f


# ---- Gallery 1: Hero ----
def make_hero():
    img = base_canvas()
    hero = load("hero.jpg", W, H)
    img.paste(hero, (0, 0))
    img = gradient_top(img)
    d = ImageDraw.Draw(img)
    # eyebrow
    label(d, "● Booking projects for late 2026", 120, H - 470, ACCENT, 34)
    # headline
    f = font(150, True)
    d.text((120, H - 410), "Crafting digital", font=f, fill=INK)
    d.text((120, H - 250), "experiences that", font=f, fill=INK)
    d.text((120, H - 90), "move people.", font=f, fill=INK)
    # wordmark top
    wf = font(40, True)
    d.text((120, 60), "STUDIO  NORTH", font=wf, fill=INK)
    return img


# ---- Gallery 2: Work ----
def make_work():
    img = base_canvas()
    d = ImageDraw.Draw(img)
    # header
    label(d, "SELECTED WORK", 120, 120, INK_MUTE, 30, True)
    f = font(90, True)
    d.text((120, 165), "A selection of recent studio work.", font=f, fill=INK)
    # two project cards
    cards = [("project-1.jpg", "01", "AETHER", "Brand Identity / Digital Experience"),
             ("project-2.jpg", "02", "MONO", "Editorial / Art Direction")]
    cw, ch = 1120, 660
    positions = [(120, 460), (1320, 460)]
    for (name, idx, title, cat), (x, y) in zip(cards, positions):
        card = Image.new("RGB", (cw, ch), SURFACE)
        cd = ImageDraw.Draw(card)
        cd.rectangle([0, 0, cw, ch], fill=SURFACE)
        cd.rectangle([0, 0, cw, ch], outline=LINE, width=2)
        # image area
        ih = 410
        pim = load(name, cw - 4, ih)
        card.paste(pim, (2, 2))
        cd.line([(0, ih + 2), (cw, ih + 2)], fill=LINE, width=2)
        cd.text((40, ih + 30), cat, font=font(28, False), fill=INK_MUTE)
        cd.text((40, ih + 75), title, font=font(64, True), fill=INK)
        img.paste(card, (x, y))
    # scanline subtle
    return img


# ---- Gallery 3: Capabilities ----
def make_capabilities():
    img = base_canvas()
    d = ImageDraw.Draw(img)
    label(d, "CAPABILITIES", 120, 120, INK_MUTE, 30, True)
    f = font(90, True)
    d.text((120, 165), "What the studio can do for your team.", font=f, fill=INK)
    services = [
        ("01", "Brand Identity", "Identity systems built to last — naming, wordmarks, type, and motion."),
        ("02", "Art Direction", "A coherent visual direction across product, editorial, and campaign."),
        ("03", "Digital Experiences", "Immersive, performance-minded sites and product surfaces."),
        ("04", "Creative Development", "Design systems, motion engineering, and front-end craft."),
    ]
    y = 430
    for idx, title, desc in services:
        d.line([(120, y), (W - 120, y)], fill=LINE, width=2)
        label(d, idx, 120, y + 40, INK_MUTE, 40, True)
        label(d, "●", 230, y + 48, ACCENT, 36, True)
        d.text((320, y + 35), title, font=font(64, True), fill=INK)
        f2 = font(30, False)
        # wrap desc
        max_w = W - 320 - 900
        words = desc.split()
        line = ""
        ly = y + 120
        for w_ in words:
            test = (line + " " + w_).strip()
            if text_w(d, test, f2) > 1300:
                d.text((320, ly), line, font=f2, fill=INK_SOFT)
                ly += 44
                line = w_
            else:
                line = test
        if line:
            d.text((320, ly), line, font=f2, fill=INK_SOFT)
        y += 210
    d.line([(120, y), (W - 120, y)], fill=LINE, width=2)
    return img


# ---- Gallery 4: Contact ----
def make_contact():
    img = base_canvas()
    d = ImageDraw.Draw(img)
    label(d, "CONTACT", 120, 120, INK_MUTE, 30, True)
    f = font(110, True)
    d.text((120, 170), "Let's work together.", font=f, fill=INK)
    f2 = font(34, False)
    d.text((120, 360), "We take on a small number of engagements each quarter.", font=f2, fill=INK_SOFT)
    d.text((120, 410), "Tell us what you're building and we'll reply within two business days.", font=f2, fill=INK_SOFT)
    label(d, "hello@studionorth.example →", 120, 500, INK, 52, True)
    label(d, "● Booking projects for late 2026", 120, 600, INK_MUTE, 30, False)
    # form card on right
    fw, fh = 900, 760
    fx, fy = W - fw - 120, 360
    d.rectangle([fx, fy, fx + fw, fy + fh], fill=SURFACE, outline=LINE, width=2)
    fields = [("NAME", "Jordan Lee"), ("EMAIL", "you@company.com"),
              ("COMPANY", "Acme Inc. (optional)"), ("PROJECT", "What are you building?")]
    fy2 = fy + 50
    for lab, ph in fields:
        label(d, lab, fx + 40, fy2, INK_MUTE, 26, True)
        d.rectangle([fx + 40, fy2 + 40, fx + fw - 40, fy2 + 120], fill=BASE, outline=LINE, width=2)
        d.text((fx + 60, fy2 + 62), ph, font=font(30, False), fill=INK_MUTE)
        fy2 += 170
    # button
    d.rounded_rectangle([fx + 40, fy2 + 10, fx + fw - 40, fy2 + 90], radius=45, fill=ACCENT)
    label(d, "Send message  ↗", fx + (fw - text_w(d, "Send message  ↗", font(34, True))) // 2, fy2 + 30, BASE, 34, True)
    return img


def main():
    os.makedirs(OUT_GALLERY, exist_ok=True)
    imgs = [
        (make_hero(), "1.jpg"),
        (make_work(), "2.jpg"),
        (make_capabilities(), "3.jpg"),
        (make_contact(), "4.jpg"),
    ]
    for im, name in imgs:
        # add browser chrome to all gallery shots for a polished preview
        # (skip chrome on hero for full-bleed impact)
        if name != "1.jpg":
            tmp = base_canvas()
            tmp.paste(im, (0, 0))
            # no chrome — keep full-bleed; gallery images are section previews
        im.save(os.path.join(OUT_GALLERY, name), "JPEG", quality=88)
        print("saved gallery", name, im.size)
    # thumbnail = hero preview
    thumb = make_hero()
    thumb.save(OUT_THUMB, "JPEG", quality=90)
    print("saved thumbnail", OUT_THUMB, thumb.size)


if __name__ == "__main__":
    main()
