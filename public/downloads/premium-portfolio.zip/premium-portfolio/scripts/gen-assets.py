#!/usr/bin/env python3
"""Generate premium abstract demo assets for the premium-portfolio template.

All imagery is procedurally generated (no external sources, no licensing risk).
Customers replace these with their own assets. Outputs:
  hero.jpg, hero-depth.png        -> depth-displacement hero centerpiece
  project-1..4.jpg                -> selected-work cards
  about.jpg                       -> studio/about visual
  gallery-1..4.jpg                -> marketplace gallery
"""
import math
import os
import random
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance, ImageChops

random.seed(7)
OUT = "public/images"
os.makedirs(OUT, exist_ok=True)

W, H = 2560, 1440
PW, PH = 1600, 1000
GW, GH = 1200, 900


def lerp(a, b, t):
    return a + (b - a) * t


def vgrad(size, stops):
    w, h = size
    base = Image.new("RGB", (1, h))
    px = base.load()
    for i in range(len(stops) - 1):
        p0, c0 = stops[i]
        p1, c1 = stops[i + 1]
        y0 = int(p0 * (h - 1))
        y1 = int(p1 * (h - 1))
        for y in range(y0, y1 + 1):
            t = (y - y0) / max(1, y1 - y0)
            r = int(lerp(c0[0], c1[0], t))
            g = int(lerp(c0[1], c1[1], t))
            b = int(lerp(c0[2], c1[2], t))
            px[0, y] = (r, g, b)
    return base.resize((w, h))


def add_grain(img, amount=6):
    w, h = img.size
    noise = Image.new("L", (w, h))
    nd = noise.load()
    for y in range(h):
        for x in range(w):
            nd[x, y] = random.randint(0, 255)
    noise = noise.filter(ImageFilter.GaussianBlur(0.6))
    noise = ImageEnhance.Brightness(noise).enhance(0.5)
    grain = Image.merge("RGB", [noise, noise, noise])
    return ImageChops.blend(img, ImageChops.screen(img, grain), amount / 100.0)


def soft_orbs(img, n, colors, spread=1.0, max_r=None):
    w, h = img.size
    overlay = Image.new("RGB", (w, h), (0, 0, 0))
    od = ImageDraw.Draw(overlay)
    for _ in range(n):
        cx = random.randint(0, w)
        cy = random.randint(0, h)
        r = random.randint(int((max_r or min(w, h) // 4) * 0.3), max_r or min(w, h) // 4)
        col = random.choice(colors)
        od.ellipse([cx - r, cy - r, cx + r, cy + r], fill=col)
    overlay = overlay.filter(ImageFilter.GaussianBlur(min(w, h) // 8))
    return ImageChops.screen(img, ImageEnhance.Brightness(overlay).enhance(spread))


def ribbons(img, n, color, width=3):
    w, h = img.size
    layer = Image.new("RGB", (w, h), (0, 0, 0))
    d = ImageDraw.Draw(layer)
    for _ in range(n):
        pts = []
        amp = random.randint(60, 260)
        freq = random.uniform(0.0015, 0.006)
        phase = random.uniform(0, math.pi * 2)
        for xi in range(0, w, 12):
            yi = h // 2 + int(math.sin(xi * freq + phase) * amp) + random.randint(-20, 20)
            pts.append((xi, yi))
        for i in range(len(pts) - 1):
            d.line([pts[i], pts[i + 1]], fill=color, width=width)
    layer = layer.filter(ImageFilter.GaussianBlur(3))
    return ImageChops.screen(img, layer)


def save_jpg(img, path, quality=82):
    img = img.convert("RGB")
    img.save(path, "JPEG", quality=quality, optimize=True, progressive=True)
    print("wrote", path, os.path.getsize(path) // 1024, "KB")


def make_accent_field(w, h, dark, accent, accent2):
    img = vgrad((w, h), [(0, dark[0]), (0.5, dark[1]), (1, dark[2])])
    img = soft_orbs(img, 14, [accent, accent2, accent], spread=1.15, max_r=min(w, h) // 3)
    return img


def make_hero():
    dark = [(10, 10, 16), (8, 10, 20), (4, 6, 14)]
    accent = (212, 255, 79)
    accent2 = (139, 92, 246)
    img = make_accent_field(W, H, dark, accent, accent2)
    img = ribbons(img, 5, accent, width=2)
    img = ribbons(img, 3, accent2, width=2)
    core = Image.new("RGB", (W, H), (0, 0, 0))
    cd = ImageDraw.Draw(core)
    cd.ellipse([W // 2 - 360, H // 2 - 360, W // 2 + 360, H // 2 + 360], fill=accent)
    core = core.filter(ImageFilter.GaussianBlur(260))
    img = ImageChops.screen(img, ImageEnhance.Brightness(core).enhance(0.8))
    img = add_grain(img, 4)
    save_jpg(img, f"{OUT}/hero.jpg")

    depth = Image.new("L", (W, H), 0)
    dd = ImageDraw.Draw(depth)
    for r in range(700, 0, -4):
        v = int(255 * (1 - r / 700.0) ** 1.6)
        dd.ellipse([W // 2 - r, H // 2 - r, W // 2 + r, H // 2 + r], fill=v)
    depth = depth.filter(ImageFilter.GaussianBlur(30))
    depth.save(f"{OUT}/hero-depth.png")
    print("wrote", f"{OUT}/hero-depth.png")


def make_project(idx, palette):
    img = make_accent_field(PW, PH, palette["dark"], palette["a"], palette["b"])
    img = ribbons(img, 4, palette["a"], width=3)
    layer = Image.new("RGB", (PW, PH), (0, 0, 0))
    d = ImageDraw.Draw(layer)
    cx, cy = PW // 2, PH // 2
    if idx == 0:
        for r in range(60, 520, 40):
            d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=palette["a"], width=2)
    elif idx == 1:
        for i in range(7):
            x = 180 + i * 180
            d.line([x, 120, x, PH - 120], fill=palette["b"], width=3)
        d.rectangle([300, 200, 900, 360], fill=palette["a"])
    elif idx == 2:
        for gx in range(120, PW - 100, 140):
            for gy in range(120, PH - 100, 140):
                d.rectangle([gx, gy, gx + 110, gy + 90], outline=palette["a"], width=2)
        d.rectangle([520, 320, 900, 520], fill=palette["b"])
    else:
        pts = []
        for x in range(0, PW, 14):
            y = cy + int(math.sin(x * 0.006 + idx) * 160)
            pts.append((x, y))
        d.line(pts, fill=palette["a"], width=14)
    layer = layer.filter(ImageFilter.GaussianBlur(2))
    img = ImageChops.screen(img, layer)
    img = add_grain(img, 5)
    save_jpg(img, f"{OUT}/project-{idx + 1}.jpg")


def make_about():
    w, h = 1600, 1200
    dark = [(14, 14, 22), (10, 12, 24), (6, 8, 16)]
    img = make_accent_field(w, h, dark, (139, 92, 246), (212, 255, 79))
    img = ribbons(img, 4, (212, 255, 79), width=2)
    img = add_grain(img, 5)
    save_jpg(img, f"{OUT}/about.jpg")


def make_gallery():
    palettes = [
        {"dark": [(12, 14, 22), (8, 10, 18), (4, 6, 12)], "a": (96, 165, 250), "b": (212, 255, 79)},
        {"dark": [(18, 12, 22), (12, 8, 18), (6, 4, 12)], "a": (249, 115, 22), "b": (139, 92, 246)},
        {"dark": [(10, 18, 20), (8, 14, 16), (4, 8, 10)], "a": (45, 212, 191), "b": (212, 255, 79)},
        {"dark": [(20, 12, 18), (14, 8, 14), (6, 4, 8)], "a": (236, 72, 153), "b": (139, 92, 246)},
    ]
    for i, p in enumerate(palettes):
        img = make_accent_field(GW, GH, p["dark"], p["a"], p["b"])
        img = ribbons(img, 3, p["a"], width=2)
        img = add_grain(img, 5)
        save_jpg(img, f"{OUT}/gallery-{i + 1}.jpg")


if __name__ == "__main__":
    make_hero()
    proj_palettes = [
        {"dark": [(10, 12, 20), (8, 10, 18), (4, 6, 12)], "a": (212, 255, 79), "b": (139, 92, 246)},
        {"dark": [(14, 12, 18), (10, 8, 14), (6, 4, 10)], "a": (249, 115, 22), "b": (212, 255, 79)},
        {"dark": [(10, 14, 18), (8, 10, 14), (4, 6, 10)], "a": (96, 165, 250), "b": (45, 212, 191)},
        {"dark": [(14, 10, 20), (10, 8, 16), (6, 4, 12)], "a": (236, 72, 153), "b": (139, 92, 246)},
    ]
    for i, p in enumerate(proj_palettes):
        make_project(i, p)
    make_about()
    make_gallery()
    print("DONE")
