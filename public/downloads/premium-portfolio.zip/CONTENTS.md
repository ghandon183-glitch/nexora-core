# Package Contents

```
README.md                    Overview, requirements, env vars, deploy, honest limits
QUICKSTART.md                Install, run, build, sub-path build, launch checklist
CONTENTS.md                  This file map
CHANGELOG.md                 Version history
LICENSE.md                   Single end-product license
SUPPORT.md                   Support scope and what to include in a request
ASSET-LICENSES.md            Font, icon, library and imagery licenses

premium-portfolio/
  package.json               Scripts, dependencies, Node engine, npm overrides
  package-lock.json          Lockfile v3 — the tested dependency graph
  .env.example               The two optional public variables
  .gitignore                 Build output, dependencies, local env files
  next.config.ts             Static export, optional basePath, unoptimized images
  tsconfig.json              TypeScript configuration (strict, path alias @/*)
  next-env.d.ts              Next.js type references
  eslint.config.mjs          ESLint flat config (next/core-web-vitals + TypeScript)
  postcss.config.mjs         Tailwind CSS v4 PostCSS plugin

  app/
    layout.tsx               Fonts, metadata, canonical/Open Graph/Twitter, theme color
    page.tsx                 Skip link, header, main sections, footer
    globals.css              Design tokens, textures, animation, focus styles
    not-found.tsx            Branded 404 page
    icon.svg                 Favicon
    robots.ts                robots.txt (sitemap reference when SITE_URL is set)
    sitemap.ts               sitemap.xml (single page, needs SITE_URL)

  components/
    nav.tsx                  Fixed header, anchor navigation, mobile menu (Escape closes)
    hero.tsx                 Hero copy, CTAs, CSS entrance animation
    hero-canvas.tsx          WebGL depth-displaced plane, pointer parallax, static fallback
    tech-strip.tsx           Marquee of tools
    about.tsx                Studio section with capability tags and image
    projects.tsx             Project cards (each links to the contact section)
    services.tsx             Capability rows (each links to the contact section)
    contact.tsx              Contact details and demo form that composes an email draft
    footer.tsx               CTA band, navigation, social links, colophon
    reveal.tsx               CSS/IntersectionObserver scroll reveal

  lib/
    data.ts                  All editable content: studio, projects, services, links
    base-path.ts             BASE_PATH, SITE_URL, assetPath(), sitePath()

  public/images/
    hero.jpg                 Hero base image (2560x1440)
    hero-depth.png           Depth map for the WebGL displacement
    project-1..4.jpg         Project card imagery (1600x1000)
    about.jpg                Studio imagery

  scripts/
    gen-assets.py            Optional procedural regeneration of the demo images
```

The project has one route (`/`). `404.html`, `robots.txt` and `sitemap.xml` are
generated into `out/` at build time. No `node_modules`, build output or local
environment files are included.
