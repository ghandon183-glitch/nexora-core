# Solace Studio — Start Here

This archive contains the complete, standalone Next.js 16 source for the
Solace Studio template.

- **Project source:** [`solace-studio/`](./solace-studio)
- **Full documentation:** [`solace-studio/README.md`](./solace-studio/README.md)
- **Contents of this archive:** [`CONTENTS.md`](./CONTENTS.md)
- **Install checklist:** [`QUICKSTART.md`](./QUICKSTART.md)
- **License:** [`LICENSE.md`](./LICENSE.md)
- **Support:** [`SUPPORT.md`](./SUPPORT.md)
- **Asset & third-party licenses:** [`ASSET-LICENSES.md`](./ASSET-LICENSES.md)
- **Changes in this version:** [`CHANGELOG.md`](./CHANGELOG.md)

## Fastest path to a running site

```bash
cd solace-studio
npm ci
npm run dev      # http://localhost:3000
```

For a production build:

```bash
npm run build    # static export written to out/
```

Requires Node.js 20.9 or newer (22 LTS is what the package is tested on).

Read [`solace-studio/README.md`](./solace-studio/README.md) before launching:
it documents the folder structure, the customisation points, and the
front-end-only demo behaviours you must replace or connect before going live.
