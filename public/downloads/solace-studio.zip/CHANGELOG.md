# Changelog

## 1.1.0
- Security update: Next.js 16.3.6 → 16.4.5 (fixes the critical `use cache`,
  cache-poisoning, MCP-disclosure and image-route advisories).
- Removed the unused `shadcn` CLI from runtime dependencies; use
  `npx shadcn@latest add <component>` on demand instead.
- Added a `package-lock.json` so `npm ci` reproduces the exact tested tree.
- Added a working ESLint 9 flat config (`npm run lint` previously failed
  because ESLint was not installed) that ignores generated `out/` output.
- Documented the optional `NEXT_PUBLIC_BASE_PATH` variable and the static
  export build in README / `.env.example`.
- Type errors now fail the production build instead of being ignored.

## 1.0.0
- Customer-ready commercial package.
- Standard license and support documentation.
- Installation and production checklist included.
