# Changelog

## 1.2.0
- Replaced the three raw `<img>` elements (hero, trainers, gallery) with
  `next/image`, keeping the original aspect ratios, cropping, hover motion and
  alt text. The hero image is eager with `fetchPriority="high"`; the remaining
  images lazy-load with explicit `sizes`.
- Pinned `turbopack.root` in `next.config.mjs` so the project builds correctly
  when the folder is extracted inside another repository that also has a
  lockfile (previously Next.js could pick the parent project's root and fail
  with module-resolution errors).
- Mobile navigation now closes on <kbd>Escape</kbd> and returns focus to the
  toggle button.
- Fixed a hydration mismatch for visitors with `prefers-reduced-motion: reduce`:
  the server and client now render identical markup, and reduced motion only
  shortens the transitions.
- The free-pass form now states plainly that it is a front-end demo and that no
  address is sent or stored, instead of implying a successful signup.
- Documented Node.js requirements and the demo/backend limitations in
  `README.md`; added a `README.md` at the archive root that the other documents
  link to.
- `.gitignore` now ignores `.env` and `.env.*` while keeping `.env.example`.

## 1.1.0
- Security update: Next.js 16.3.6 → 16.4.5 (fixes the critical `use cache`,
  cache-poisoning, MCP-disclosure and image-route advisories).
- Removed the unused `shadcn` CLI from runtime dependencies; use
  `npx shadcn@latest add <component>` on demand instead.
- Added a `package-lock.json` so `npm ci` reproduces the exact tested tree.
- Added a working ESLint 9 flat config (`npm run lint` previously failed
  because ESLint was not installed) that ignores generated `out/` output.
- Documented the optional `NEXT_PUBLIC_BASE_PATH` variable and the static
  export build in README / `.env.example`.
- Type errors now fail the production build instead of being ignored.

## 1.0.0
- Customer-ready commercial package.
- Standard license and support documentation.
- Installation and production checklist included.
