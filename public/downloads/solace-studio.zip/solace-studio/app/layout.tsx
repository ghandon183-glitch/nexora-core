import type { Metadata, Viewport } from 'next'
import '@fontsource-variable/inter/index.css'
import '@fontsource/fraunces/400.css'
import '@fontsource/fraunces/500.css'
import '@fontsource/fraunces/700.css'
import './globals.css'

export const metadata: Metadata = {
  title: 'Solace Studio — Boutique Yoga, Pilates & Strength',
  description:
    'A twelve-mat boutique studio in Portland. Small-group yoga, reformer pilates, strength and sound baths, taught by people who remember your name.',
  openGraph: {
    title: 'Solace Studio — A quieter way to move',
    description: 'Small-group yoga, pilates and strength in a calm room.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light',
  themeColor: '#16241e',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="bg-cream">
      <body className="font-sans antialiased">{children}</body>
    </html>
  )
}
