import { Nav } from '@/components/nav'
import { Hero } from '@/components/hero'
import { Classes } from '@/components/classes'
import { Trainers } from '@/components/trainers'
import { Pricing } from '@/components/pricing'
import { Testimonials } from '@/components/testimonials'
import { Gallery } from '@/components/gallery'
import { Newsletter } from '@/components/newsletter'
import { Footer } from '@/components/footer'

export default function Page() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Classes />
        <Trainers />
        <Pricing />
        <Testimonials />
        <Gallery />
        <Newsletter />
      </main>
      <Footer />
    </>
  )
}
