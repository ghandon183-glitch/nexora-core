# Solace Studio — Boutique Yoga & Fitness Template

Thanks for purchasing Solace Studio! This is a complete, standalone Next.js 16
project for a boutique yoga/pilates/strength studio landing page.

## Stack

- Next.js 16 (App Router) + TypeScript
- Tailwind CSS v4
- Framer Motion (scroll reveals)
- Self-hosted fonts via @fontsource (Fraunces, Inter) — no external font
  requests at build or runtime

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Project structure

- `app/page.tsx` — assembles all homepage sections
- `components/` — Nav, Hero, Classes, Trainers, Pricing, Testimonials,
  Gallery, Newsletter, Footer, and a shared NextClassBadge / Reveal helper
- `lib/data.ts` — studio info, class schedule, trainers, and gallery content
  — edit this to swap in your own studio's details
- `app/globals.css` — color and type tokens (forest/cream/clay/mustard
  palette, `--font-display`, `--font-sans`)

## Customizing

- Swap the images in `public/images/` for your own studio photography
  whenever you have it.
- Studio, schedule, trainer, and gallery content all lives in `lib/data.ts`.

## Building for production

```bash
npm run build
npm run start
```

## Support

If you run into an issue with the template, reach out via the support
channel listed on your purchase receipt.
