# Solace Studio — Boutique Yoga & Fitness Template

Thanks for purchasing Solace Studio! This is a complete, standalone Next.js 16
project for a boutique yoga/pilates/strength studio landing page.

## Stack

- Next.js 16 (App Router) + TypeScript
- Tailwind CSS v4
- Framer Motion (scroll reveals)
- Self-hosted fonts via @fontsource (Fraunces, Inter) — no external font
  requests at build or runtime

## Getting started

```bash
npm ci
npm run dev
```

Open http://localhost:3000.

`npm ci` installs the exact dependency versions pinned in the included
`package-lock.json`. If you would rather resolve newer minor versions inside
the declared ranges, run `npm install` instead.

### Optional environment variable

Copy `.env.example` to `.env.local` only if you need to override the default:

| Variable | Default | Purpose |
|---|---|---|
| `NEXT_PUBLIC_BASE_PATH` | empty | Prefix for files under `public/`. Set it only when the site is served from a sub-path, e.g. `/demo/solace-studio`. Leave it empty for a normal domain-root deployment. |

No other environment variables, API keys, or third-party accounts are required.

### Requirements

- Node.js **20.9 or newer** (the package is tested on Node.js 22 LTS).
- npm 10 or newer — the included `package-lock.json` is what `npm ci` uses.

### Demo limitations (read before launch)

This is a front-end template. Nothing in it talks to a server, a database, or
an email provider:

- **The newsletter / free-pass form is a demo.** It validates the address in the
  browser and shows a confirmation, but **it does not send, store, or forward
  the address anywhere** — there is no request to any backend. Replace the
  `onSubmit` handler in `components/newsletter.tsx` with a call to your own
  endpoint or form service, and update the confirmation copy when you do.
- **No booking, payment, or account system is included.** The pricing and
  schedule sections are static content from `lib/data.ts`; the “Choose …”
  and “Book a Class” buttons are in-page links to the contact section.
- **All copy, photography, testimonials, trainers, and prices are demo
  content.** Replace them before publishing.
- The build is a **static export** (`output: 'export'`), so any dynamic
  behaviour you add later needs a server, edge function, or third-party API.

## Project structure

- `app/page.tsx` — assembles all homepage sections
- `components/` — Nav, Hero, Classes, Trainers, Pricing, Testimonials,
  Gallery, Newsletter, Footer, and a shared NextClassBadge / Reveal helper
- `lib/data.ts` — studio info, class schedule, trainers, and gallery content
  — edit this to swap in your own studio's details
- `lib/base-path.ts` — helper that prefixes `public/` asset URLs with
  `NEXT_PUBLIC_BASE_PATH` when one is set
- `app/globals.css` — color and type tokens (forest/cream/clay/mustard
  palette, `--font-display`, `--font-sans`)

## Customizing

- Swap the images in `public/images/` for your own studio photography
  whenever you have it.
- Studio, schedule, trainer, and gallery content all lives in `lib/data.ts`.
- Need another shadcn/ui component? `components.json` is included, so the CLI
  works on demand: `npx shadcn@latest add <component>`. The CLI is not a
  runtime dependency of this project and is intentionally not installed.

## Building for production

This template uses a static export (`output: 'export'` in `next.config.mjs`),
so the build writes plain files to `out/`:

```bash
npm run build
npx serve out
```

Deploy the contents of `out/` to any static host. `npm run start` (`next start`)
is not supported for a static export and is provided only for parity with
standard Next.js scripts.

## Quality checks

```bash
npm run lint
npx tsc --noEmit
```

## Support

If you run into an issue with the template, reach out via the support
channel listed on your purchase receipt.
