import { dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

// Pin the Turbopack workspace root to this project. Without it, Next.js walks up
// looking for a lockfile and can pick a *parent* project's root when this folder
// is extracted inside another repository — which then builds the parent's files
// instead of this one. The path is derived from this config file, so it also
// works when the project is moved or renamed.
const projectRoot = dirname(fileURLToPath(import.meta.url))

/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  basePath: process.env.NEXT_PUBLIC_BASE_PATH || undefined,
  images: {
    unoptimized: true,
  },
  turbopack: {
    root: projectRoot,
  },
}

export default nextConfig
