'use client'

import { useState } from 'react'

export function Newsletter() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)

  return (
    <section id="contact" className="grain relative bg-forest py-24 sm:py-32">
      <div className="relative mx-auto max-w-3xl px-5 text-center sm:px-8">
        <p className="mb-5 text-xs uppercase tracking-[0.22em] text-mustard">First class is on us</p>
        <h2 className="font-display text-[clamp(2rem,4.8vw,3.5rem)] leading-[1.03] tracking-tight text-cream text-balance">
          Come once. Decide after.
        </h2>
        <p className="mx-auto mt-5 max-w-md text-sm leading-relaxed text-cream/65 text-pretty">
          Leave your email and we&apos;ll send a free class pass plus this week&apos;s schedule. One message, no
          drip campaign.
        </p>

        <form
          className="mx-auto mt-10 flex w-full max-w-md flex-col gap-3 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault()
            setSent(true)
          }}
        >
          <div className="flex-1 text-left">
            <label htmlFor="newsletter-email" className="sr-only">
              Email address
            </label>
            <input
              id="newsletter-email"
              name="email"
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full rounded-full border border-cream/20 bg-cream/5 px-5 py-3.5 text-sm text-cream placeholder:text-cream/40 focus:border-mustard focus:outline-none focus:ring-2 focus:ring-mustard/40"
            />
          </div>
          <button
            type="submit"
            className="rounded-full bg-clay px-7 py-3.5 text-sm font-medium text-cream transition-colors hover:bg-mustard hover:text-ink"
          >
            Send my pass
          </button>
        </form>

        <p aria-live="polite" className="mt-4 min-h-5 text-xs text-mustard">
          {sent ? 'Thanks — your free class pass is on the way.' : ''}
        </p>
      </div>
    </section>
  )
}
