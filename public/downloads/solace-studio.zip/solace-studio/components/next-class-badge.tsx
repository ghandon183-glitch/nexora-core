'use client'

import { motion, useReducedMotion } from 'framer-motion'

type Props = {
  next: { time: string; name: string; teacher: string }
}

/**
 * Signature moment: a live "next class" chip with a breathing pulse
 * and a thin countdown ring, floating over the hero image.
 */
export function NextClassBadge({ next }: Props) {
  const reduced = useReducedMotion()

  return (
    <div className="absolute -bottom-6 left-3 right-3 flex items-center gap-4 rounded-2xl bg-cream px-5 py-4 shadow-[0_18px_40px_-20px_rgba(16,26,22,0.6)] sm:left-8 sm:right-auto">
      <span className="relative flex h-3 w-3 shrink-0">
        {!reduced && (
          <motion.span
            className="absolute inset-0 rounded-full bg-clay"
            animate={{ scale: [1, 2.6], opacity: [0.55, 0] }}
            transition={{ duration: 2.4, repeat: Number.POSITIVE_INFINITY, ease: 'easeOut' }}
          />
        )}
        <span className="relative h-3 w-3 rounded-full bg-clay" />
      </span>

      <div>
        <p className="text-[0.7rem] uppercase tracking-[0.18em] text-ink/50">Next class · starts in 20 min</p>
        <p className="font-display text-lg leading-tight text-ink">
          {next.name} <span className="text-ink/40">· {next.time}</span>
        </p>
      </div>

      <div aria-hidden className="ml-2 hidden sm:block">
        <svg viewBox="0 0 40 40" className="h-10 w-10 -rotate-90">
          <circle cx="20" cy="20" r="17" fill="none" stroke="#ded6c7" strokeWidth="3" />
          <motion.circle
            cx="20"
            cy="20"
            r="17"
            fill="none"
            stroke="#d9a43b"
            strokeWidth="3"
            strokeLinecap="round"
            strokeDasharray="107"
            initial={{ strokeDashoffset: 107 }}
            animate={{ strokeDashoffset: reduced ? 40 : [107, 40] }}
            transition={reduced ? { duration: 0 } : { duration: 2.2, ease: 'easeOut', delay: 0.6 }}
          />
        </svg>
      </div>
    </div>
  )
}
