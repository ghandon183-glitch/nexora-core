import { gallery } from '@/lib/data'
import { Reveal } from '@/components/reveal'
import { assetPath } from '@/lib/base-path'

export function Gallery() {
  return (
    <section className="bg-cream py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <Reveal>
            <p className="mb-5 flex items-center gap-3 text-xs uppercase tracking-[0.22em] text-clay">
              <span aria-hidden className="h-px w-8 bg-clay/50" />
              @solacestudio
            </p>
            <h2 className="font-display text-[clamp(2rem,4.4vw,3.25rem)] leading-[1.05] tracking-tight text-ink text-balance">
              The room, most mornings.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <a
              href="#contact"
              className="rounded-full border border-ink/20 px-6 py-3 text-sm font-medium text-ink transition-colors hover:bg-forest hover:text-cream"
            >
              Follow along
            </a>
          </Reveal>
        </div>

        <ul className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4">
          {gallery.map((shot, i) => (
            <Reveal as="li" key={i} delay={(i % 3) * 0.06}>
              <div className="group overflow-hidden rounded-2xl">
                <img
                  src={assetPath(shot.image || '/placeholder.svg')}
                  alt={shot.alt}
                  className="aspect-square w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  )
}
