import { navLinks, studio } from '@/lib/data'

const socials = ['Instagram', 'Spotify', 'Newsletter']

export function Footer() {
  return (
    <footer className="border-t border-cream/10 bg-forest">
      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 sm:grid-cols-2 sm:px-8 lg:grid-cols-4">
        <div className="lg:col-span-2">
          <a href="#top" className="flex items-center gap-2.5 text-cream">
            <span aria-hidden className="block h-2.5 w-2.5 rotate-45 bg-clay" />
            <span className="font-display text-lg tracking-tight">{studio.name}</span>
          </a>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-cream/55 text-pretty">{studio.tagline} — twelve mats, warm light, and no mirrors.</p>
        </div>

        <nav aria-label="Footer">
          <h2 className="text-xs uppercase tracking-[0.18em] text-mustard">Explore</h2>
          <ul className="mt-4 flex flex-col gap-2.5">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a href={link.href} className="text-sm text-cream/60 transition-colors hover:text-cream">
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <h2 className="text-xs uppercase tracking-[0.18em] text-mustard">Visit</h2>
          <address className="mt-4 flex flex-col gap-2.5 text-sm not-italic leading-relaxed text-cream/60">
            <span>{studio.address}</span>
            <a href={`mailto:${studio.email}`} className="transition-colors hover:text-cream">
              {studio.email}
            </a>
            <a href={`tel:${studio.phone.replace(/[^0-9]/g, '')}`} className="transition-colors hover:text-cream">
              {studio.phone}
            </a>
          </address>
          <ul className="mt-5 flex flex-wrap gap-x-4 gap-y-2">
            {socials.map((s) => (
              <li key={s}>
                <a href="#top" className="text-xs uppercase tracking-wider text-cream/45 transition-colors hover:text-mustard">
                  {s}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-cream/10 px-5 py-6 sm:px-8">
        <p className="mx-auto max-w-6xl text-xs text-cream/40">
          © {new Date().getFullYear()} {studio.name}. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
