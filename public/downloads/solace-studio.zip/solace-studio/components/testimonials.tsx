import { testimonials } from '@/lib/data'
import { Reveal } from '@/components/reveal'

function Stars({ rating }: { rating: number }) {
  return (
    <p className="flex items-center gap-1" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} viewBox="0 0 20 20" aria-hidden className="h-3.5 w-3.5">
          <path
            d="M10 1.6l2.5 5.3 5.7.8-4.2 4 1 5.7L10 14.7l-5 2.7 1-5.7-4.2-4 5.7-.8z"
            fill={i < rating ? '#c4623c' : 'none'}
            stroke="#c4623c"
            strokeWidth="1.2"
          />
        </svg>
      ))}
    </p>
  )
}

export function Testimonials() {
  return (
    <section className="bg-cream-dim/45 py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal className="max-w-2xl">
          <p className="mb-5 flex items-center gap-3 text-xs uppercase tracking-[0.22em] text-clay">
            <span aria-hidden className="h-px w-8 bg-clay/50" />
            Members
          </p>
          <h2 className="font-display text-[clamp(2rem,4.4vw,3.25rem)] leading-[1.05] tracking-tight text-ink text-balance">
            What people say after six weeks.
          </h2>
        </Reveal>

        <ul className="mt-14 grid gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <Reveal as="li" key={t.name} delay={i * 0.08} className="h-full">
              <figure className="flex h-full flex-col gap-5 rounded-3xl rounded-tl-[3.5rem] bg-cream p-8">
                <Stars rating={t.rating} />
                <blockquote className="font-display text-lg leading-snug text-ink text-pretty">
                  &ldquo;{t.quote}&rdquo;
                </blockquote>
                <figcaption className="mt-auto text-xs uppercase tracking-[0.14em] text-ink/45">
                  {t.name} · {t.detail}
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  )
}
