import { classes } from '@/lib/data'
import { ClassIcon } from '@/components/class-icons'
import { Reveal } from '@/components/reveal'

export function Classes() {
  return (
    <section id="classes" className="bg-cream py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal className="max-w-2xl">
          <p className="mb-5 flex items-center gap-3 text-xs uppercase tracking-[0.22em] text-clay">
            <span aria-hidden className="h-px w-8 bg-clay/50" />
            The classes
          </p>
          <h2 className="font-display text-[clamp(2rem,4.4vw,3.25rem)] leading-[1.05] tracking-tight text-ink text-balance">
            Six ways into the room. None of them shouty.
          </h2>
        </Reveal>

        <ul className="mt-14 grid gap-px overflow-hidden rounded-3xl bg-border sm:grid-cols-2 lg:grid-cols-3">
          {classes.map((item, i) => (
            <Reveal as="li" key={item.name} delay={i * 0.06} className="group bg-cream">
              <article className="flex h-full flex-col gap-5 p-8 transition-colors duration-500 group-hover:bg-forest">
                <ClassIcon
                  name={item.icon}
                  className="h-14 w-14 text-clay transition-colors duration-500 group-hover:text-mustard"
                />
                <div>
                  <h3 className="font-display text-2xl text-ink transition-colors duration-500 group-hover:text-cream">
                    {item.name}
                  </h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-ink/60 transition-colors duration-500 group-hover:text-cream/70">
                    {item.blurb}
                  </p>
                </div>
                <div className="mt-auto flex items-center gap-3 pt-2 text-[0.7rem] uppercase tracking-[0.16em]">
                  <span className="rounded-full border border-ink/15 px-3 py-1 text-ink/60 transition-colors duration-500 group-hover:border-cream/25 group-hover:text-cream/70">
                    {item.duration}
                  </span>
                  <span className="rounded-full border border-ink/15 px-3 py-1 text-ink/60 transition-colors duration-500 group-hover:border-cream/25 group-hover:text-cream/70">
                    {item.level}
                  </span>
                </div>
              </article>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  )
}
