import type { ClassItem } from '@/lib/data'

type Props = {
  name: ClassItem['icon']
  className?: string
}

const stroke = {
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 1.4,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
}

/** Hand-drawn line illustrations, one unique drawing per class. */
export function ClassIcon({ name, className }: Props) {
  const common = {
    viewBox: '0 0 64 64',
    className,
    'aria-hidden': true,
    focusable: false as const,
  }

  switch (name) {
    case 'flow':
      // breath ribbon spiralling upward
      return (
        <svg {...common}>
          <g {...stroke}>
            <path d="M10 52c8 0 12-6 12-12s-5-9-9-6.5 0 9 6 9c9 0 14-8 14-16" />
            <path d="M33 26c0-9 6-15 13-15 5 0 8 3 8 7s-3 6-6 6" />
            <circle cx="47" cy="45" r="6" />
            <path d="M41 51l-6 6" />
          </g>
        </svg>
      )
    case 'reformer':
      // reformer carriage with springs
      return (
        <svg {...common}>
          <g {...stroke}>
            <path d="M6 44h52" />
            <path d="M12 44v6M52 44v6" />
            <rect x="18" y="32" width="26" height="10" rx="2" />
            <path d="M44 37h10" />
            <path d="M6 37c2 0 2 2 4 2s2-2 4-2 2 2 4 2" />
            <path d="M22 32V22h10" />
          </g>
        </svg>
      )
    case 'strength':
      // kettlebell + bar
      return (
        <svg {...common}>
          <g {...stroke}>
            <path d="M24 30a8 8 0 1 1 16 0" />
            <path d="M20 30h24c3 0 5 4 5 10s-4 10-9 10H24c-5 0-9-4-9-10s2-10 5-10z" />
            <path d="M28 40h8" />
          </g>
        </svg>
      )
    case 'restore':
      // bolster with folded blanket + moon
      return (
        <svg {...common}>
          <g {...stroke}>
            <path d="M8 44h34a6 6 0 0 0 0-12H8a6 6 0 0 0 0 12z" />
            <path d="M14 32v12M20 32v12" />
            <path d="M52 14a8 8 0 1 0 4 15 9 9 0 0 1-4-15z" />
            <path d="M8 52h44" />
          </g>
        </svg>
      )
    case 'hiit':
      // stopwatch with lightning
      return (
        <svg {...common}>
          <g {...stroke}>
            <circle cx="32" cy="36" r="18" />
            <path d="M26 10h12M32 10v8" />
            <path d="M34 26l-8 12h7l-2 10 9-13h-7z" />
            <path d="M48 20l4-4" />
          </g>
        </svg>
      )
    case 'sound':
      // singing bowl with resonance arcs
      return (
        <svg {...common}>
          <g {...stroke}>
            <path d="M18 34h28c0 10-6 16-14 16s-14-6-14-16z" />
            <ellipse cx="32" cy="34" rx="14" ry="4" />
            <path d="M46 22c3 3 4 6 4 9M52 16c5 5 6 10 6 15" />
            <path d="M18 22c-3 3-4 6-4 9M12 16c-5 5-6 10-6 15" />
            <path d="M32 50v6" />
          </g>
        </svg>
      )
  }
}
