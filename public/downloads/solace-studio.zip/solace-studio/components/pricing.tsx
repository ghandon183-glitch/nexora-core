import { plans, schedule } from '@/lib/data'
import { cn } from '@/lib/utils'
import { Reveal } from '@/components/reveal'

export function Pricing() {
  return (
    <section id="pricing" className="bg-cream py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <Reveal className="max-w-2xl">
          <p className="mb-5 flex items-center gap-3 text-xs uppercase tracking-[0.22em] text-clay">
            <span aria-hidden className="h-px w-8 bg-clay/50" />
            Schedule & pricing
          </p>
          <h2 className="font-display text-[clamp(2rem,4.4vw,3.25rem)] leading-[1.05] tracking-tight text-ink text-balance">
            Pay for what you actually attend.
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-14">
          {/* Today's schedule */}
          <Reveal>
            <div className="rounded-3xl border border-border bg-cream-dim/40 p-7">
              <h3 className="font-display text-xl text-ink">Today at the studio</h3>
              <ul className="mt-5 divide-y divide-ink/10">
                {schedule.map((slot) => (
                  <li key={slot.time} className="flex items-baseline gap-4 py-3.5">
                    <span className="w-14 shrink-0 font-display text-base text-clay">{slot.time}</span>
                    <span className="text-sm text-ink">{slot.name}</span>
                    <span className="ml-auto text-xs uppercase tracking-wider text-ink/45">{slot.teacher}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          {/* Plans */}
          <div className="grid gap-5 sm:grid-cols-3">
            {plans.map((plan, i) => (
              <Reveal key={plan.name} delay={i * 0.08} className="h-full">
                <div
                  className={cn(
                    'flex h-full flex-col rounded-3xl border p-6',
                    plan.featured
                      ? 'grain relative border-forest bg-forest text-cream'
                      : 'border-border bg-cream text-ink',
                  )}
                >
                  {plan.featured && (
                    <span className="relative mb-3 w-fit rounded-full bg-mustard px-3 py-1 text-[0.65rem] uppercase tracking-[0.16em] text-ink">
                      Most chosen
                    </span>
                  )}
                  <h3 className={cn('relative font-display text-xl', plan.featured ? 'text-cream' : 'text-ink')}>
                    {plan.name}
                  </h3>
                  <p className="relative mt-4 flex items-baseline gap-1.5">
                    <span className={cn('font-display text-4xl', plan.featured ? 'text-cream' : 'text-ink')}>
                      {plan.price}
                    </span>
                    <span className={cn('text-xs', plan.featured ? 'text-cream/55' : 'text-ink/50')}>{plan.unit}</span>
                  </p>
                  <p className={cn('relative mt-2 text-xs', plan.featured ? 'text-cream/55' : 'text-ink/50')}>
                    {plan.note}
                  </p>
                  <ul className="relative mt-6 flex flex-col gap-2.5">
                    {plan.features.map((f) => (
                      <li key={f} className="flex gap-2.5 text-sm leading-relaxed">
                        <span aria-hidden className={cn('mt-2 h-1.5 w-1.5 shrink-0 rotate-45', plan.featured ? 'bg-mustard' : 'bg-clay')} />
                        <span className={plan.featured ? 'text-cream/75' : 'text-ink/70'}>{f}</span>
                      </li>
                    ))}
                  </ul>
                  <a
                    href="#contact"
                    className={cn(
                      'relative mt-7 rounded-full px-5 py-3 text-center text-sm font-medium transition-colors',
                      plan.featured
                        ? 'bg-clay text-cream hover:bg-mustard hover:text-ink'
                        : 'border border-ink/20 text-ink hover:bg-forest hover:text-cream',
                    )}
                  >
                    Choose {plan.name}
                  </a>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
