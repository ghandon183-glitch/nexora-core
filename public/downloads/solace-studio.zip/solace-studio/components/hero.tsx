'use client'

import { motion, useReducedMotion } from 'framer-motion'
import { studio, schedule } from '@/lib/data'
import { NextClassBadge } from '@/components/next-class-badge'
import { assetPath } from '@/lib/base-path'

export function Hero() {
  const reduced = useReducedMotion()

  const words = 'A quieter way to move.'.split(' ')

  return (
    <section id="top" className="grain relative overflow-hidden bg-forest pb-20 pt-32 sm:pb-28 sm:pt-40">
      {/* signature: slow breathing arc behind the headline */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -right-24 top-10 h-[34rem] w-[34rem] rounded-full border border-cream/10"
        animate={reduced ? undefined : { scale: [1, 1.06, 1], opacity: [0.5, 0.85, 0.5] }}
        transition={{ duration: 9, repeat: Number.POSITIVE_INFINITY, ease: 'easeInOut' }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -right-10 top-32 h-[22rem] w-[22rem] rounded-full border border-clay/25"
        animate={reduced ? undefined : { scale: [1.04, 1, 1.04] }}
        transition={{ duration: 9, repeat: Number.POSITIVE_INFINITY, ease: 'easeInOut' }}
      />

      <div className="relative mx-auto grid max-w-6xl gap-14 px-5 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:items-end lg:gap-10">
        <div>
          <p className="mb-6 flex items-center gap-3 text-xs uppercase tracking-[0.22em] text-mustard">
            <span aria-hidden className="h-px w-8 bg-mustard/60" />
            Portland · Twelve mats
          </p>

          <h1 className="font-display text-[clamp(2.75rem,7vw,5.25rem)] leading-[0.98] tracking-tight text-cream text-balance">
            {words.map((word, i) => (
              <motion.span
                key={word + i}
                className="mr-[0.28em] inline-block"
                initial={reduced ? undefined : { opacity: 0, y: '0.4em' }}
                animate={reduced ? undefined : { opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.1 + i * 0.09, ease: [0.22, 1, 0.36, 1] }}
              >
                {word === 'move.' ? <em className="not-italic text-clay">{word}</em> : word}
              </motion.span>
            ))}
          </h1>

          <p className="mt-7 max-w-md text-base leading-relaxed text-cream/70 text-pretty">{studio.description}</p>

          <div className="mt-9 flex flex-wrap items-center gap-3">
            <a
              href="#pricing"
              className="rounded-full bg-clay px-7 py-3.5 text-sm font-medium text-cream transition-colors hover:bg-mustard hover:text-ink"
            >
              Book a Free Class
            </a>
            <a
              href="#pricing"
              className="rounded-full border border-cream/25 px-7 py-3.5 text-sm font-medium text-cream transition-colors hover:border-cream hover:bg-cream hover:text-ink"
            >
              See Schedule
            </a>
          </div>

          <dl className="mt-12 grid max-w-md grid-cols-3 gap-6 border-t border-cream/10 pt-7">
            {[
              { k: '12', v: 'mats per class' },
              { k: '34', v: 'classes weekly' },
              { k: '9y', v: 'in the neighbourhood' },
            ].map((stat) => (
              <div key={stat.v}>
                <dt className="font-display text-3xl text-cream">{stat.k}</dt>
                <dd className="mt-1 text-xs uppercase tracking-wider text-cream/50">{stat.v}</dd>
              </div>
            ))}
          </dl>
        </div>

        <div className="relative mb-10 lg:mb-0">
          <div className="relative overflow-hidden rounded-[2rem] rounded-tr-[6rem]">
            <img
              src={assetPath('/images/hero-studio.png')}
              alt="Morning light crossing the studio floor while a member holds a standing stretch"
              className="aspect-[4/5] w-full object-cover"
            />
          </div>
          <NextClassBadge next={schedule[4]} />
        </div>
      </div>
    </section>
  )
}
