'use client'

import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import { navLinks, studio } from '@/lib/data'

export function Nav() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-colors duration-500',
        scrolled ? 'bg-forest/95 backdrop-blur-sm' : 'bg-transparent',
      )}
    >
      <nav aria-label="Main" className="mx-auto flex h-20 max-w-6xl items-center gap-8 px-5 sm:px-8">
        <a href="#top" className="flex items-center gap-2.5 text-cream">
          <span aria-hidden className="block h-2.5 w-2.5 rotate-45 bg-clay" />
          <span className="font-display text-lg tracking-tight">{studio.name}</span>
        </a>

        <ul className="ml-auto hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="text-sm text-cream/70 underline-offset-8 transition-colors hover:text-cream hover:underline"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <a
          href="#pricing"
          className="ml-auto hidden rounded-full bg-clay px-5 py-2.5 text-sm font-medium text-cream transition-colors hover:bg-mustard hover:text-ink md:ml-0 md:block"
        >
          Book a Class
        </a>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="mobile-menu"
          className="ml-auto flex h-10 w-10 flex-col items-center justify-center gap-1.5 text-cream md:hidden"
        >
          <span className="sr-only">Toggle navigation</span>
          <span aria-hidden className={cn('h-px w-6 bg-cream transition-transform', open && 'translate-y-[3px] rotate-45')} />
          <span aria-hidden className={cn('h-px w-6 bg-cream transition-transform', open && '-translate-y-[3px] -rotate-45')} />
        </button>
      </nav>

      {open && (
        <div id="mobile-menu" className="border-t border-cream/10 bg-forest px-5 pb-6 pt-2 md:hidden">
          <ul className="flex flex-col">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block border-b border-cream/10 py-3.5 font-display text-xl text-cream"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#pricing"
            onClick={() => setOpen(false)}
            className="mt-5 block rounded-full bg-clay px-5 py-3 text-center text-sm font-medium text-cream"
          >
            Book a Class
          </a>
        </div>
      )}
    </header>
  )
}
