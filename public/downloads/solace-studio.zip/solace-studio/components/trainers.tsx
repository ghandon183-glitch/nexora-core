import { trainers } from '@/lib/data'
import { Reveal } from '@/components/reveal'
import { assetPath } from '@/lib/base-path'

export function Trainers() {
  return (
    <section id="trainers" className="grain relative bg-forest py-24 sm:py-32">
      <div className="relative mx-auto max-w-6xl px-5 sm:px-8">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <Reveal className="max-w-xl">
            <p className="mb-5 flex items-center gap-3 text-xs uppercase tracking-[0.22em] text-mustard">
              <span aria-hidden className="h-px w-8 bg-mustard/50" />
              Who teaches
            </p>
            <h2 className="font-display text-[clamp(2rem,4.4vw,3.25rem)] leading-[1.05] tracking-tight text-cream text-balance">
              Three teachers. No rotating cast of strangers.
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="max-w-xs text-sm leading-relaxed text-cream/60 text-pretty">
              Everyone on the schedule has taught here for at least four years. They know your knee, your week, and
              your name.
            </p>
          </Reveal>
        </div>

        <ul className="mt-16 grid gap-10 sm:grid-cols-3">
          {trainers.map((person, i) => (
            <Reveal as="li" key={person.name} delay={i * 0.08}>
              <div className="overflow-hidden rounded-[1.75rem] rounded-bl-[4.5rem]">
                <img
                  src={assetPath(person.image || '/placeholder.svg')}
                  alt={`Portrait of ${person.name}, ${person.role} teacher at Solace Studio`}
                  className="aspect-[4/5] w-full object-cover grayscale-[0.15] transition-transform duration-700 hover:scale-[1.03]"
                />
              </div>
              <h3 className="mt-6 font-display text-2xl text-cream">{person.name}</h3>
              <p className="mt-1 text-xs uppercase tracking-[0.16em] text-mustard">{person.role}</p>
              <p className="mt-3 text-sm leading-relaxed text-cream/60 text-pretty">{person.line}</p>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  )
}
