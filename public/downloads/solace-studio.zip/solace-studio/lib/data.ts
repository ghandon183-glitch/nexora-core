export const studio = {
  name: 'Solace Studio',
  tagline: 'A quieter way to move',
  description:
    'Small-group yoga, pilates and strength in a calm room. Twelve mats, warm light, and teachers who remember your name.',
  address: '218 Alder Lane, Portland, OR 97209',
  email: 'hello@solacestudio.com',
  phone: '(503) 555-0142',
}

export const navLinks = [
  { label: 'Classes', href: '#classes' },
  { label: 'Trainers', href: '#trainers' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Contact', href: '#contact' },
]

export type ClassItem = {
  name: string
  duration: string
  level: 'Gentle' | 'All levels' | 'Intermediate' | 'Advanced'
  blurb: string
  icon: 'flow' | 'reformer' | 'strength' | 'restore' | 'hiit' | 'sound'
}

export const classes: ClassItem[] = [
  {
    name: 'Vinyasa Flow',
    duration: '60 min',
    level: 'All levels',
    blurb: 'Breath-led sequences that build heat slowly and end soft.',
    icon: 'flow',
  },
  {
    name: 'Reformer Pilates',
    duration: '50 min',
    level: 'Intermediate',
    blurb: 'Six reformers, precise cues, deep core work without strain.',
    icon: 'reformer',
  },
  {
    name: 'Strength Circuit',
    duration: '45 min',
    level: 'Intermediate',
    blurb: 'Kettlebells and dumbbells in a small, coached rotation.',
    icon: 'strength',
  },
  {
    name: 'Restorative Yoga',
    duration: '75 min',
    level: 'Gentle',
    blurb: 'Bolsters, blankets and long holds by candlelight.',
    icon: 'restore',
  },
  {
    name: 'HIIT Express',
    duration: '30 min',
    level: 'Advanced',
    blurb: 'A short, honest effort you can fit into a lunch break.',
    icon: 'hiit',
  },
  {
    name: 'Sound Bath',
    duration: '45 min',
    level: 'Gentle',
    blurb: 'Bowls, chimes and stillness. No movement required.',
    icon: 'sound',
  },
]

export const trainers = [
  {
    name: 'Maya Ellison',
    role: 'Yoga & Breathwork',
    line: 'Fifteen years on the mat, still teaches like it is her first week.',
    image: '/images/trainer-1.png',
  },
  {
    name: 'Andre Whitfield',
    role: 'Pilates & Strength',
    line: 'Believes good form beats heavy weight, every single time.',
    image: '/images/trainer-2.png',
  },
  {
    name: 'Rin Nakamura',
    role: 'Restorative & Sound',
    line: 'Builds classes for nervous systems, not for the mirror.',
    image: '/images/trainer-3.png',
  },
]

export const plans = [
  {
    name: 'Drop-in',
    price: '$26',
    unit: 'per class',
    note: 'No commitment, ever.',
    features: ['Any class on the schedule', 'Mat & props included', 'Book up to 7 days ahead'],
    featured: false,
  },
  {
    name: 'Monthly',
    price: '$149',
    unit: 'per month',
    note: 'Eight classes a month.',
    features: ['8 classes / month', 'Free guest pass each month', '10% off workshops', 'Pause anytime'],
    featured: true,
  },
  {
    name: 'Unlimited',
    price: '$219',
    unit: 'per month',
    note: 'For the everyday practice.',
    features: ['Unlimited classes', 'Priority reformer booking', '2 guest passes / month', 'Quarterly 1-on-1 check-in'],
    featured: false,
  },
]

export const testimonials = [
  {
    quote:
      'I came for the pilates and stayed for the room. It is the only hour of my week where nobody wants anything from me.',
    name: 'Elena R.',
    detail: 'Member since 2022',
    rating: 5,
  },
  {
    quote:
      'Twelve mats means the teacher actually watches you. My shoulder pain disappeared in six weeks of Strength Circuit.',
    name: 'Tomas K.',
    detail: 'Monthly member',
    rating: 5,
  },
  {
    quote:
      'The sound bath on Sunday evenings resets my whole week. I have never slept better than the nights after class.',
    name: 'Priya S.',
    detail: 'Unlimited member',
    rating: 5,
  },
]

export const gallery = [
  { image: '/images/gallery-1.png', alt: 'Rolled cream yoga mats stacked on an oak shelf' },
  { image: '/images/gallery-2.png', alt: 'A pilates reformer in the empty morning studio' },
  { image: '/images/gallery-3.png', alt: 'A small restorative yoga class lying on mats in candlelight' },
  { image: '/images/hero-studio.png', alt: 'Sunlight crossing the studio floor during a standing stretch' },
  { image: '/images/gallery-4.png', alt: 'Prop shelf detail with folded wool blankets and cork blocks' },
  { image: '/images/gallery-5.png', alt: 'Brass singing bowls and a mallet beside a lit candle' },
]

export const schedule = [
  { time: '06:30', name: 'Vinyasa Flow', teacher: 'Maya' },
  { time: '08:00', name: 'Reformer Pilates', teacher: 'Andre' },
  { time: '12:15', name: 'HIIT Express', teacher: 'Andre' },
  { time: '17:30', name: 'Strength Circuit', teacher: 'Andre' },
  { time: '19:00', name: 'Restorative Yoga', teacher: 'Rin' },
  { time: '20:15', name: 'Sound Bath', teacher: 'Rin' },
]
