# Quick Start

1. Extract the package.
2. Read README.md and the project documentation.
3. Install dependencies with the package manager used by the project.
4. Start the development server using the documented command.
5. Replace demo content, branding, links, and assets.
6. Configure environment variables and third-party services.
7. Run the production build before launch.

## Production checklist
- Replace demo content.
- Review asset licenses.
- Configure environment variables.
- Test responsive states, forms, navigation, and accessibility.
- Run the production build.
- Deploy and verify the live site.
