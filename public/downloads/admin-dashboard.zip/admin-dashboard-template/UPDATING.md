# Updating Admin Dashboard

There is no automatic updater in this ZIP. Check the Nexora product/download page for a newer release and review its changelog when available.

1. Back up your customized project and commit it to version control.
2. Download and extract the new release into a separate directory.
3. Compare files and merge changes rather than overwriting custom work blindly.
4. Keep package-lock.json in sync with package.json; use npm ci for a clean install.
5. Run npm run build where a build script exists, then test routes, forms, images, accessibility, and mobile layouts before deploying.
