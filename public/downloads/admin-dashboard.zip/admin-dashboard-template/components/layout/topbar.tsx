import { Search, Bell } from "lucide-react";
import ThemeToggle from "@/components/ui/theme-toggle";

export default function Topbar({ title }: { title: string }) {
  return (
    <header className="flex h-16 items-center justify-between border-b border-line px-6">

      <h1 className="font-display text-xl font-semibold text-text">
        {title}
      </h1>

      <div className="flex items-center gap-3">

        <div className="hidden items-center gap-2 rounded-lg border border-line bg-bg-sunken px-3 py-2 text-text-muted sm:flex">
          <Search size={14} />
          <span className="text-sm">Search…</span>
        </div>

        <button
          aria-label="Notifications"
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-line text-text-muted transition hover:border-amber hover:text-amber"
        >
          <Bell size={16} />
        </button>

        <ThemeToggle />

        <div className="h-9 w-9 rounded-full bg-teal text-center font-display text-sm font-semibold leading-9 text-white">
          N
        </div>

      </div>

    </header>
  );
}
