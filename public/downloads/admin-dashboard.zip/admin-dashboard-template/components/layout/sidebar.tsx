"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutGrid, Users, Settings, Radar } from "lucide-react";

const links = [
  { label: "Overview", href: "/", icon: LayoutGrid },
  { label: "Customers", href: "/customers", icon: Users },
  { label: "Settings", href: "/settings", icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="hidden w-64 shrink-0 border-r border-line bg-bg-sunken lg:flex lg:flex-col">

      <div className="flex h-16 items-center gap-2 border-b border-line px-6">
        <Radar size={20} className="text-amber" />
        <span className="font-display text-lg font-semibold text-text">
          Northstar
        </span>
      </div>

      <nav className="flex-1 space-y-1 p-4">
        {links.map((link) => {
          const isActive = pathname === link.href;
          const Icon = link.icon;

          return (
            <Link
              key={link.href}
              href={link.href}
              className={`flex items-center gap-3 rounded-lg border-l-2 px-3 py-2.5 text-sm transition ${
                isActive
                  ? "border-amber bg-amber/10 text-text font-medium"
                  : "border-transparent text-text-muted hover:bg-line/50 hover:text-text"
              }`}
            >
              <Icon size={16} />
              {link.label}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-line p-4">
        <p className="font-mono text-[11px] text-text-muted">
          Northstar Admin v1.0
        </p>
      </div>

    </aside>
  );
}
