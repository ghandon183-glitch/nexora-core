"use client";

import { useEffect, useRef, useState } from "react";
import { Bell } from "lucide-react";

const NOTIFICATIONS = [
  { title: "Trial converted", body: "Acme Studio moved to the Growth plan.", age: "12m" },
  { title: "Payment failed", body: "Card declined for Northwind Labs.", age: "1h" },
  { title: "New signup", body: "3 accounts created in the last hour.", age: "2h" },
];

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const container = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    const onClick = (event: MouseEvent) => {
      if (container.current && !container.current.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onClick);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("mousedown", onClick);
    };
  }, [open]);

  return (
    <div ref={container} className="relative">
      <button
        type="button"
        aria-label="Notifications"
        aria-expanded={open}
        aria-haspopup="dialog"
        onClick={() => setOpen((value) => !value)}
        className="flex h-9 w-9 items-center justify-center rounded-lg border border-line text-text-muted transition hover:border-amber hover:text-amber"
      >
        <Bell size={16} />
      </button>
      {open ? (
        <div
          role="dialog"
          aria-label="Notifications"
          className="absolute right-0 top-11 z-50 w-72 rounded-xl border border-line bg-bg p-4 shadow-xl"
        >
          <p className="font-display text-sm font-semibold text-text">Notifications</p>
          <ul className="mt-3 space-y-3">
            {NOTIFICATIONS.map((item) => (
              <li key={item.title} className="border-b border-line pb-3 last:border-0 last:pb-0">
                <p className="text-sm font-medium text-text">{item.title}</p>
                <p className="text-xs text-text-muted">{item.body}</p>
                <p className="mt-1 font-mono text-[11px] text-text-muted">{item.age} ago</p>
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="mt-4 w-full rounded-lg border border-line px-3 py-2 text-xs font-medium text-text-muted transition hover:text-text"
          >
            Close
          </button>
        </div>
      ) : null}
    </div>
  );
}
