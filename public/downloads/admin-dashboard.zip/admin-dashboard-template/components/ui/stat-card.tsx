import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import Card from "@/components/ui/card";

interface StatCardProps {
  label: string;
  value: string;
  change: string;
  trend: "up" | "down";
  live?: boolean;
}

export default function StatCard({ label, value, change, trend, live }: StatCardProps) {
  return (
    <Card className="p-5">

      <div className="flex items-center justify-between">
        <p className="text-xs text-text-muted">{label}</p>

        {live && (
          <span className="relative flex h-2 w-2">
            <span className="signal-dot absolute inline-flex h-2 w-2 rounded-full" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-amber" />
          </span>
        )}
      </div>

      <p className="mt-3 font-display text-3xl font-semibold text-text">
        {value}
      </p>

      <div
        className={`mt-2 flex items-center gap-1 text-xs font-medium ${
          trend === "up" ? "text-teal-bright" : "text-danger"
        }`}
      >
        {trend === "up" ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
        {change}
        <span className="text-text-muted">vs last month</span>
      </div>

    </Card>
  );
}
