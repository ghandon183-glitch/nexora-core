interface BadgeProps {
  children: React.ReactNode;
  variant?: "active" | "warning" | "neutral";
}

const variants = {
  active: "bg-teal/15 text-teal-bright border-teal/30",
  warning: "bg-danger/15 text-danger border-danger/30",
  neutral: "bg-line text-text-muted border-line",
};

export default function Badge({ children, variant = "neutral" }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center rounded-full border px-2.5 py-1 font-mono text-[11px] uppercase tracking-wide ${variants[variant]}`}
    >
      {children}
    </span>
  );
}
