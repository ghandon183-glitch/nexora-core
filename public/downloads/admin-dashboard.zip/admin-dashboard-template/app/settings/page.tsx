"use client";

import { useState } from "react";
import DashboardShell from "@/components/layout/dashboard-shell";
import Card from "@/components/ui/card";

export default function SettingsPage() {
  const [name, setName] = useState("Northstar Inc.");
  const [email, setEmail] = useState("billing@northstar.io");

  return (
    <DashboardShell title="Settings">

      <Card className="max-w-xl p-6">

        <p className="font-display text-lg font-semibold text-text">
          Workspace settings
        </p>

        <p className="mt-1 text-sm text-text-muted">
          Placeholder settings form — wire this up to your own backend.
        </p>

        <div className="mt-6 space-y-5">

          <div>
            <label className="mb-2 block text-sm text-text-muted">
              Workspace name
            </label>

            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full rounded-lg border border-line bg-bg-sunken px-4 py-2.5 text-sm text-text outline-none focus:border-amber"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm text-text-muted">
              Billing email
            </label>

            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border border-line bg-bg-sunken px-4 py-2.5 text-sm text-text outline-none focus:border-amber"
            />
          </div>

          <button className="rounded-lg bg-amber px-5 py-2.5 text-sm font-semibold text-[#1a1917] transition hover:bg-amber-bright">
            Save changes
          </button>

        </div>

      </Card>

    </DashboardShell>
  );
}
