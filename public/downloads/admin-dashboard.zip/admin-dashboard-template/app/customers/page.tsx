"use client";

import DashboardShell from "@/components/layout/dashboard-shell";
import Card from "@/components/ui/card";
import Badge from "@/components/ui/badge";
import { customers } from "@/lib/data";

const statusVariant = {
  active: "active" as const,
  past_due: "warning" as const,
  canceled: "neutral" as const,
};

export default function CustomersPage() {
  return (
    <DashboardShell title="Customers">

      <Card className="p-5">

        <div className="flex items-center justify-between">
          <p className="font-display text-lg font-semibold text-text">
            All customers
          </p>
          <p className="text-xs text-text-muted">{customers.length} total</p>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-line text-xs text-text-muted">
                <th className="pb-3 font-medium">Name</th>
                <th className="pb-3 font-medium">Plan</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">MRR</th>
                <th className="pb-3 font-medium">Joined</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-line">
              {customers.map((customer) => (
                <tr key={customer.id}>
                  <td className="py-3">
                    <p className="font-medium text-text">{customer.name}</p>
                    <p className="text-xs text-text-muted">{customer.email}</p>
                  </td>
                  <td className="py-3 text-text-muted">{customer.plan}</td>
                  <td className="py-3">
                    <Badge variant={statusVariant[customer.status]}>
                      {customer.status.replace("_", " ")}
                    </Badge>
                  </td>
                  <td className="py-3 font-mono text-text">${customer.mrr}</td>
                  <td className="py-3 text-text-muted">{customer.joined}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </Card>

    </DashboardShell>
  );
}
