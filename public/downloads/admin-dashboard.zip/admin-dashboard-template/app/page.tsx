"use client";

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
} from "recharts";

import DashboardShell from "@/components/layout/dashboard-shell";
import Card from "@/components/ui/card";
import Badge from "@/components/ui/badge";
import StatCard from "@/components/ui/stat-card";
import { revenueData, planBreakdown, stats, customers } from "@/lib/data";

const statusVariant = {
  active: "active" as const,
  past_due: "warning" as const,
  canceled: "neutral" as const,
};

export default function Overview() {
  return (
    <DashboardShell title="Overview">

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, i) => (
          <StatCard key={stat.label} {...stat} live={i === 0} />
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">

        <Card className="p-5 lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-display text-lg font-semibold text-text">
                Monthly recurring revenue
              </p>
              <p className="text-xs text-text-muted">Last 12 months</p>
            </div>

            <Badge variant="active">+68% YoY</Badge>
          </div>

          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="mrrGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F5A623" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#F5A623" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" vertical={false} />
                <XAxis dataKey="month" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(v) => `$${v / 1000}k`} />
                <Tooltip
                  contentStyle={{
                    background: "var(--bg-raised)",
                    border: "1px solid var(--line)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Area type="monotone" dataKey="mrr" stroke="#F5A623" strokeWidth={2} fill="url(#mrrGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <p className="font-display text-lg font-semibold text-text">
            Customers by plan
          </p>
          <p className="text-xs text-text-muted">Current distribution</p>

          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={planBreakdown} layout="vertical" margin={{ left: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" horizontal={false} />
                <XAxis type="number" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis dataKey="plan" type="category" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} width={70} />
                <Tooltip
                  contentStyle={{
                    background: "var(--bg-raised)",
                    border: "1px solid var(--line)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                <Bar dataKey="customers" fill="#0F5257" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

      </div>

      <Card className="mt-6 p-5">

        <div className="flex items-center justify-between">
          <p className="font-display text-lg font-semibold text-text">
            Recent customers
          </p>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-line text-xs text-text-muted">
                <th className="pb-3 font-medium">Name</th>
                <th className="pb-3 font-medium">Plan</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium">MRR</th>
                <th className="pb-3 font-medium">Joined</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-line">
              {customers.slice(0, 5).map((customer) => (
                <tr key={customer.id}>
                  <td className="py-3">
                    <p className="font-medium text-text">{customer.name}</p>
                    <p className="text-xs text-text-muted">{customer.email}</p>
                  </td>
                  <td className="py-3 text-text-muted">{customer.plan}</td>
                  <td className="py-3">
                    <Badge variant={statusVariant[customer.status]}>
                      {customer.status.replace("_", " ")}
                    </Badge>
                  </td>
                  <td className="py-3 font-mono text-text">${customer.mrr}</td>
                  <td className="py-3 text-text-muted">{customer.joined}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </Card>

    </DashboardShell>
  );
}
