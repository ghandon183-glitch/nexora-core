# Admin Dashboard — Nexora Core Template

A subscription analytics admin dashboard template built with Next.js (App
Router), Tailwind CSS v4, TypeScript, and Recharts. Ships with a working
light/dark theme toggle, a sidebar + topbar shell, and three pages.

## What's inside

- `app/page.tsx` — Overview: stat cards, an MRR area chart, a plan
  breakdown bar chart, and a recent-customers table
- `app/customers/page.tsx` — full customers table
- `app/settings/page.tsx` — a placeholder settings form
- `components/layout/` — Sidebar, Topbar, DashboardShell (wraps every page)
- `components/ui/` — Card, Badge, StatCard, ThemeToggle
- `lib/data.ts` — all the mock data used across the dashboard
- `lib/use-theme.ts` — the light/dark theme hook

## Getting started

```bash
npm install
npm run dev
```

Open `http://localhost:3000` to see it running.

## Customizing

1. **Data**: Replace the arrays in `lib/data.ts` with real data from your
   own API or database.
2. **Colors & fonts**: Design tokens live in `app/globals.css` under
   `:root`, `[data-theme="dark"]`, and `[data-theme="light"]`.
3. **Navigation**: Add or remove pages by editing the `links` array in
   `components/layout/sidebar.tsx` and creating a matching folder under
   `app/`.
4. **Charts**: Built with [Recharts](https://recharts.org) — swap chart
   types or add new ones using their documented components.

## License

This template is licensed for use in your own personal or commercial
projects, including client work. You may not resell or redistribute the
source code itself as a standalone template or product.
