export const revenueData = [
  { month: "Jan", mrr: 18200, lastYear: 12800 },
  { month: "Feb", mrr: 19600, lastYear: 13400 },
  { month: "Mar", mrr: 21100, lastYear: 14100 },
  { month: "Apr", mrr: 22800, lastYear: 15200 },
  { month: "May", mrr: 24500, lastYear: 16000 },
  { month: "Jun", mrr: 26900, lastYear: 17300 },
  { month: "Jul", mrr: 29400, lastYear: 18100 },
  { month: "Aug", mrr: 31200, lastYear: 19400 },
  { month: "Sep", mrr: 33800, lastYear: 20600 },
  { month: "Oct", mrr: 36100, lastYear: 21900 },
  { month: "Nov", mrr: 38700, lastYear: 23200 },
  { month: "Dec", mrr: 41500, lastYear: 24800 },
];

export const planBreakdown = [
  { plan: "Starter", customers: 412 },
  { plan: "Growth", customers: 268 },
  { plan: "Scale", customers: 94 },
  { plan: "Enterprise", customers: 21 },
];

export const stats = [
  { label: "Monthly recurring revenue", value: "$41,500", change: "+7.2%", trend: "up" as const },
  { label: "Active customers", value: "795", change: "+3.4%", trend: "up" as const },
  { label: "Churn rate", value: "1.8%", change: "-0.3%", trend: "up" as const },
  { label: "New signups (30d)", value: "86", change: "-4.1%", trend: "down" as const },
];

export interface Customer {
  id: string;
  name: string;
  email: string;
  plan: "Starter" | "Growth" | "Scale" | "Enterprise";
  status: "active" | "past_due" | "canceled";
  mrr: number;
  joined: string;
}

export const customers: Customer[] = [
  { id: "cus_1", name: "Priya Nair", email: "priya@fieldnote.io", plan: "Scale", status: "active", mrr: 249, joined: "2025-11-02" },
  { id: "cus_2", name: "Marcus Webb", email: "marcus@papercrane.co", plan: "Growth", status: "active", mrr: 89, joined: "2025-12-18" },
  { id: "cus_3", name: "Elena Torres", email: "elena@wrenandidle.com", plan: "Enterprise", status: "active", mrr: 899, joined: "2025-08-27" },
  { id: "cus_4", name: "Sam Okafor", email: "sam@harborco.com", plan: "Starter", status: "past_due", mrr: 29, joined: "2026-01-14" },
  { id: "cus_5", name: "Julia Lindqvist", email: "julia@kettle.studio", plan: "Growth", status: "active", mrr: 89, joined: "2025-09-30" },
  { id: "cus_6", name: "Tomas Reyes", email: "tomas@northfield.design", plan: "Scale", status: "canceled", mrr: 0, joined: "2025-05-11" },
  { id: "cus_7", name: "Aisha Bello", email: "aisha@fernway.co", plan: "Starter", status: "active", mrr: 29, joined: "2026-02-02" },
  { id: "cus_8", name: "David Kim", email: "david@loomstack.io", plan: "Enterprise", status: "active", mrr: 899, joined: "2025-07-19" },
];
