# Support & Updates

## Included
- Installation and setup questions.
- Clarification of documented template behavior.
- Reasonable troubleshooting of reproducible issues in the supplied source.
- Published template updates while the product is maintained.

## Not included
- Custom development or bespoke integrations.
- Copywriting, branding, photography, or content production.
- Hosting, domains, paid APIs, or third-party service fees.

## For faster support
Include the template version, OS, Node.js version, package-manager version, the command that failed, and the complete error output.
