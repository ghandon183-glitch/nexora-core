# Package Contents

This archive contains the editable source code for the purchased template plus the documentation needed to install, customize, and deploy it.

Review README.md first. Demo branding, text, imagery, testimonials, pricing, contact details, and third-party integrations should be replaced or configured for the buyer's project.
