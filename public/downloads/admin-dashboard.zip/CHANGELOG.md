# Changelog

## 1.0.0
- Customer-ready commercial package.
- Standard license and support documentation.
- Installation and production checklist included.
