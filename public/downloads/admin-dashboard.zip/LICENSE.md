# Nexora Core — Single End Product License

Copyright © 2026 Nexora Core. All rights reserved.

This package is licensed, not sold, to the purchaser. One purchase grants one license for one finished end product.

## You may
- Use the source in one personal, commercial, or client-facing end product.
- Modify, extend, restyle, refactor, and combine the source with your own code.
- Deploy the finished end product publicly, including hosted and SaaS applications.
- Keep private development and backup copies.

## You may not
- Resell, redistribute, sublicense, publish, or share the source package itself.
- Offer the source as a template, UI kit, boilerplate, starter kit, theme, or competing marketplace product.
- Give the reusable source package to a client as a standalone deliverable.
- Claim the original template source as your own work.
- Use the package to create a competing source-code marketplace or library.

## Client work
You may build a finished website or application for a client. The client may receive the finished end product, but not the reusable template source as a separate product.

## Multiple end products
One purchase covers one end product. Independent products or separate client deliverables require additional licenses unless a written agreement says otherwise.

## Third-party assets
Fonts, photographs, icons, illustrations, logos, and other third-party assets remain subject to their own licenses. Review the project notes and replace demo assets when necessary.

## Updates and support
Future updates are included while Nexora Core maintains the purchased template. Support covers installation and documented template behavior. Custom development, hosting, paid third-party services, and bespoke integrations are outside standard support.

## Warranty and liability
The package is provided as source code for development use. To the maximum extent permitted by applicable law, Nexora Core disclaims warranties for uninterrupted operation, third-party services, future dependency changes, and fitness for a particular purpose.

If a written order-specific agreement conflicts with these terms, that written agreement controls.
