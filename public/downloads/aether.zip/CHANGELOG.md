# Changelog — AETHER

## 1.0.1

Packaging, honesty and lint-hardening pass. No visual redesign.

### Fixed
- **Five raw `<img>` elements** replaced with `next/image` in
  `components/site/hero.tsx`, `components/site/studio.tsx`,
  `components/site/projects.tsx`, `components/site/footer.tsx` and
  `components/webgl/hero-scene.tsx`. This resolves the five
  `@next/next/no-img-element` warnings, adds explicit sizing/`sizes` hints and
  keeps the WebGL fallback image identical.
- **Dead case-study control removed.** Each project image was wrapped in an
  anchor pointing at `#work` (its own section) with a "View case study" chip,
  implying detail pages that do not exist. Cards are now static figures with the
  image, category, client and description; the parallax and hover treatment stay.
- **"Process" anchor had no destination.** The navigation and footer both linked
  to `#process`, but the four-step process data in `lib/site-data.ts` was never
  rendered. The process section now exists ("How we work"), so the link is real;
  the footer's studio column also pointed at a non-existent `#services` and now
  links Work / Studio / Process / Contact.
- **Placeholder contact address** changed from a real-looking `.studio` domain to
  `hello@aether.example`, and the footer now reads the address from
  `lib/site-data.ts` instead of duplicating it in three places.
- **`tsconfig.tsbuildinfo`** (a 200 KB TypeScript build artifact) was shipped in
  the archive; it is now git-ignored and excluded from the package.
- **`components.json`** (configuration for the shadcn CLI, which is no longer a
  dependency) removed.
- `npm audit` now reports **0 vulnerabilities** (it previously reported a
  high-severity `deepmerge` advisory and a moderate `minimatch` advisory through
  the unused `shadcn` CLI dependency).

### Changed
- `next` and `eslint-config-next` bumped to **16.4.5**.
- **`shadcn` dependency removed.** The stylesheet it provided
  (`shadcn/tailwind.css`, 16 KB of generic Tailwind v4 utilities) is now vendored
  at `app/vendor/shadcn-tailwind.css` with its MIT notice, so the build no longer
  depends on a CLI package — and no longer pulls that package's advisories.
- A scoped `overrides` entry pins `minimatch` inside
  `@typescript-eslint/typescript-estree` to `^11.0.1`, clearing the remaining
  moderate advisory in the lint toolchain.
- `package.json` declares `engines.node >= 20.9.0`, adds `npm run typecheck`, and
  drops the unused pnpm-only `hono` override.

### Added
- `.env.example` documenting `NEXT_PUBLIC_BASE_PATH` and `NEXT_PUBLIC_SITE_URL`.
- `app/robots.ts`, `app/sitemap.ts` and a branded `app/not-found.tsx`.
- `metadataBase` (from `NEXT_PUBLIC_SITE_URL`) so Open Graph URLs resolve
  absolutely; the `v0.app` generator tag was removed.
- Complete customer documentation: rewritten README, QUICKSTART, CONTENTS,
  SUPPORT and ASSET-LICENSES.

## 1.0.0
- Initial customer package: WebGL hero, motion system, six case studies, studio
  manifesto, marquee and contact footer.
