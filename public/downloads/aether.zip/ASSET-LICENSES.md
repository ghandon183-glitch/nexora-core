# Asset & Third-Party Licenses — AETHER

This manifest covers what actually ships in this archive. It is not a grant of
rights beyond the licenses named here.

## 1. Demo imagery — `public/images/` (9 PNG files)

`hero-fallback.png`, `project-01.png` … `project-06.png`, `studio-portrait.png`,
`texture-abstract.png`.

These are **demo assets supplied with the template** to make the layout look
finished. They are not photographs of a real studio, and the people, brands and
projects they suggest are fictional. Treat them as placeholders: before shipping,
either confirm you hold the rights to use each file commercially or replace it
with your own artwork. Keep the filenames (or update the paths in
`lib/site-data.ts` and the components) when replacing.

## 2. Icons and placeholders

`public/icon.svg`, `icon-dark-32x32.png`, `icon-light-32x32.png`,
`apple-icon.png`, `placeholder.svg`, `placeholder.png`, `placeholder-logo.svg`,
`placeholder-logo.png`, `placeholder-user.jpg` — original neutral artwork created
for this template. Use, modify and redistribute them with the template.

## 3. Fonts

Loaded at build time through `next/font/google` in `app/layout.tsx`:

| Font | Used for | License |
| --- | --- | --- |
| Geist | body sans-serif | SIL Open Font License 1.1 |
| Geist Mono | monospace accents | SIL Open Font License 1.1 |
| Instrument Serif | display serif | SIL Open Font License 1.1 |

The font files are fetched by Next.js during `npm run build`, not redistributed in
this archive. If you self-host them instead, include the OFL text with your site.

## 4. Vendored stylesheet

`app/vendor/shadcn-tailwind.css` — copied from the `shadcn` package v4.23.0
(`dist/tailwind.css`), 16 KB of generic Tailwind v4 utilities.

```
MIT License — Copyright (c) 2023 shadcn

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```

## 5. npm libraries (installed from the registry, not vendored here)

| Package | License |
| --- | --- |
| `next`, `react`, `react-dom`, `eslint-config-next` | MIT |
| `three`, `@react-three/fiber`, `@react-three/drei` | MIT |
| `framer-motion` | MIT |
| `@base-ui/react` | MIT |
| `class-variance-authority`, `clsx`, `tailwind-merge` | MIT |
| `lucide-react` | ISC |
| `tailwindcss`, `@tailwindcss/postcss`, `tw-animate-css` | MIT |
| `typescript` | Apache-2.0 |
| `eslint` and its plugins | MIT |

Each package ships its own license text in `node_modules/`; keep those files when
redistributing a built site.

## 6. External services

None. The template makes no runtime requests to third-party APIs, analytics or
tracking services. The only network dependency is the Google Fonts download
during `npm run build`, plus your own asset host if you move images to a CDN.

## 7. Customer responsibility

You are responsible for the final site's content, imagery, fonts, trademarks and
third-party services. Replace the demo case studies, client names, statistics and
contact details before launch — they are fictional sample content.
