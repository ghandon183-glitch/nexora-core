# Quick Start — AETHER

Five commands from archive to running site. Node.js 20.9+ required.

```bash
# 1. extract, then enter the folder that contains package.json
cd aether

# 2. install the locked dependency tree
npm ci

# 3. run the dev server → http://localhost:3000
npm run dev
```

Production:

```bash
npm run build
npm start
```

Sub-path build (e.g. the marketplace demo at `/demo/aether`):

```bash
NEXT_PUBLIC_BASE_PATH=/demo/aether npm run build
npm start
```

Quality gates before you ship:

```bash
npm run lint
npm run typecheck
npm run build
```

## First edits

1. `lib/site-data.ts` — projects, services, process, stats, clients, nav, contact.
2. `public/images/` — replace the nine PNGs, keeping filenames.
3. `app/layout.tsx` — page title, description, Open Graph copy, fonts.
4. `app/globals.css` — colour, radius and type tokens.
5. `.env.example` → `.env.local` — set `NEXT_PUBLIC_SITE_URL` for social previews.

## Before launch

- Replace every placeholder: case studies, stats, client names, social links,
  `hello@aether.example` and the 555 phone number.
- Convert the PNG artwork to WebP/AVIF and serve it from your CDN.
- Decide where contact should go — the footer uses `mailto:`/`tel:`; add your own
  form or booking tool if you need one.
- Choose a production mode: `next start` on a Node host (security headers from
  `next.config.mjs` apply), or a static/CDN setup where you replicate those
  headers yourself.
- Re-run `npm run lint`, `npm run typecheck` and `npm run build`.
