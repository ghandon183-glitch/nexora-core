# Support — AETHER

Current version: **1.0.1**

## Included in support
- Installation and setup questions for the supplied source.
- Clarification of documented behaviour (build modes, base path, environment
  variables, fallbacks).
- Reasonable troubleshooting of reproducible defects in the template code.
- Published updates while the product is maintained.

## Not included
- Custom development, new sections, or bespoke integrations.
- Copywriting, branding, photography or content production.
- Hosting, domains, CDNs, paid APIs or any third-party service fees.
- Debugging of code you have modified, or of platform-specific hosting issues.

## Before you report an issue
1. Run the checks and note the results:
   ```bash
   node -v
   npm -v
   npm ci
   npm run lint
   npm run typecheck
   npm run build
   ```
2. Confirm you are on the version above (`package.json` → `version`).
3. Note the exact command, the full error output, your OS and Node version.
4. If the problem only appears under a sub-path, include the
   `NEXT_PUBLIC_BASE_PATH` value you used and the failing URL.

## Known limitations (not defects)
- Case studies are demo content and have no detail pages — the cards are static by
  design.
- There is no contact form, CRM, booking or payment backend; the site uses
  `mailto:` and `tel:` links.
- Social links point at the platforms' home pages and are placeholders.
- The WebGL hero needs a browser with WebGL; otherwise the static fallback image
  is shown (this is expected behaviour, not an error).
- Building downloads Google Fonts through `next/font`, so the build machine needs
  network access.
- Source images are uncompressed PNGs; convert them for production.
