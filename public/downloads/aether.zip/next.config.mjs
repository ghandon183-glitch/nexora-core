/** @type {import('next').NextConfig} */
const nextConfig = {
  // Set NEXT_PUBLIC_BASE_PATH when the site is served from a sub-path, e.g.
  // the marketplace demo at /demo/aether. Paired with lib/asset-path.ts for
  // the public assets Next.js does not rewrite itself.
  basePath: process.env.NEXT_PUBLIC_BASE_PATH || undefined,
  images: {
    unoptimized: true,
  },
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=63072000; includeSubDomains',
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()',
          },
        ],
      },
    ]
  },
}

export default nextConfig
