// Files under /public are referenced with root-relative URLs, and Next.js does
// not rewrite those when the app is built with a basePath (as the marketplace
// demo is). Prefix them here so the same source works standalone at "/" and
// under "/demo/aether".
//
// Buyers running the template at the domain root leave the variable unset, so
// every path below stays exactly as before.
export const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || ''

export function assetPath(path: string): string {
  return `${BASE_PATH}${path}`
}
