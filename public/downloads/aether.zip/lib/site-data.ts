export type Project = {
  id: string
  index: string
  title: string
  client: string
  category: string
  year: string
  image: string
  description: string
  services: string[]
}

export const projects: Project[] = [
  {
    id: 'aurelia',
    index: '01',
    title: 'Aurelia',
    client: 'Aurelia Parfums',
    category: 'Brand Identity',
    year: '2025',
    image: '/images/project-01.png',
    description:
      'A full sensory rebrand for a niche fragrance house — identity, packaging and a scent-led digital flagship that made a smell feel visible.',
    services: ['Identity', 'Packaging', 'Web'],
  },
  {
    id: 'monolith',
    index: '02',
    title: 'Monolith',
    client: 'Monolith Studios',
    category: 'Art Direction',
    year: '2025',
    image: '/images/project-02.png',
    description:
      'Spatial art direction for an architecture practice, translating brutalist form into a living visual system that moves with the light.',
    services: ['Art Direction', 'Systems', 'Motion'],
  },
  {
    id: 'seiden',
    index: '03',
    title: 'Seiden',
    client: 'Seiden Atelier',
    category: 'Campaign',
    year: '2024',
    image: '/images/project-03.png',
    description:
      'A couture campaign built around movement, texture and light for a Milan-based silk atelier — film, print and a living lookbook.',
    services: ['Campaign', 'Film', 'Editorial'],
  },
  {
    id: 'volt',
    index: '04',
    title: 'Volt',
    client: 'Volt Motors',
    category: 'Digital Product',
    year: '2024',
    image: '/images/project-04.png',
    description:
      'A configurator and launch experience for an electric flagship — motion, spatial sound and a cinematic reveal engineered to convert.',
    services: ['Product', 'WebGL', 'Sound'],
  },
  {
    id: 'edition',
    index: '05',
    title: 'Edition',
    client: 'Edition Press',
    category: 'Editorial',
    year: '2024',
    image: '/images/project-05.png',
    description:
      'An editorial system for a collectible print quarterly, blending gold-foil craft with a fluid, unmistakably modern grid.',
    services: ['Editorial', 'Print', 'Identity'],
  },
  {
    id: 'flux',
    index: '06',
    title: 'Flux',
    client: 'Flux Collective',
    category: 'Motion & 3D',
    year: '2023',
    image: '/images/project-06.png',
    description:
      'A generative brand world of liquid chrome — a real-time 3D identity for a creative technology label that is never the same twice.',
    services: ['3D', 'Generative', 'Motion'],
  },
]

export const services = [
  {
    title: 'Brand Systems',
    body: 'Identity, voice and living design systems engineered to scale across every surface without losing their soul.',
  },
  {
    title: 'Art Direction',
    body: 'Campaign concepts, photography and cinematic direction delivered with obsessive, frame-by-frame craft.',
  },
  {
    title: 'Interactive',
    body: 'WebGL, motion and product experiences that make a brand feel physical, tactile and alive in the hand.',
  },
  {
    title: 'Spatial & 3D',
    body: 'Real-time worlds, configurators and immersive environments built to perform at sixty frames a second.',
  },
]

export type ProcessStep = {
  no: string
  title: string
  body: string
}

export const process: ProcessStep[] = [
  {
    no: '01',
    title: 'Immerse',
    body: 'We embed with your team, absorb the category and interrogate every assumption until the real opportunity is impossible to miss.',
  },
  {
    no: '02',
    title: 'Define',
    body: 'Strategy becomes a sharp, quotable idea — a single north star that every pixel, word and frame can be measured against.',
  },
  {
    no: '03',
    title: 'Craft',
    body: 'Designers and engineers work in the same room, prototyping in real materials so the work is felt long before it is finished.',
  },
  {
    no: '04',
    title: 'Launch',
    body: 'We ship, measure and refine — staying close after go-live so the brand keeps compounding instead of fading.',
  },
]

export const stats = [
  { value: '14', label: 'Years crafting' },
  { value: '38', label: 'Awards won' },
  { value: '120+', label: 'Brands shipped' },
  { value: '26', label: 'Countries reached' },
]

export const clients = [
  'Aurelia',
  'Monolith',
  'Seiden',
  'Volt',
  'Edition',
  'Flux',
  'Lumen',
  'Atlas',
  'Verre',
]

export const navLinks = [
  { label: 'Studio', href: '#studio' },
  { label: 'Work', href: '#work' },
  { label: 'Process', href: '#process' },
  { label: 'Contact', href: '#contact' },
]

export const studio = {
  email: 'hello@aether.studio',
  phone: '+1 (310) 555-0142',
  phoneHref: 'tel:+13105550142',
  location: 'Los Angeles & worldwide',
}
