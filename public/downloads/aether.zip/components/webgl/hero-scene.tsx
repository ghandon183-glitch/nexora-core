'use client'

import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { useEffect, useMemo, useRef, useState } from 'react'
import * as THREE from 'three'

/* ---------------------------------------------------------------------------
 * AETHER hero — a living, mouse-reactive atmosphere.
 *   Layer 1  Displaced icosphere (3D simplex noise) — the "core"
 *   Layer 2  Drifting particle field with additive glow — the "atmosphere"
 *   Layer 3  CSS radial glow + gradient wash (in the wrapping section)
 * All layers respond to an inertia-eased pointer and settle when idle.
 * ------------------------------------------------------------------------- */

const vertexShader = /* glsl */ `
  uniform float uTime;
  uniform vec2 uPointer;
  uniform float uActive;
  uniform float uScroll;
  varying vec3 vNormal;
  varying vec3 vPosition;
  varying float vDisp;

  vec4 permute(vec4 x){return mod(((x*34.0)+1.0)*x,289.0);}
  vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
  float snoise(vec3 v){
    const vec2 C=vec2(1.0/6.0,1.0/3.0);
    const vec4 D=vec4(0.0,0.5,1.0,2.0);
    vec3 i=floor(v+dot(v,C.yyy));
    vec3 x0=v-i+dot(i,C.xxx);
    vec3 g=step(x0.yzx,x0.xyz);
    vec3 l=1.0-g;
    vec3 i1=min(g.xyz,l.zxy);
    vec3 i2=max(g.xyz,l.zxy);
    vec3 x1=x0-i1+1.0*C.xxx;
    vec3 x2=x0-i2+2.0*C.xxx;
    vec3 x3=x0-1.0+3.0*C.xxx;
    i=mod(i,289.0);
    vec4 p=permute(permute(permute(
      i.z+vec4(0.0,i1.z,i2.z,1.0))
      +i.y+vec4(0.0,i1.y,i2.y,1.0))
      +i.x+vec4(0.0,i1.x,i2.x,1.0));
    float n_=1.0/7.0;
    vec3 ns=n_*D.wyz-D.xzx;
    vec4 j=p-49.0*floor(p*ns.z*ns.z);
    vec4 x_=floor(j*ns.z);
    vec4 y_=floor(j-7.0*x_);
    vec4 x=x_*ns.x+ns.yyyy;
    vec4 y=y_*ns.x+ns.yyyy;
    vec4 h=1.0-abs(x)-abs(y);
    vec4 b0=vec4(x.xy,y.xy);
    vec4 b1=vec4(x.zw,y.zw);
    vec4 s0=floor(b0)*2.0+1.0;
    vec4 s1=floor(b1)*2.0+1.0;
    vec4 sh=-step(h,vec4(0.0));
    vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy;
    vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
    vec3 p0=vec3(a0.xy,h.x);
    vec3 p1=vec3(a0.zw,h.y);
    vec3 p2=vec3(a1.xy,h.z);
    vec3 p3=vec3(a1.zw,h.w);
    vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3)));
    p0*=norm.x;p1*=norm.y;p2*=norm.z;p3*=norm.w;
    vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0);
    m=m*m;
    return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3)));
  }

  void main(){
    vNormal = normal;
    float t = uTime * 0.26;
    vec3 samplePos = position + vec3(uPointer * 1.35, 0.0);
    float n = snoise(samplePos * 0.85 + vec3(t, t * 0.7, t * 0.5));
    float n2 = snoise(samplePos * 2.0 - vec3(t * 0.6));
    float n3 = snoise(samplePos * 4.0 + vec3(t * 1.1));
    float amp = 0.30 + uActive * 0.5 + uScroll * 0.16;
    float disp = (n * 0.62 + n2 * 0.3 + n3 * 0.08) * amp;
    vDisp = disp;
    vec3 displaced = position + normal * disp;
    vPosition = displaced;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(displaced, 1.0);
  }
`

const fragmentShader = /* glsl */ `
  uniform float uTime;
  uniform vec2 uPointer;
  uniform float uActive;
  uniform vec3 uColorA;
  uniform vec3 uColorB;
  uniform vec3 uColorC;
  varying vec3 vNormal;
  varying vec3 vPosition;
  varying float vDisp;

  void main(){
    vec3 normal = normalize(vNormal);
    vec3 lightDir = normalize(vec3(uPointer * 1.6, 1.0));
    float diff = clamp(dot(normal, lightDir), 0.0, 1.0);
    vec3 viewDir = normalize(cameraPosition - vPosition);
    float fres = pow(1.0 - clamp(dot(viewDir, normal), 0.0, 1.0), 2.2);

    // smooth color shift driven by pointer + displacement + slow time cycle
    float cycle = 0.5 + 0.5 * sin(uTime * 0.2);
    float mixT = clamp(0.5 + vDisp * 0.85 + uPointer.x * 0.32, 0.0, 1.0);
    vec3 base = mix(uColorA, uColorB, mixT);
    base = mix(base, uColorC, clamp(uPointer.y * 0.5 + 0.5, 0.0, 1.0) * (0.45 + cycle * 0.25));

    vec3 color = base * (0.24 + diff * 0.92);
    color += uColorC * fres * (0.85 + uActive * 1.25);
    color += diff * diff * 0.16;

    gl_FragColor = vec4(color, 1.0);
  }
`

function Core({ reducedMotion }: { reducedMotion: boolean }) {
  const mesh = useRef<THREE.Mesh>(null)
  const mat = useRef<THREE.ShaderMaterial>(null)
  const { size } = useThree()

  const pointer = useRef(new THREE.Vector2(0, 0))
  const target = useRef(new THREE.Vector2(0, 0))
  const active = useRef(0)
  const lastMove = useRef(0)

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uPointer: { value: new THREE.Vector2(0, 0) },
      uActive: { value: 0 },
      uScroll: { value: 0 },
      uColorA: { value: new THREE.Color('#26211a') },
      uColorB: { value: new THREE.Color('#c9a25b') },
      uColorC: { value: new THREE.Color('#f0e2c2') },
    }),
    [],
  )

  useEffect(() => {
    const handleMove = (x: number, y: number) => {
      target.current.set(
        (x / window.innerWidth) * 2 - 1,
        -(y / window.innerHeight) * 2 + 1,
      )
      lastMove.current = performance.now()
    }
    const onPointer = (e: PointerEvent) => handleMove(e.clientX, e.clientY)
    const onTouch = (e: TouchEvent) => {
      if (e.touches[0]) handleMove(e.touches[0].clientX, e.touches[0].clientY)
    }
    let scroll = 0
    const onScroll = () => {
      scroll = Math.min(window.scrollY / (window.innerHeight || 1), 1)
    }
    window.addEventListener('pointermove', onPointer, { passive: true })
    window.addEventListener('touchmove', onTouch, { passive: true })
    window.addEventListener('scroll', onScroll, { passive: true })
    ;(Core as any)._pointer = () => pointer.current
    ;(Core as any)._scroll = () => scroll
    return () => {
      window.removeEventListener('pointermove', onPointer)
      window.removeEventListener('touchmove', onTouch)
      window.removeEventListener('scroll', onScroll)
    }
  }, [])

  useFrame((state, delta) => {
    if (!mat.current) return
    const d = Math.min(delta, 0.05)
    pointer.current.lerp(target.current, 1 - Math.pow(0.0015, d))
    const idle = performance.now() - lastMove.current
    const moving = idle < 120 ? 1 : 0
    active.current += (moving - active.current) * (1 - Math.pow(0.02, d))

    const u = mat.current.uniforms
    u.uTime.value = state.clock.elapsedTime * (reducedMotion ? 0.15 : 1)
    u.uPointer.value.copy(pointer.current)
    u.uActive.value = reducedMotion ? 0 : active.current
    u.uScroll.value = (Core as any)._scroll ? (Core as any)._scroll() : 0

    if (mesh.current) {
      const tRot = reducedMotion ? 0.02 : 0.06
      mesh.current.rotation.y += delta * tRot
      mesh.current.rotation.x =
        pointer.current.y * 0.3 + Math.sin(state.clock.elapsedTime * 0.2) * 0.05
      mesh.current.rotation.z = -pointer.current.x * 0.15
      // gentle floating drift
      mesh.current.position.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.06
    }
  })

  const detail = size.width < 640 ? 24 : 64

  return (
    <mesh ref={mesh} scale={size.width < 640 ? 1.3 : 1.65}>
      <icosahedronGeometry args={[1, detail]} />
      <shaderMaterial
        ref={mat}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
      />
    </mesh>
  )
}

function Atmosphere({ reducedMotion }: { reducedMotion: boolean }) {
  const points = useRef<THREE.Points>(null)
  const { size } = useThree()
  const count = size.width < 640 ? 320 : 900

  const { geometry, texture } = useMemo(() => {
    const positions = new Float32Array(count * 3)
    const scales = new Float32Array(count)
    for (let i = 0; i < count; i++) {
      // distribute in a soft spherical shell around the core
      const r = 2.2 + Math.random() * 3.4
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta)
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta) * 0.7
      positions[i * 3 + 2] = r * Math.cos(phi) - 1.5
      scales[i] = Math.random()
    }
    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    geo.setAttribute('aScale', new THREE.BufferAttribute(scales, 1))

    // soft round sprite
    const c = document.createElement('canvas')
    c.width = c.height = 64
    const ctx = c.getContext('2d')!
    const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32)
    grad.addColorStop(0, 'rgba(255,244,214,1)')
    grad.addColorStop(0.4, 'rgba(230,205,150,0.5)')
    grad.addColorStop(1, 'rgba(230,205,150,0)')
    ctx.fillStyle = grad
    ctx.fillRect(0, 0, 64, 64)
    const tex = new THREE.CanvasTexture(c)

    return { geometry: geo, texture: tex }
  }, [count])

  useFrame((state, delta) => {
    if (!points.current) return
    const p = (Core as any)._pointer ? (Core as any)._pointer() : { x: 0, y: 0 }
    const spd = reducedMotion ? 0.15 : 1
    points.current.rotation.y += delta * 0.03 * spd
    points.current.rotation.x += delta * 0.008 * spd
    // pointer parallax
    points.current.position.x += (p.x * 0.6 - points.current.position.x) * 0.04
    points.current.position.y += (p.y * 0.4 - points.current.position.y) * 0.04
  })

  return (
    <points ref={points}>
      <primitive object={geometry} attach="geometry" />
      <pointsMaterial
        size={size.width < 640 ? 0.09 : 0.12}
        map={texture}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        opacity={0.9}
        sizeAttenuation
      />
    </points>
  )
}

function Scene({ reducedMotion }: { reducedMotion: boolean }) {
  return (
    <>
      <Core reducedMotion={reducedMotion} />
      <Atmosphere reducedMotion={reducedMotion} />
    </>
  )
}

export default function HeroScene({
  reducedMotion = false,
}: {
  reducedMotion?: boolean
}) {
  const [failed, setFailed] = useState(false)

  if (failed) {
    return (
      <img
        src="/images/hero-fallback.png"
        alt="Abstract luxury creative studio composition"
        className="h-full w-full object-cover opacity-80"
      />
    )
  }

  return (
    <Canvas
      camera={{ position: [0, 0, 4.2], fov: 45 }}
      dpr={[1, 1.75]}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      onCreated={({ gl }) => {
        gl.setClearColor(0x000000, 0)
      }}
      onError={() => setFailed(true)}
    >
      <Scene reducedMotion={reducedMotion} />
    </Canvas>
  )
}
