'use client'

import { useEffect, useRef, useState } from 'react'

/**
 * Inertia-based blend cursor.
 * - A large soft dot that eases toward the pointer with spring-like lag
 * - Grows and switches to an outlined ring over interactive elements
 * - Shows a text label when hovering elements with [data-cursor]
 * - Only mounts on fine pointers (never interferes with touch / a11y)
 */
export function Cursor() {
  const dot = useRef<HTMLDivElement>(null)
  const ring = useRef<HTMLDivElement>(null)
  const [enabled, setEnabled] = useState(false)
  const [label, setLabel] = useState('')
  const [variant, setVariant] = useState<'default' | 'link' | 'view'>('default')

  useEffect(() => {
    const fine = window.matchMedia('(pointer: fine)').matches
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (!fine || reduced) return
    setEnabled(true)
    document.documentElement.classList.add('has-cursor')

    const target = { x: window.innerWidth / 2, y: window.innerHeight / 2 }
    const ringPos = { x: target.x, y: target.y }
    let raf = 0
    let visible = false

    const onMove = (e: PointerEvent) => {
      target.x = e.clientX
      target.y = e.clientY
      if (!visible) {
        visible = true
        if (dot.current) dot.current.style.opacity = '1'
        if (ring.current) ring.current.style.opacity = '1'
      }
      if (dot.current) {
        dot.current.style.transform = `translate3d(${e.clientX}px, ${e.clientY}px, 0)`
      }
      const el = (e.target as HTMLElement)?.closest<HTMLElement>(
        'a, button, [data-cursor]',
      )
      if (el) {
        const l = el.getAttribute('data-cursor')
        setLabel(l ?? '')
        setVariant(l ? 'view' : 'link')
      } else {
        setLabel('')
        setVariant('default')
      }
    }

    const loop = () => {
      ringPos.x += (target.x - ringPos.x) * 0.16
      ringPos.y += (target.y - ringPos.y) * 0.16
      if (ring.current) {
        ring.current.style.transform = `translate3d(${ringPos.x}px, ${ringPos.y}px, 0)`
      }
      raf = requestAnimationFrame(loop)
    }

    const onLeave = () => {
      if (dot.current) dot.current.style.opacity = '0'
      if (ring.current) ring.current.style.opacity = '0'
      visible = false
    }

    window.addEventListener('pointermove', onMove, { passive: true })
    document.addEventListener('pointerleave', onLeave)
    raf = requestAnimationFrame(loop)

    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('pointermove', onMove)
      document.removeEventListener('pointerleave', onLeave)
      document.documentElement.classList.remove('has-cursor')
    }
  }, [])

  if (!enabled) return null

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 z-[70]">
      <div
        ref={dot}
        className="fixed left-0 top-0 -ml-1 -mt-1 h-2 w-2 rounded-full bg-primary opacity-0 transition-opacity duration-300 will-change-transform"
      />
      <div
        ref={ring}
        className={`fixed left-0 top-0 flex items-center justify-center rounded-full border border-primary/70 opacity-0 transition-[width,height,margin,background-color,border-color] duration-300 ease-out will-change-transform ${
          variant === 'view'
            ? '-ml-9 -mt-9 h-[72px] w-[72px] bg-primary text-primary-foreground'
            : variant === 'link'
              ? '-ml-6 -mt-6 h-12 w-12 bg-primary/10'
              : '-ml-4 -mt-4 h-8 w-8'
        }`}
      >
        {variant === 'view' && label && (
          <span className="text-[10px] font-medium uppercase tracking-[0.15em]">
            {label}
          </span>
        )}
      </div>
    </div>
  )
}
