'use client'

import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion'
import { useRef, useState } from 'react'
import { Reveal } from '@/components/motion/reveal'

const EASE = [0.16, 1, 0.3, 1] as const

const socials = [
  { label: 'Instagram', href: 'https://instagram.com' },
  { label: 'Behance', href: 'https://behance.net' },
  { label: 'Dribbble', href: 'https://dribbble.com' },
  { label: 'LinkedIn', href: 'https://linkedin.com' },
]

export function Footer() {
  const reduced = useReducedMotion()
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end end'],
  })
  const bgY = useTransform(scrollYProgress, [0, 1], ['-20%', '0%'])
  const [hovering, setHovering] = useState(false)

  return (
    <footer
      id="contact"
      ref={ref}
      className="relative overflow-hidden scroll-mt-24"
    >
      {/* Textured parallax backdrop */}
      <motion.div
        style={reduced ? undefined : { y: bgY }}
        aria-hidden="true"
        className="absolute inset-0 scale-125"
      >
        <img
          src="/images/texture-abstract.png"
          alt=""
          className="h-full w-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/85 to-background" />
      </motion.div>

      <div className="relative z-10 mx-auto max-w-7xl px-5 pb-12 pt-28 md:px-10 md:pt-40">
        {/* Big CTA */}
        <div className="border-b border-border pb-20 md:pb-28">
          <Reveal>
            <p className="mb-8 flex items-center gap-3 text-xs uppercase tracking-[0.35em] text-muted-foreground">
              <span className="h-px w-10 bg-primary" />
              Let&apos;s build something
            </p>
          </Reveal>

          <a
            href="mailto:hello@aether.studio"
            onMouseEnter={() => setHovering(true)}
            onMouseLeave={() => setHovering(false)}
            className="group block"
          >
            <span className="block overflow-hidden">
              <motion.span
                initial={{ y: '110%' }}
                whileInView={{ y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 1.1, ease: EASE }}
                className="block font-serif text-[16vw] leading-[0.85] tracking-tight text-balance md:text-[12vw] lg:text-[11rem]"
              >
                Start a
              </motion.span>
            </span>
            <span className="block overflow-hidden">
              <motion.span
                initial={{ y: '110%' }}
                whileInView={{ y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 1.1, delay: 0.08, ease: EASE }}
                className="flex items-center gap-6 font-serif text-[16vw] italic leading-[0.85] tracking-tight text-primary md:text-[12vw] lg:text-[11rem]"
              >
                project
                <span
                  className={`hidden transition-transform duration-500 md:inline ${
                    hovering ? 'translate-x-4' : ''
                  }`}
                  aria-hidden="true"
                >
                  →
                </span>
              </motion.span>
            </span>
          </a>

          <Reveal delay={0.1}>
            <div className="mt-12 flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
              <a
                href="mailto:hello@aether.studio"
                className="text-lg text-foreground underline-offset-4 transition-colors hover:text-primary hover:underline"
              >
                hello@aether.studio
              </a>
              <a
                href="tel:+13105550142"
                className="text-lg text-muted-foreground transition-colors hover:text-foreground"
              >
                +1 (310) 555-0142
              </a>
            </div>
          </Reveal>
        </div>

        {/* Columns */}
        <div className="grid gap-12 py-16 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 text-sm font-medium tracking-[0.25em]">
              <span className="inline-block h-2 w-2 rounded-full bg-primary" />
              AETHER
            </div>
            <p className="mt-5 max-w-sm text-pretty text-sm leading-relaxed text-muted-foreground">
              An independent creative studio designing brands, campaigns and
              interactive experiences from Los Angeles and remotely worldwide.
            </p>
          </div>

          <div>
            <p className="mb-5 text-xs uppercase tracking-[0.25em] text-muted-foreground">
              Studio
            </p>
            <ul className="flex flex-col gap-3 text-sm">
              {['Work', 'Studio', 'Services', 'Contact'].map((l) => (
                <li key={l}>
                  <a
                    href={`#${l.toLowerCase()}`}
                    className="text-foreground/80 transition-colors hover:text-primary"
                  >
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="mb-5 text-xs uppercase tracking-[0.25em] text-muted-foreground">
              Elsewhere
            </p>
            <ul className="flex flex-col gap-3 text-sm">
              {socials.map((s) => (
                <li key={s.label}>
                  <a
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group inline-flex items-center gap-2 text-foreground/80 transition-colors hover:text-primary"
                  >
                    {s.label}
                    <span className="opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:opacity-100">
                      ↗
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="flex flex-col gap-3 border-t border-border pt-8 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between">
          <p>© {new Date().getFullYear()} AETHER Studio. All rights reserved.</p>
          <p className="tracking-[0.2em]">
            DESIGNED &amp; BUILT WITH INTENT — A AETHER TEMPLATE
          </p>
        </div>
      </div>
    </footer>
  )
}
