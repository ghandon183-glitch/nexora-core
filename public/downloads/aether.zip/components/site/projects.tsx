'use client'

import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion'
import { useRef, useState } from 'react'
import { Reveal, StaggerWords } from '@/components/motion/reveal'
import { projects, type Project } from '@/lib/site-data'

const EASE = [0.16, 1, 0.3, 1] as const

export function Projects() {
  return (
    <section id="work" className="relative py-24 md:py-40 scroll-mt-24">
      <div className="mx-auto max-w-7xl px-5 md:px-10">
        <div className="mb-16 flex flex-col justify-between gap-6 md:mb-24 md:flex-row md:items-end">
          <div>
            <Reveal>
              <p className="mb-5 flex items-center gap-3 text-xs uppercase tracking-[0.35em] text-muted-foreground">
                <span className="h-px w-10 bg-primary" />
                Selected work
              </p>
            </Reveal>
            <StaggerWords
              as="h2"
              text="Case studies, not screenshots."
              className="max-w-2xl font-serif text-4xl leading-[0.95] text-balance md:text-6xl"
            />
          </div>
          <Reveal delay={0.15}>
            <p className="max-w-xs text-pretty text-sm leading-relaxed text-muted-foreground">
              Six recent engagements spanning fragrance, mobility, fashion and
              editorial — each built end to end.
            </p>
          </Reveal>
        </div>

        <div className="flex flex-col gap-20 md:gap-32">
          {projects.map((p, i) => (
            <ProjectCard key={p.id} project={p} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}

function ProjectCard({ project, index }: { project: Project; index: number }) {
  const reduced = useReducedMotion()
  const ref = useRef<HTMLDivElement>(null)
  const [hover, setHover] = useState(false)
  const flip = index % 2 === 1

  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  })
  const imgY = useTransform(scrollYProgress, [0, 1], ['-8%', '8%'])
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [1.12, 1, 1.12])

  return (
    <div
      ref={ref}
      className={`flex flex-col gap-6 md:flex-row md:items-center md:gap-14 ${
        flip ? 'md:flex-row-reverse' : ''
      }`}
    >
      {/* Image */}
      <motion.a
        href={`#work`}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
        onFocus={() => setHover(true)}
        onBlur={() => setHover(false)}
        initial={{ opacity: 0, y: 40 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-15% 0px' }}
        transition={{ duration: 1, ease: EASE }}
        className="group relative block aspect-[4/3] w-full overflow-hidden rounded-xl bg-card md:w-[62%]"
        aria-label={`${project.title} — ${project.category}`}
      >
        <motion.div
          style={reduced ? undefined : { y: imgY, scale }}
          className="absolute inset-0"
        >
          <img
            src={project.image || '/placeholder.svg'}
            alt={`${project.client} — ${project.category}`}
            className="h-full w-full object-cover transition-[filter] duration-700 group-hover:brightness-110"
          />
        </motion.div>
        <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent opacity-70" />

        {/* hover reveal chip */}
        <div className="absolute left-5 top-5 flex items-center gap-2 rounded-full border border-border bg-background/60 px-4 py-2 text-xs uppercase tracking-[0.2em] backdrop-blur-md">
          {project.category}
        </div>
        <motion.div
          animate={{
            opacity: hover ? 1 : 0,
            y: hover ? 0 : 12,
          }}
          transition={{ duration: 0.4, ease: EASE }}
          className="absolute bottom-5 right-5 flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground"
        >
          View case study
          <span aria-hidden="true">→</span>
        </motion.div>
      </motion.a>

      {/* Meta */}
      <div className="md:w-[38%]">
        <Reveal>
          <div className="mb-4 flex items-center gap-4 text-xs uppercase tracking-[0.3em] text-muted-foreground">
            <span className="text-primary">{project.index}</span>
            <span className="h-px flex-1 bg-border" />
            <span>{project.year}</span>
          </div>
        </Reveal>
        <Reveal delay={0.05}>
          <h3 className="font-serif text-4xl leading-none md:text-5xl">
            {project.title}
          </h3>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mt-4 max-w-sm text-pretty text-sm leading-relaxed text-muted-foreground">
            {project.description}
          </p>
        </Reveal>
        <Reveal delay={0.15}>
          <p className="mt-5 text-sm text-foreground/80">{project.client}</p>
        </Reveal>
      </div>
    </div>
  )
}
