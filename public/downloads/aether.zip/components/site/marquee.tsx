'use client'

import { clients } from '@/lib/site-data'

export function Marquee() {
  const row = [...clients, ...clients]
  return (
    <section
      className="relative overflow-hidden border-y border-border py-6"
      aria-label="Selected clients"
    >
      <div className="flex w-max marquee-track">
        {row.map((c, i) => (
          <div key={i} className="flex items-center gap-10 px-10">
            <span className="font-serif text-2xl italic text-muted-foreground md:text-3xl">
              {c}
            </span>
            <span className="h-1.5 w-1.5 rounded-full bg-primary/60" />
          </div>
        ))}
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-background to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-background to-transparent" />
    </section>
  )
}
