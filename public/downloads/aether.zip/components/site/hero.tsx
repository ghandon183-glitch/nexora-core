'use client'

import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion'
import dynamic from 'next/dynamic'
import { useRef } from 'react'

const HeroScene = dynamic(() => import('@/components/webgl/hero-scene'), {
  ssr: false,
  loading: () => (
    <img
      src="/images/hero-fallback.png"
      alt=""
      aria-hidden="true"
      className="h-full w-full object-cover opacity-70"
    />
  ),
})

const EASE = [0.16, 1, 0.3, 1] as const

export function Hero() {
  const reduced = useReducedMotion()
  const ref = useRef<HTMLElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start start', 'end start'],
  })
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '32%'])
  const sceneY = useTransform(scrollYProgress, [0, 1], ['0%', '14%'])
  const opacity = useTransform(scrollYProgress, [0, 0.85], [1, 0])
  const blur = useTransform(scrollYProgress, [0, 1], ['0px', '6px'])

  return (
    <section
      ref={ref}
      id="top"
      className="relative flex min-h-[100svh] flex-col justify-center overflow-hidden"
    >
      {/* WebGL layer + glow */}
      <motion.div
        style={{ opacity, y: sceneY, filter: reduced ? undefined : blur }}
        className="pointer-events-none absolute inset-0"
        aria-hidden="true"
      >
        {/* soft radial glow behind the core */}
        <div className="absolute left-1/2 top-1/2 h-[80vmin] w-[80vmin] -translate-x-1/2 -translate-y-1/2 glow-primary opacity-60 blur-2xl" />
        <div className="absolute inset-0">
          <HeroScene reducedMotion={!!reduced} />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-transparent to-background" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/40 via-transparent to-background/40" />
      </motion.div>

      {/* Typographic layer */}
      <motion.div
        style={{ y }}
        className="relative z-10 mx-auto w-full max-w-7xl px-5 md:px-10"
      >
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.4, ease: EASE }}
          className="mb-7 flex items-center gap-3 text-xs uppercase tracking-[0.4em] text-muted-foreground"
        >
          <span className="h-px w-12 bg-primary" />
          Creative Studio — Est. 2011
        </motion.p>

        <h1 className="font-serif text-[16vw] leading-[0.82] tracking-[-0.02em] text-balance md:text-[11vw] lg:text-[9.5rem]">
          <Line delay={0.5}>We craft</Line>
          <Line delay={0.62} className="text-primary italic">
            worlds
          </Line>
          <Line delay={0.74}>brands live in.</Line>
        </h1>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1, ease: EASE }}
          className="mt-10 flex max-w-2xl flex-col gap-6 md:flex-row md:items-end md:justify-between"
        >
          <p className="max-w-xl text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
            AETHER is an award-winning studio building motion-first identities,
            campaigns and interactive experiences for the world&apos;s most
            ambitious brands.
          </p>
        </motion.div>
      </motion.div>

      {/* scroll cue */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 1 }}
        className="absolute inset-x-0 bottom-8 z-10 mx-auto flex w-full max-w-7xl items-center justify-between px-5 text-xs uppercase tracking-[0.3em] text-muted-foreground md:px-10"
      >
        <span className="flex items-center gap-3">
          <span className="relative flex h-6 w-px overflow-hidden bg-border">
            <motion.span
              animate={reduced ? {} : { y: ['-100%', '100%'] }}
              transition={{ repeat: Infinity, duration: 1.8, ease: 'easeInOut' }}
              className="absolute inset-x-0 h-1/2 bg-primary"
            />
          </span>
          Scroll to explore
        </span>
        <span className="hidden items-center gap-2 md:flex">
          Move your cursor to shape the light
        </span>
      </motion.div>
    </section>
  )
}

function Line({
  children,
  delay,
  className,
}: {
  children: React.ReactNode
  delay: number
  className?: string
}) {
  return (
    <span className="block overflow-hidden pb-[0.06em]">
      <motion.span
        initial={{ y: '110%' }}
        animate={{ y: 0 }}
        transition={{ duration: 1.1, delay, ease: EASE }}
        className={`block ${className ?? ''}`}
      >
        {children}
      </motion.span>
    </span>
  )
}
