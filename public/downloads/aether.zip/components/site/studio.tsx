'use client'

import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion'
import { useRef } from 'react'
import { Reveal, StaggerWords } from '@/components/motion/reveal'
import { services, stats } from '@/lib/site-data'

export function Studio() {
  const reduced = useReducedMotion()
  const ref = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  })
  const imgY = useTransform(scrollYProgress, [0, 1], ['-12%', '12%'])

  return (
    <section id="studio" className="relative py-24 md:py-40 scroll-mt-24">
      <div className="mx-auto max-w-7xl px-5 md:px-10">
        {/* Manifesto */}
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-5">
            <Reveal>
              <p className="mb-6 flex items-center gap-3 text-xs uppercase tracking-[0.35em] text-muted-foreground">
                <span className="h-px w-10 bg-primary" />
                The studio
              </p>
            </Reveal>
            <div ref={ref} className="relative overflow-hidden rounded-xl bg-card">
              <motion.div style={reduced ? undefined : { y: imgY }} className="scale-110">
                <img
                  src="/images/studio-portrait.png"
                  alt="The AETHER creative team in the studio"
                  className="aspect-[4/5] w-full object-cover"
                />
              </motion.div>
            </div>
          </div>

          <div className="flex flex-col justify-center md:col-span-7 md:pl-10">
            <StaggerWords
              as="h2"
              text="A small studio with an obsessive appetite for craft."
              className="font-serif text-4xl leading-[1.02] text-balance md:text-6xl"
            />
            <Reveal delay={0.1}>
              <p className="mt-8 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
                We are strategists, designers and engineers who believe the most
                valuable brands are felt before they are understood. Every
                engagement is led by the people who do the work — no layers, no
                handoffs, no dilution.
              </p>
            </Reveal>

            <div className="mt-12 grid grid-cols-2 gap-8 md:mt-16 md:grid-cols-4">
              {stats.map((s, i) => (
                <Reveal key={s.label} delay={i * 0.08}>
                  <div>
                    <p className="font-serif text-4xl text-primary md:text-5xl">
                      {s.value}
                    </p>
                    <p className="mt-2 text-xs uppercase tracking-[0.2em] text-muted-foreground">
                      {s.label}
                    </p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>

        {/* Services */}
        <div id="services" className="mt-28 scroll-mt-24 md:mt-40">
          <div className="mb-14 flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <StaggerWords
              as="h2"
              text="What we do"
              className="font-serif text-4xl text-balance md:text-6xl"
            />
            <Reveal delay={0.1}>
              <p className="max-w-sm text-pretty text-sm leading-relaxed text-muted-foreground">
                Four disciplines, one integrated team. We move between them
                fluidly so ideas never lose momentum.
              </p>
            </Reveal>
          </div>

          <div className="grid gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-2">
            {services.map((s, i) => (
              <ServiceRow key={s.title} title={s.title} body={s.body} index={i} />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

function ServiceRow({
  title,
  body,
  index,
}: {
  title: string
  body: string
  index: number
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-10% 0px' }}
      transition={{ duration: 0.8, delay: index * 0.06, ease: [0.16, 1, 0.3, 1] }}
      className="group relative bg-background p-8 transition-colors duration-500 hover:bg-card md:p-12"
    >
      <div className="flex items-start justify-between gap-4">
        <span className="font-mono text-xs text-muted-foreground">
          0{index + 1}
        </span>
        <span className="text-muted-foreground transition-all duration-500 group-hover:translate-x-1 group-hover:text-primary">
          →
        </span>
      </div>
      <h3 className="mt-8 font-serif text-3xl md:text-4xl">{title}</h3>
      <p className="mt-4 max-w-sm text-pretty text-sm leading-relaxed text-muted-foreground">
        {body}
      </p>
      <span className="mt-8 block h-px w-0 bg-primary transition-all duration-500 group-hover:w-full" />
    </motion.div>
  )
}
