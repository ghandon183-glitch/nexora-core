import type { MetadataRoute } from 'next'
import { BASE_PATH } from '@/lib/asset-path'

// Required for metadata routes when the project is built with `output: export`.
export const dynamic = 'force-static'

/**
 * robots.txt for the single-page studio site. The sitemap URL is absolute, so it
 * is only advertised when NEXT_PUBLIC_SITE_URL is configured; the crawl rules
 * themselves do not depend on it.
 */
export default function robots(): MetadataRoute.Robots {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL
  return {
    rules: { userAgent: '*', allow: `${BASE_PATH}/` },
    sitemap: siteUrl ? `${siteUrl.replace(/\/$/, '')}${BASE_PATH}/sitemap.xml` : undefined,
  }
}
