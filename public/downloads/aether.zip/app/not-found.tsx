import type { Metadata } from 'next'
import { BASE_PATH } from '@/lib/asset-path'

export const metadata: Metadata = {
  title: 'Page not found — AETHER',
  robots: { index: false, follow: false },
}

export default function NotFound() {
  return (
    <main className="flex min-h-[100svh] flex-col items-center justify-center px-6 text-center">
      <p className="text-xs uppercase tracking-[0.4em] text-muted-foreground">Error 404</p>
      <h1 className="mt-6 font-serif text-5xl leading-[0.95] text-balance md:text-7xl">
        This page drifted out of frame.
      </h1>
      <p className="mt-6 max-w-md text-pretty text-sm leading-relaxed text-muted-foreground">
        The address you opened does not exist in this build. Head back to the
        studio home to see the work.
      </p>
      <a
        href={`${BASE_PATH}/`}
        className="mt-10 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground transition-transform hover:scale-[1.03] focus-visible:scale-[1.03]"
      >
        Back to the studio
      </a>
    </main>
  )
}
