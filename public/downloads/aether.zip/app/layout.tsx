import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono, Instrument_Serif } from 'next/font/google'
import { Cursor } from '@/components/motion/cursor'
import { ScrollProgress } from '@/components/motion/scroll-progress'
import './globals.css'

const geistSans = Geist({
  subsets: ['latin'],
  variable: '--font-geist-sans',
  display: 'swap',
})

const geistMono = Geist_Mono({
  subsets: ['latin'],
  variable: '--font-geist-mono',
  display: 'swap',
})

const instrumentSerif = Instrument_Serif({
  subsets: ['latin'],
  weight: '400',
  style: ['normal', 'italic'],
  variable: '--font-instrument-serif',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'AETHER — Premium Creative Studio Template',
  description:
    'A world-class, motion-first creative studio and branding agency template. WebGL-powered, cinematic and marketplace-ready for agencies, art directors and luxury brands.',
  generator: 'v0.app',
  keywords: [
    'creative studio',
    'portfolio template',
    'luxury branding',
    'design agency',
    'art director',
    'webgl',
    'interactive',
    'awwwards',
  ],
  openGraph: {
    title: 'AETHER — Premium Creative Studio Template',
    description:
      'A cinematic, motion-first, WebGL-powered template for premium creative studios and luxury brands.',
    type: 'website',
  },
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#1a1815',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html
      lang="en"
      className={`dark bg-background ${geistSans.variable} ${geistMono.variable} ${instrumentSerif.variable}`}
    >
      <body className="font-sans antialiased grain">
        <ScrollProgress />
        <Cursor />
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
