import { Footer } from '@/components/site/footer'
import { Hero } from '@/components/site/hero'
import { Marquee } from '@/components/site/marquee'
import { Navbar } from '@/components/site/navbar'
import { Projects } from '@/components/site/projects'
import { Studio } from '@/components/site/studio'

export default function Page() {
  return (
    <main className="relative">
      <Navbar />
      <Hero />
      <Marquee />
      <Projects />
      <Studio />
      <Footer />
    </main>
  )
}
