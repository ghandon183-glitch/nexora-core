import type { MetadataRoute } from 'next'
import { BASE_PATH } from '@/lib/asset-path'

// Required for metadata routes when the project is built with `output: export`.
export const dynamic = 'force-static'

/**
 * The template is a one-page site, so the sitemap lists a single URL. Sitemap
 * entries must be absolute, so nothing is emitted until NEXT_PUBLIC_SITE_URL is
 * set (see .env.example) — a build without it stays valid and simply ships no
 * sitemap entries.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL
  if (!siteUrl) return []

  return [
    {
      url: `${siteUrl.replace(/\/$/, '')}${BASE_PATH}/`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: 1,
    },
  ]
}
