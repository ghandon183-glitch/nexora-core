# Package Contents — AETHER v1.0.1

The archive root is the project root. Everything below is source you can edit.

```
package.json           scripts, dependencies, engines (Node >= 20.9)
package-lock.json      lockfileVersion 3 — the tested dependency graph
next.config.mjs        basePath from env, security headers, unoptimized images
eslint.config.mjs      flat ESLint config (Next.js core-web-vitals + TS)
postcss.config.mjs     Tailwind CSS v4 via @tailwindcss/postcss
tsconfig.json          TypeScript config with the "@/*" path alias
.env.example           NEXT_PUBLIC_BASE_PATH / NEXT_PUBLIC_SITE_URL
.gitignore             ignores node_modules, .next, env files and build output

app/
  layout.tsx           fonts, metadata/metadataBase, icons, theme viewport
  page.tsx             section assembly (navbar → hero → marquee → work → studio → footer)
  globals.css          design tokens, grain texture, base layer
  vendor/
    shadcn-tailwind.css  vendored Tailwind utilities (MIT, see ASSET-LICENSES.md)
  not-found.tsx        branded 404
  robots.ts            robots.txt (sitemap link when NEXT_PUBLIC_SITE_URL is set)
  sitemap.ts           sitemap.xml (single URL, emitted when NEXT_PUBLIC_SITE_URL is set)

components/
  site/navbar.tsx      fixed nav, scroll-spy, mobile overlay menu
  site/hero.tsx        WebGL layer, headline animation, scroll cue
  site/marquee.tsx     client marquee
  site/projects.tsx    six alternating case-study cards with parallax
  site/studio.tsx      manifesto, portrait, stats, services, process
  site/footer.tsx      oversized contact CTA, studio links, socials
  webgl/hero-scene.tsx GLSL shader scene + static fallback
  motion/reveal.tsx    Reveal / StaggerWords primitives
  motion/cursor.tsx    pointer-fine inertia cursor
  motion/scroll-progress.tsx  top scroll progress bar
  ui/button.tsx        Base UI button with cva variants

lib/
  site-data.ts         all demo content and image paths
  asset-path.ts        BASE_PATH + assetPath() helper for /public files
  utils.ts             cn() class-name helper

public/
  images/              9 PNG images (hero fallback, 6 projects, portrait, texture)
  icon.svg, icon-dark-32x32.png, icon-light-32x32.png, apple-icon.png
  placeholder*.{svg,png,jpg}   neutral placeholders (logo, avatar, generic image)

README.md              full documentation
QUICKSTART.md          five-command setup
CHANGELOG.md           release history
SUPPORT.md             support scope and how to report an issue
ASSET-LICENSES.md      licenses for assets, fonts, libraries and vendored CSS
LICENSE.md             commercial template license
```

Not included (by design): `node_modules/`, `.next/`, build output, environment
files with values, and any secret or credential.
