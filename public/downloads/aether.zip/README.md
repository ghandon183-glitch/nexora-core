# AETHER — Premium Creative Studio Portfolio

An award-winning, motion-first portfolio template for creative studios, luxury
brands and modern design agencies. Built around an interactive WebGL hero, a
coherent cinematic motion system and editorial-grade imagery.

> Marketplace-ready premium template. Positioned at **$59–$79**.

## Highlights

- **Interactive WebGL hero** — a custom GLSL shader on a displaced icosphere that
  reacts to pointer motion (depth displacement, color shift, pointer-steered
  lighting and fresnel rim), scroll and touch. It settles smoothly when the
  pointer is idle.
- **Coherent motion system** — staggered word reveals, masked line reveals,
  scroll-linked parallax and layered transitions via Framer Motion. No lazy
  fade-ins.
- **Editorial imagery** — 9 premium, cohesive images across hero, projects,
  studio and footer. No placeholders.
- **Case-study project showcase** — alternating layouts, hover reveals and
  parallax image motion.
- **Premium interactive footer** — parallax textured backdrop and an oversized
  animated CTA.
- **Fully responsive** with touch equivalents for every desktop interaction.
- **Accessibility & reduced motion** — honors `prefers-reduced-motion`, semantic
  landmarks, ARIA labels and a high-quality WebGL fallback image.

## Tech stack

- Next.js 16 (App Router) · React 19 · TypeScript
- Tailwind CSS v4
- Framer Motion
- React Three Fiber + Three.js (`@react-three/fiber`, `@react-three/drei`)

## Getting started

```bash
pnpm install
pnpm dev
```

Open [http://localhost:3000](http://localhost:3000).

```bash
pnpm build && pnpm start   # production
```

## Project structure

```
app/
  layout.tsx          # fonts, metadata, dark theme
  page.tsx            # section assembly
  globals.css         # design tokens, grain + marquee utilities
components/
  webgl/hero-scene.tsx   # interactive R3F shader scene + fallback
  motion/reveal.tsx      # Reveal + StaggerWords motion primitives
  site/                  # navbar, hero, marquee, projects, studio, footer
lib/site-data.ts      # projects, services, stats, clients, nav (demo data)
public/images/        # 9 editorial images
```

## Customizing

- **Content** — edit `lib/site-data.ts` (projects, services, stats, clients, nav).
- **Colors / radius** — edit the tokens in `app/globals.css` (`:root`). The palette
  is a dark obsidian + champagne-gold system in OKLCH.
- **Fonts** — swapped in `app/layout.tsx` (Instrument Serif display + Geist body).
- **Hero shader** — tune uniforms/amplitude in `components/webgl/hero-scene.tsx`.
- **Images** — replace files in `public/images/` (keep the same filenames).

## Performance notes

- WebGL scene is dynamically imported (`ssr: false`) with a fallback image while
  loading, capped DPR, and reduced geometry detail on small screens.
- Images are lazy by default; parallax uses transform-only animations for 60fps.
- Security headers configured in `next.config.mjs`.

## License

Commercial template. Licensed per marketplace terms.
