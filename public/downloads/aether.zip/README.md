# AETHER — Premium Creative Studio Template

A motion-first portfolio and studio site for creative agencies, art directors and
luxury brands: a pointer-reactive WebGL hero, a cinematic scroll system, six
editorial case studies, a studio manifesto and an oversized contact footer.

- **Stack:** Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS v4
- **Rendering:** server build (`next build` → `next start`), not a static export
- **Routes:** `/` and a branded 404 page
- **Package version:** 1.0.1

> All studio content in the demo — case studies, clients, stats, awards, quotes,
> the `hello@aether.example` address and the 555 phone number — is placeholder
> material. Replace it before launch. See [Demo content and honest limits](#demo-content-and-honest-limits).

## 1. What you receive

| Item | Details |
| --- | --- |
| Full source | `app/`, `components/`, `lib/`, configuration files |
| Content model | `lib/site-data.ts` — every piece of copy and imagery path |
| Imagery | 9 PNG images in `public/images/` plus favicons and placeholders |
| Documentation | this README, `QUICKSTART.md`, `CONTENTS.md`, `CHANGELOG.md`, `SUPPORT.md`, `ASSET-LICENSES.md`, `LICENSE.md` |
| Locked dependencies | `package-lock.json` (lockfileVersion 3) |
| Environment template | `.env.example` |

The archive root **is** the project root: after extracting, run the commands
below from the folder that contains `package.json`.

## 2. Requirements

- **Node.js 20.9 or newer** (declared in `package.json` → `engines`). Node 22 LTS
  is recommended.
- **npm 10 or newer** (ships with Node 20+).
- A build machine with network access: `next/font` downloads Geist, Geist Mono
  and Instrument Serif from Google Fonts **at build time**, and `npm ci` needs
  the registry.
- No database, API key or third-party account is required.

## 3. Install

```bash
cd <extracted-folder>
npm ci          # exact, locked dependency tree
```

`npm ci` is the supported path because `package-lock.json` is included. Plain
`npm install` also works but may resolve newer patch versions.

## 4. Local development

```bash
npm run dev
```

Open <http://localhost:3000>. The dev server hot-reloads `app/`, `components/`
and `lib/`.

## 5. Production build and run

```bash
npm run build     # compiles, type-checks and prerenders
npm start         # serves the production build on port 3000
```

`next start` is the supported production mode. The site is prerendered as static
HTML, but `next.config.mjs` also sets security headers (`X-Content-Type-Options`,
`Referrer-Policy`, `Strict-Transport-Security`, `Permissions-Policy`), which need
a Node server or a host that applies the same headers. A static export
(`output: 'export'`) is **not** the shipped configuration; if you switch to one,
those headers must be configured at the CDN instead.

Quality checks:

```bash
npm run lint        # ESLint, no warnings
npm run typecheck   # tsc --noEmit
```

## 6. Deploying under a sub-path (`NEXT_PUBLIC_BASE_PATH`)

The template can be served from a sub-directory, e.g. `https://example.com/demo/aether`.

```bash
NEXT_PUBLIC_BASE_PATH=/demo/aether npm run build
```

Rules:

- No trailing slash, and it must start with `/` when set. Leave it **empty** for
  a domain-root deployment.
- The value is compiled into the build — rebuild after changing it.
- Files under `public/` are not rewritten by Next.js, so the template routes
  every one of them through `assetPath()` in `lib/asset-path.ts`. When you add a
  new image, reference it as `assetPath('/images/your-file.png')`, not as
  `'/images/your-file.png'`.
- The demo in this marketplace is built with `NEXT_PUBLIC_BASE_PATH=/demo/aether`.

## 7. Environment variables

Both are optional; the template builds and runs with neither set. Copy
`.env.example` to `.env.local` for development or configure the same names in
your host's dashboard for production.

| Variable | Default | Purpose |
| --- | --- | --- |
| `NEXT_PUBLIC_BASE_PATH` | empty | Sub-path the site is served from (see above). Baked into the build. |
| `NEXT_PUBLIC_SITE_URL` | empty | Absolute site origin (e.g. `https://studio.com`). Sets `metadataBase` for Open Graph/social previews and enables `sitemap.xml` plus the sitemap link in `robots.txt`. |

Both are `NEXT_PUBLIC_*`, so they are visible in the browser bundle — never put a
secret in them.

## 8. Customizing content

All copy and demo data lives in `lib/site-data.ts`:

- `projects` — six case studies (title, client, category, year, image, description, services)
- `services` — the four capability cards
- `process` — the four-step process
- `stats` — the studio numbers
- `clients` — the marquee names
- `navLinks` — the section anchors and nav labels
- `studio` — contact email, phone and display phone number

Images: replace the files in `public/images/` **keeping the same filenames**, or
update the paths in `lib/site-data.ts` and `components/` (hero, studio, footer
reference their own paths).

Design tokens colour, radius and typography are CSS variables in
`app/globals.css` (`:root` and `@theme inline`). Fonts are wired in
`app/layout.tsx` via `next/font`.

## 9. Demo content and honest limits

- **Case studies are fictional.** There are no project detail pages, and the
  cards are intentionally static (image + metadata); nothing pretends to open a
  case study.
- **Contact is a real `mailto:`/`tel:` link, not a form.** No message is sent by
  the site, nothing is stored, and no backend or CRM is included. "Start a
  project" scrolls to the contact footer.
- **Social links** in the footer point at the platforms' own home pages
  (instagram.com, behance.net, dribbble.com, linkedin.com) and are placeholders.
- **Contact details** (`hello@aether.example`, `+1 (310) 555-0142`) are
  placeholders that use reserved example/555 ranges — replace them with your own.
- **Stats and client names** are sample content, not claims about your studio.
- **No CMS, no analytics, no cookie banner.** Add an analytics or consent tool
  yourself if your jurisdiction requires one.

## 10. WebGL, motion and fallbacks

- The hero is a React Three Fiber scene (`components/webgl/hero-scene.tsx`),
  dynamically imported with `ssr: false`.
- A static image (`public/images/hero-fallback.png`) is shown while the scene
  loads and is also the fallback if the WebGL context fails or is unavailable.
- `prefers-reduced-motion` is respected by the reveal system, the scroll cue, the
  parallax transforms and the custom cursor.
- The custom cursor only mounts for fine pointers (never on touch) and is
  disabled for reduced-motion users.
- DPR is capped at 1.75 and particle counts drop on small screens.

## 11. Project structure

See [CONTENTS.md](CONTENTS.md) for the annotated file tree.

## 12. Accessibility

Semantic landmarks (`main`, `nav aria-label`), labelled menu toggle with
`aria-expanded`, keyboard-operable navigation buttons, visible focus styles from
the theme, and descriptive `alt` text on every content image. Decorative layers
are `aria-hidden`.

## 13. Performance notes

- Images use `next/image` with `unoptimized: true` (required for
  `images.unoptimized` builds and sub-path hosting) — compression is your CDN's
  job. Source PNGs are large; convert them to WebP/AVIF for production.
- Parallax and hover effects animate transforms and filters only.
- The WebGL bundle is code-split and only loaded in the browser.

## 14. Deployment

Static hosting of the `next start` output, Vercel, Netlify, or any Node 20 host
that runs `npm ci && npm run build && npm start`. Memory: the build is CPU-light;
no background jobs, cron or database.

## 15. License

Commercial template license — see [LICENSE.md](LICENSE.md). Third-party libraries,
fonts and demo artwork are listed in [ASSET-LICENSES.md](ASSET-LICENSES.md).

## 16. Support

See [SUPPORT.md](SUPPORT.md). Include the template version (`1.0.1`), Node
version and the full command output when reporting an issue.
