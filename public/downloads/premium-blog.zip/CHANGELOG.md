# Changelog

## 1.1.0 — 2026-11-09

Customer-readiness release. No design or content rewrite: the magazine looks and
reads the same, but every shipped control now works and the package installs
reproducibly.

### Security and dependencies
- Upgraded `next` and `eslint-config-next` to 16.4.5 (the previously shipped
  16.3.6 was inside an advisory range for production builds).
- Added `package-lock.json` (lockfileVersion 3) so `npm ci` is reproducible.
- Added one scoped `overrides` entry (`@typescript-eslint/typescript-estree` →
  `minimatch ^11.0.1`) to clear a transitive denial-of-service advisory in the
  lint toolchain. `npm audit` and `npm audit --omit=dev` both report
  **0 vulnerabilities**.
- Removed three unused dependencies (`framer-motion`, `clsx`, `tailwind-merge`)
  and the dead `lib/utils.ts` helper that imported two of them.

### Fixed
- `eslint.config.mjs` contained TypeScript syntax inside an `.mjs` file, so
  `npm run lint` crashed on startup. Replaced with a valid flat config.
- Every internal link used a hard-coded root path, so the whole site 404'd when
  built with `NEXT_PUBLIC_BASE_PATH`. All navigation now uses `next/link`.
- The header search input accepted text and returned nothing. Search now filters
  the shipped essays by title, excerpt, section, and author, with result links,
  a live result count, an empty state, and Escape to close.
- The newsletter form claimed "You're subscribed" without a backend. It now
  validates the address and states plainly that nothing was sent or stored, with
  instructions for connecting a provider.
- The "Subscribe" header button and footer icon set were inert or pointed at the
  About page. They now link to the newsletter section, About, and Contributors.
- Category counts were invented (24/18/12/15/9 essays) while only six essays
  ship. Counts are derived from the articles, and a section with no essays no
  longer appears.
- About-page statistics (240+ essays, 1.2M readers, 48 contributors) were
  fictional marketing numbers. They are now derived from the delivered content.
- Article author cards linked every contributor to the editor's profile. Only the
  editor's essays link there; other contributors render as plain attribution.
- `related-articles` ignored sections; it now prefers essays from the same
  section before filling from the archive.
- Trending numbering broke past nine items; it is now zero-padded and correct.
- The SVG cover gradient IDs could collide between essays; they are now derived
  from the full title, and the unused `ArticleCoverImage` export is gone.
- Article and section pages could render for unknown slugs in some hosting
  setups; both now set `dynamicParams = false`.

### Added
- `NEXT_PUBLIC_SITE_URL` support: canonical links, Open Graph URLs,
  `sitemap.xml`, and `robots.txt` now exist and match the real 13 routes.
- Favicon (`app/icon.svg`) and a branded 404 page.
- Skip-to-content link, labelled form controls, `aria-expanded` / `aria-controls`
  on both header toggles, Escape handling, and visible focus rings.
- Honest `README.md`, `QUICKSTART.md`, `CONTENTS.md`, `ASSET-LICENSES.md`, and
  `.env.example` (both variables optional, none invented).
- `npm run typecheck` script and a Node `engines` requirement (`>=20.9.0`).
- `.gitignore` so buyers do not commit build output or env files.

### Notes
- The newsletter remains a demo form by design; connecting a provider is
  documented in the README.
- The magazine's brand, essays, and author are fictional sample content.

## 1.0.0
- Customer-ready commercial package.
- Standard license and support documentation.
- Installation and production checklist included.
