# Premium Blog — The Margin

A complete editorial magazine template for Next.js 16 (App Router), TypeScript,
and Tailwind CSS v4. It ships as a **static export**: the build produces plain
HTML, CSS, and JS that can be hosted on any static host or CDN.

- **Live structure:** homepage, section pages, article pages, editor profile,
  about page, and a branded 404.
- **Sample content:** six full essays, four sections, and the editorial voice of
  "The Margin". Every word is fictional demo content you are expected to replace.
- **No backend, no database, no third-party account is required** to run it.

---

## 1. What is in this package

```
premium-blog/            ← the Next.js project (this folder)
├── app/                 routes, metadata, sitemap, robots, icon, 404
├── components/          navigation, cards, newsletter, footer, covers
├── lib/data.ts          ALL editorial content: articles, sections, author
├── lib/base-path.ts     base path + absolute URL helpers
├── package.json         scripts, dependency ranges, npm overrides
├── package-lock.json    exact, reproducible dependency tree
├── next.config.ts       static export, base path, unoptimized images
├── .env.example         the two optional variables (copy to .env.local)
└── .gitignore
```

The archive root also contains `QUICKSTART.md`, `CONTENTS.md`, `CHANGELOG.md`,
`LICENSE.md`, `SUPPORT.md`, and `ASSET-LICENSES.md`.

---

## 2. Requirements

| Requirement | Version |
| --- | --- |
| Node.js | **20.9 or newer** (LTS 20 and 22 are tested; `engines` is `>=20.9.0`) |
| npm | 10 or newer (ships with Node 20/22) |
| Browser | any modern evergreen browser |

No global CLI, database, CMS, or API key is needed.

---

## 3. Install and run

```bash
cd premium-blog
npm ci            # reproducible install from the bundled lockfile
npm run dev       # http://localhost:3000
```

`npm install` also works, but `npm ci` is the supported path because the package
ships a lockfile.

Other scripts:

| Script | What it does |
| --- | --- |
| `npm run dev` | Next.js development server with hot reload |
| `npm run build` | production static export into `out/` |
| `npm run lint` | ESLint (Next.js core-web-vitals + TypeScript rules) |
| `npm run typecheck` | `tsc --noEmit` |

There is no `next start` script on purpose: a static export is served by a plain
file server, not by the Next.js server runtime.

---

## 4. Environment variables

Both variables are **optional**; the template builds and runs with neither.
Copy `.env.example` to `.env.local` for development, or set the same names in
your hosting provider's dashboard.

| Variable | Required | Purpose |
| --- | --- | --- |
| `NEXT_PUBLIC_BASE_PATH` | no | Serves the whole site from a sub-directory, e.g. `/demo/premium-blog`. Leave empty at a domain root. |
| `NEXT_PUBLIC_SITE_URL` | no | Public origin of the deployed site (no trailing slash). Enables canonical links, Open Graph URLs, `sitemap.xml`, and `robots.txt`. |

Anything prefixed with `NEXT_PUBLIC_` is inlined into the client bundle, so never
put a secret there. The template reads no other variable.

---

## 5. Production build and deployment

```bash
npm run build          # → out/
npx serve out          # quick local check of the real build
```

Deploy the **contents of `out/`** to any static host (Cloudflare Pages, Netlify,
Vercel static, S3 + CloudFront, Nginx). Two things matter:

1. **Clean URLs.** The export writes `about.html`, `articles/<slug>.html`, and so
   on. Your host must map `/about` to `about.html` (all mainstream static hosts
   and `npx serve` do this by default).
2. **404 handling.** `out/404.html` is the branded not-found page; most hosts
   pick it up automatically.

### Serving from a sub-directory

```bash
NEXT_PUBLIC_BASE_PATH=/demo/premium-blog npm run build
```

Then upload `out/` so that `/demo/premium-blog/` is the site root. All internal
links use `next/link`, so they pick up the base path automatically. Changing the
base path requires a rebuild — it is compiled in, not read at runtime.

### Setting the canonical origin

```bash
NEXT_PUBLIC_SITE_URL=https://your-domain.com npm run build
```

With it set, `sitemap.xml` lists all 13 routes (home, about, editor, four
sections, six essays) under your base path and `robots.txt` points at that
sitemap. Without it, the sitemap is empty and no canonical tag is emitted, so the
site is never advertised under a wrong domain.

---

## 6. Customizing the template

### Editorial content — `lib/data.ts`

- `articles`: each entry has `slug`, `title`, `excerpt`, `category`, `author`,
  `date`, `readTime`, optional `featured` / `trending` flags, a `cover` palette,
  and a `content` block list (`p`, `h2`, `quote`, `ul`).
- `sections`: the editorial sections. **Every section must contain at least one
  essay** — counts on the homepage, section pages, and sitemap are derived from
  the articles, never hard-coded, so they cannot drift.
- `author`: the editor profile used on `/author` and on essays written by them.
- `newsletter`: the copy above the subscribe form.

Adding an article automatically creates its page, its section listing, its
search result, related-article candidates, and its sitemap entry. Slugs must be
unique and URL-safe (`lowercase-with-hyphens`).

### Branding and theme

- Site name, tagline, and social copy: `lib/data.ts` and the page metadata in
  `app/layout.tsx`, `app/about/page.tsx`, `app/author/page.tsx`.
- Colour tokens, typography scale, and light/dark palettes: `app/globals.css`
  (`@theme inline`). Dark mode follows the visitor's OS preference.
- Fonts: `@fontsource/lora` and `@fontsource/inter`, imported in
  `app/layout.tsx`. Self-hosted, no Google Fonts request at runtime.
- Favicon: `app/icon.svg`.
- Cover art: `components/article-cover.tsx` generates abstract SVG covers from
  the palette and pattern in `lib/data.ts`. Replace the component with
  `next/image` if you have photography.

### Navigation

`components/nav.tsx` renders the desktop sections bar and the mobile menu, both
built from `sections`. Search is client-side: it filters the essay title, excerpt,
section, and author in memory. That is the right trade-off for a few dozen essays;
for a large archive, replace the `useMemo` filter with your search endpoint.

---

## 7. Connecting a real newsletter provider

The subscribe form is an honest demo: it validates the address, then tells the
visitor that nothing was sent. To connect a provider (Buttondown, Mailchimp,
ConvertKit, Resend, your own API…), edit `components/newsletter.tsx`:

```tsx
onSubmit={async (event) => {
  event.preventDefault();
  const email = new FormData(event.currentTarget).get("email");
  const response = await fetch("/api/subscribe", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email }),
  });
  if (!response.ok) throw new Error("Subscribe failed");
  setSubmittedEmail(String(email));
}}
```

Then replace the demo confirmation copy with your real success message. If you
add a server route, remember that a static export cannot run it — host the
endpoint separately or switch the project to a server deployment.

---

## 8. What is real and what is demo-only

**Real:** routing, all pages, section filtering, article reading, search,
keyboard navigation, mobile menu, responsive layouts, metadata, sitemap, robots,
404 page, static build.

**Demo-only:**

- The newsletter form never sends or stores anything (see section 7).
- All essays, authors, statistics, and the "The Margin" brand are fictional
  sample content. About-page numbers are derived from the shipped articles, not
  invented marketing figures.
- Cover images are generated SVG art, not licensed photography.

---

## 9. Accessibility and responsive behaviour

- Skip-to-content link, landmark `<main>`, labelled form controls, `aria-expanded`
  on the search and menu toggles, Escape closes both, visible focus rings.
- Tested at 320 px, 390 px, 768 px, and desktop; no horizontal overflow.
- Motion respects `prefers-reduced-motion`; colour scheme follows
  `prefers-color-scheme`.

---

## 10. Updating dependencies safely

```bash
npm outdated
npm update            # within the declared semver ranges
npm audit             # must report 0 vulnerabilities
npm ci && npm run build && npm run lint && npm run typecheck
```

`package.json` pins `next` and `eslint-config-next` to the same version and
contains one scoped `overrides` entry (`@typescript-eslint/typescript-estree` →
`minimatch ^11.0.1`) that removes a transitive advisory in the lint toolchain.
Remove it only after `npm audit` stays clean without it.

---

## 11. Troubleshooting

| Symptom | Cause and fix |
| --- | --- |
| `Unsupported Node.js version` | Node older than 20.9. Install Node 20 LTS or 22 and rerun `npm ci`. |
| `npm ci` fails on the lockfile | Node/npm too old, or the lockfile was edited by hand. Use npm 10+, or delete `node_modules` and retry. |
| Every page 404s under `/demo/premium-blog` | The build did not include the base path. Rebuild with `NEXT_PUBLIC_BASE_PATH=/demo/premium-blog`. |
| Direct URL to `/about` 404s after upload | The host is not mapping clean URLs. Enable clean/index URLs or upload to a host that does. |
| Canonical/sitemap empty | `NEXT_PUBLIC_SITE_URL` was not set at build time. Rebuild with it. |
| `next start` errors | Expected: this is a static export. Serve `out/` with a static server. |
| Type errors after editing `lib/data.ts` | Keep the `Article` type shape; `content` blocks must use `p`, `h2`, `quote`, or `ul`. |

---

## 12. Support, license, and assets

- License terms: `LICENSE.md`.
- Support scope: `SUPPORT.md`.
- Fonts, icons, and artwork: `ASSET-LICENSES.md`.
- Version history: `CHANGELOG.md`.
- File-by-file inventory: `CONTENTS.md`.
