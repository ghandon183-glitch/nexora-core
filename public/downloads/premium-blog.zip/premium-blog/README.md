# Premium Blog — The Margin

A production-ready editorial magazine template with article, category, author,
and about pages. Built with Next.js (App Router), TypeScript, Tailwind CSS v4,
and Framer Motion-ready architecture.

## Features

- Magazine homepage with featured essay, article grid, categories, trending
- Dynamic article detail pages with rich prose styling
- Category listing pages (static-generated)
- Author profile page with authored essays
- About page with stats
- Newsletter call-to-action with success state
- Editorial typography (Lora serif + Inter body)
- Light/dark mode support
- SEO metadata and Open Graph per article
- Fully responsive

## Tech stack

- Next.js 16 (App Router, static export)
- TypeScript
- Tailwind CSS v4
- lucide-react icons

## Getting started

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`.

## Build

```bash
npm run build
```

Static export (`output: "export"`). Set `NEXT_PUBLIC_BASE_PATH` to host under a sub-path.

## Customization

- Articles, categories, author, and newsletter config live in `lib/data.ts`.
- Generated SVG cover art in `components/article-cover.tsx` — replace with
  photography or illustrations as needed.
- Theme tokens in `app/globals.css` under `@theme inline`.
