import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { ArticleCover } from "@/components/article-cover";
import { RelatedArticles } from "@/components/related-articles";
import { Newsletter } from "@/components/newsletter";
import { articles } from "@/lib/data";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { Clock, Calendar, ArrowLeft } from "lucide-react";

export function generateStaticParams() {
  return articles.map((a) => ({ slug: a.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const article = articles.find((a) => a.slug === slug);
  if (!article) return { title: "Article not found" };
  return {
    title: `${article.title} — The Margin`,
    description: article.excerpt,
    openGraph: { title: article.title, description: article.excerpt, type: "article" },
  };
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = articles.find((a) => a.slug === slug);
  if (!article) notFound();

  return (
    <>
      <Nav />
      <main>
        <article>
          <header className="border-b border-line dark:border-base-line">
            <div className="mx-auto max-w-3xl px-5 py-12 md:px-8 md:py-16">
              <a href="/" className="inline-flex items-center gap-1.5 text-sm text-ink-mute dark:text-base-ink-soft">
                <ArrowLeft size={15} />
                All essays
              </a>
              <div className="mt-6 flex items-center gap-3">
                <span className="rounded-full bg-accent-soft px-3 py-1 text-xs font-semibold text-accent">
                  {article.category}
                </span>
              </div>
              <h1 className="font-serif mt-5 text-3xl font-700 leading-[1.15] text-ink dark:text-base-ink md:text-4xl lg:text-5xl">
                {article.title}
              </h1>
              <p className="mt-5 text-lg leading-relaxed text-ink-soft dark:text-base-ink-soft">
                {article.excerpt}
              </p>
              <div className="mt-7 flex flex-wrap items-center gap-5 text-sm text-ink-mute dark:text-base-ink-soft">
                <span className="font-medium text-ink dark:text-base-ink">{article.author}</span>
                <span className="flex items-center gap-1.5">
                  <Calendar size={14} />
                  {article.date}
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock size={14} />
                  {article.readTime}
                </span>
              </div>
            </div>
          </header>

          <div className="mx-auto max-w-4xl px-5 md:px-8">
            <ArticleCover article={article} className="aspect-[16/9] rounded-lg md:-mt-8" />
          </div>

          <div className="mx-auto max-w-3xl px-5 py-12 md:px-8 md:py-16">
            <div className="prose-article">
              {article.content.map((block, i) => {
                if (block.type === "h2")
                  return <h2 key={i}>{block.text}</h2>;
                if (block.type === "quote")
                  return <blockquote key={i}>{block.text}</blockquote>;
                if (block.type === "ul")
                  return (
                    <ul key={i}>
                      {block.items?.map((it, j) => (
                        <li key={j}>{it}</li>
                      ))}
                    </ul>
                  );
                return <p key={i}>{block.text}</p>;
              })}
            </div>

            <div className="mt-12 border-t border-line pt-8 dark:border-base-line">
              <a
                href="/author"
                className="flex items-center gap-4 rounded-xl border border-line bg-paper-2 p-5 transition-colors hover:border-accent dark:border-base-line dark:bg-base-surface"
              >
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent font-serif text-lg font-700 text-paper">
                  {article.author.split(" ").map((n) => n[0]).join("")}
                </div>
                <div>
                  <p className="text-xs text-ink-mute dark:text-base-ink-soft">Written by</p>
                  <p className="font-serif text-lg font-600 text-ink dark:text-base-ink">{article.author}</p>
                  <p className="text-sm text-ink-soft dark:text-base-ink-soft">Contributing writer at The Margin</p>
                </div>
              </a>
            </div>
          </div>
        </article>

        <RelatedArticles currentSlug={article.slug} />
        <Newsletter />
      </main>
      <Footer />
    </>
  );
}
