import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { Newsletter } from "@/components/newsletter";
import { author, site } from "@/lib/data";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About — The Margin",
  description: site.tagline,
};

export default function AboutPage() {
  return (
    <>
      <Nav />
      <main>
        <section className="border-b border-line dark:border-base-line">
          <div className="mx-auto max-w-3xl px-5 py-16 md:px-8 md:py-24">
            <p className="eyebrow">About</p>
            <h1 className="font-serif mt-4 text-4xl font-700 leading-tight text-ink dark:text-base-ink md:text-5xl">
              {site.tagline}.
            </h1>
            <div className="mt-8 space-y-5 text-lg leading-relaxed text-ink-soft dark:text-base-ink-soft">
              <p>
                The Margin is an independent magazine for people who build, make, and stay curious.
                We publish deeply-reported essays on technology, design, culture, and the craft of work
                that lasts — the kind of writing that rewards a second read.
              </p>
              <p>
                We started The Margin because the conversation about building things had become either
                too loud or too shallow. We wanted a place for the slower piece, the considered argument,
                the idea that needs more than eight hundred words.
              </p>
              <p>
                The magazine is reader-supported. No display advertising, no sponsored content disguised
                as editorial. Just essays, and the people who write them.
              </p>
            </div>
          </div>
        </section>

        <section className="border-b border-line bg-paper-2 dark:border-base-line dark:bg-base-surface">
          <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
            <div className="grid gap-8 md:grid-cols-3">
              {author.stats.map((stat) => (
                <div key={stat.label} className="text-center">
                  <p className="font-serif text-4xl font-700 text-accent dark:text-base-accent">{stat.value}</p>
                  <p className="mt-2 text-sm text-ink-soft dark:text-base-ink-soft">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Newsletter />
      </main>
      <Footer />
    </>
  );
}
