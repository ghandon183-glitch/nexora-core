import Link from "next/link";
import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";

export default function NotFound() {
  return (
    <>
      <Nav />
      <main id="main" className="mx-auto max-w-3xl px-5 py-24 text-center md:px-8">
        <p className="eyebrow">404</p>
        <h1 className="font-serif mt-4 text-3xl font-700 text-ink dark:text-base-ink md:text-4xl">
          That page is not in this issue.
        </h1>
        <p className="mt-4 text-ink-soft dark:text-base-ink-soft">
          The link may be outdated or the essay may have moved. The archive is still here.
        </p>
        <Link
          href="/"
          className="mt-8 inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3 text-sm font-semibold text-paper transition-colors hover:bg-accent dark:bg-base-ink dark:text-base dark:hover:bg-base-accent"
        >
          Back to the homepage
        </Link>
      </main>
      <Footer />
    </>
  );
}
