import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { ArticleCover } from "@/components/article-cover";
import { articles, categories } from "@/lib/data";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { Clock } from "lucide-react";

export function generateStaticParams() {
  return categories.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const cat = categories.find((c) => c.slug === slug);
  return { title: `${cat?.name ?? "Category"} — The Margin` };
}

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const cat = categories.find((c) => c.slug === slug);
  if (!cat) notFound();

  const matches = articles.filter((a) => a.category.toLowerCase() === cat.name.toLowerCase());

  return (
    <>
      <Nav />
      <main>
        <section className="border-b border-line dark:border-base-line">
          <div className="mx-auto max-w-6xl px-5 py-12 md:px-8 md:py-16">
            <p className="eyebrow">Section</p>
            <h1 className="font-serif mt-3 text-4xl font-700 text-ink dark:text-base-ink md:text-5xl">
              {cat.name}
            </h1>
            <p className="mt-3 text-sm text-ink-mute dark:text-base-ink-soft">{cat.count} essays in this section</p>
          </div>
        </section>

        <section className="border-b border-line dark:border-base-line">
          <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
            {matches.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-line p-12 text-center dark:border-base-line">
                <p className="font-serif text-xl text-ink dark:text-base-ink">No essays in this section yet</p>
                <p className="mt-2 text-sm text-ink-soft dark:text-base-ink-soft">
                  New writing in {cat.name} is published regularly. Check back soon.
                </p>
                <a href="/" className="mt-5 inline-flex items-center gap-2 rounded-full bg-ink px-5 py-2.5 text-sm font-semibold text-paper dark:bg-base-ink dark:text-base">
                  Browse all essays
                </a>
              </div>
            ) : (
              <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                {matches.map((article) => (
                  <article key={article.slug} className="group flex flex-col">
                    <a href={`/articles/${article.slug}`} className="block overflow-hidden rounded-lg">
                      <ArticleCover article={article} className="aspect-[16/10] transition-transform duration-500 group-hover:scale-[1.03]" />
                    </a>
                    <h3 className="font-serif mt-3 text-lg font-600 leading-snug text-ink dark:text-base-ink">
                      <a href={`/articles/${article.slug}`} className="transition-colors hover:text-accent dark:hover:text-base-accent">
                        {article.title}
                      </a>
                    </h3>
                    <p className="mt-2 line-clamp-2 text-sm text-ink-soft dark:text-base-ink-soft">{article.excerpt}</p>
                    <p className="mt-3 flex items-center gap-1.5 text-xs text-ink-mute dark:text-base-ink-soft">
                      <Clock size={12} />
                      {article.readTime} · {article.date}
                    </p>
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
