import type { MetadataRoute } from "next";
import { articles, categories } from "@/lib/data";
import { BASE_PATH, SITE_URL } from "@/lib/base-path";

export const dynamic = "force-static";

/**
 * Sitemap entries need absolute URLs, so they are only generated when
 * NEXT_PUBLIC_SITE_URL is set. Set it before deploying and the sitemap picks up
 * the base path automatically.
 */
export default function sitemap(): MetadataRoute.Sitemap {
  if (!SITE_URL) return [];

  const base = `${SITE_URL}${BASE_PATH}`;
  const routes = [
    "/",
    "/about",
    "/author",
    ...categories.map((category) => `/category/${category.slug}`),
    ...articles.map((article) => `/articles/${article.slug}`),
  ];

  return routes.map((route) => ({
    url: `${base}${route}`,
    changeFrequency: route === "/" ? "daily" : "monthly",
    priority: route === "/" ? 1 : 0.7,
  }));
}
