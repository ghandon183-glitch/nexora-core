import type { MetadataRoute } from "next";
import { BASE_PATH, SITE_URL } from "@/lib/base-path";

export const dynamic = "force-static";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: "*", allow: "/" },
    sitemap: SITE_URL ? `${SITE_URL}${BASE_PATH}/sitemap.xml` : undefined,
  };
}
