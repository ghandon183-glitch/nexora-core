import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { FeaturedArticle } from "@/components/featured-article";
import { ArticleGrid } from "@/components/article-grid";
import { Categories } from "@/components/categories";
import { Trending } from "@/components/trending";
import { Newsletter } from "@/components/newsletter";

export default function Home() {
  return (
    <>
      <Nav />
      <main>
        <FeaturedArticle />
        <Categories />
        <ArticleGrid />
        <Trending />
        <Newsletter />
      </main>
      <Footer />
    </>
  );
}
