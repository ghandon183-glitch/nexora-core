import type { Metadata } from "next";
import "@fontsource/lora/400.css";
import "@fontsource/lora/500.css";
import "@fontsource/lora/600.css";
import "@fontsource/lora/700.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "@fontsource/inter/700.css";
import "./globals.css";
import { SITE_URL, absoluteUrl } from "@/lib/base-path";

const siteDescription =
  "The Margin is an independent magazine publishing deeply-reported essays on technology, design, culture, and the craft of building things that last.";

export const metadata: Metadata = {
  metadataBase: SITE_URL ? new URL(SITE_URL) : undefined,
  title: {
    default: "The Margin — A magazine for builders, makers, and the curious",
    template: "%s",
  },
  description: siteDescription,
  keywords: ["magazine", "blog", "essays", "technology", "design", "culture"],
  alternates: { canonical: absoluteUrl("/") ?? "/" },
  openGraph: {
    title: "The Margin — A magazine for builders, makers, and the curious",
    description:
      "Deeply-reported essays on technology, design, culture, and the craft of building.",
    type: "website",
    url: absoluteUrl("/"),
  },
  twitter: { card: "summary_large_image" },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <a href="#main" className="skip-link">
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
