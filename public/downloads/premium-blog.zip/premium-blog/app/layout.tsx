import type { Metadata } from "next";
import "@fontsource/lora/400.css";
import "@fontsource/lora/500.css";
import "@fontsource/lora/600.css";
import "@fontsource/lora/700.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "@fontsource/inter/700.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "The Margin — A magazine for builders, makers, and the curious",
  description:
    "The Margin is an independent magazine publishing deeply-reported essays on technology, design, culture, and the craft of building things that last.",
  keywords: ["magazine", "blog", "essays", "technology", "design", "culture"],
  openGraph: {
    title: "The Margin — A magazine for builders, makers, and the curious",
    description:
      "Deeply-reported essays on technology, design, culture, and the craft of building.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
