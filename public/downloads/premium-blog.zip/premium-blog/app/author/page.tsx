import Link from "next/link";
import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { ArticleCover } from "@/components/article-cover";
import { articles, author } from "@/lib/data";
import { absoluteUrl } from "@/lib/base-path";
import type { Metadata } from "next";
import { Clock } from "lucide-react";

const canonical = absoluteUrl("/author");

export const metadata: Metadata = {
  title: `${author.name} — The Margin`,
  description: author.bio,
  alternates: canonical ? { canonical } : undefined,
};

export default function AuthorPage() {
  const authored = articles.filter((a) => a.author === author.name);
  const contributors = [...new Set(articles.map((a) => a.author))].filter(
    (name) => name !== author.name,
  );

  return (
    <>
      <Nav />
      <main id="main">
        <section className="border-b border-line dark:border-base-line">
          <div className="mx-auto max-w-6xl px-5 py-12 md:px-8 md:py-16">
            <div className="flex flex-col gap-6 md:flex-row md:items-center md:gap-8">
              <div className="flex h-24 w-24 shrink-0 items-center justify-center rounded-full bg-accent font-serif text-3xl font-700 text-paper dark:text-base">
                {author.name
                  .split(" ")
                  .map((name) => name[0])
                  .join("")}
              </div>
              <div>
                <p className="eyebrow">{author.role}</p>
                <h1 className="font-serif mt-2 text-3xl font-700 text-ink dark:text-base-ink md:text-4xl">
                  {author.name}
                </h1>
                <p className="mt-3 max-w-2xl leading-relaxed text-ink-soft dark:text-base-ink-soft">
                  {author.bio}
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="border-b border-line dark:border-base-line">
          <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
            <p className="eyebrow">Essays by {author.name.split(" ")[0]}</p>
            <div className="mt-8 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              {authored.map((article) => (
                <article key={article.slug} className="group flex flex-col">
                  <Link href={`/articles/${article.slug}`} className="block overflow-hidden rounded-lg">
                    <ArticleCover article={article} className="aspect-[16/10] transition-transform duration-500 group-hover:scale-[1.03]" />
                  </Link>
                  <p className="mt-3 text-xs font-semibold text-accent dark:text-base-accent">{article.category}</p>
                  <h2 className="font-serif mt-1.5 text-lg font-600 leading-snug text-ink dark:text-base-ink">
                    <Link href={`/articles/${article.slug}`} className="transition-colors hover:text-accent dark:hover:text-base-accent">
                      {article.title}
                    </Link>
                  </h2>
                  <p className="mt-2 line-clamp-2 text-sm text-ink-soft dark:text-base-ink-soft">{article.excerpt}</p>
                  <p className="mt-3 flex items-center gap-1.5 text-xs text-ink-mute dark:text-base-ink-soft">
                    <Clock size={12} aria-hidden="true" />
                    {article.readTime} · {article.date}
                  </p>
                </article>
              ))}
            </div>

            {contributors.length > 0 && (
              <div className="mt-14 border-t border-line pt-8 dark:border-base-line">
                <p className="eyebrow">Contributing writers in this issue</p>
                <p className="mt-3 text-sm leading-relaxed text-ink-soft dark:text-base-ink-soft">
                  {contributors.join(", ")}.
                </p>
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
