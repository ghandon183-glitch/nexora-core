import { categories } from "@/lib/data";

export function Categories() {
  return (
    <section className="border-b border-line bg-paper-2 dark:border-base-line dark:bg-base-surface">
      <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-16">
        <div className="flex items-end justify-between">
          <div>
            <p className="eyebrow">Browse</p>
            <h2 className="font-serif mt-3 text-2xl font-700 text-ink dark:text-base-ink md:text-3xl">
              By section
            </h2>
          </div>
          <a href="/about" className="link-underline hidden text-sm font-medium text-ink-soft dark:text-base-ink-soft md:block">
            All sections
          </a>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-5">
          {categories.map((cat) => (
            <a
              key={cat.slug}
              href={`/category/${cat.slug}`}
              className="group rounded-xl border border-line bg-paper p-5 transition-all hover:border-accent dark:border-base-line dark:bg-base"
            >
              <p className="font-serif text-lg font-600 text-ink dark:text-base-ink">{cat.name}</p>
              <p className="mt-1 text-xs text-ink-mute dark:text-base-ink-soft">{cat.count} essays</p>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
