import { articles } from "@/lib/data";
import { ArticleCover } from "@/components/article-cover";
import { Clock } from "lucide-react";

export function RelatedArticles({ currentSlug }: { currentSlug: string }) {
  const related = articles
    .filter((a) => a.slug !== currentSlug)
    .slice(0, 3);

  if (related.length === 0) return null;

  return (
    <section className="border-b border-line bg-paper-2 dark:border-base-line dark:bg-base-surface">
      <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
        <p className="eyebrow">Keep reading</p>
        <h2 className="font-serif mt-3 text-2xl font-700 text-ink dark:text-base-ink md:text-3xl">
          Related essays
        </h2>
        <div className="mt-8 grid gap-8 md:grid-cols-3">
          {related.map((article) => (
            <article key={article.slug} className="group">
              <a href={`/articles/${article.slug}`} className="block overflow-hidden rounded-lg">
                <ArticleCover article={article} className="aspect-[16/10] transition-transform duration-500 group-hover:scale-[1.03]" />
              </a>
              <p className="mt-3 text-xs font-semibold text-accent dark:text-base-accent">{article.category}</p>
              <h3 className="font-serif mt-1.5 text-lg font-600 leading-snug text-ink dark:text-base-ink">
                <a href={`/articles/${article.slug}`} className="transition-colors hover:text-accent dark:hover:text-base-accent">
                  {article.title}
                </a>
              </h3>
              <p className="mt-2 flex items-center gap-1.5 text-xs text-ink-mute dark:text-base-ink-soft">
                <Clock size={12} />
                {article.readTime}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
