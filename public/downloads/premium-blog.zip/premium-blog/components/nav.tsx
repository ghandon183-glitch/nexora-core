"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { Search, Menu, X, ArrowRight } from "lucide-react";
import { articles, categories, site } from "@/lib/data";

export function Nav() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const searchInput = useRef<HTMLInputElement>(null);

  const trimmed = query.trim().toLowerCase();

  const results = useMemo(() => {
    if (trimmed.length < 2) return [];
    return articles
      .filter((article) =>
        [article.title, article.excerpt, article.category, article.author]
          .join(" ")
          .toLowerCase()
          .includes(trimmed),
      )
      .slice(0, 5);
  }, [trimmed]);

  useEffect(() => {
    if (!menuOpen && !searchOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      setMenuOpen(false);
      setSearchOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [menuOpen, searchOpen]);

  useEffect(() => {
    if (searchOpen) searchInput.current?.focus();
  }, [searchOpen]);

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-paper/90 backdrop-blur-xl dark:border-base-line dark:bg-base/90">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 md:px-8">
        <div className="flex min-w-0 items-center gap-8">
          <Link
            href="/"
            className="font-serif shrink-0 text-xl font-700 tracking-tight text-ink dark:text-base-ink"
          >
            {site.name}
          </Link>
          <nav aria-label="Sections" className="hidden items-center gap-6 lg:flex">
            {categories.map((cat) => (
              <Link
                key={cat.slug}
                href={`/category/${cat.slug}`}
                className="link-underline text-sm font-medium text-ink-soft dark:text-base-ink-soft"
              >
                {cat.name}
              </Link>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              setSearchOpen((value) => !value);
              setMenuOpen(false);
            }}
            aria-label={searchOpen ? "Close search" : "Search articles"}
            aria-expanded={searchOpen}
            aria-controls="site-search"
            className="rounded-full p-2 text-ink-soft transition-colors hover:text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent dark:text-base-ink-soft dark:hover:text-base-ink"
          >
            <Search size={19} strokeWidth={1.75} />
          </button>
          <Link
            href="/#newsletter"
            className="hidden rounded-full bg-ink px-4 py-2 text-sm font-semibold text-paper transition-colors hover:bg-accent dark:bg-base-ink dark:text-base dark:hover:bg-base-accent md:inline-block"
          >
            Subscribe
          </Link>
          <button
            type="button"
            className="rounded-full p-2 text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent dark:text-base-ink lg:hidden"
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
            aria-controls="site-menu"
            onClick={() => {
              setMenuOpen((value) => !value);
              setSearchOpen(false);
            }}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      <div id="site-search" hidden={!searchOpen} className="border-t border-line bg-paper dark:border-base-line dark:bg-base">
        {searchOpen && (
          <div role="search" className="mx-auto max-w-6xl px-5 py-4 md:px-8">
            <label htmlFor="site-search-input" className="sr-only">
              Search essays, topics, and authors
            </label>
            <input
              ref={searchInput}
              id="site-search-input"
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search essays, topics, authors…"
              className="w-full border-b border-line bg-transparent pb-3 text-lg text-ink outline-none placeholder:text-ink-mute focus:border-accent dark:border-base-line dark:text-base-ink dark:placeholder:text-base-ink-soft"
            />
            <p className="mt-3 text-xs text-ink-mute dark:text-base-ink-soft" aria-live="polite">
              {trimmed.length < 2
                ? "Type at least two characters. Try “slow software”, “attention”, or “edge”."
                : `${results.length} result${results.length === 1 ? "" : "s"} for “${query.trim()}”.`}
            </p>

            {results.length > 0 && (
              <ul className="mt-4 divide-y divide-line dark:divide-base-line">
                {results.map((article) => (
                  <li key={article.slug}>
                    <Link
                      href={`/articles/${article.slug}`}
                      onClick={() => setSearchOpen(false)}
                      className="group flex items-start justify-between gap-4 py-3"
                    >
                      <span>
                        <span className="block text-xs font-semibold text-accent dark:text-base-accent">
                          {article.category}
                        </span>
                        <span className="font-serif mt-0.5 block text-base font-600 text-ink group-hover:text-accent dark:text-base-ink dark:group-hover:text-base-accent">
                          {article.title}
                        </span>
                      </span>
                      <ArrowRight
                        size={16}
                        aria-hidden="true"
                        className="mt-1 shrink-0 text-ink-mute transition-transform group-hover:translate-x-1 dark:text-base-ink-soft"
                      />
                    </Link>
                  </li>
                ))}
              </ul>
            )}

            {trimmed.length >= 2 && results.length === 0 && (
              <p className="mt-4 text-sm text-ink-soft dark:text-base-ink-soft">
                No essays match that search yet.
              </p>
            )}
          </div>
        )}
      </div>

      <div id="site-menu" hidden={!menuOpen} className="border-t border-line bg-paper dark:border-base-line dark:bg-base lg:hidden">
        {menuOpen && (
          <nav aria-label="Mobile" className="flex flex-col gap-4 px-5 py-5">
            {categories.map((cat) => (
              <Link
                key={cat.slug}
                href={`/category/${cat.slug}`}
                onClick={() => setMenuOpen(false)}
                className="text-base font-medium text-ink-soft dark:text-base-ink-soft"
              >
                {cat.name}
              </Link>
            ))}
            <Link
              href="/about"
              onClick={() => setMenuOpen(false)}
              className="text-base font-medium text-ink-soft dark:text-base-ink-soft"
            >
              About
            </Link>
            <Link
              href="/author"
              onClick={() => setMenuOpen(false)}
              className="text-base font-medium text-ink-soft dark:text-base-ink-soft"
            >
              Contributors
            </Link>
            <Link
              href="/#newsletter"
              onClick={() => setMenuOpen(false)}
              className="text-base font-medium text-ink-soft dark:text-base-ink-soft"
            >
              Subscribe
            </Link>
          </nav>
        )}
      </div>
    </header>
  );
}
