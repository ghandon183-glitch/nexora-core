"use client";

import { useState } from "react";
import { Search, Menu, X } from "lucide-react";
import { site, categories } from "@/lib/data";

export function Nav() {
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-line bg-paper/90 backdrop-blur-xl dark:border-base-line dark:bg-base/90">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 md:px-8">
        <div className="flex items-center gap-8">
          <a href="/" className="font-serif text-xl font-700 tracking-tight text-ink dark:text-base-ink">
            {site.name}
          </a>
          <nav className="hidden items-center gap-6 lg:flex">
            {categories.slice(0, 5).map((cat) => (
              <a
                key={cat.slug}
                href={`/category/${cat.slug}`}
                className="link-underline text-sm font-medium text-ink-soft dark:text-base-ink-soft"
              >
                {cat.name}
              </a>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setSearchOpen((v) => !v)}
            aria-label="Search articles"
            className="text-ink-soft transition-colors hover:text-ink dark:text-base-ink-soft"
          >
            <Search size={19} strokeWidth={1.75} />
          </button>
          <a
            href="/about"
            className="hidden rounded-full bg-ink px-4 py-2 text-sm font-semibold text-paper transition-colors hover:bg-accent dark:bg-base-ink dark:text-base dark:hover:bg-base-accent md:inline-block"
          >
            Subscribe
          </a>
          <button
            className="text-ink dark:text-base-ink lg:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {searchOpen && (
        <div className="border-t border-line bg-paper px-5 py-4 dark:border-base-line dark:bg-base md:px-8">
          <input
            autoFocus
            type="search"
            placeholder="Search essays, topics, authors…"
            className="w-full bg-transparent text-lg text-ink outline-none placeholder:text-ink-mute dark:text-base-ink dark:placeholder:text-base-ink-soft"
          />
          <p className="mt-2 text-xs text-ink-mute dark:text-base-ink-soft">
            Try “slow software”, “attention”, or “edge computing”.
          </p>
        </div>
      )}

      {open && (
        <div className="border-t border-line bg-paper px-5 py-5 dark:border-base-line dark:bg-base lg:hidden">
          <nav className="flex flex-col gap-4">
            {categories.map((cat) => (
              <a
                key={cat.slug}
                href={`/category/${cat.slug}`}
                onClick={() => setOpen(false)}
                className="text-base font-medium text-ink-soft dark:text-base-ink-soft"
              >
                {cat.name}
              </a>
            ))}
            <a href="/about" className="text-base font-medium text-ink-soft dark:text-base-ink-soft">
              About
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
