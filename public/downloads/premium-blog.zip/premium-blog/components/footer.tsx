import Link from "next/link";
import { site, categories, newsletter } from "@/lib/data";
import { Mail, Globe, MessageCircle } from "lucide-react";

const socials = [
  { label: "About the magazine", href: "/about", icon: Globe },
  { label: "Contributors", href: "/author", icon: MessageCircle },
  { label: "Newsletter", href: "/#newsletter", icon: Mail },
];

export function Footer() {
  return (
    <footer className="border-t border-line bg-paper-2 dark:border-base-line dark:bg-base-surface">
      <div className="mx-auto max-w-6xl px-5 py-14 md:px-8">
        <div className="grid gap-10 md:grid-cols-[1.5fr_1fr_1fr]">
          <div>
            <p className="font-serif text-2xl font-700 text-ink dark:text-base-ink">{site.name}</p>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-ink-soft dark:text-base-ink-soft">
              {site.tagline}. Independently published, reader-supported.
            </p>
            <ul className="mt-5 flex gap-3">
              {socials.map((item) => (
                <li key={item.label}>
                  <Link
                    href={item.href}
                    aria-label={item.label}
                    title={item.label}
                    className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-ink-soft transition-colors hover:border-accent hover:text-accent focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent dark:border-base-line dark:text-base-ink-soft dark:hover:border-base-accent dark:hover:text-base-accent"
                  >
                    <item.icon size={15} aria-hidden="true" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <nav aria-label="Sections">
            <p className="eyebrow">Sections</p>
            <ul className="mt-4 space-y-3">
              {categories.map((cat) => (
                <li key={cat.slug}>
                  <Link
                    href={`/category/${cat.slug}`}
                    className="link-underline text-sm text-ink-soft dark:text-base-ink-soft"
                  >
                    {cat.name}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <p className="eyebrow">{newsletter.title}</p>
            <p className="mt-4 text-sm leading-relaxed text-ink-soft dark:text-base-ink-soft">
              {newsletter.description}
            </p>
            <Link
              href="/#newsletter"
              className="link-underline mt-3 inline-block text-sm font-semibold text-ink dark:text-base-ink"
            >
              Join the list
            </Link>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-line pt-6 text-xs text-ink-mute dark:border-base-line dark:text-base-ink-soft md:flex-row">
          <p>
            © {new Date().getFullYear()} {site.name}. All rights reserved.
          </p>
          <p>Editorial type, set in Lora and Inter.</p>
        </div>
      </div>
    </footer>
  );
}
