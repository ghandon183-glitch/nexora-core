import { site, categories, newsletter } from "@/lib/data";
import { Mail, Globe, MessageCircle } from "lucide-react";

const socials = [
  { label: "Website", icon: Globe },
  { label: "Letters", icon: MessageCircle },
  { label: "Newsletter", icon: Mail },
];

export function Footer() {
  return (
    <footer className="border-t border-line bg-paper-2 dark:border-base-line dark:bg-base-surface">
      <div className="mx-auto max-w-6xl px-5 py-14 md:px-8">
        <div className="grid gap-10 md:grid-cols-[1.5fr_1fr_1fr]">
          <div>
            <p className="font-serif text-2xl font-700 text-ink dark:text-base-ink">{site.name}</p>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-ink-soft dark:text-base-ink-soft">
              {site.tagline}. Independently published, reader-supported.
            </p>
            <div className="mt-5 flex gap-3">
              {socials.map((s) => (
                <span
                  key={s.label}
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-ink-soft dark:border-base-line dark:text-base-ink-soft"
                >
                  <s.icon size={15} />
                </span>
              ))}
            </div>
          </div>

          <div>
            <p className="eyebrow">Sections</p>
            <ul className="mt-4 space-y-3">
              {categories.map((cat) => (
                <li key={cat.slug}>
                  <a href={`/category/${cat.slug}`} className="link-underline text-sm text-ink-soft dark:text-base-ink-soft">
                    {cat.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="eyebrow">{newsletter.title}</p>
            <p className="mt-4 text-sm leading-relaxed text-ink-soft dark:text-base-ink-soft">
              {newsletter.description}
            </p>
            <p className="mt-3 text-xs text-ink-mute dark:text-base-ink-soft">
              {newsletter.subscribers} readers
            </p>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-line pt-6 text-xs text-ink-mute dark:border-base-line dark:text-base-ink-soft md:flex-row">
          <p>© {new Date().getFullYear()} {site.name}. All rights reserved.</p>
          <p>Editorial type, set in Lora and Inter.</p>
        </div>
      </div>
    </footer>
  );
}
