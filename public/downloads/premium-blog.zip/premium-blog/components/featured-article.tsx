import { articles } from "@/lib/data";
import { ArticleCover } from "@/components/article-cover";
import { Clock } from "lucide-react";

export function FeaturedArticle() {
  const article = articles.find((a) => a.featured) ?? articles[0];

  return (
    <section className="border-b border-line dark:border-base-line">
      <div className="mx-auto max-w-6xl px-5 py-12 md:px-8 md:py-16">
        <p className="eyebrow">Featured essay</p>
        <div className="mt-6 grid gap-8 lg:grid-cols-2 lg:gap-12">
          <a href={`/articles/${article.slug}`} className="group block overflow-hidden rounded-lg">
            <ArticleCover article={article} className="aspect-[16/10] transition-transform duration-500 group-hover:scale-[1.02]" />
          </a>
          <div className="flex flex-col justify-center">
            <div className="flex items-center gap-3">
              <span className="rounded-full bg-accent-soft px-3 py-1 text-xs font-semibold text-accent">
                {article.category}
              </span>
              <span className="text-xs text-ink-mute dark:text-base-ink-soft">{article.date}</span>
            </div>
            <h1 className="font-serif mt-4 text-3xl font-700 leading-tight text-ink dark:text-base-ink md:text-4xl lg:text-[2.6rem]">
              <a href={`/articles/${article.slug}`} className="transition-colors hover:text-accent dark:hover:text-base-accent">
                {article.title}
              </a>
            </h1>
            <p className="mt-4 text-base leading-relaxed text-ink-soft dark:text-base-ink-soft">
              {article.excerpt}
            </p>
            <div className="mt-6 flex items-center gap-4 text-sm text-ink-mute dark:text-base-ink-soft">
              <span className="font-medium text-ink dark:text-base-ink">{article.author}</span>
              <span className="flex items-center gap-1.5">
                <Clock size={14} />
                {article.readTime}
              </span>
            </div>
            <a
              href={`/articles/${article.slug}`}
              className="mt-8 inline-flex w-fit items-center gap-2 rounded-full bg-ink px-6 py-3 text-sm font-semibold text-paper transition-colors hover:bg-accent dark:bg-base-ink dark:text-base dark:hover:bg-base-accent"
            >
              Read the essay
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
