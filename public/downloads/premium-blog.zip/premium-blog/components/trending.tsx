import { articles } from "@/lib/data";
import { Flame } from "lucide-react";

export function Trending() {
  const trending = articles.filter((a) => a.trending);

  return (
    <section className="border-b border-line dark:border-base-line">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-[1fr_1.5fr] md:px-8 md:py-20">
        <div>
          <p className="eyebrow flex items-center gap-2">
            <Flame size={14} />
            Trending
          </p>
          <h2 className="font-serif mt-3 text-2xl font-700 leading-tight text-ink dark:text-base-ink md:text-3xl">
            What readers are returning to this week.
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-ink-soft dark:text-base-ink-soft">
            A rolling selection of the essays with the most re-reads, saves, and reader responses.
          </p>
        </div>

        <ol className="divide-y divide-line dark:divide-base-line">
          {trending.map((article, i) => (
            <li key={article.slug}>
              <a href={`/articles/${article.slug}`} className="group flex gap-5 py-5">
                <span className="font-serif text-3xl font-700 text-ink-mute dark:text-base-ink-soft">
                  0{i + 1}
                </span>
                <div className="flex-1">
                  <p className="text-xs font-semibold text-accent dark:text-base-accent">{article.category}</p>
                  <h3 className="font-serif mt-1 text-lg font-600 text-ink transition-colors group-hover:text-accent dark:text-base-ink dark:hover:text-base-accent">
                    {article.title}
                  </h3>
                  <p className="mt-1 text-xs text-ink-mute dark:text-base-ink-soft">
                    {article.author} · {article.readTime}
                  </p>
                </div>
              </a>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
