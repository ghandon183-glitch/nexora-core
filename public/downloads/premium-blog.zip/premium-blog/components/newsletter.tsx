"use client";

import { useState } from "react";
import { newsletter } from "@/lib/data";
import { Check, ArrowRight } from "lucide-react";

export function Newsletter() {
  const [sent, setSent] = useState(false);

  return (
    <section className="border-b border-line bg-ink dark:border-base-line dark:bg-base-surface">
      <div className="mx-auto max-w-4xl px-5 py-16 text-center md:px-8 md:py-24">
        <p className="eyebrow text-accent-soft">{newsletter.title}</p>
        <h2 className="font-serif mt-4 text-3xl font-700 leading-tight text-paper dark:text-base-ink md:text-4xl">
          {newsletter.description}
        </h2>
        <p className="mt-4 text-sm text-paper-2/70 dark:text-base-ink-soft">
          Join {newsletter.subscribers} readers. Free, no spam, unsubscribe anytime.
        </p>

        {sent ? (
          <div className="mx-auto mt-8 flex max-w-md items-center justify-center gap-2 rounded-full bg-accent px-6 py-4 text-sm font-semibold text-paper">
            <Check size={18} />
            You&apos;re subscribed. See you Saturday.
          </div>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setSent(true);
            }}
            className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
          >
            <input
              type="email"
              required
              placeholder="you@example.com"
              className="flex-1 rounded-full border border-white/15 bg-white/5 px-5 py-3.5 text-sm text-paper placeholder:text-paper-2/50 focus:border-accent focus:outline-none dark:text-base-ink dark:placeholder:text-base-ink-soft"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-accent px-6 py-3.5 text-sm font-semibold text-paper transition-transform hover:scale-[1.02] dark:text-base"
            >
              Subscribe
              <ArrowRight size={16} />
            </button>
          </form>
        )}
      </div>
    </section>
  );
}
