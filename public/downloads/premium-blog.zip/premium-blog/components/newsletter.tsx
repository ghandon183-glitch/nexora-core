"use client";

import { useState } from "react";
import { newsletter } from "@/lib/data";
import { Check, ArrowRight } from "lucide-react";

export function Newsletter() {
  const [submittedEmail, setSubmittedEmail] = useState<string | null>(null);

  return (
    <section id="newsletter" className="border-b border-line bg-ink dark:border-base-line dark:bg-base-surface">
      <div className="mx-auto max-w-4xl px-5 py-16 text-center md:px-8 md:py-24">
        <p className="eyebrow text-accent-soft">{newsletter.title}</p>
        <h2 className="font-serif mt-4 text-3xl font-700 leading-tight text-paper dark:text-base-ink md:text-4xl">
          {newsletter.description}
        </h2>
        <p className="mt-4 text-sm text-paper-2/70 dark:text-base-ink-soft">
          Free, no spam, unsubscribe anytime.
        </p>

        {submittedEmail ? (
          <div
            role="status"
            className="mx-auto mt-8 max-w-md rounded-2xl border border-white/15 bg-white/5 px-6 py-5 text-sm text-paper dark:border-base-line dark:text-base-ink"
          >
            <p className="flex items-center justify-center gap-2 font-semibold">
              <Check size={18} aria-hidden="true" />
              Demo form — nothing was sent or stored.
            </p>
            <p className="mt-2 text-paper-2/70 dark:text-base-ink-soft">
              This template ships without a newsletter backend, so{" "}
              <span className="font-medium">{submittedEmail}</span> was not saved, emailed, or sent
              anywhere. Connect your provider in <code>components/newsletter.tsx</code>; the README
              explains the two-line change.
            </p>
          </div>
        ) : (
          <form
            onSubmit={(event) => {
              event.preventDefault();
              const input = event.currentTarget.elements.namedItem("email");
              setSubmittedEmail(input instanceof HTMLInputElement ? input.value : "your address");
            }}
            className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
          >
            <label htmlFor="newsletter-email" className="sr-only">
              Email address
            </label>
            <input
              id="newsletter-email"
              name="email"
              type="email"
              required
              autoComplete="email"
              placeholder="you@example.com"
              className="flex-1 rounded-full border border-white/15 bg-white/5 px-5 py-3.5 text-sm text-paper placeholder:text-paper-2/50 focus:border-accent focus:outline-none dark:text-base-ink dark:placeholder:text-base-ink-soft"
            />
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-accent px-6 py-3.5 text-sm font-semibold text-paper transition-transform hover:scale-[1.02] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-paper dark:text-base"
            >
              Subscribe
              <ArrowRight size={16} aria-hidden="true" />
            </button>
          </form>
        )}

        <p className="mt-4 text-xs text-paper-2/60 dark:text-base-ink-soft">
          Demo form: no email service is connected in this package.
        </p>
      </div>
    </section>
  );
}
