import { articles } from "@/lib/data";
import { ArticleCover } from "@/components/article-cover";
import { Clock } from "lucide-react";

export function ArticleGrid() {
  const grid = articles.filter((a) => !a.featured).slice(0, 6);

  return (
    <section className="border-b border-line dark:border-base-line">
      <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
        <div className="flex items-end justify-between">
          <div>
            <p className="eyebrow">Latest</p>
            <h2 className="font-serif mt-3 text-2xl font-700 text-ink dark:text-base-ink md:text-3xl">
              Recently published
            </h2>
          </div>
        </div>

        <div className="mt-10 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {grid.map((article) => (
            <article key={article.slug} className="group flex flex-col">
              <a href={`/articles/${article.slug}`} className="block overflow-hidden rounded-lg">
                <ArticleCover article={article} className="aspect-[16/10] transition-transform duration-500 group-hover:scale-[1.03]" />
              </a>
              <div className="mt-4 flex flex-1 flex-col">
                <div className="flex items-center gap-2 text-xs text-ink-mute dark:text-base-ink-soft">
                  <span className="font-semibold text-accent dark:text-base-accent">{article.category}</span>
                  <span>·</span>
                  <span className="flex items-center gap-1">
                    <Clock size={12} />
                    {article.readTime}
                  </span>
                </div>
                <h3 className="font-serif mt-2 text-lg font-600 leading-snug text-ink dark:text-base-ink">
                  <a href={`/articles/${article.slug}`} className="transition-colors hover:text-accent dark:hover:text-base-accent">
                    {article.title}
                  </a>
                </h3>
                <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-ink-soft dark:text-base-ink-soft">
                  {article.excerpt}
                </p>
                <p className="mt-3 text-xs text-ink-mute dark:text-base-ink-soft">
                  {article.author} · {article.date}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
