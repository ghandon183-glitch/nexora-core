import Link from "next/link";
import { articles } from "@/lib/data";
import { ArticleCover } from "@/components/article-cover";
import { Clock } from "lucide-react";

export function ArticleGrid() {
  const grid = articles.filter((a) => !a.featured).slice(0, 6);

  return (
    <section className="border-b border-line dark:border-base-line">
      <div className="mx-auto max-w-6xl px-5 py-14 md:px-8 md:py-20">
        <div className="flex items-end justify-between">
          <div>
            <p className="eyebrow">Latest</p>
            <h2 className="font-serif mt-3 text-2xl font-700 text-ink dark:text-base-ink md:text-3xl">
              Recently published
            </h2>
          </div>
        </div>

        <div className="mt-10 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {grid.map((article) => (
            <article key={article.slug} className="group flex flex-col">
              <Link href={`/articles/${article.slug}`} className="block overflow-hidden rounded-lg">
                <ArticleCover article={article} className="aspect-[16/10] transition-transform duration-500 group-hover:scale-[1.03]" />
              </Link>
              <div className="mt-4 flex flex-1 flex-col">
                <div className="flex items-center gap-2 text-xs text-ink-mute dark:text-base-ink-soft">
                  <Link
                    href={`/category/${article.category.toLowerCase()}`}
                    className="font-semibold text-accent hover:underline dark:text-base-accent"
                  >
                    {article.category}
                  </Link>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1">
                    <Clock size={12} aria-hidden="true" />
                    {article.readTime}
                  </span>
                </div>
                <h3 className="font-serif mt-2 text-lg font-600 leading-snug text-ink dark:text-base-ink">
                  <Link href={`/articles/${article.slug}`} className="transition-colors hover:text-accent dark:hover:text-base-accent">
                    {article.title}
                  </Link>
                </h3>
                <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-ink-soft dark:text-base-ink-soft">
                  {article.excerpt}
                </p>
                <p className="mt-3 text-xs text-ink-mute dark:text-base-ink-soft">
                  {article.author} · {article.date}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
