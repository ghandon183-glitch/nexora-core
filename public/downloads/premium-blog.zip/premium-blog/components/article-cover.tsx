import type { Article } from "@/lib/data";

export function ArticleCover({
  article,
  className,
}: {
  article: Pick<Article, "title" | "category" | "cover">;
  className?: string;
}) {
  const { palette, pattern } = article.cover;
  const gradientId = `cover-${article.title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")}`;

  return (
    <div className={`relative overflow-hidden ${className ?? ""}`} aria-hidden="true">
      <svg viewBox="0 0 800 450" className="h-full w-full" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={palette} stopOpacity="0.9" />
            <stop offset="100%" stopColor={palette} stopOpacity="0.55" />
          </linearGradient>
        </defs>
        <rect width="800" height="450" fill={`url(#${gradientId})`} />
        {pattern === "waves" &&
          Array.from({ length: 5 }).map((_, i) => (
            <path
              key={i}
              d={`M-50 ${100 + i * 70} Q 200 ${50 + i * 70} 400 ${100 + i * 70} T 850 ${100 + i * 70}`}
              stroke="rgba(255,255,255,0.18)"
              strokeWidth="2"
              fill="none"
            />
          ))}
        {pattern === "grid" &&
          Array.from({ length: 12 }).map((_, i) => (
            <line key={`v${i}`} x1={i * 70} y1="0" x2={i * 70} y2="450" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
          ))}
        {pattern === "blobs" &&
          [
            { cx: 200, cy: 150, r: 90 },
            { cx: 560, cy: 280, r: 120 },
            { cx: 640, cy: 100, r: 60 },
          ].map((c, i) => (
            <circle key={i} cx={c.cx} cy={c.cy} r={c.r} fill="rgba(255,255,255,0.12)" />
          ))}
        {pattern === "stripes" &&
          Array.from({ length: 14 }).map((_, i) => (
            <rect
              key={i}
              x={i * 70}
              y={0}
              width="22"
              height={450}
              fill="rgba(255,255,255,0.08)"
              transform="skewX(-18)"
            />
          ))}
        <text x="48" y="395" fill="rgba(255,255,255,0.9)" fontSize="13" letterSpacing="3" fontWeight="600">
          {article.category.toUpperCase()}
        </text>
      </svg>
    </div>
  );
}
