import { assetPath } from "@/lib/base-path";
import type { Article } from "@/lib/data";

export function ArticleCover({
  article,
  className,
}: {
  article: Pick<Article, "cover" | "title" | "category">;
  className?: string;
}) {
  const { palette, pattern } = article.cover;
  return (
    <div className={`relative overflow-hidden ${className ?? ""}`} aria-hidden="true">
      <svg viewBox="0 0 800 450" className="h-full w-full" preserveAspectRatio="xMidYMid slice" role="img">
        <defs>
          <linearGradient id={`bg-${article.title.slice(0, 6).replace(/\s/g, "")}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={palette} stopOpacity="0.9" />
            <stop offset="100%" stopColor={palette} stopOpacity="0.55" />
          </linearGradient>
        </defs>
        <rect width="800" height="450" fill={`url(#bg-${article.title.slice(0, 6).replace(/\s/g, "")})`} />
        {pattern === "waves" &&
          Array.from({ length: 5 }).map((_, i) => (
            <path
              key={i}
              d={`M-50 ${100 + i * 70} Q 200 ${50 + i * 70} 400 ${100 + i * 70} T 850 ${100 + i * 70}`}
              stroke="rgba(255,255,255,0.18)"
              strokeWidth="2"
              fill="none"
            />
          ))}
        {pattern === "grid" &&
          Array.from({ length: 12 }).map((_, i) => (
            <line key={`v${i}`} x1={i * 70} y1="0" x2={i * 70} y2="450" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
          ))}
        {pattern === "blobs" &&
          [
            { cx: 200, cy: 150, r: 90 },
            { cx: 560, cy: 280, r: 120 },
            { cx: 640, cy: 100, r: 60 },
          ].map((c, i) => (
            <circle key={i} cx={c.cx} cy={c.cy} r={c.r} fill="rgba(255,255,255,0.12)" />
          ))}
        {pattern === "stripes" &&
          Array.from({ length: 14 }).map((_, i) => (
            <rect
              key={i}
              x={i * 70}
              y={0}
              width="22"
              height={450}
              fill="rgba(255,255,255,0.08)"
              transform={`skewX(-18)`}
              transform-origin={`${i * 70} 0`}
            />
          ))}
        <text x="48" y="395" fill="rgba(255,255,255,0.9)" fontSize="13" letterSpacing="3" fontWeight="600">
          {article.category.toUpperCase()}
        </text>
      </svg>
    </div>
  );
}

export function ArticleCoverImage({ src, alt }: { src: string; alt: string }) {
  return <img src={assetPath(src)} alt={alt} className="h-full w-full object-cover" />;
}
