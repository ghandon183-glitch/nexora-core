export type Article = {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  author: string;
  date: string;
  readTime: string;
  featured?: boolean;
  trending?: boolean;
  cover: { palette: string; pattern: "waves" | "grid" | "blobs" | "stripes" };
  content: { type: "p" | "h2" | "quote" | "ul"; text?: string; items?: string[] }[];
};

export const categories = [
  { name: "Technology", slug: "technology", count: 24 },
  { name: "Design", slug: "design", count: 18 },
  { name: "Culture", slug: "culture", count: 12 },
  { name: "Business", slug: "business", count: 15 },
  { name: "Science", slug: "science", count: 9 },
];

export const author = {
  name: "Eleanor Vance",
  role: "Editor-in-Chief",
  bio: "Eleanor has spent fifteen years reporting on the people and ideas shaping how we build. Before The Margin she led editorial at two independent publications and wrote for national outlets on technology and culture.",
  stats: [
    { value: "240+", label: "Essays published" },
    { value: "1.2M", label: "Monthly readers" },
    { value: "48", label: "Contributors" },
  ],
};

export const articles: Article[] = [
  {
    slug: "the-quiet-return-of-slow-software",
    title: "The Quiet Return of Slow Software",
    excerpt:
      "After a decade of breakneck shipping, a generation of engineers is rediscovering the value of software that takes its time — and the craft that comes with it.",
    category: "Technology",
    author: "Eleanor Vance",
    date: "August 11, 2026",
    readTime: "9 min read",
    featured: true,
    trending: true,
    cover: { palette: "#c2410c", pattern: "waves" },
    content: [
      {
        type: "p",
        text: "There is a particular silence in the room when a piece of software opens instantly. No spinner, no skeleton screen, no apology. The interface is simply there, as though it had been waiting. For a growing number of engineers, that silence has become a kind of manifesto.",
      },
      {
        type: "p",
        text: "Slow software is not software that is slow. It is software that respects the time of the person using it — and the time of the people who will maintain it. It is built with the assumption that performance is a feature, that correctness is a feature, and that the most valuable code is the code you never have to rewrite.",
      },
      {
        type: "h2",
        text: "The cost of the speed spiral",
      },
      {
        type: "p",
        text: "For most of the last decade, the dominant question in product engineering was how quickly something could ship. Roadmaps were measured in two-week cadences. Frameworks competed on developer experience above all else. The result was extraordinary: more software, faster, than at any point in history. But the result was also a quiet accumulation of debt — interfaces that shifted under users, dashboards that loaded eight megabytes to show a number, and teams that spent more time maintaining than making.",
      },
      {
        type: "quote",
        text: "We optimised for the sprint and forgot about the decade. The bill is coming due.",
      },
      {
        type: "p",
        text: "What changed is not the tools, exactly. The tools are, if anything, more capable than ever. What changed is the recognition that the sprint is not the only unit of time that matters. A codebase is a long-lived thing. The decisions that feel cheap in week two are the decisions that hurt in year three.",
      },
      {
        type: "h2",
        text: "What slow software actually looks like",
      },
      {
        type: "ul",
        items: [
          "Interfaces that settle into place rather than animate to distract from loading.",
          "Dependencies chosen for longevity, not novelty.",
          "Tests written as documentation for the engineer who arrives in eighteen months.",
          "Performance budgets treated as seriously as design budgets.",
        ],
      },
      {
        type: "p",
        text: "None of this is glamorous. It rarely wins a launch announcement. But the teams pursuing it report something the speed-first era rarely delivered: software that still feels good to use three years after it was written, and codebases that still feel good to work in.",
      },
      {
        type: "p",
        text: "The quiet return of slow software is not a rejection of progress. It is a recalibration — a reminder that the goal was never to ship fast, but to ship something worth keeping.",
      },
    ],
  },
  {
    slug: "designing-for-the-second-glance",
    title: "Designing for the Second Glance",
    excerpt:
      "First impressions are easy. The real craft is in the interface that rewards a second look — and a third, and a thirtieth.",
    category: "Design",
    author: "Marcus Lindqvist",
    date: "August 9, 2026",
    readTime: "7 min read",
    trending: true,
    cover: { palette: "#0ea5e9", pattern: "grid" },
    content: [
      {
        type: "p",
        text: "Anyone can make a screen that photographs well. The hard part is the screen that still feels considered on the hundredth visit — the one that doesn't wear out its welcome, that hides a small reward for the person who looks closely.",
      },
      {
        type: "h2",
        text: "The familiarity problem",
      },
      {
        type: "p",
        text: "Novelty is a powerful and dangerous tool. A novel interface grabs attention, which is why it dominates screenshots and launch posts. But attention is not the same as comfort, and comfort is what people actually return to. The interface that wins in the long run is the one whose details compound with familiarity rather than corrode it.",
      },
      {
        type: "quote",
        text: "Good design is the thing you stop noticing, until you use something else.",
      },
      {
        type: "p",
        text: "Designing for the second glance means designing the spacing of a list so that the eye lands without searching. It means the button that is slightly larger than it needs to be, because the thumb is slightly less precise than the cursor. It means the loading state that says nothing, because the load was instant.",
      },
      {
        type: "ul",
        items: [
          "Type that is sized for reading, not for screenshots.",
          "Colour contrast that survives a bright screen and tired eyes.",
          "Motion that explains hierarchy instead of performing it.",
        ],
      },
      {
        type: "p",
        text: "The second glance is where loyalty is built. It is the quiet, repeatable proof that someone cared.",
      },
    ],
  },
  {
    slug: "the-economics-of-independent-publishing",
    title: "The Economics of Independent Publishing",
    excerpt:
      "Three independent publications, three different revenue models, and the same surprising answer about what actually pays the bills.",
    category: "Business",
    author: "Priya Nadar",
    date: "August 6, 2026",
    readTime: "11 min read",
    cover: { palette: "#7c3aed", pattern: "blobs" },
    content: [
      {
        type: "p",
        text: "The conventional wisdom about independent publishing is that it is a labour of love subsidised by something else — a day job, a course, a consultancy. When we sat down with the founders of three publications that have outlasted their fifth year, we expected to hear about sacrifice. Instead we heard about arithmetic.",
      },
      {
        type: "h2",
        text: "Three models, one principle",
      },
      {
        type: "p",
        text: "The first publication runs on memberships: a small number of readers paying a meaningful annual fee. The second runs on sponsorship from companies whose audience overlaps precisely with theirs. The third runs on a hybrid — a free edition for reach and a paid edition for depth. The revenue sources differ. The principle does not: each built a model around a single, durable relationship rather than chasing volume.",
      },
      {
        type: "quote",
        text: "We stopped asking how to get more readers and started asking how to be worth the ones we have.",
      },
      {
        type: "p",
        text: "The arithmetic is unglamorous. A publication that converts two percent of a hundred thousand readers to a paid tier has a very different business than one that converts half a percent of a million. The numbers that look smaller in a press release are the numbers that pay salaries.",
      },
      {
        type: "p",
        text: "What united the three was a refusal to optimise for the metric that did not pay them. Reach is seductive. Revenue is honest.",
      },
    ],
  },
  {
    slug: "what-we-learned-from-a-year-of-edge-computing",
    title: "What We Learned From a Year of Edge Computing",
    excerpt:
      "Twelve months of moving workloads to the edge taught us when it pays off, when it doesn't, and when it actively makes things worse.",
    category: "Technology",
    author: "Daniel Okafor",
    date: "August 3, 2026",
    readTime: "13 min read",
    trending: true,
    cover: { palette: "#059669", pattern: "stripes" },
    content: [
      {
        type: "p",
        text: "A year ago we began moving parts of our platform to edge runtimes. We were promised lower latency, simpler architecture, and costs that scaled with use. Some of that turned out to be true. Some of it turned out to be the kind of promise that is technically accurate and operationally misleading.",
      },
      {
        type: "h2",
        text: "Where it paid off",
      },
      {
        type: "p",
        text: "Latency-sensitive workloads — personalisation, auth checks, A/B routing — improved measurably. The median request to our nearest region dropped from forty-two milliseconds to nine. For the parts of the product that were genuinely regional, the edge was exactly the right place for them.",
      },
      {
        type: "quote",
        text: "The edge is not a place to put everything. It is a place to put the things that care about distance.",
      },
      {
        type: "p",
        text: "Where it did not pay off was the work we moved because we could, not because we should. Stateful operations that now had to coordinate across regions. Background jobs that the edge runtime was never designed to host. The cost of the rewrite dwarfed the cost of the latency we saved.",
      },
      {
        type: "ul",
        items: [
          "Move the request, not the database.",
          "Treat the edge as a specialisation, not a default.",
          "Measure before and after — assumptions about latency are usually wrong.",
        ],
      },
      {
        type: "p",
        text: "A year in, the lesson is mundane and important: the edge is a tool with a shape, and the work you give it has to match that shape. Where it did, we would not go back. Where it didn't, we are quietly moving things home.",
      },
    ],
  },
  {
    slug: "the-last-paragraph",
    title: "The Last Paragraph",
    excerpt:
      "On endings — why the conclusion of an essay is the hardest sentence to write, and the one that matters most.",
    category: "Culture",
    author: "Eleanor Vance",
    date: "July 30, 2026",
    readTime: "5 min read",
    cover: { palette: "#db2777", pattern: "waves" },
    content: [
      {
        type: "p",
        text: "Every editor knows the feeling. The essay is written. The argument is made. And then there is the last paragraph — the one that has to do something the rest of the piece could not. Summarise and it dies. Moralise and it betrays. Stop and it feels accidental.",
      },
      {
        type: "h2",
        text: "The exit, not the summary",
      },
      {
        type: "p",
        text: "The good last paragraph is not a summary. It is an exit — a door placed at exactly the right moment, left open just enough that the reader walks through it carrying the argument rather than being told what to feel about it.",
      },
      {
        type: "quote",
        text: "Endings are not where you stop talking. They are where the reader starts thinking.",
      },
      {
        type: "p",
        text: "The hardest part is the restraint. The instinct is to nail the thesis down, to make sure no one misses the point. But the point was the essay. The last paragraph only has to set it down gently and let it breathe.",
      },
    ],
  },
  {
    slug: "the-architecture-of-attention",
    title: "The Architecture of Attention",
    excerpt:
      "Attention is the scarcest material in the modern economy. The interfaces that respect it are quietly winning.",
    category: "Design",
    author: "Marcus Lindqvist",
    date: "July 27, 2026",
    readTime: "8 min read",
    cover: { palette: "#2563eb", pattern: "grid" },
    content: [
      {
        type: "p",
        text: "Every interface makes a demand. The question is whether the demand is worth what it costs. In an economy where attention is the scarcest input, the products that survive will be the ones that spend it carefully.",
      },
      {
        type: "h2",
        text: "Demand and reward",
      },
      {
        type: "p",
        text: "A notification is a demand. A modal is a demand. An animation that delays a click is a demand. None of these are inherently wrong — but each one should carry a reward proportional to its interruption. The interface that demands attention and returns nothing for it erodes trust quietly and then all at once.",
      },
      {
        type: "quote",
        text: "Respect is not a feature you ship. It is the residue of a thousand small decisions.",
      },
      {
        type: "p",
        text: "The architecture of attention is, finally, a question of what you are willing to take from someone and what you are willing to give back. The best interfaces give back more than they take, and they do it so quietly that the person using them never thinks to be grateful.",
      },
    ],
  },
];

export const newsletter = {
  title: "The Saturday Edition",
  description:
    "One thoughtful essay, one piece of craft worth studying, and one thing we're reading — every Saturday morning. No filler, no noise.",
  subscribers: "34,000+",
};

export const site = {
  name: "The Margin",
  tagline: "A magazine for builders, makers, and the curious",
};
