/**
 * Deployment helpers.
 *
 * `NEXT_PUBLIC_BASE_PATH` is read by next.config.ts so the whole site can be
 * served from a sub-directory (for example a marketplace demo at
 * `/demo/premium-blog`).
 *
 * `NEXT_PUBLIC_SITE_URL` is optional and only used to build absolute URLs for
 * canonical tags, Open Graph metadata, the sitemap, and robots.txt. When it is
 * not set the site still builds and runs; those absolute URLs are simply omitted.
 */
export const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || "";

export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL || "").replace(/\/+$/, "");

export function absoluteUrl(path = "/"): string | undefined {
  if (!SITE_URL) return undefined;
  return `${SITE_URL}${BASE_PATH}${path}`;
}
