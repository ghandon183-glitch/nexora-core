# Quick Start

Five minutes from download to a running magazine.

## 1. Extract and enter the project

```bash
unzip premium-blog.zip
cd premium-blog/premium-blog
```

The archive root holds the documentation; the Next.js project is the
`premium-blog/` folder inside it.

## 2. Check your Node.js version

```bash
node -v      # must be v20.9.0 or newer (v22 LTS recommended)
```

## 3. Install dependencies

```bash
npm ci
```

This installs the exact tree recorded in `package-lock.json` (about 300
packages) and takes well under a minute on a normal connection.

## 4. Start the development server

```bash
npm run dev
```

Open <http://localhost:3000>. You should see the homepage with the featured
essay "The Quiet Return of Slow Software", the section grid, the latest essays,
the trending list, and the newsletter block.

## 5. Click through the template

- Section links (header, cards, footer) → `/category/<section>`
- Any essay → `/articles/<slug>`
- Search icon in the header → type `attention` → one result
- `/about` and `/author` from the footer
- Resize to 320 px wide → the menu button replaces the section bar
- Submit the newsletter form → an explicit "nothing was sent" demo message

## 6. Build the production export

```bash
npm run build     # writes out/
npx serve out     # verify the real static output
```

## 7. Configure before launch

Copy `.env.example` to `.env.local` and set what you need:

```bash
NEXT_PUBLIC_SITE_URL=https://your-domain.com   # canonical URLs + sitemap
NEXT_PUBLIC_BASE_PATH=                          # only for sub-directory hosting
```

## 8. Launch checklist

- [ ] Replace the sample essays, author, and brand in `lib/data.ts`.
- [ ] Update the site name, tagline, and page metadata.
- [ ] Adjust colours and typography in `app/globals.css`.
- [ ] Replace `app/icon.svg` with your own icon.
- [ ] Connect your newsletter provider (`README.md`, section 7).
- [ ] Run `npm run lint`, `npm run typecheck`, `npm run build`.
- [ ] Upload the contents of `out/` to your static host.
- [ ] Re-check 320 px, 390 px, and desktop layouts on the live site.
