# Premium Blog — The Margin

Thank you for purchasing Premium Blog. This archive contains the complete,
editable Next.js source for the magazine template, plus the documentation you
need to install, customize, and deploy it.

## Start here

| Document | What it covers |
| --- | --- |
| [`premium-blog/README.md`](premium-blog/README.md) | The full guide: requirements, install, environment variables, build, deployment, customization, connecting a newsletter provider, troubleshooting. |
| [`QUICKSTART.md`](QUICKSTART.md) | The five-minute path from extraction to a running build. |
| [`CONTENTS.md`](CONTENTS.md) | Every delivered file, described. |
| [`CHANGELOG.md`](CHANGELOG.md) | What changed in each version. |
| [`LICENSE.md`](LICENSE.md) | License terms for the source. |
| [`SUPPORT.md`](SUPPORT.md) | What support covers. |
| [`ASSET-LICENSES.md`](ASSET-LICENSES.md) | Fonts, icons, and artwork licenses. |

## The 60-second version

```bash
cd premium-blog
npm ci
npm run dev      # http://localhost:3000
npm run build    # static export into out/
```

Requires Node.js **20.9 or newer**. No database, CMS, API key, or third-party
account is required. Both environment variables are optional and documented in
`premium-blog/.env.example`.

All editorial content lives in `premium-blog/lib/data.ts`; branding and colours
live in `premium-blog/lib/data.ts` and `premium-blog/app/globals.css`.

The newsletter form is a demo: it validates the address and states clearly that
nothing was sent or stored. `premium-blog/README.md` (section 7) shows how to
connect a real provider.
