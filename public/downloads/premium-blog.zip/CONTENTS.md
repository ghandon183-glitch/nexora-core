# Package Contents

Every file below is included in `premium-blog.zip`. No build output, dependency
folder, cache, or secret is shipped.

## Documentation (archive root)

| File | Purpose |
| --- | --- |
| `README.md` (in `premium-blog/`) | Full guide: install, configure, deploy, customize, troubleshoot. |
| `QUICKSTART.md` | Five-minute path from extraction to a running build. |
| `LICENSE.md` | Single end-product commercial license. |
| `SUPPORT.md` | What support covers and what it does not. |
| `ASSET-LICENSES.md` | Fonts, icons, and artwork attribution. |
| `CONTENTS.md` | This inventory. |
| `CHANGELOG.md` | Version history. |

## Project — `premium-blog/`

### Configuration

| File | Purpose |
| --- | --- |
| `package.json` | Dependencies, scripts (`dev`, `build`, `lint`, `typecheck`), Node engine, npm overrides. |
| `package-lock.json` | Lockfile v3 — exact tree for reproducible `npm ci`. |
| `next.config.ts` | Static export, optional base path, unoptimized images. |
| `tsconfig.json` | Strict TypeScript, `@/*` path alias. |
| `eslint.config.mjs` | Flat ESLint config (Next.js core-web-vitals + TypeScript). |
| `postcss.config.mjs` | Tailwind CSS v4 PostCSS pipeline. |
| `next-env.d.ts` | Next.js type references. |
| `.env.example` | The two optional public variables, documented. |
| `.gitignore` | Ignores `node_modules`, `.next`, `out`, env files. |

### Application — `app/`

| File | Purpose |
| --- | --- |
| `layout.tsx` | Root layout, fonts, global metadata, skip link. |
| `page.tsx` | Homepage: featured essay, sections, latest grid, trending, newsletter. |
| `globals.css` | Design tokens, light/dark palettes, prose styles, focus and reduced-motion rules. |
| `icon.svg` | Favicon. |
| `not-found.tsx` | Branded 404 page. |
| `robots.ts` | `robots.txt` route. |
| `sitemap.ts` | `sitemap.xml` built from the real routes. |
| `about/page.tsx` | About page with content-derived statistics. |
| `author/page.tsx` | Editor profile, their essays, and contributing writers. |
| `category/[slug]/page.tsx` | Section listing with derived counts and empty state. |
| `articles/[slug]/page.tsx` | Essay page: cover, prose, author card, related essays, newsletter. |

### Components — `components/`

| File | Purpose |
| --- | --- |
| `nav.tsx` | Sticky header, section links, working search, accessible mobile menu. |
| `featured-article.tsx` | Lead essay block. |
| `article-grid.tsx` | Latest essays grid. |
| `categories.tsx` | Section grid with real counts. |
| `trending.tsx` | Trending list. |
| `related-articles.tsx` | Same-section-first related essays. |
| `newsletter.tsx` | Subscribe form with honest demo-only behaviour. |
| `footer.tsx` | Footer navigation and section links. |
| `article-cover.tsx` | Generated SVG cover art per article palette/pattern. |

### Data and helpers — `lib/`

| File | Purpose |
| --- | --- |
| `data.ts` | Articles, sections, author, newsletter copy, derived counts. |
| `base-path.ts` | Base path constant and absolute-URL helper for metadata/sitemap. |
