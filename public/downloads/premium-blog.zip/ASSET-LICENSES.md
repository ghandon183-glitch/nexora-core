# Asset & Third-Party License Manifest — Premium Blog

This manifest describes what actually ships in `premium-blog.zip`. It is not a
grant of rights from Nexora Core; the template license is in `LICENSE.md`.

## Summary

| Asset | Where | License | Attribution required |
| --- | --- | --- | --- |
| Lora typeface | `@fontsource/lora` (self-hosted `.woff2` files) | SIL Open Font License 1.1 | No (keep the license text in the package) |
| Inter typeface | `@fontsource/inter` (self-hosted `.woff2` files) | SIL Open Font License 1.1 | No (keep the license text in the package) |
| Lucide icons | `lucide-react` (rendered as inline SVG) | ISC | No |
| Cover artwork | Generated at runtime by `components/article-cover.tsx` | Original code in this package | No |
| Favicon | `app/icon.svg`, drawn for this package | Original artwork in this package | No |
| Essays, brand, author, site copy | `lib/data.ts`, page files | Fictional sample content written for this package | No |

## Details

### Fonts
Both families are installed through Fontsource and are bundled into the build as
self-hosted files. No request is made to Google Fonts at runtime.

- **Lora** — Copyright 2011 The Lora Project Authors
  (<https://github.com/cyrealtype/Lora-Cyrillic>), SIL Open Font License 1.1.
- **Inter** — Copyright 2016 The Inter Project Authors
  (<https://github.com/rsms/inter>), SIL Open Font License 1.1.

The full license text for each font is included by the Fontsource packages under
`node_modules/@fontsource/*/LICENSE` after `npm ci`.

### Icons
`lucide-react` is distributed under the ISC license (Copyright © Lucide
Contributors). Icons are compiled into the markup; no icon font or CDN is used.

### Imagery
The package ships **no photographic or stock imagery**. Every article cover is an
abstract SVG generated from the palette and pattern declared in `lib/data.ts`.
Replacing the covers with photography is the buyer's responsibility, including
clearing the rights for that photography.

### Sample content
All essays, author biographies, section names, and the "The Margin" brand are
fictional and were written for this template. Replace them before publishing.

### External services
The template calls no external API. The newsletter form is a demo that sends
nothing; if you connect a provider, that provider's terms and privacy policy
apply to the data you collect.

## Before you publish

- [ ] Replace the sample essays, author, and brand.
- [ ] Confirm the license of any photography or illustration you add.
- [ ] Keep the Fontsource and Lucide license files if you redistribute the build.
- [ ] Update this manifest if you swap fonts, icons, or artwork.
