# Premium Restaurant — Oria

A single-restaurant site with a seasonal menu, an honest reservation request flow,
and an editorial dark-and-gold design. Built with Next.js (App Router),
TypeScript and Tailwind CSS v4, and exported as a static site.

Everything you receive is editable source. Read this file, then
`QUICKSTART.md`, then `premium-restaurant/README.md`.

## What's in this package

```
README.md            this file
QUICKSTART.md        step-by-step install and launch
CONTENTS.md          file-by-file map of the package
CHANGELOG.md         version history
LICENSE.md           license terms
SUPPORT.md           what support covers
ASSET-LICENSES.md    licenses for fonts, icons, code and artwork
premium-restaurant/  the Next.js project (source, lockfile, .env.example)
```

## Requirements

- Node.js **20.9 or newer** (`engines` is `>=20.9.0`; built and tested on Node 22 and Node 26)
- npm 10 or newer (the package ships a lockfileVersion 3 `package-lock.json`)
- No database, API key or account is required. The reservation form needs no
  provider because it only prepares an email draft.

## Quick start

```bash
cd premium-restaurant
npm ci
npm run dev
```

Open <http://localhost:3000>.

Production build (static export into `out/`):

```bash
npm run build
npm run preview     # serves out/ on http://localhost:3000
```

## Routes

| Route | What it is |
| --- | --- |
| `/` | Home: hero, philosophy, menu preview, chef, gallery, sample quotes, sample events, visit, footer |
| `/menu/` | Full à la carte menu plus the seven-course tasting call to action |
| `/reserve/` | Reservation request form (demo flow, see below) |
| `404.html` | Branded not-found page, served by your host for unknown paths |

## Environment variables

Both are optional and both are read at build time. See
`premium-restaurant/.env.example`.

| Variable | Required | Purpose |
| --- | --- | --- |
| `NEXT_PUBLIC_BASE_PATH` | No | Serve the export from a sub-path, e.g. `/demo/premium-restaurant`. |
| `NEXT_PUBLIC_SITE_URL` | No | Public origin (no path) for canonical, Open Graph, `sitemap.xml` and `robots.txt`. |

Sub-path build example:

```bash
NEXT_PUBLIC_BASE_PATH=/demo/premium-restaurant \
NEXT_PUBLIC_SITE_URL=https://oria.example.com \
npm run build
```

## Deploy

The build output is static. Upload the contents of `premium-restaurant/out/` to
any static host (Cloudflare Pages, Netlify, Vercel static, S3/CDN, nginx).
Configure the host to serve `404.html` for unknown paths. No server-side runtime
is needed, and `next start` is intentionally not provided.

## Honest limits

- **The reservation form is a demo.** There is no booking backend, no database
  and no email service. Submitting builds a pre-filled `mailto:` draft, shows
  "Nothing has been sent yet", and stores nothing. Connect your own booking
  provider (SevenRooms, Resy, OpenTable, Formspree, a serverless function) before
  launch, and update the copy in `components/reservation-form.tsx`.
- **All content is fictional**: restaurant name, chef, address, phone number,
  hours, menu, prices and events. The phone number uses the reserved 555 range
  and the email uses the reserved `.example` domain.
- **Quotes and events are labelled samples**, not real reviews or a real
  calendar. Replace them before launch.
- **Imagery is generated placeholder artwork** (inline SVG), not photography.
  There are no stock photos and no external image requests.
- No map embed is included, because no real address exists. Add your own if you
  want one in the Visit section.

## License and support

`LICENSE.md` covers usage rights, `SUPPORT.md` explains what is included, and
`ASSET-LICENSES.md` lists every third-party asset and its license.
