# Package Contents

```
README.md                    Overview, routes, env vars, deploy, honest limits
QUICKSTART.md                Install, run, build, sub-path build, launch checklist
CONTENTS.md                  This file map
CHANGELOG.md                 Version history
LICENSE.md                   Single end-product license
SUPPORT.md                   Support scope and what to include in a request
ASSET-LICENSES.md            Font, icon, library and artwork licenses

premium-restaurant/
  package.json               Scripts, dependencies, Node engine, npm overrides
  package-lock.json          Lockfile v3 — the tested dependency graph
  .env.example               The two optional public variables
  .gitignore                 Build output, dependencies, local env files
  next.config.ts             Static export, trailing slashes, optional basePath
  tsconfig.json              TypeScript configuration (strict, path alias @/*)
  next-env.d.ts              Next.js type references
  eslint.config.mjs          ESLint flat config (next/core-web-vitals + TypeScript)
  postcss.config.mjs         Tailwind CSS v4 PostCSS plugin

  app/
    layout.tsx               Fonts, metadata, canonical/Open Graph, theme color
    page.tsx                 Skip link, header, home sections, footer
    globals.css              Design tokens, focus styles, anchors, demo notes
    menu/page.tsx            Full à la carte menu and tasting call to action
    reserve/page.tsx         Reservation page shell and metadata
    not-found.tsx            Branded 404 page
    icon.svg                 Favicon
    robots.ts                robots.txt (sitemap reference when SITE_URL is set)
    sitemap.ts               sitemap.xml for /, /menu/ and /reserve/

  components/
    nav.tsx                  Fixed header, primary nav, mobile menu (Escape closes)
    hero.tsx                 Hero copy, CTAs, stats, generated backdrop
    philosophy.tsx           Three principles with icons
    menu-preview.tsx         Homepage menu preview (two items per section)
    chef.tsx                 Chef profile with generated portrait
    gallery.tsx              Gallery grid of labelled placeholder artwork
    testimonials.tsx         Sample quotes, explicitly labelled as samples
    events.tsx               Sample events with reserve links
    visit.tsx                Address, phone, email, hours and reserve CTA
    footer.tsx               Navigation, contact links and colophon
    reservation-form.tsx     Reservation request that prepares an email draft

  lib/
    data.ts                  All editable content: restaurant, menu, chef, samples
    base-path.ts             BASE_PATH, SITE_URL, assetPath(), sitePath()
```

Three routes are generated (`/`, `/menu/`, `/reserve/`) plus `404.html`,
`robots.txt`, `sitemap.xml` and `icon.svg`. No `node_modules`, build output or
local environment files are included in the archive.
