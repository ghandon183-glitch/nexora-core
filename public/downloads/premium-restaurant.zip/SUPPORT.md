# Support & Updates

## Covered
- Installation with `npm ci` and the documented Node.js version.
- Running `npm run dev`, `npm run build`, `npm run preview`,
  `npm run lint` and `npm run typecheck`.
- Documented behaviour of the static export, `NEXT_PUBLIC_BASE_PATH` and
  `NEXT_PUBLIC_SITE_URL`.
- Reproducible bugs in the supplied source (with the steps that reproduce them).
- Package updates while this template is maintained.

## Not covered
- Connecting the reservation form to a booking provider, CRM, email service or
  backend. The shipped form only prepares an `mailto:` draft.
- Custom design work, new pages, online ordering, payments or a CMS.
- Hosting, domains, DNS, CDN configuration or paid third-party services.
- Copywriting, photography, logo design or other content production.
- Dependency upgrades beyond the versions shipped in this package.

## Before you write
Please include:
1. Package version (`1.1.1`).
2. Operating system and Node.js version (`node -v`), npm version (`npm -v`).
3. The exact command that failed and its full output.
4. Whether you built at the root or with `NEXT_PUBLIC_BASE_PATH`, and the
   sub-path used.
5. Browser and viewport size for visual issues, plus a screenshot if possible.

## Known behaviour (not bugs)
- `npm start` is not provided. This is a static export; serve `out/` with
  `npm run preview` or your own static server.
- The reservation form does not create a booking. It prepares an email draft and
  says so on screen. Replace it with your booking provider before launch.
- `sitemap.xml` is empty until `NEXT_PUBLIC_SITE_URL` is set at build time.
- Gallery imagery is generated placeholder artwork, not photography.
- Testimonials and events are sample content and are labelled as such in the UI.
- There is no map embed because the address is a placeholder.
