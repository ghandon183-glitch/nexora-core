# Changelog

## 1.1.1

### Fixed
- Reservation date validation used `new Date().toISOString().slice(0, 10)`, which
  converts to UTC before reading the day. Guests in time zones ahead of UTC
  (e.g. UTC+3 at 00:30) got **yesterday** as the earliest selectable date, and
  guests behind UTC lost today's date. The minimum date and the submit-time
  guard now both build `YYYY-MM-DD` from local `getFullYear()`,
  `getMonth()` and `getDate()`, so they match the guest's calendar date in
  every time zone and across midnight. The date field also refreshes its
  minimum when it receives focus, so a tab left open overnight cannot keep
  yesterday's limit.

## 1.1.0

Reliability, honesty and accessibility pass on the delivered package.

### Added
- `package-lock.json` (lockfileVersion 3) and `.env.example`, so `npm ci`
  installs exactly the tested dependency graph.
- `.gitignore` for build output, dependencies and local env files.
- `npm run typecheck` (`tsc --noEmit`) and `npm run preview` (serves `out/`).
- Branded `404` page, `icon.svg` favicon, `robots.txt` and `sitemap.xml`
  (sitemap and robots sitemap link require `NEXT_PUBLIC_SITE_URL`).
- Canonical URL, Open Graph/Twitter metadata, `metadataBase` and a
  `theme-color` viewport export.
- `NEXT_PUBLIC_SITE_URL` support and `sitePath()` helper in `lib/base-path.ts`.
- Skip link to the main landmark; every page now has an `id="main"` landmark.
- `scroll-margin-top` on anchors so the fixed header no longer covers headings.
- Escape closes the mobile menu; the toggle reports `aria-expanded` and
  `aria-controls`; desktop and mobile navigation are labelled.
- `aria-pressed` on party-size and time buttons, `aria-label` on the events
  reserve links, `<figure>`/`<figcaption>` gallery items and `role="img"`
  labels for the generated artwork.
- Valid visible focus states for links, buttons and form fields.

### Fixed
- The reservation form claimed "Request received" and promised confirmation
  although nothing was sent. It now validates the date, prepares a pre-filled
  `mailto:` draft, and states plainly that nothing was sent or stored.
- Every internal link was root-absolute (`/menu`, `/#visit`), so the site broke
  completely under a base path. All internal navigation now uses `next/link`,
  which applies `NEXT_PUBLIC_BASE_PATH` automatically.
- `npm start` was advertised but cannot run a static export. Replaced with
  `npm run preview`.
- `eslint.config.mjs` used TypeScript syntax and a non-existent `next()` export,
  so `npm run lint` crashed. Replaced with a valid flat config.
- `font-500`, `font-600` and `font-400` are not Tailwind utilities, so every
  heading rendered at the default weight. Replaced with `font-medium`,
  `font-semibold` and `font-normal`.
- `text-base` collided with the font-size utility of the same name, leaving gold
  buttons with cream text. Introduced the explicit `--color-ink-invert` token.
- `body { overflow-x: hidden }` masked layout bugs; removed after verifying the
  page is overflow-free from 320px up.
- The chef section printed the establishment year only when the signature was
  "Maren"; it now uses `restaurant.established`.
- The reservation page was a client component, so it could not export its own
  metadata and inherited the homepage title. Split into a server page plus
  `components/reservation-form.tsx`.
- Client-side navigation from the 404 page requested a non-existent `.txt` RSC
  payload and logged a 404 in the console. `trailingSlash: true` makes the
  payload resolve to the exported `index.txt`.
- The hero used `min-h-screen`, which is unreliable on mobile browsers; now
  `100svh` with header-aware padding.
- Root `README.md` shipped empty. All seven documents were rewritten around the
  real behaviour, with routes, env vars, deployment steps and explicit demo
  limits.
- Fabricated third-party claims removed: the "One Michelin star" stat is gone,
  the sample quotes are labelled as samples, and the fictional phone/email are
  documented as placeholders (`.example` domain).

### Changed
- `next` and `eslint-config-next` upgraded to **16.4.5**; `react` and
  `react-dom` pinned to **19.2.4**.
- Added a scoped `minimatch` override (`@typescript-eslint/typescript-estree`)
  to clear a transitive advisory in the lint toolchain.
- `package.json` declares `engines.node >= 20.9.0`.
- Removed unused `framer-motion`, `clsx`, `tailwind-merge` and `lib/utils.ts`.

## 1.0.0
- Initial customer package: single-restaurant site with menu, chef, gallery,
  sample quotes and events, and a reservation page.
