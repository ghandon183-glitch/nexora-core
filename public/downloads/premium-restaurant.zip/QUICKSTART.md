# Quick Start

## 1. Unpack and install

```bash
unzip premium-restaurant.zip
cd premium-restaurant/premium-restaurant
npm ci
```

`npm ci` uses the shipped `package-lock.json` and installs exactly the tested
dependency versions. Use `npm install` only when you change dependencies.

Node.js 20.9 or newer is required.

## 2. Run it locally

```bash
npm run dev
```

Open <http://localhost:3000>. The editable content lives in `lib/data.ts`
(restaurant details, menu, prices, chef, gallery labels, quotes, events);
colours and type are in `app/globals.css`.

## 3. Build the static site

```bash
npm run build
```

The finished site is written to `out/`. Preview it with:

```bash
npm run preview
```

`npm start` is not provided: `next start` does not work with a static export.

## 4. Build for a sub-path (optional)

```bash
NEXT_PUBLIC_BASE_PATH=/demo/premium-restaurant \
NEXT_PUBLIC_SITE_URL=https://your-domain.example \
npm run build
```

Upload the contents of `out/` into that sub-path. Both variables are optional;
see `.env.example`.

## 5. Before you launch

- Replace `restaurant` in `lib/data.ts`: name, tagline, phone, email, address
  and opening hours. The shipped values are placeholders (555 phone, `.example`
  email, fictional street).
- Replace `menu` and the tasting price (`restaurant.tastingPrice`).
- Replace `gallery` labels and the generated SVG artwork with real photography.
- Replace `testimonials` (currently labelled sample quotes) with real reviews,
  and `events` with your real calendar.
- Update `metadata` in `app/layout.tsx` and the per-page metadata in
  `app/menu/page.tsx` and `app/reserve/page.tsx`.
- Decide how reservations should work. The shipped form only prepares an email
  draft. Either keep that (and say so on the page) or connect a booking provider
  in `components/reservation-form.tsx`.
- Configure your host to serve `404.html` for unknown paths.
- Run `npm run lint` and `npm run typecheck` before deploying.

## Troubleshooting

| Symptom | Cause |
| --- | --- |
| Styles or `_next` files 404 under a sub-path | Build with `NEXT_PUBLIC_BASE_PATH` set, and upload `out/` into that directory. |
| `next start` fails | This project is a static export; serve `out/` instead (`npm run preview`). |
| Empty `sitemap.xml` | `NEXT_PUBLIC_SITE_URL` was not set at build time. |
| Reservation button shows "Nothing has been sent yet" | Expected: the template has no booking backend and only opens an email draft. |
| Dates in the reservation form before today are rejected | The form sets `min` to today on purpose. |
