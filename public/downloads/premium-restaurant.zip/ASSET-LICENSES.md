# Asset & Third-Party License Manifest

This manifest lists what ships in `premium-restaurant.zip` and the license that
covers each item. It is a review aid, not a grant of rights from Nexora Core.

## Imagery

The package contains **no photographs and no raster images**. The hero backdrop,
chef portrait and all six gallery tiles are inline SVG drawn in code
(`components/hero.tsx`, `components/chef.tsx`, `components/gallery.tsx`) from
brand colours and simple geometry. They are original to this template, contain
no third-party artwork, logos or people, and carry no external attribution
requirement.

Replace them with your own photography before launch; rights to any replacement
images are your responsibility.

## Fonts (bundled via npm, self-hosted at build time)

| Font | Package | License |
| --- | --- | --- |
| Cormorant Garamond | `@fontsource/cormorant-garamond` | SIL Open Font License 1.1 |
| Inter | `@fontsource/inter` | SIL Open Font License 1.1 |

No font is requested from an external CDN at runtime; the woff2 files are
emitted into `out/_next/static`.

## Icons

`lucide-react` — ISC License. Icons are rendered as inline SVG components and
are marked `aria-hidden` where they are decorative.

## Code libraries (all permissively licensed)

| Package | License |
| --- | --- |
| Next.js | MIT |
| React / React DOM | MIT |
| Tailwind CSS | MIT |
| TypeScript, ESLint and tooling | MIT / Apache-2.0 as published by their authors |

The full dependency list, including transitive packages, is in
`package-lock.json`. Every installed package carries its own license file under
`node_modules/<package>/LICENSE`.

## Demo content and placeholder details

`lib/data.ts` contains fictional content for a restaurant called Oria: the
chef's name and biography, the street address, the phone number
`+1 (415) 555-0118` (a reserved 555 number), the email
`reservations@oria.example` (a reserved `.example` domain), opening hours,
dishes and prices, sample quotes and sample event dates. None of it refers to a
real restaurant, person, publication or award. Replace it before launch.

## Customer responsibility

Before launch, confirm that your final copy, imagery, trademarks, fonts and
third-party services are licensed for your intended commercial use. Keep any
attribution notices your chosen assets require.
