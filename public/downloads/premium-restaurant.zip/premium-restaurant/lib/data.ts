export const restaurant = {
  name: "Oria",
  tagline: "A modern dining room",
  established: "2019",
  cuisine: "Seasonal · Fire · Fermentation",
  phone: "+1 (415) 555-0118",
  email: "reservations@oria.dining",
  address: {
    line1: "248 Hearth Lane",
    line2: "North District, City Center",
  },
  hours: [
    { day: "Tuesday – Thursday", time: "5:00 – 10:00 PM" },
    { day: "Friday – Saturday", time: "5:00 – 11:00 PM" },
    { day: "Sunday", time: "5:00 – 9:00 PM" },
    { day: "Monday", time: "Closed" },
  ],
};

export const stats = [
  { value: "2019", label: "Established" },
  { value: "7", label: "Course tasting menu" },
  { value: "★", label: "One Michelin star" },
];

export const menu = [
  {
    section: "To Begin",
    description: "Small plates to open the meal",
    items: [
      { name: "Charred leek, hazelnut", price: "16", desc: "Black garlic emulsion, brown butter" },
      { name: "Oyster, fermented gooseberry", price: "18", desc: "Sorrel, sea salt, cold distillate" },
      { name: "Beet tartare, smoked yolk", price: "17", desc: "Rye, capers, mustard leaf" },
    ],
  },
  {
    section: "From the Hearth",
    description: "Cooked over open fire",
    items: [
      { name: "Dry-aged duck, plum", price: "32", desc: "Fermented blackberry, charred onion" },
      { name: "Wagyu short rib, bone marrow", price: "38", desc: "Smoked salt, fermented chili" },
      { name: "Dayboat cod, seaweed butter", price: "29", desc: "Pickled samphire, dill oil" },
    ],
  },
  {
    section: "Garden",
    description: "What the season offers",
    items: [
      { name: "Heirloom carrot, miso", price: "19", desc: "Toasted seeds, carrot top pesto" },
      { name: "Wild mushroom, aged parmesan", price: "22", desc: "Truffle, fermented rye crisp" },
      { name: "Squash, brown butter, sage", price: "18", desc: "Pumpkin seed, smoked honey" },
    ],
  },
  {
    section: "Sweet",
    description: "Final courses",
    items: [
      { name: "Burnt honey custard", price: "14", desc: "Fig leaf, fermented cream" },
      { name: "Chocolate, cocoa nib", price: "15", desc: "Olive oil, sea salt, malt" },
      { name: "Aged cheddar, quince", price: "13", desc: "Walnut crisp, honeycomb" },
    ],
  },
];

export const chef = {
  name: "Maren Holloway",
  title: "Executive Chef & Owner",
  bio: "Maren Holloway trained in Copenhagen and San Sebastián before returning home to open Oria. Her cooking is built around live fire, fermentation, and a relentless relationship with the growers within fifty miles of the kitchen. The menu changes with what arrives at the door.",
  signature: "Maren",
};

export const gallery = [
  { palette: "#c8a25a", label: "The dining room" },
  { palette: "#8b5e34", label: "Open hearth" },
  { palette: "#7d4f1e", label: "Plating" },
  { palette: "#5e7a3a", label: "From the garden" },
  { palette: "#9b3d2f", label: "The cellar" },
  { palette: "#d4b87a", label: "Service" },
];

export const testimonials = [
  {
    quote: "A restaurant that thinks in seasons and cooks with fire. The duck alone is worth the journey.",
    name: "The Culinary Review",
    title: "Annual Guide",
  },
  {
    quote: "Maren Holloway cooks with an intelligence that makes you sit up. Every plate has a reason.",
    name: "Faye Okonkwo",
    title: "Food Writer",
  },
  {
    quote: "We have eaten at Oria every season since it opened. It only gets more itself.",
    name: "Daniel & Sue",
    title: "Regulars since 2019",
  },
];

export const events = [
  {
    date: "Sep 14",
    title: "Harvest Table",
    desc: "A five-course collaboration with three local growers, celebrating the late harvest.",
    price: "from $145 / guest",
  },
  {
    date: "Oct 02",
    title: "Wine Maker's Dinner",
    desc: "A natural-wine producer joins us for a paired seven-course tasting.",
    price: "from $220 / guest",
  },
  {
    date: "Nov 11",
    title: "Fire & Smoke",
    desc: "An evening dedicated to the hearth — everything touched by live fire.",
    price: "from $165 / guest",
  },
];

export const navLinks = [
  { label: "Menu", href: "/menu" },
  { label: "Reserve", href: "/reserve" },
];
