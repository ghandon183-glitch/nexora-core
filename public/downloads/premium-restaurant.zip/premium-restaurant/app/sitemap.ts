import type { MetadataRoute } from "next";
import { sitePath } from "@/lib/base-path";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  if (!process.env.NEXT_PUBLIC_SITE_URL) return [];

  return [
    { url: sitePath("/"), changeFrequency: "monthly", priority: 1 },
    { url: sitePath("/menu/"), changeFrequency: "weekly", priority: 0.8 },
    { url: sitePath("/reserve/"), changeFrequency: "monthly", priority: 0.6 },
  ];
}
