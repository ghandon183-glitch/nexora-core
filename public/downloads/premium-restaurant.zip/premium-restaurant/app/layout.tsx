import type { Metadata } from "next";
import "@fontsource/cormorant-garamond/400.css";
import "@fontsource/cormorant-garamond/500.css";
import "@fontsource/cormorant-garamond/600.css";
import "@fontsource/cormorant-garamond/700.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "Oria — A modern dining room in the heart of the city",
  description:
    "Oria is a seasonal tasting restaurant where fire, fermentation, and local produce meet. Reserve your table.",
  keywords: ["restaurant", "fine dining", "tasting menu", "seasonal", "reservation"],
  openGraph: {
    title: "Oria — A modern dining room",
    description: "Seasonal tasting menus. Fire, fermentation, and local produce.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
