import type { Metadata, Viewport } from "next";
import "@fontsource/cormorant-garamond/400.css";
import "@fontsource/cormorant-garamond/500.css";
import "@fontsource/cormorant-garamond/600.css";
import "@fontsource/cormorant-garamond/700.css";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import { SITE_URL, sitePath } from "@/lib/base-path";
import "./globals.css";

const title = "Oria — A modern dining room in the heart of the city";
const description =
  "Oria is a seasonal tasting restaurant where fire, fermentation, and local produce meet. Reserve your table.";

export const metadata: Metadata = {
  metadataBase: SITE_URL ? new URL(SITE_URL) : undefined,
  title,
  description,
  applicationName: "Oria",
  keywords: ["restaurant", "fine dining", "tasting menu", "seasonal", "reservation"],
  alternates: SITE_URL ? { canonical: sitePath("/") } : undefined,
  openGraph: {
    type: "website",
    siteName: "Oria",
    title: "Oria — A modern dining room",
    description: "Seasonal tasting menus. Fire, fermentation, and local produce.",
    url: SITE_URL ? sitePath("/") : undefined,
  },
  twitter: {
    card: "summary",
    title: "Oria — A modern dining room",
    description: "Seasonal tasting menus. Fire, fermentation, and local produce.",
  },
};

export const viewport: Viewport = {
  themeColor: "#14110d",
  colorScheme: "dark",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
