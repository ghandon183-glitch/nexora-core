import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { Hero } from "@/components/hero";
import { Philosophy } from "@/components/philosophy";
import { MenuPreview } from "@/components/menu-preview";
import { Chef } from "@/components/chef";
import { Gallery } from "@/components/gallery";
import { Testimonials } from "@/components/testimonials";
import { Events } from "@/components/events";
import { Visit } from "@/components/visit";

export default function Home() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Philosophy />
        <MenuPreview />
        <Chef />
        <Gallery />
        <Testimonials />
        <Events />
        <Visit />
      </main>
      <Footer />
    </>
  );
}
