import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { Hero } from "@/components/hero";
import { Philosophy } from "@/components/philosophy";
import { MenuPreview } from "@/components/menu-preview";
import { Chef } from "@/components/chef";
import { Gallery } from "@/components/gallery";
import { Testimonials } from "@/components/testimonials";
import { Events } from "@/components/events";
import { Visit } from "@/components/visit";

export default function Home() {
  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-accent focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-ink-invert"
      >
        Skip to content
      </a>
      <Nav />
      <main id="main">
        <Hero />
        <Philosophy />
        <MenuPreview />
        <Chef />
        <Gallery />
        <Testimonials />
        <Events />
        <Visit />
      </main>
      <Footer />
    </>
  );
}
