import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { Visit } from "@/components/visit";
import { menu } from "@/lib/data";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Menu — Oria",
  description: "The full seasonal menu at Oria. À la carte and seven-course tasting.",
};

export default function MenuPage() {
  return (
    <>
      <Nav />
      <main>
        <section className="border-b border-line pt-16">
          <div className="mx-auto max-w-4xl px-5 py-16 text-center md:px-8 md:py-24">
            <p className="eyebrow">The table</p>
            <h1 className="font-display mt-4 text-5xl font-500 text-ink md:text-6xl">The Menu</h1>
            <p className="mx-auto mt-5 max-w-xl leading-relaxed text-ink-soft">
              A living menu that changes with the season. Below is a sample of the current à la carte.
              A seven-course tasting is offered each evening at $145 per guest.
            </p>
          </div>
        </section>

        <section className="border-b border-line bg-base-2">
          <div className="mx-auto max-w-4xl px-5 py-16 md:px-8 md:py-20">
            <div className="space-y-16">
              {menu.map((section) => (
                <div key={section.section}>
                  <div className="flex items-baseline justify-between border-b border-line pb-3">
                    <h2 className="font-display text-3xl font-500 text-accent">{section.section}</h2>
                    <span className="text-xs uppercase tracking-widest text-ink-mute">{section.description}</span>
                  </div>
                  <ul className="mt-6 space-y-6">
                    {section.items.map((item) => (
                      <li key={item.name} className="flex items-baseline gap-3">
                        <div className="flex-1">
                          <p className="font-display text-xl font-500 text-ink">{item.name}</p>
                          <p className="mt-1 text-sm text-ink-mute">{item.desc}</p>
                        </div>
                        <span className="h-px flex-1 translate-y-[-3px] bg-line" />
                        <span className="font-500 text-accent">${item.price}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            <div className="mt-16 rounded-sm border border-line p-8 text-center">
              <p className="font-display text-2xl font-500 text-ink">Seven-Course Tasting</p>
              <p className="mt-2 text-sm text-ink-soft">
                A curated journey through the season, with optional wine pairing.
              </p>
              <p className="mt-4 font-display text-3xl font-600 text-accent">$145 <span className="text-base text-ink-mute">/ guest</span></p>
              <a
                href="/reserve"
                className="mt-6 inline-flex items-center justify-center rounded-full bg-accent px-7 py-3.5 text-sm font-500 uppercase tracking-widest text-base transition-transform hover:scale-[1.02]"
              >
                Reserve the tasting
              </a>
            </div>
          </div>
        </section>

        <Visit />
      </main>
      <Footer />
    </>
  );
}
