import type { MetadataRoute } from "next";
import { sitePath } from "@/lib/base-path";

export const dynamic = "force-static";

export default function robots(): MetadataRoute.Robots {
  if (!process.env.NEXT_PUBLIC_SITE_URL) {
    return { rules: [{ userAgent: "*", allow: "/" }] };
  }

  return {
    rules: [{ userAgent: "*", allow: "/" }],
    sitemap: sitePath("/sitemap.xml"),
  };
}
