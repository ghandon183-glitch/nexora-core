"use client";

import { useState } from "react";
import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { restaurant } from "@/lib/data";
import { Check, Calendar, Users, Clock } from "lucide-react";

const times = ["5:30 PM", "6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM", "8:00 PM", "8:30 PM", "9:00 PM"];
const partySizes = ["1", "2", "3", "4", "5", "6", "7+"];

export default function ReservePage() {
  const [submitted, setSubmitted] = useState(false);
  const [party, setParty] = useState("2");
  const [time, setTime] = useState("7:00 PM");

  return (
    <>
      <Nav />
      <main className="pt-16">
        <section className="border-b border-line">
          <div className="mx-auto max-w-3xl px-5 py-16 text-center md:px-8 md:py-24">
            <p className="eyebrow">Reservations</p>
            <h1 className="font-display mt-4 text-5xl font-500 text-ink md:text-6xl">Reserve a table</h1>
            <p className="mx-auto mt-5 max-w-lg leading-relaxed text-ink-soft">
              We accept reservations for parties up to seven. For larger parties or private events,
              please contact us directly at {restaurant.phone}.
            </p>
          </div>
        </section>

        <section className="border-b border-line bg-base-2">
          <div className="mx-auto max-w-2xl px-5 py-16 md:px-8 md:py-20">
            {submitted ? (
              <div className="rounded-sm border border-accent/40 bg-surface p-10 text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-accent/15">
                  <Check size={30} className="text-accent" />
                </div>
                <h2 className="font-display mt-5 text-3xl font-500 text-ink">Request received</h2>
                <p className="mt-3 text-ink-soft">
                  Thank you. We hold all reservations manually and will confirm by phone or email within
                  a few hours. If you don&apos;t hear from us by the day of your booking, please call.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-6 link-underline text-sm uppercase tracking-widest text-accent"
                >
                  Make another request
                </button>
              </div>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setSubmitted(true);
                }}
                className="space-y-6"
              >
                <div className="grid gap-6 md:grid-cols-2">
                  <Field label="First name" name="firstName" placeholder="Jordan" />
                  <Field label="Last name" name="lastName" placeholder="Lee" />
                </div>
                <div className="grid gap-6 md:grid-cols-2">
                  <Field label="Email" name="email" type="email" placeholder="you@email.com" />
                  <Field label="Phone" name="phone" type="tel" placeholder="(415) 555-0100" />
                </div>

                <div>
                  <label className="eyebrow flex items-center gap-2">
                    <Calendar size={13} />
                    Date
                  </label>
                  <input
                    type="date"
                    required
                    className="mt-2 w-full rounded-sm border border-line bg-base px-4 py-3 text-ink focus:border-accent focus:outline-none"
                  />
                </div>

                <div>
                  <label className="eyebrow flex items-center gap-2">
                    <Users size={13} />
                    Party size
                  </label>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {partySizes.map((size) => (
                      <button
                        key={size}
                        type="button"
                        onClick={() => setParty(size)}
                        className={`h-11 w-11 rounded-sm border text-sm font-500 transition-colors ${
                          party === size
                            ? "border-accent bg-accent text-base"
                            : "border-line text-ink-soft hover:border-accent/50"
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="eyebrow flex items-center gap-2">
                    <Clock size={13} />
                    Time
                  </label>
                  <div className="mt-2 grid grid-cols-4 gap-2">
                    {times.map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setTime(t)}
                        className={`rounded-sm border py-2.5 text-xs font-500 transition-colors ${
                          time === t
                            ? "border-accent bg-accent text-base"
                            : "border-line text-ink-soft hover:border-accent/50"
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label htmlFor="notes" className="eyebrow">
                    Occasion or notes
                  </label>
                  <textarea
                    id="notes"
                    rows={3}
                    placeholder="Allergies, accessibility, celebration…"
                    className="mt-2 w-full resize-none rounded-sm border border-line bg-base px-4 py-3 text-sm text-ink placeholder:text-ink-mute focus:border-accent focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full rounded-full bg-accent px-7 py-4 text-sm font-500 uppercase tracking-widest text-base transition-transform hover:scale-[1.01]"
                >
                  Request reservation
                </button>
                <p className="text-center text-xs text-ink-mute">
                  Reservations are confirmed manually. You will receive confirmation within a few hours.
                </p>
              </form>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
}) {
  return (
    <div>
      <label htmlFor={name} className="eyebrow">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required
        placeholder={placeholder}
        className="mt-2 w-full rounded-sm border border-line bg-base px-4 py-3 text-sm text-ink placeholder:text-ink-mute focus:border-accent focus:outline-none"
      />
    </div>
  );
}
