import type { Metadata } from "next";
import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { ReservationForm } from "@/components/reservation-form";
import { restaurant } from "@/lib/data";
import { SITE_URL, sitePath } from "@/lib/base-path";

export const metadata: Metadata = {
  title: "Reserve a table — Oria",
  description:
    "Request a table at Oria. Parties up to seven; for larger groups or private events, call the dining room directly.",
  alternates: SITE_URL ? { canonical: sitePath("/reserve/") } : undefined,
};

export default function ReservePage() {
  return (
    <>
      <Nav />
      <main id="main" className="pt-16">
        <section className="border-b border-line">
          <div className="mx-auto max-w-3xl px-5 py-16 text-center md:px-8 md:py-24">
            <p className="eyebrow">Reservations</p>
            <h1 className="font-display mt-4 text-5xl font-medium text-ink md:text-6xl">
              Reserve a table
            </h1>
            <p className="mx-auto mt-5 max-w-lg leading-relaxed text-ink-soft">
              We accept reservations for parties up to seven. For larger parties or private events,
              please call us at{" "}
              <a
                href={`tel:${restaurant.phone.replace(/[^+\d]/g, "")}`}
                className="link-underline text-accent"
              >
                {restaurant.phone}
              </a>
              .
            </p>
          </div>
        </section>

        <section className="border-b border-line bg-base-2">
          <div className="mx-auto max-w-2xl px-5 py-16 md:px-8 md:py-20">
            <ReservationForm />
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
