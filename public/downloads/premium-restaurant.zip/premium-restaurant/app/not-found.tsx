import Link from "next/link";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Page not found — Oria",
  robots: { index: false, follow: false },
};

export default function NotFound() {
  return (
    <main
      id="main"
      className="flex min-h-[100svh] flex-col items-center justify-center px-5 text-center"
    >
      <p className="eyebrow">404</p>
      <h1 className="font-display mt-4 text-balance text-4xl font-medium leading-tight text-ink md:text-5xl">
        This page isn&apos;t on the menu.
      </h1>
      <p className="mt-4 max-w-md text-sm leading-relaxed text-ink-soft">
        The page you were looking for has moved or never existed. The menu,
        reservations and visit details all start from the dining room.
      </p>
      <Link
        href="/"
        className="mt-8 inline-flex items-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-medium uppercase tracking-widest text-ink-invert transition-transform hover:scale-[1.02] focus-visible:scale-[1.02]"
      >
        Back to Oria
      </Link>
    </main>
  );
}
