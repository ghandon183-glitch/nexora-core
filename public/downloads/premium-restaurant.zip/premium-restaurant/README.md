# Premium Restaurant — Oria

A production-ready restaurant template with a full menu, reservation flow,
and elegant editorial design. Built with Next.js (App Router), TypeScript,
Tailwind CSS v4.

## Features

- Cinematic hero with animated stats
- Philosophy section (live fire, local pantry, fermentation)
- Menu preview on homepage + full dedicated menu page
- Chef profile with signature
- Gallery grid with generated SVG visuals
- Testimonials from press and regulars
- Upcoming events listing
- Hours, location, and contact details
- Interactive reservation page with date, party size, and time selectors
- Reservation success state
- Warm dark palette with gold accents, Cormorant Garamond + Inter

## Tech stack

- Next.js 16 (App Router, static export)
- TypeScript
- Tailwind CSS v4
- lucide-react icons

## Getting started

```bash
npm install
npm run dev
```

Visit `http://localhost:3000`.

## Build

```bash
npm run build
```

Static export (`output: "export"`). Set `NEXT_PUBLIC_BASE_PATH` to host under a sub-path.

## Customization

- Restaurant details, menu, chef, gallery, testimonials, and events live in `lib/data.ts`.
- Replace the generated SVG hero/gallery visuals with professional food photography.
- Theme tokens in `app/globals.css` under `@theme inline`.
