# Premium Restaurant — Oria

A single-restaurant site with a seasonal menu, an honest reservation request
flow and an editorial dark-and-gold design. Built with Next.js (App Router),
TypeScript and Tailwind CSS v4, exported as a fully static site.

## Requirements

| Requirement | Notes |
| --- | --- |
| Node.js | **20.9 or newer** (`engines` is `>=20.9.0`; built and tested on Node 22 and Node 26) |
| npm | 10 or newer (the package ships a lockfileVersion 3 `package-lock.json`) |
| Backend | None. No database, API key or account is required. |

## Install and run

```bash
npm ci          # reproducible install from the shipped lockfile
npm run dev     # http://localhost:3000
```

If you add or change dependencies, use `npm install` instead of `npm ci` and
commit the updated lockfile in your own repository.

## Build

```bash
npm run build       # static export -> out/
npm run preview     # serves out/ on http://localhost:3000 (npx serve)
```

`npm start` is intentionally not provided: `next start` does not work with
`output: "export"`. Serve the generated `out/` directory instead.

## Routes

| Route | File |
| --- | --- |
| `/` | `app/page.tsx` |
| `/menu/` | `app/menu/page.tsx` |
| `/reserve/` | `app/reserve/page.tsx` + `components/reservation-form.tsx` |
| `404.html` | `app/not-found.tsx` |

## Environment variables

Both variables are optional. Copy `.env.example` to `.env.local` for local use.

| Variable | Required | What it does |
| --- | --- | --- |
| `NEXT_PUBLIC_BASE_PATH` | No | Serves the export from a sub-path, e.g. `/demo/premium-restaurant`. Must start with `/` and must not end with `/`. |
| `NEXT_PUBLIC_SITE_URL` | No | Public origin only, e.g. `https://oria.example.com` (no path). Used for the canonical URLs, Open Graph URLs, `sitemap.xml` and `robots.txt`. Without it, no canonical/OG URL is emitted and the sitemap is empty. |

Environment variables are read at build time for a static export — rebuild
after changing them.

### Building for a sub-path

```bash
NEXT_PUBLIC_BASE_PATH=/demo/premium-restaurant \
NEXT_PUBLIC_SITE_URL=https://oria.example.com \
npm run build
```

The exported `out/` then expects to be served at
`https://oria.example.com/demo/premium-restaurant/`. Upload the **contents of
`out/`** into that directory. Never mix a base-path build with a root deploy.

## Deploy

1. `npm run build`
2. Upload the contents of `out/` to any static host (Cloudflare Pages, Netlify,
   Vercel static, S3 + CDN, nginx, GitHub Pages).
3. Configure the host to serve `404.html` for unknown paths.
4. Optional: long cache headers for `_next/static/*` (content-hashed), short
   ones for `index.html`.

No server, database, API key or build-time secret is required.

## What is real and what is demo

- **Reservation form** — demo only. There is no booking backend. The form
  validates the date, then prepares a pre-filled `mailto:` draft to
  `restaurant.email` and says clearly that nothing was sent or stored. Wire it
  to your booking provider in `components/reservation-form.tsx` before launch.
- **Menu, prices, chef, hours, address, phone, email** — fictional sample
  content in `lib/data.ts`. The phone number is in the reserved 555 range and
  the email uses the reserved `.example` domain.
- **Quotes** — sample text, labelled as samples in the UI. Not real reviews.
- **Events** — sample entries with sample dates, labelled in the UI.
- **Gallery and hero imagery** — generated inline SVG artwork, not photography,
  so the package ships with no stock assets and makes no external image
  requests.
- **No map embed** — there is no real address, so no map is included.

## Customization

- `lib/data.ts` — restaurant details, hours, menu and prices, chef, gallery
  labels, sample quotes and events.
- `app/globals.css` — design tokens (`@theme inline`), focus styles, textures.
- `app/layout.tsx`, `app/menu/page.tsx`, `app/reserve/page.tsx` — page metadata.
- `components/reservation-form.tsx` — the reservation flow and its wording.

## Accessibility

- Skip link to the main landmark and a labelled `main` on every page.
- Visible focus rings on links, buttons and fields.
- `aria-expanded`/`aria-controls` on the mobile menu toggle, which also closes
  with Escape.
- `aria-pressed` on the party-size and time selectors; labelled fieldsets.
- Gallery figures use `<figcaption>` and descriptive `role="img"` labels.
- `prefers-reduced-motion` disables the bounce and smooth scrolling.

## Project structure

```
app/            layout, home, menu, reserve, not-found, icon.svg, robots, sitemap, globals.css
components/     nav, hero, philosophy, menu-preview, chef, gallery,
                testimonials, events, visit, footer, reservation-form
lib/            data.ts (content), base-path.ts (BASE_PATH/SITE_URL helpers)
```
