import { testimonials } from "@/lib/data";

export function Testimonials() {
  return (
    <section id="words" className="border-b border-line">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-28">
        <p className="eyebrow text-center">Kind words</p>
        <div className="mt-10 grid gap-8 md:grid-cols-3">
          {testimonials.map((t) => (
            <figure
              key={t.name}
              className="flex h-full flex-col rounded-sm border border-line bg-surface p-7"
            >
              <span aria-hidden="true" className="font-display text-5xl leading-none text-accent/40">
                &ldquo;
              </span>
              <blockquote className="mt-2 flex-1 font-display text-xl italic leading-relaxed text-ink">
                {t.quote}
              </blockquote>
              <figcaption className="mt-6 border-t border-line pt-4">
                <p className="font-medium text-ink">{t.name}</p>
                <p className="mt-0.5 text-xs uppercase tracking-widest text-ink-mute">{t.title}</p>
              </figcaption>
            </figure>
          ))}
        </div>
        <p className="demo-note mt-8 text-center">
          These quotes are sample text for the layout — not real reviews. Replace them with your own
          guest or press quotes before launch.
        </p>
      </div>
    </section>
  );
}
