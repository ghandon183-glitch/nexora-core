import { restaurant } from "@/lib/data";
import { Clock, MapPin, Phone, Mail } from "lucide-react";

export function Visit() {
  return (
    <section id="visit" className="border-b border-line">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-28">
        <div className="grid gap-12 lg:grid-cols-2">
          <div>
            <p className="eyebrow">Visit</p>
            <h2 className="font-display mt-4 text-4xl font-500 leading-tight text-ink md:text-5xl">
              Find your way to the table.
            </h2>

            <div className="mt-8 space-y-6">
              <div className="flex gap-4">
                <MapPin size={20} className="mt-0.5 shrink-0 text-accent" />
                <div>
                  <p className="font-500 text-ink">{restaurant.address.line1}</p>
                  <p className="text-ink-soft">{restaurant.address.line2}</p>
                </div>
              </div>
              <div className="flex gap-4">
                <Phone size={20} className="mt-0.5 shrink-0 text-accent" />
                <a href={`tel:${restaurant.phone.replace(/[^+\d]/g, "")}`} className="text-ink-soft link-underline">
                  {restaurant.phone}
                </a>
              </div>
              <div className="flex gap-4">
                <Mail size={20} className="mt-0.5 shrink-0 text-accent" />
                <a href={`mailto:${restaurant.email}`} className="text-ink-soft link-underline">
                  {restaurant.email}
                </a>
              </div>
            </div>
          </div>

          <div className="rounded-sm border border-line bg-base-2 p-7">
            <div className="flex items-center gap-2 border-b border-line pb-4">
              <Clock size={18} className="text-accent" />
              <h3 className="font-display text-xl font-500 text-ink">Hours</h3>
            </div>
            <ul className="mt-5 space-y-3">
              {restaurant.hours.map((h) => (
                <li key={h.day} className="flex items-center justify-between border-b border-line/50 pb-3">
                  <span className="text-sm text-ink-soft">{h.day}</span>
                  <span className={`text-sm ${h.time === "Closed" ? "text-ink-mute" : "font-500 text-ink"}`}>
                    {h.time}
                  </span>
                </li>
              ))}
            </ul>
            <a
              href="/reserve"
              className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-accent px-6 py-3.5 text-sm font-500 uppercase tracking-widest text-base transition-transform hover:scale-[1.01]"
            >
              Reserve a table
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
