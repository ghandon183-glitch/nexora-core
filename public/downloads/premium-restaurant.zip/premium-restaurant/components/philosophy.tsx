import { Flame, Sprout, Hourglass } from "lucide-react";

const principles = [
  {
    icon: Flame,
    title: "Live fire",
    text: "Every plate passes through the hearth. We cook with embers, smoke, and the direct heat of open flame.",
  },
  {
    icon: Sprout,
    title: "Fifty-mile pantry",
    text: "We work with the growers, fishers, and foragers within fifty miles. The menu follows what arrives each morning.",
  },
  {
    icon: Hourglass,
    title: "Time as ingredient",
    text: "Fermentation, ageing, and patience shape the flavours. Nothing here is rushed that shouldn't be.",
  },
];

export function Philosophy() {
  return (
    <section id="philosophy" className="noise relative border-b border-line">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-28">
        <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="eyebrow">Philosophy</p>
            <h2 className="font-display mt-5 text-4xl font-500 leading-tight text-ink md:text-5xl">
              A kitchen defined by what it is close to.
            </h2>
          </div>
          <div className="space-y-8">
            {principles.map((p) => (
              <div key={p.title} className="flex gap-5">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full border border-accent/40">
                  <p.icon size={20} className="text-accent" />
                </div>
                <div>
                  <h3 className="font-display text-2xl font-500 text-ink">{p.title}</h3>
                  <p className="mt-2 leading-relaxed text-ink-soft">{p.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
