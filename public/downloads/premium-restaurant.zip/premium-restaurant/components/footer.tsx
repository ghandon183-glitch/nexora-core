import Link from "next/link";
import { MapPin, Phone, Mail } from "lucide-react";
import { restaurant, sectionLinks } from "@/lib/data";

export function Footer() {
  return (
    <footer className="bg-base">
      <div className="mx-auto max-w-6xl px-5 py-14 md:px-8">
        <div className="flex flex-col items-center justify-between gap-8 md:flex-row md:items-start">
          <div className="text-center md:text-left">
            <p className="font-display text-3xl font-medium text-ink">{restaurant.name}</p>
            <p className="mt-2 text-sm text-ink-mute">
              {restaurant.tagline} · Est. {restaurant.established}
            </p>
            <nav className="mt-5 flex flex-wrap justify-center gap-x-6 gap-y-2 md:justify-start" aria-label="Footer">
              {sectionLinks.map((link) => (
                <Link
                  key={link.label}
                  href={link.href}
                  className="link-underline text-sm text-ink-soft transition-colors hover:text-ink"
                >
                  {link.label}
                </Link>
              ))}
              <Link
                href="/menu/"
                className="link-underline text-sm text-ink-soft transition-colors hover:text-ink"
              >
                Menu
              </Link>
              <Link
                href="/reserve/"
                className="link-underline text-sm text-ink-soft transition-colors hover:text-ink"
              >
                Reserve
              </Link>
            </nav>
          </div>

          <div className="space-y-2 text-sm text-ink-soft">
            <p className="flex items-center justify-center gap-2 md:justify-start">
              <MapPin size={15} className="text-accent" aria-hidden="true" />
              {restaurant.address.line1}, {restaurant.address.line2}
            </p>
            <a
              href={`tel:${restaurant.phone.replace(/[^+\d]/g, "")}`}
              className="link-underline flex items-center justify-center gap-2 transition-colors hover:text-ink md:justify-start"
            >
              <Phone size={15} className="text-accent" aria-hidden="true" />
              {restaurant.phone}
            </a>
            <a
              href={`mailto:${restaurant.email}`}
              className="link-underline flex items-center justify-center gap-2 break-all transition-colors hover:text-ink md:justify-start"
            >
              <Mail size={15} className="text-accent" aria-hidden="true" />
              {restaurant.email}
            </a>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-line pt-6 text-xs text-ink-mute md:flex-row">
          <p>
            © {new Date().getFullYear()} {restaurant.name}. Demo template — all content is
            fictional.
          </p>
          <p>Seasonal menu. Cooked over live fire.</p>
        </div>
      </div>
    </footer>
  );
}
