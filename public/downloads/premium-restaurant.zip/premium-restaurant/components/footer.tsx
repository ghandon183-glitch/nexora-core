import { restaurant } from "@/lib/data";
import { MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-base">
      <div className="mx-auto max-w-6xl px-5 py-14 md:px-8">
        <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
          <div className="text-center md:text-left">
            <p className="font-display text-3xl font-500 text-ink">{restaurant.name}</p>
            <p className="mt-2 text-sm text-ink-mute">{restaurant.tagline} · Est. {restaurant.established}</p>
          </div>
          <div className="flex items-center gap-2 text-sm text-ink-soft">
            <MapPin size={15} className="text-accent" />
            {restaurant.address.line1}, {restaurant.address.line2}
          </div>
        </div>
        <div className="mt-10 flex flex-col items-center justify-between gap-3 border-t border-line pt-6 text-xs text-ink-mute md:flex-row">
          <p>© {new Date().getFullYear()} {restaurant.name}. All rights reserved.</p>
          <p>Seasonal menu. Cooked over live fire.</p>
        </div>
      </div>
    </footer>
  );
}
