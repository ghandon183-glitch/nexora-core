import { chef } from "@/lib/data";

export function Chef() {
  return (
    <section className="border-b border-line">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-20 md:px-8 md:py-28 lg:grid-cols-[1fr_1.2fr]">
        <div className="relative">
          <div className="aspect-[4/5] overflow-hidden rounded-sm bg-surface">
            <svg viewBox="0 0 400 500" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
              <defs>
                <linearGradient id="chefBg" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#221d16" />
                  <stop offset="100%" stopColor="#14110d" />
                </linearGradient>
              </defs>
              <rect width="400" height="500" fill="url(#chefBg)" />
              <ellipse cx="200" cy="190" rx="90" ry="100" fill="#c4b9a4" fillOpacity="0.85" />
              <path d="M90 460 Q 90 320 200 320 Q 310 320 310 460 Z" fill="#1c1813" />
              <path d="M140 200 Q 200 250 260 200 L 270 360 Q 200 380 130 360 Z" fill="#1c1813" />
              <rect x="170" y="360" width="60" height="8" fill="#c8a25a" fillOpacity="0.6" />
            </svg>
          </div>
          <p className="font-display absolute bottom-4 right-4 text-5xl text-accent/30">{chef.signature}</p>
        </div>

        <div>
          <p className="eyebrow">The kitchen</p>
          <h2 className="font-display mt-4 text-4xl font-500 leading-tight text-ink md:text-5xl">
            {chef.name}
          </h2>
          <p className="mt-2 text-sm uppercase tracking-widest text-accent">{chef.title}</p>
          <p className="mt-6 text-lg leading-relaxed text-ink-soft">{chef.bio}</p>
          <div className="mt-8 flex items-center gap-4">
            <span className="h-px w-12 bg-accent" />
            <span className="font-display text-xl italic text-ink-soft">Est. {chef.signature === "Maren" ? "2019" : ""}</span>
          </div>
        </div>
      </div>
    </section>
  );
}
