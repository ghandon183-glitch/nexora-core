import { restaurant, stats } from "@/lib/data";
import { ArrowDown } from "lucide-react";

export function Hero() {
  return (
    <section className="noise relative flex min-h-screen items-center overflow-hidden">
      <div className="absolute inset-0">
        <svg viewBox="0 0 1600 900" className="h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
          <defs>
            <radialGradient id="heroGlow" cx="35%" cy="40%" r="70%">
              <stop offset="0%" stopColor="#c8a25a" stopOpacity="0.22" />
              <stop offset="55%" stopColor="#221d16" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#14110d" stopOpacity="1" />
            </radialGradient>
            <linearGradient id="heroFade" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#14110d" stopOpacity="0.4" />
              <stop offset="60%" stopColor="#14110d" stopOpacity="0.7" />
              <stop offset="100%" stopColor="#14110d" stopOpacity="1" />
            </linearGradient>
          </defs>
          <rect width="1600" height="900" fill="#14110d" />
          <rect width="1600" height="900" fill="url(#heroGlow)" />
          <g opacity="0.5">
            <ellipse cx="560" cy="360" rx="220" ry="140" fill="#c8a25a" fillOpacity="0.15" />
            <ellipse cx="1100" cy="520" rx="280" ry="180" fill="#8b5e34" fillOpacity="0.18" />
          </g>
          {Array.from({ length: 60 }).map((_, i) => (
            <circle key={i} cx={(i * 97) % 1600} cy={(i * 61) % 900} r="1" fill="#c8a25a" fillOpacity="0.3" />
          ))}
          <rect width="1600" height="900" fill="url(#heroFade)" />
        </svg>
      </div>

      <div className="relative mx-auto w-full max-w-6xl px-5 pt-16 md:px-8">
        <div className="max-w-3xl">
          <p className="eyebrow flex items-center gap-3">
            <span className="h-px w-10 bg-accent/60" />
            {restaurant.cuisine}
          </p>
          <h1 className="font-display mt-6 text-6xl font-500 leading-[0.95] text-ink md:text-8xl">
            {restaurant.name}
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-soft">
            {restaurant.tagline} in the heart of the city. A seasonal table built on live fire,
            fermentation, and the growers within fifty miles.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a
              href="/reserve"
              className="inline-flex items-center gap-2 rounded-full bg-accent px-7 py-3.5 text-sm font-500 uppercase tracking-widest text-base transition-transform hover:scale-[1.02]"
            >
              Reserve a table
            </a>
            <a
              href="/menu"
              className="link-underline text-sm font-500 uppercase tracking-widest text-ink-soft"
            >
              View the menu
            </a>
          </div>
        </div>

        <div className="mt-20 flex flex-wrap items-center gap-10 border-t border-line/60 pt-8">
          {stats.map((s) => (
            <div key={s.label}>
              <p className="font-display text-3xl font-600 text-accent">{s.value}</p>
              <p className="mt-1 text-xs uppercase tracking-widest text-ink-mute">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      <a
        href="#philosophy"
        aria-label="Scroll down"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-ink-mute transition-colors hover:text-accent"
      >
        <ArrowDown size={20} className="animate-bounce" />
      </a>
    </section>
  );
}
