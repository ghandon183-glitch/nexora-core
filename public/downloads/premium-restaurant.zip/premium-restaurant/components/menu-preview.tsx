import { menu } from "@/lib/data";

export function MenuPreview() {
  const featured = menu.map((s) => ({ ...s, items: s.items.slice(0, 2) }));

  return (
    <section id="menu" className="border-b border-line bg-base-2">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-28">
        <div className="text-center">
          <p className="eyebrow">The table</p>
          <h2 className="font-display mt-4 text-4xl font-500 text-ink md:text-5xl">A seasonal menu</h2>
          <p className="mx-auto mt-4 max-w-xl leading-relaxed text-ink-soft">
            A selection from the current menu. The full seven-course tasting and à la carte change weekly.
          </p>
        </div>

        <div className="mt-14 grid gap-12 md:grid-cols-2">
          {featured.map((section) => (
            <div key={section.section}>
              <div className="flex items-baseline justify-between border-b border-line pb-3">
                <h3 className="font-display text-2xl font-500 text-accent">{section.section}</h3>
                <span className="text-xs uppercase tracking-widest text-ink-mute">{section.description}</span>
              </div>
              <ul className="mt-5 space-y-5">
                {section.items.map((item) => (
                  <li key={item.name} className="flex items-baseline gap-3">
                    <div className="flex-1">
                      <p className="font-display text-xl font-500 text-ink">{item.name}</p>
                      <p className="mt-0.5 text-sm text-ink-mute">{item.desc}</p>
                    </div>
                    <span className="h-px flex-1 translate-y-[-3px] bg-line" />
                    <span className="font-500 text-accent">${item.price}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 text-center">
          <a
            href="/menu"
            className="link-underline inline-block text-sm font-500 uppercase tracking-widest text-ink-soft"
          >
            View the full menu
          </a>
        </div>
      </div>
    </section>
  );
}
