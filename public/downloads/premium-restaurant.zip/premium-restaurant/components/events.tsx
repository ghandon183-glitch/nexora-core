import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { events } from "@/lib/data";

export function Events() {
  return (
    <section id="events" className="border-b border-line bg-base-2">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-28">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">Upcoming</p>
            <h2 className="font-display mt-4 text-4xl font-medium text-ink md:text-5xl">
              Evenings at Oria
            </h2>
          </div>
          <Link
            href="/reserve/"
            className="link-underline text-sm font-medium uppercase tracking-widest text-ink-soft transition-colors hover:text-ink"
          >
            Reserve a place
          </Link>
        </div>

        <div className="mt-10 divide-y divide-line">
          {events.map((event) => (
            <div
              key={event.title}
              className="group grid gap-4 py-6 md:grid-cols-[100px_1fr_auto] md:items-center md:gap-8"
            >
              <p className="font-display text-3xl font-medium text-accent">{event.date}</p>
              <div>
                <h3 className="font-display text-2xl font-medium text-ink">{event.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{event.desc}</p>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-sm text-ink-mute">{event.price}</span>
                <Link
                  href="/reserve/"
                  aria-label={`Reserve a place at ${event.title}`}
                  className="flex h-10 w-10 items-center justify-center rounded-full border border-line transition-colors group-hover:border-accent group-hover:text-accent focus-visible:border-accent"
                >
                  <ArrowRight size={16} aria-hidden="true" />
                </Link>
              </div>
            </div>
          ))}
        </div>

        <p className="demo-note mt-8">
          Sample events with sample dates. Replace them with your own calendar in
          <code className="mx-1 text-accent-soft">lib/data.ts</code>.
        </p>
      </div>
    </section>
  );
}
