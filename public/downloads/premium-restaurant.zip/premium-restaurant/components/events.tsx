import { events } from "@/lib/data";
import { ArrowRight } from "lucide-react";

export function Events() {
  return (
    <section className="border-b border-line bg-base-2">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-28">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">Upcoming</p>
            <h2 className="font-display mt-4 text-4xl font-500 text-ink md:text-5xl">Evenings at Oria</h2>
          </div>
          <a href="/reserve" className="link-underline text-sm uppercase tracking-widest text-ink-soft">
            Reserve a place
          </a>
        </div>

        <div className="mt-10 divide-y divide-line">
          {events.map((event) => (
            <div key={event.title} className="group grid gap-4 py-6 md:grid-cols-[100px_1fr_auto] md:items-center md:gap-8">
              <p className="font-display text-3xl font-500 text-accent">{event.date}</p>
              <div>
                <h3 className="font-display text-2xl font-500 text-ink">{event.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{event.desc}</p>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-sm text-ink-mute">{event.price}</span>
                <a href="/reserve" className="flex h-10 w-10 items-center justify-center rounded-full border border-line transition-colors group-hover:border-accent group-hover:text-accent">
                  <ArrowRight size={16} />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
