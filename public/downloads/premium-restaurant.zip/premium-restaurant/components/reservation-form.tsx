"use client";

import { useEffect, useRef, useState } from "react";
import { Calendar, Clock, Mail, Users } from "lucide-react";
import { restaurant } from "@/lib/data";

const times = ["5:30 PM", "6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM", "8:00 PM", "8:30 PM", "9:00 PM"];
const partySizes = ["1", "2", "3", "4", "5", "6", "7"];

type Draft = {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  date: string;
  party: string;
  time: string;
  notes: string;
};

// Calendar dates here are the guest's local dates. Deriving them with
// toISOString() converts to UTC and can shift the day: a guest at 00:30 in
// UTC+3 would get yesterday as the minimum, and a guest in UTC-8 would lose
// today. Build the YYYY-MM-DD string from local getters instead.
function localToday() {
  const now = new Date();
  const pad = (value: number) => String(value).padStart(2, "0");
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}

function buildMailto(draft: Draft) {
  const subject = `Reservation request — ${draft.firstName} ${draft.lastName} — ${draft.date} at ${draft.time}`;
  const body = [
    `Name: ${draft.firstName} ${draft.lastName}`,
    `Email: ${draft.email}`,
    `Phone: ${draft.phone}`,
    `Date: ${draft.date}`,
    `Time: ${draft.time}`,
    `Party size: ${draft.party}`,
    draft.notes ? `Notes: ${draft.notes}` : null,
  ]
    .filter((line) => line !== null)
    .join("\n");

  return `mailto:${restaurant.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

export function ReservationForm() {
  const [draft, setDraft] = useState<Draft | null>(null);
  const [party, setParty] = useState("2");
  const [time, setTime] = useState("7:00 PM");
  const dateRef = useRef<HTMLInputElement>(null);
  const formRef = useRef<HTMLFormElement>(null);

  // Set the earliest selectable date on the client so server and client HTML
  // match, and past dates cannot be requested.
  useEffect(() => {
    const input = dateRef.current;
    if (!input) return;
    input.min = localToday();
  }, []);

  if (draft) {
    return (
      <div role="status" className="rounded-sm border border-accent/40 bg-surface p-8 md:p-10">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-accent/15">
          <Mail size={24} className="text-accent" />
        </div>
        <h2 className="font-display mt-5 text-3xl font-medium text-ink">Nothing has been sent yet</h2>
        <p className="mt-3 text-sm leading-relaxed text-ink-soft">
          This template ships without a booking backend or email service, so the form cannot create
          a reservation. Your details stay in this browser tab. Open the pre-filled request in your
          email app, or call the dining room on{" "}
          <a
            href={`tel:${restaurant.phone.replace(/[^+\d]/g, "")}`}
            className="link-underline text-accent"
          >
            {restaurant.phone}
          </a>
          .
        </p>

        <dl className="mt-6 grid gap-2 border-t border-line pt-5 text-sm sm:grid-cols-2">
          <div>
            <dt className="text-ink-mute">Name</dt>
            <dd className="text-ink">
              {draft.firstName} {draft.lastName}
            </dd>
          </div>
          <div>
            <dt className="text-ink-mute">Party</dt>
            <dd className="text-ink">{draft.party}</dd>
          </div>
          <div>
            <dt className="text-ink-mute">Date</dt>
            <dd className="text-ink">{draft.date}</dd>
          </div>
          <div>
            <dt className="text-ink-mute">Time</dt>
            <dd className="text-ink">{draft.time}</dd>
          </div>
        </dl>

        <a
          href={buildMailto(draft)}
          className="mt-6 inline-flex w-fit items-center justify-center gap-2 rounded-full bg-accent px-6 py-3 text-sm font-medium uppercase tracking-widest text-ink-invert transition-transform hover:scale-[1.02] focus-visible:scale-[1.02]"
        >
          Open draft in email app
        </a>

        <button
          type="button"
          onClick={() => setDraft(null)}
          className="link-underline mt-5 block text-sm uppercase tracking-widest text-accent"
        >
          Back to the form
        </button>
      </div>
    );
  }

  return (
    <form
      ref={formRef}
      onSubmit={(event) => {
        event.preventDefault();
        const form = event.currentTarget;
        if (!form.reportValidity()) return;

        const data = new FormData(form);
        const chosenDate = String(data.get("date") ?? "");
        const today = localToday();
        if (chosenDate < today) {
          const input = dateRef.current;
          input?.setCustomValidity("Please choose today or a later date.");
          input?.reportValidity();
          return;
        }

        setDraft({
          firstName: String(data.get("firstName") ?? "").trim(),
          lastName: String(data.get("lastName") ?? "").trim(),
          email: String(data.get("email") ?? "").trim(),
          phone: String(data.get("phone") ?? "").trim(),
          date: chosenDate,
          party,
          time,
          notes: String(data.get("notes") ?? "").trim(),
        });
      }}
      className="space-y-6"
    >
      <div className="grid gap-6 md:grid-cols-2">
        <Field label="First name" name="firstName" placeholder="Jordan" autoComplete="given-name" />
        <Field label="Last name" name="lastName" placeholder="Lee" autoComplete="family-name" />
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <Field
          label="Email"
          name="email"
          type="email"
          placeholder="you@email.com"
          autoComplete="email"
        />
        <Field
          label="Phone"
          name="phone"
          type="tel"
          placeholder="(415) 555-0100"
          autoComplete="tel"
          inputMode="tel"
        />
      </div>

      <div>
        <label htmlFor="date" className="eyebrow flex items-center gap-2">
          <Calendar size={13} aria-hidden="true" />
          Date
        </label>
        <input
          ref={dateRef}
          id="date"
          name="date"
          type="date"
          required
          onChange={(event) => event.currentTarget.setCustomValidity("")}
          onFocus={(event) => {
            // A tab left open past midnight must not keep yesterday's limit.
            event.currentTarget.min = localToday();
          }}
          className="mt-2 w-full rounded-sm border border-line bg-base px-4 py-3 text-ink focus:border-accent focus:outline-none"
        />
      </div>

      <fieldset>
        <legend className="eyebrow flex items-center gap-2">
          <Users size={13} aria-hidden="true" />
          Party size
        </legend>
        <div className="mt-2 flex flex-wrap gap-2">
          {partySizes.map((size) => (
            <button
              key={size}
              type="button"
              aria-pressed={party === size}
              aria-label={`${size} ${size === "1" ? "guest" : "guests"}`}
              onClick={() => setParty(size)}
              className={`h-11 w-11 rounded-sm border text-sm font-medium transition-colors ${
                party === size
                  ? "border-accent bg-accent text-ink-invert"
                  : "border-line text-ink-soft hover:border-accent/50"
              }`}
            >
              {size}
            </button>
          ))}
        </div>
        <p className="demo-note mt-2">Parties larger than seven: please call.</p>
      </fieldset>

      <fieldset>
        <legend className="eyebrow flex items-center gap-2">
          <Clock size={13} aria-hidden="true" />
          Time
        </legend>
        <div className="mt-2 grid grid-cols-4 gap-2">
          {times.map((slot) => (
            <button
              key={slot}
              type="button"
              aria-pressed={time === slot}
              onClick={() => setTime(slot)}
              className={`rounded-sm border py-2.5 text-xs font-medium transition-colors ${
                time === slot
                  ? "border-accent bg-accent text-ink-invert"
                  : "border-line text-ink-soft hover:border-accent/50"
              }`}
            >
              {slot}
            </button>
          ))}
        </div>
      </fieldset>

      <div>
        <label htmlFor="notes" className="eyebrow">
          Occasion or notes
        </label>
        <textarea
          id="notes"
          name="notes"
          rows={3}
          placeholder="Allergies, accessibility, celebration…"
          className="mt-2 w-full resize-none rounded-sm border border-line bg-base px-4 py-3 text-sm text-ink placeholder:text-ink-mute focus:border-accent focus:outline-none"
        />
      </div>

      <button
        type="submit"
        className="w-full rounded-full bg-accent px-7 py-4 text-sm font-medium uppercase tracking-widest text-ink-invert transition-transform hover:scale-[1.01] focus-visible:scale-[1.01]"
      >
        Prepare reservation request
      </button>
      <p className="demo-note text-center">
        Demo form — this page has no booking backend and stores nothing. Submitting prepares an
        email draft to{" "}
        <a href={`mailto:${restaurant.email}`} className="link-underline text-accent">
          {restaurant.email}
        </a>{" "}
        that you send yourself. Connect your own booking provider before launch.
      </p>
    </form>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
  autoComplete,
  inputMode,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  autoComplete?: string;
  inputMode?: "tel" | "email" | "text";
}) {
  return (
    <div>
      <label htmlFor={name} className="eyebrow">
        {label}
      </label>
      <input
        id={name}
        name={name}
        type={type}
        required
        autoComplete={autoComplete}
        inputMode={inputMode}
        placeholder={placeholder}
        className="mt-2 w-full rounded-sm border border-line bg-base px-4 py-3 text-sm text-ink placeholder:text-ink-mute focus:border-accent focus:outline-none"
      />
    </div>
  );
}
