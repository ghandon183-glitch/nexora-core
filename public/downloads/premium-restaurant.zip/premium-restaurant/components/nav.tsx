"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu as MenuIcon, X, Phone } from "lucide-react";
import { restaurant, sectionLinks } from "@/lib/data";

export function Nav() {
  const [open, setOpen] = useState(false);

  // Escape closes the mobile menu, matching the visible close affordance.
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header className="fixed top-0 z-50 w-full border-b border-line/50 bg-base/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 md:px-8">
        <Link
          href="/"
          onClick={() => setOpen(false)}
          className="font-display text-2xl font-semibold tracking-wide text-ink"
          aria-label={`${restaurant.name} — home`}
        >
          {restaurant.name}
        </Link>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Primary">
          {sectionLinks.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className="link-underline text-sm uppercase tracking-widest text-ink-soft transition-colors hover:text-ink"
            >
              {link.label}
            </Link>
          ))}
          <Link
            href="/menu/"
            className="link-underline text-sm uppercase tracking-widest text-ink-soft transition-colors hover:text-ink"
          >
            Menu
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          <Link
            href="/reserve/"
            className="hidden rounded-full border border-accent px-5 py-2 text-sm font-medium uppercase tracking-widest text-accent transition-colors hover:bg-accent hover:text-ink-invert md:inline-block"
          >
            Reserve
          </Link>
          <a
            href={`tel:${restaurant.phone.replace(/[^+\d]/g, "")}`}
            className="hidden items-center gap-1.5 text-sm text-ink-soft transition-colors hover:text-ink lg:flex"
          >
            <Phone size={14} aria-hidden="true" />
            {restaurant.phone}
          </a>
          <button
            type="button"
            className="text-ink md:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            aria-controls="site-menu"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={22} aria-hidden="true" /> : <MenuIcon size={22} aria-hidden="true" />}
          </button>
        </div>
      </div>

      {open && (
        <div id="site-menu" className="border-t border-line bg-base px-5 py-5 md:hidden">
          <nav className="flex flex-col gap-4" aria-label="Mobile">
            {[...sectionLinks, { label: "Menu", href: "/menu/" }].map((link) => (
              <Link
                key={link.label}
                href={link.href}
                onClick={() => setOpen(false)}
                className="text-sm uppercase tracking-widest text-ink-soft"
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/reserve/"
              onClick={() => setOpen(false)}
              className="mt-2 inline-flex w-fit rounded-full bg-accent px-4 py-2 text-sm font-medium uppercase tracking-widest text-ink-invert"
            >
              Reserve
            </Link>
            <a
              href={`tel:${restaurant.phone.replace(/[^+\d]/g, "")}`}
              className="mt-1 inline-flex items-center gap-2 text-sm text-ink-soft"
            >
              <Phone size={14} aria-hidden="true" />
              {restaurant.phone}
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
