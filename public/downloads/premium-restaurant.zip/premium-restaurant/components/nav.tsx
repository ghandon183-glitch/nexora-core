"use client";

import { useState } from "react";
import { Menu as MenuIcon, X, Phone } from "lucide-react";
import { restaurant } from "@/lib/data";

export function Nav() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed top-0 z-50 w-full border-b border-line/50 bg-base/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 md:px-8">
        <a href="/" className="font-display text-2xl font-600 tracking-wide text-ink">
          {restaurant.name}
        </a>

        <nav className="hidden items-center gap-8 md:flex">
          <a href="/#philosophy" className="link-underline text-sm uppercase tracking-widest text-ink-soft">
            Philosophy
          </a>
          <a href="/menu" className="link-underline text-sm uppercase tracking-widest text-ink-soft">
            Menu
          </a>
          <a href="/#gallery" className="link-underline text-sm uppercase tracking-widest text-ink-soft">
            Gallery
          </a>
          <a href="/#visit" className="link-underline text-sm uppercase tracking-widest text-ink-soft">
            Visit
          </a>
        </nav>

        <div className="flex items-center gap-4">
          <a
            href="/reserve"
            className="hidden rounded-full border border-accent px-5 py-2 text-sm font-500 uppercase tracking-widest text-accent transition-colors hover:bg-accent hover:text-base md:inline-block"
          >
            Reserve
          </a>
          <a
            href={`tel:${restaurant.phone.replace(/[^+\d]/g, "")}`}
            className="hidden items-center gap-1.5 text-sm text-ink-soft lg:flex"
          >
            <Phone size={14} />
            {restaurant.phone}
          </a>
          <button
            className="text-ink md:hidden"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X size={22} /> : <MenuIcon size={22} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-line bg-base px-5 py-5 md:hidden">
          <nav className="flex flex-col gap-4">
            {[
              { label: "Philosophy", href: "/#philosophy" },
              { label: "Menu", href: "/menu" },
              { label: "Gallery", href: "/#gallery" },
              { label: "Visit", href: "/#visit" },
              { label: "Reserve", href: "/reserve" },
            ].map((l) => (
              <a
                key={l.label}
                href={l.href}
                onClick={() => setOpen(false)}
                className="text-sm uppercase tracking-widest text-ink-soft"
              >
                {l.label}
              </a>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
