import { gallery } from "@/lib/data";

export function Gallery() {
  return (
    <section id="gallery" className="border-b border-line bg-base-2">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-28">
        <p className="eyebrow">The room</p>
        <h2 className="font-display mt-4 text-4xl font-500 text-ink md:text-5xl">A glimpse inside</h2>

        <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-3">
          {gallery.map((item, i) => (
            <div
              key={item.label}
              className={`relative overflow-hidden rounded-sm ${
                i === 0 || i === 5 ? "col-span-2 row-span-2 md:col-span-1" : ""
              }`}
            >
              <svg
                viewBox="0 0 400 300"
                className={`w-full ${i === 0 || i === 5 ? "aspect-[4/3]" : "aspect-[4/3]"}`}
                preserveAspectRatio="xMidYMid slice"
                aria-hidden="true"
              >
                <defs>
                  <linearGradient id={`g${i}`} x1="0" y1="0" x2="0.7" y2="1">
                    <stop offset="0%" stopColor={item.palette} stopOpacity="0.85" />
                    <stop offset="100%" stopColor="#14110d" stopOpacity="0.95" />
                  </linearGradient>
                </defs>
                <rect width="400" height="300" fill={`url(#g${i})`} />
                {i % 2 === 0
                  ? Array.from({ length: 6 }).map((_, r) => (
                      <line key={r} x1="0" y1={r * 50 + 20} x2="400" y2={r * 50 + 20} stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
                    ))
                  : Array.from({ length: 8 }).map((_, r) => (
                      <circle key={r} cx={(r * 53) % 400} cy={(r * 71) % 300} r="30" fill="rgba(255,255,255,0.05)" />
                    ))}
              </svg>
              <span className="absolute bottom-3 left-3 text-xs uppercase tracking-widest text-ink/80">
                {item.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
