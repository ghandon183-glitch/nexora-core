import { gallery } from "@/lib/data";

export function Gallery() {
  return (
    <section id="gallery" className="border-b border-line bg-base-2">
      <div className="mx-auto max-w-6xl px-5 py-20 md:px-8 md:py-28">
        <p className="eyebrow">The room</p>
        <h2 className="font-display mt-4 text-4xl font-medium text-ink md:text-5xl">
          A glimpse inside
        </h2>

        <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-3">
          {gallery.map((item, i) => (
            <figure
              key={item.label}
              className="relative overflow-hidden rounded-sm border border-line/60"
            >
              <svg
                viewBox="0 0 400 300"
                className="aspect-[4/3] w-full"
                preserveAspectRatio="xMidYMid slice"
                role="img"
                aria-label={`${item.label} — generated placeholder artwork`}
              >
                <defs>
                  <linearGradient id={`g${i}`} x1="0" y1="0" x2="0.7" y2="1">
                    <stop offset="0%" stopColor={item.palette} stopOpacity="0.85" />
                    <stop offset="100%" stopColor="#14110d" stopOpacity="0.95" />
                  </linearGradient>
                </defs>
                <rect width="400" height="300" fill={`url(#g${i})`} />
                {i % 2 === 0
                  ? Array.from({ length: 6 }).map((_, r) => (
                      <line
                        key={r}
                        x1="0"
                        y1={r * 50 + 20}
                        x2="400"
                        y2={r * 50 + 20}
                        stroke="rgba(255,255,255,0.06)"
                        strokeWidth="1"
                      />
                    ))
                  : Array.from({ length: 8 }).map((_, r) => (
                      <circle
                        key={r}
                        cx={(r * 53) % 400}
                        cy={(r * 71) % 300}
                        r="30"
                        fill="rgba(255,255,255,0.05)"
                      />
                    ))}
              </svg>
              <figcaption className="absolute bottom-3 left-3 text-xs uppercase tracking-widest text-ink/80">
                {item.label}
              </figcaption>
            </figure>
          ))}
        </div>

        <p className="demo-note mt-8">
          Gallery images are generated placeholder artwork so the template ships with no stock
          photography. Replace them with your own photos before launch.
        </p>
      </div>
    </section>
  );
}
