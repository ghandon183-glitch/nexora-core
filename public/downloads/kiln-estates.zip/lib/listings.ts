export interface Listing {
  slug: string;
  name: string;
  location: string;
  price: number;
  sqft: number;
  year: number;
  architect: string;
  bedrooms: number;
  bathrooms: number;
  image: string;
  tagline: string;
  description: string;
}

export const listings: Listing[] = [
  {
    slug: "the-holloway-ranch",
    name: "The Holloway Ranch",
    location: "Ojai, California",
    price: 1850000,
    sqft: 2400,
    year: 1962,
    architect: "Marion Voss",
    bedrooms: 3,
    bathrooms: 2,
    image: "/images/listings/holloway-ranch.jpg",
    tagline: "A low-slung original, untouched since 1962.",
    description:
      "Set behind a citrus grove, the Holloway Ranch is a rare unaltered example of Marion Voss's residential work — post-and-beam construction, a continuous run of clerestory glass, and a central atrium that was radical for its time. The current owners have preserved the original terrazzo floors and cork ceiling panels.",
  },
  {
    slug: "glasswood-house",
    name: "Glasswood House",
    location: "Portland, Oregon",
    price: 2400000,
    sqft: 3100,
    year: 1998,
    architect: "Tomas Rhee",
    bedrooms: 4,
    bathrooms: 3,
    image: "/images/listings/glasswood-house.jpg",
    tagline: "A stone-and-glass volume set into the hillside.",
    description:
      "Glasswood House steps down a forested slope in three staggered volumes, each wrapped in a curtain of glass that frames the fir canopy outside. Tomas Rhee designed the home around a single basalt hearth that anchors all three levels.",
  },
  {
    slug: "casa-del-viento",
    name: "Casa del Viento",
    location: "Marfa, Texas",
    price: 1450000,
    sqft: 1950,
    year: 2011,
    architect: "Elena Duarte",
    bedrooms: 2,
    bathrooms: 2,
    image: "/images/listings/casa-del-viento.jpg",
    tagline: "A butterfly-roofed retreat on the high desert.",
    description:
      "Elena Duarte's Casa del Viento was built to catch the desert's rare rain — its butterfly roof channels water to a below-ground cistern. Rammed-earth walls keep the interior cool through the summer without mechanical air conditioning.",
  },
  {
    slug: "the-birchmark-cabin",
    name: "The Birchmark Cabin",
    location: "Stowe, Vermont",
    price: 980000,
    sqft: 1600,
    year: 1948,
    architect: "Unknown, restored by Iver Solum",
    bedrooms: 3,
    bathrooms: 1,
    image: "/images/listings/birchmark-cabin.jpg",
    tagline: "A postwar A-frame with its original fieldstone hearth.",
    description:
      "One of the earliest A-frames in the valley, the Birchmark Cabin was restored plank by plank by Iver Solum in 2019, who kept the original fieldstone chimney and hand-hewn ceiling beams while quietly modernizing the systems beneath.",
  },
];

export function getListing(slug: string) {
  return listings.find((l) => l.slug === slug);
}
