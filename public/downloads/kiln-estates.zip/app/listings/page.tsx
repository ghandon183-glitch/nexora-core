import Link from "next/link";
import Image from "next/image";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { listings } from "@/lib/listings";

export const metadata = {
  title: "Listings | Kiln Estates",
};

export default function ListingsPage() {
  return (
    <>
      <Navbar />

      <section className="mx-auto max-w-7xl px-6 pb-8 pt-16 lg:px-10">
        <span className="font-mono text-xs uppercase tracking-[0.3em] text-clay">
          Current Listings
        </span>
        <h1 className="mt-4 font-display text-5xl font-medium text-forest lg:text-6xl">
          Four homes, four stories.
        </h1>
        <p className="mt-6 max-w-xl font-sans text-lg leading-relaxed text-forest/70">
          Each listing below has been chosen for its architectural
          significance — not simply its square footage.
        </p>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 lg:px-10">
        <div className="grid gap-14 md:grid-cols-2">
          {listings.map((listing) => (
            <Link
              key={listing.slug}
              href={`/listings/${listing.slug}`}
              className="group block"
            >
              <div className="relative h-80 overflow-hidden rounded-2xl">
                <Image
                  src={listing.image}
                  alt={listing.name}
                  fill
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-forest/70 via-transparent to-transparent" />
                <div className="absolute bottom-5 left-5 rounded-full bg-background/95 px-4 py-1.5 font-mono text-xs text-forest">
                  {listing.year} · {listing.architect.split(" ").pop()}
                </div>
              </div>

              <div className="mt-5 flex items-start justify-between gap-4">
                <div>
                  <h2 className="font-display text-2xl font-medium text-forest">
                    {listing.name}
                  </h2>
                  <p className="mt-1 font-sans text-sm text-forest/60">
                    {listing.location}
                  </p>
                  <p className="mt-3 max-w-sm font-sans text-sm leading-relaxed text-forest/70">
                    {listing.tagline}
                  </p>
                </div>
                <p className="whitespace-nowrap font-mono text-base text-clay">
                  ${(listing.price / 1000).toFixed(0)}K
                </p>
              </div>

              <div className="mt-5 flex gap-6 border-t border-sand pt-4 font-mono text-xs text-forest/60">
                <span>{listing.sqft.toLocaleString()} SQFT</span>
                <span>{listing.bedrooms} BED</span>
                <span>{listing.bathrooms} BATH</span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <Footer />
    </>
  );
}
