import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import MaterialSwatch from "@/components/MaterialSwatch";
import { listings, getListing } from "@/lib/listings";

export function generateStaticParams() {
  return listings.map((l) => ({ slug: l.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const listing = getListing(slug);
  if (!listing) return {};
  return { title: `${listing.name} | Kiln Estates` };
}

export default async function ListingDetail({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const listing = getListing(slug);
  if (!listing) notFound();

  const others = listings.filter((l) => l.slug !== slug).slice(0, 2);

  return (
    <>
      <Navbar />

      <section className="relative h-[60vh] min-h-[420px] w-full">
        <Image
          src={listing.image}
          alt={listing.name}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-forest via-forest/20 to-transparent" />

        <div className="absolute inset-x-0 bottom-0 mx-auto max-w-7xl px-6 pb-10 lg:px-10">
          <Link
            href="/listings"
            className="font-mono text-xs uppercase tracking-wider text-background/70 hover:text-background"
          >
            ← All Listings
          </Link>
          <h1 className="mt-4 font-display text-5xl font-medium text-background lg:text-6xl">
            {listing.name}
          </h1>
          <p className="mt-2 font-sans text-lg text-background/80">
            {listing.location}
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
        <div className="grid gap-14 lg:grid-cols-[1fr_360px]">

          <div>
            <p className="font-display text-2xl italic text-clay">
              {listing.tagline}
            </p>
            <p className="mt-6 max-w-2xl font-sans text-lg leading-relaxed text-forest/80">
              {listing.description}
            </p>

            <MaterialSwatch orientation="horizontal" className="mt-12 max-w-xs" />
          </div>

          <aside className="h-fit rounded-2xl border border-sand bg-stone/40 p-8">
            <p className="font-mono text-3xl text-forest">
              ${listing.price.toLocaleString()}
            </p>

            <dl className="mt-8 space-y-4 border-t border-sand pt-6 font-mono text-sm">
              <div className="flex justify-between">
                <dt className="text-forest/50">Square Feet</dt>
                <dd className="text-forest">{listing.sqft.toLocaleString()}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-forest/50">Year Built</dt>
                <dd className="text-forest">{listing.year}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-forest/50">Architect</dt>
                <dd className="text-forest">{listing.architect}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-forest/50">Bedrooms</dt>
                <dd className="text-forest">{listing.bedrooms}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-forest/50">Bathrooms</dt>
                <dd className="text-forest">{listing.bathrooms}</dd>
              </div>
            </dl>

            <Link
              href="/contact"
              className="mt-8 block rounded-full bg-clay px-6 py-3 text-center font-sans text-sm font-medium text-background transition-transform hover:scale-105"
            >
              Inquire About This Home
            </Link>
          </aside>

        </div>
      </section>

      {others.length > 0 && (
        <section className="bg-stone/40 py-20">
          <div className="mx-auto max-w-7xl px-6 lg:px-10">
            <span className="font-mono text-xs uppercase tracking-[0.3em] text-clay">
              Other Homes
            </span>
            <h2 className="mt-4 font-display text-3xl font-medium text-forest">
              You may also like
            </h2>

            <div className="mt-10 grid gap-10 sm:grid-cols-2">
              {others.map((o) => (
                <Link key={o.slug} href={`/listings/${o.slug}`} className="group block">
                  <div className="relative h-64 overflow-hidden rounded-2xl">
                    <Image src={o.image} alt={o.name} fill className="object-cover transition-transform duration-500 group-hover:scale-105" />
                  </div>
                  <div className="mt-4 flex justify-between">
                    <h3 className="font-display text-xl font-medium text-forest">{o.name}</h3>
                    <p className="font-mono text-sm text-clay">${(o.price / 1000).toFixed(0)}K</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      <Footer />
    </>
  );
}
