import Link from "next/link";
import Image from "next/image";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import MaterialSwatch from "@/components/MaterialSwatch";
import { listings } from "@/lib/listings";

export default function Home() {
  const featured = listings.slice(0, 3);
  const hero = listings[0];

  return (
    <>
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="mx-auto grid max-w-7xl gap-12 px-6 pb-20 pt-16 lg:grid-cols-[1.1fr_0.9fr] lg:gap-8 lg:px-10 lg:pt-24">

          <div className="flex flex-col justify-center">
            <span className="font-mono text-xs uppercase tracking-[0.3em] text-clay">
              Est. 2014 — Architect-Designed Homes
            </span>

            <h1 className="mt-6 font-display text-6xl font-medium leading-[0.95] tracking-tight text-forest lg:text-7xl">
              Homes with a<br />
              <span className="italic text-clay">point of view.</span>
            </h1>

            <p className="mt-8 max-w-md font-sans text-lg leading-relaxed text-forest/70">
              Kiln Estates represents architecturally significant and heritage
              homes — each one chosen for what it says, not just where it sits.
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-6">
              <Link
                href="/listings"
                className="rounded-full bg-clay px-7 py-3.5 font-sans text-sm font-medium text-background transition-transform hover:scale-105"
              >
                View Listings
              </Link>
              <Link
                href="/about"
                className="font-sans text-sm font-medium text-forest underline decoration-clay decoration-2 underline-offset-4"
              >
                Our Philosophy
              </Link>
            </div>

            <MaterialSwatch orientation="horizontal" className="mt-14 max-w-xs" />
          </div>

          <div className="relative flex h-[420px] items-end overflow-hidden rounded-3xl sm:h-[520px] lg:h-[640px]">
            <Image
              src={hero.image}
              alt={hero.name}
              fill
              priority
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-forest/90 via-forest/10 to-transparent" />
            <div className="absolute inset-0 bg-clay/10 mix-blend-multiply" />

            <div className="relative m-6 flex gap-6 rounded-2xl border border-sand/40 bg-background/95 px-8 py-5 font-mono text-xs text-forest shadow-xl backdrop-blur-sm">
              <div>
                <p className="text-forest/50">SQFT</p>
                <p className="mt-1 text-base font-medium">{hero.sqft.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-forest/50">YEAR</p>
                <p className="mt-1 text-base font-medium">{hero.year}</p>
              </div>
              <div>
                <p className="text-forest/50">ARCHITECT</p>
                <p className="mt-1 text-base font-medium">{hero.architect.split(" ").pop()}</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* Featured listings */}
      <section className="mx-auto max-w-7xl px-6 py-24 lg:px-10">
        <div className="flex items-end justify-between">
          <div>
            <span className="font-mono text-xs uppercase tracking-[0.3em] text-clay">
              Current Listings
            </span>
            <h2 className="mt-4 font-display text-4xl font-medium text-forest">
              Four homes, four stories.
            </h2>
          </div>
          <Link href="/listings" className="hidden font-sans text-sm font-medium text-forest underline decoration-clay decoration-2 underline-offset-4 md:block">
            View all listings →
          </Link>
        </div>

        <div className="mt-14 grid gap-10 md:grid-cols-3">
          {featured.map((listing) => (
            <Link
              key={listing.slug}
              href={`/listings/${listing.slug}`}
              className="group block"
            >
              <div className="relative h-72 overflow-hidden rounded-2xl transition-transform duration-500 group-hover:-translate-y-2">
                <Image
                  src={listing.image}
                  alt={listing.name}
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-forest/70 via-transparent to-transparent" />
              </div>

              <div className="mt-5 flex items-start justify-between gap-4">
                <div>
                  <h3 className="font-display text-xl font-medium text-forest">
                    {listing.name}
                  </h3>
                  <p className="mt-1 font-sans text-sm text-forest/60">
                    {listing.location}
                  </p>
                </div>
                <p className="whitespace-nowrap font-mono text-sm text-clay">
                  ${(listing.price / 1000).toFixed(0)}K
                </p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Philosophy */}
      <section className="bg-forest py-24 text-stone">
        <div className="mx-auto grid max-w-7xl gap-12 px-6 lg:grid-cols-2 lg:px-10">
          <div>
            <span className="font-mono text-xs uppercase tracking-[0.3em] text-clay">
              Our Philosophy
            </span>
            <h2 className="mt-4 font-display text-4xl font-medium text-background">
              We don&apos;t list houses. We represent buildings.
            </h2>
          </div>
          <div className="space-y-6 font-sans text-lg leading-relaxed text-stone/80">
            <p>
              Every home we represent has been chosen by hand — for the
              architect who designed it, the materials it was built from, or
              the story it has quietly carried for decades.
            </p>
            <p>
              We work with a small number of clients at a time, because a
              building like this deserves more than a listing photo and a
              lockbox.
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}
