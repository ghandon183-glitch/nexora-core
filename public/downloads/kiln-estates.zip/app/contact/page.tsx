import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import MaterialSwatch from "@/components/MaterialSwatch";

export const metadata = {
  title: "Contact | Kiln Estates",
};

export default function ContactPage() {
  return (
    <>
      <Navbar />

      <section className="mx-auto max-w-7xl px-6 py-20 lg:px-10">
        <div className="grid gap-16 lg:grid-cols-2">

          <div>
            <span className="font-mono text-xs uppercase tracking-[0.3em] text-clay">
              Get in Touch
            </span>
            <h1 className="mt-6 font-display text-5xl font-medium leading-tight text-forest">
              Let&apos;s talk about
              <br />
              <span className="italic text-clay">your next home.</span>
            </h1>
            <p className="mt-6 max-w-md font-sans text-lg leading-relaxed text-forest/70">
              Whether you&apos;re interested in a current listing or thinking
              about representing your own home, we&apos;d like to hear from
              you.
            </p>

            <div className="mt-12 space-y-6 font-mono text-sm text-forest">
              <div>
                <p className="text-forest/50">Email</p>
                <p className="mt-1 text-base">hello@kilnestates.example</p>
              </div>
              <div>
                <p className="text-forest/50">Phone</p>
                <p className="mt-1 text-base">+1 (555) 014-2200</p>
              </div>
              <div>
                <p className="text-forest/50">Studio</p>
                <p className="mt-1 text-base">By appointment only</p>
              </div>
            </div>

            <MaterialSwatch orientation="horizontal" className="mt-14 max-w-xs" />
          </div>

          <form className="space-y-6 rounded-2xl border border-sand bg-stone/40 p-8">
            <div>
              <label htmlFor="name" className="font-mono text-xs uppercase tracking-wider text-forest/60">
                Name
              </label>
              <input
                id="name"
                type="text"
                required
                className="mt-2 w-full rounded-lg border border-sand bg-background px-4 py-3 font-sans text-forest outline-none transition-colors focus:border-clay"
                placeholder="Your full name"
              />
            </div>

            <div>
              <label htmlFor="email" className="font-mono text-xs uppercase tracking-wider text-forest/60">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                className="mt-2 w-full rounded-lg border border-sand bg-background px-4 py-3 font-sans text-forest outline-none transition-colors focus:border-clay"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label htmlFor="interest" className="font-mono text-xs uppercase tracking-wider text-forest/60">
                I&apos;m interested in
              </label>
              <select
                id="interest"
                className="mt-2 w-full rounded-lg border border-sand bg-background px-4 py-3 font-sans text-forest outline-none transition-colors focus:border-clay"
              >
                <option>A current listing</option>
                <option>Selling my home</option>
                <option>Something else</option>
              </select>
            </div>

            <div>
              <label htmlFor="message" className="font-mono text-xs uppercase tracking-wider text-forest/60">
                Message
              </label>
              <textarea
                id="message"
                rows={5}
                required
                className="mt-2 w-full rounded-lg border border-sand bg-background px-4 py-3 font-sans text-forest outline-none transition-colors focus:border-clay"
                placeholder="Tell us a little about what you're looking for..."
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-full bg-clay px-6 py-3.5 font-sans text-sm font-medium text-background transition-transform hover:scale-105"
            >
              Send Message
            </button>

            <p className="text-center font-sans text-xs text-forest/50">
              This form is for demonstration only and does not send a real message.
            </p>
          </form>

        </div>
      </section>

      <Footer />
    </>
  );
}
