import Image from "next/image";
import Link from "next/link";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import MaterialSwatch from "@/components/MaterialSwatch";
import { listings } from "@/lib/listings";

export const metadata = {
  title: "Philosophy | Kiln Estates",
};

export default function AboutPage() {
  return (
    <>
      <Navbar />

      <section className="mx-auto max-w-4xl px-6 pb-16 pt-20 text-center lg:px-10">
        <span className="font-mono text-xs uppercase tracking-[0.3em] text-clay">
          Our Philosophy
        </span>
        <h1 className="mt-6 font-display text-5xl font-medium leading-tight text-forest lg:text-6xl">
          A house is a body of work,
          <br />
          <span className="italic text-clay">not a listing.</span>
        </h1>
      </section>

      <section className="relative h-[50vh] min-h-[360px] w-full">
        <Image
          src={listings[1].image}
          alt="Kiln Estates architecture"
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-forest/25" />
      </section>

      <section className="mx-auto grid max-w-6xl gap-16 px-6 py-24 lg:grid-cols-2 lg:px-10">
        <div className="space-y-6 font-sans text-lg leading-relaxed text-forest/80">
          <p>
            Kiln Estates was founded in 2014 by a small group of former
            architecture writers who kept noticing the same thing: the homes
            with the most interesting stories were the hardest to sell well.
          </p>
          <p>
            Standard listing photography flattens a building into a floor
            plan and a price. We wanted something closer to how an architect
            actually experiences a house — the material choices, the way
            light moves through a room over the course of a day, the
            decisions a previous owner made and why.
          </p>
          <p>
            So we built a studio around exactly that. We represent a small
            number of homes at any given time, each one chosen for what it
            says architecturally, and we spend as much time on the story as
            we do on the square footage.
          </p>
        </div>

        <div className="space-y-10">
          <div>
            <h3 className="font-display text-2xl font-medium text-forest">
              What we look for
            </h3>
            <ul className="mt-5 space-y-4 font-sans text-forest/70">
              <li className="flex gap-3">
                <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-clay" />
                A clear point of view — from a named architect, a distinct
                era, or a material palette that was chosen deliberately.
              </li>
              <li className="flex gap-3">
                <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-clay" />
                Provenance we can document — original drawings, permits, or
                an owner who can speak to the building&apos;s history.
              </li>
              <li className="flex gap-3">
                <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-clay" />
                Enough integrity remaining that a buyer can restore rather
                than start over.
              </li>
            </ul>
          </div>

          <MaterialSwatch orientation="horizontal" className="max-w-xs" />
        </div>
      </section>

      <section className="bg-forest py-24 text-center text-stone">
        <div className="mx-auto max-w-2xl px-6 lg:px-10">
          <h2 className="font-display text-3xl font-medium text-background">
            Thinking of selling an architecturally significant home?
          </h2>
          <p className="mt-4 font-sans text-stone/70">
            We take on a small number of new listings each year.
          </p>
          <Link
            href="/contact"
            className="mt-8 inline-block rounded-full bg-clay px-7 py-3.5 font-sans text-sm font-medium text-background transition-transform hover:scale-105"
          >
            Get in Touch
          </Link>
        </div>
      </section>

      <Footer />
    </>
  );
}
