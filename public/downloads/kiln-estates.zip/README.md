# Kiln Estates

A boutique real estate template for architect-designed and heritage homes,
built with Next.js 16, TypeScript, and Tailwind CSS v4.

## What's Included

- **Home page** — editorial hero, featured listings, brand philosophy section
- **Listings page** — full grid of all properties with specs and pricing
- **Listing detail pages** — statically generated per property, with a spec
  sheet, description, and related listings
- **About page** — brand story and "what we look for" criteria
- **Contact page** — styled inquiry form (front-end only, see note below)
- A reusable `MaterialSwatch` component (the signature "material palette"
  strip used throughout the site)
- A warm, editorial color system (clay, forest, sand, brass) defined as
  Tailwind theme tokens in `app/globals.css`

## Tech Stack

- Next.js 16 (App Router)
- TypeScript
- Tailwind CSS v4
- Google Fonts: Fraunces (display), Work Sans (body), IBM Plex Mono (specs/data)

## Getting Started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Customizing

- **Listings data** lives in `lib/listings.ts` — edit or add entries here.
  Each listing needs an `image` (see below).
- **Colors** are defined as CSS variables in `app/globals.css` under `:root`
  and mapped into Tailwind via `@theme inline`. Change the hex values there
  to re-theme the whole site.
- **Fonts** are loaded in `app/layout.tsx` via `next/font/google`.

## About the Listing Photos

The four listing photos included in `public/images/listings/` are licensed
under the [Unsplash License](https://unsplash.com/license) (free for
commercial and non-commercial use, no permission or attribution required).
They are fictional stand-ins for demonstration purposes — for a real launch,
replace them with your own licensed photography in the same folder and
update the `image` path in `lib/listings.ts` for each listing.

## About the Contact Form

The contact form on `/contact` is a styled front-end only — submitting it
does not send an email or hit an API. To make it functional, connect it to
a form backend (e.g. Resend, Formspree) or build an API route similar to
Nexora Core's other templates.

## License

This template is provided under a standard commercial license for the buyer.
Resale or redistribution of the template itself is not permitted.
