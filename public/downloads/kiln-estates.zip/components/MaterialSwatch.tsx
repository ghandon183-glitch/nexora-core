interface MaterialSwatchProps {
  orientation?: "vertical" | "horizontal";
  className?: string;
}

// The signature recurring element: a strip of material swatches,
// like an architect's palette board (stone, timber, clay, brass).
export default function MaterialSwatch({ orientation = "vertical", className = "" }: MaterialSwatchProps) {
  const materials = [
    { name: "Stone", style: "bg-[repeating-linear-gradient(135deg,#DCD0B4_0px,#DCD0B4_6px,#C9BB99_6px,#C9BB99_12px)]" },
    { name: "Timber", style: "bg-[repeating-linear-gradient(90deg,#9C6B3E_0px,#9C6B3E_3px,#85582F_3px,#85582F_6px)]" },
    { name: "Clay", style: "bg-clay" },
    { name: "Brass", style: "bg-[linear-gradient(135deg,#B9955A_0%,#9C7A3C_50%,#7C5F2C_100%)]" },
  ];

  const isVertical = orientation === "vertical";

  return (
    <div
      className={`flex ${isVertical ? "flex-col" : "flex-row"} gap-2 ${className}`}
    >
      {materials.map((m) => (
        <div key={m.name} className="group relative flex-1">
          <div
            className={`${m.style} ${isVertical ? "h-16 w-10" : "h-10 w-16"} rounded-sm shadow-inner`}
            title={m.name}
          />
          <span className="pointer-events-none absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap font-mono text-[10px] uppercase tracking-wider text-forest/60 opacity-0 transition-opacity group-hover:opacity-100">
            {m.name}
          </span>
        </div>
      ))}
    </div>
  );
}
