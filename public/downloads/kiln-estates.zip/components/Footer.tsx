import Link from "next/link";
import MaterialSwatch from "./MaterialSwatch";

export default function Footer() {
  return (
    <footer className="bg-forest text-stone">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr_auto]">

          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-display text-2xl font-semibold text-background">Kiln</span>
              <span className="font-mono text-[11px] uppercase tracking-[0.25em] text-clay">Estates</span>
            </div>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-stone/70">
              A boutique studio representing architect-designed and heritage homes. Founded on the belief that a house should have a point of view.
            </p>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-clay">Explore</h4>
            <ul className="mt-4 space-y-3 text-sm text-stone/80">
              <li><Link href="/listings" className="hover:text-background">Listings</Link></li>
              <li><Link href="/about" className="hover:text-background">Philosophy</Link></li>
              <li><Link href="/contact" className="hover:text-background">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-mono text-xs uppercase tracking-[0.2em] text-clay">Studio</h4>
            <ul className="mt-4 space-y-3 text-sm text-stone/80">
              <li>hello@kilnestates.example</li>
              <li>+1 (555) 014-2200</li>
              <li>By appointment only</li>
            </ul>
          </div>

          <MaterialSwatch orientation="horizontal" className="md:flex-col" />

        </div>

        <div className="mt-16 flex flex-col justify-between gap-4 border-t border-stone/15 pt-8 text-xs text-stone/50 sm:flex-row">
          <p>© 2026 Kiln Estates. A demo template by Nexora Core.</p>
          <p>Fictional listings for demonstration purposes.</p>
        </div>
      </div>
    </footer>
  );
}
