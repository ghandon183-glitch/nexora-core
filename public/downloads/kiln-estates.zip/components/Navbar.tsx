import Link from "next/link";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-sand/60 bg-background/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5 lg:px-10">
        <Link href="/" className="flex items-baseline gap-2">
          <span className="font-display text-2xl font-semibold tracking-tight text-forest">
            Kiln
          </span>
          <span className="font-mono text-[11px] uppercase tracking-[0.25em] text-clay">
            Estates
          </span>
        </Link>

        <nav className="hidden items-center gap-10 font-sans text-sm text-forest/80 md:flex">
          <Link href="/listings" className="transition-colors hover:text-clay">Listings</Link>
          <Link href="/about" className="transition-colors hover:text-clay">Philosophy</Link>
          <Link href="/contact" className="transition-colors hover:text-clay">Contact</Link>
        </nav>

        <Link
          href="/contact"
          className="rounded-full bg-forest px-5 py-2.5 font-sans text-sm font-medium text-background transition-colors hover:bg-clay"
        >
          Inquire
        </Link>
      </div>
    </header>
  );
}
