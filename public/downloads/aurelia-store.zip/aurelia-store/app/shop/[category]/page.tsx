import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { categories, products } from "@/lib/data";
import { Subpage } from "@/components/subpage";
import { ProductCard } from "@/components/product-card";

export const dynamicParams = false;

export function generateStaticParams() {
  return categories.map((category) => ({ category: category.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ category: string }>;
}): Promise<Metadata> {
  const { category: slug } = await params;
  const category = categories.find((item) => item.slug === slug);

  if (!category) return {};

  return {
    title: `${category.name} — Aurelia`,
    description: category.description,
  };
}

export default async function CategoryPage({
  params,
}: {
  params: Promise<{ category: string }>;
}) {
  const { category: slug } = await params;
  const category = categories.find((item) => item.slug === slug);

  if (!category) notFound();

  const items = products.filter((product) => product.category === category.name);

  return (
    <Subpage
      eyebrow="Shop by kind"
      title={category.name}
      intro={category.description}
      sample={false}
    >
      <div className="grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-3">
        {items.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {items.length === 0 && (
        <p>
          No pieces are listed in this shelf yet. Add them in{" "}
          <code className="rounded bg-sand-deep px-1.5 py-0.5 text-xs text-ink">
            lib/data.ts
          </code>
          .
        </p>
      )}

      <p>
        <Link
          href="/#categories"
          className="text-sm font-semibold text-ink underline decoration-coral decoration-2 underline-offset-4"
        >
          Back to all four shelves
        </Link>
      </p>
    </Subpage>
  );
}
