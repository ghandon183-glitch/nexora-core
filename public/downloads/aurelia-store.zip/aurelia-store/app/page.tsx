import { Nav } from "@/components/nav";
import { Hero } from "@/components/hero";
import { CategoryGrid } from "@/components/category-grid";
import { FeaturedProducts } from "@/components/featured-products";
import { Bestsellers } from "@/components/bestsellers";
import { Reviews } from "@/components/reviews";
import { Newsletter } from "@/components/newsletter";
import { Footer } from "@/components/footer";

export default function Home() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <CategoryGrid />
        <FeaturedProducts />
        <Bestsellers />
        <Reviews />
        <Newsletter />
      </main>
      <Footer />
    </>
  );
}
