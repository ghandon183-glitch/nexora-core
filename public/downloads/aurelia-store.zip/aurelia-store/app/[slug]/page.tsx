import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { pages, pageSlugs } from "@/lib/pages";
import { Subpage } from "@/components/subpage";

export const dynamicParams = false;

export function generateStaticParams() {
  return pageSlugs.map((slug) => ({ slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const page = pages[slug];

  if (!page) return {};

  return {
    title: `${page.title} — Aurelia`,
    description: page.intro,
  };
}

export default async function InfoPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const page = pages[slug];

  if (!page) notFound();

  return (
    <Subpage
      eyebrow={page.eyebrow}
      title={page.title}
      intro={page.intro}
      sample={page.sample ?? true}
    >
      {page.details && (
        <dl className="grid gap-3 rounded-2xl bg-sand-deep px-6 py-5 text-sm sm:grid-cols-[9rem_1fr]">
          {page.details.map((detail) => (
            <div key={detail.label} className="contents">
              <dt className="font-semibold text-ink">{detail.label}</dt>
              <dd className="text-ink-soft">
                {detail.href ? (
                  <a
                    href={detail.href}
                    className="underline decoration-coral decoration-2 underline-offset-4 hover:text-ink"
                  >
                    {detail.value}
                  </a>
                ) : (
                  detail.value
                )}
              </dd>
            </div>
          ))}
        </dl>
      )}

      {page.sections.map((section) => (
        <section key={section.heading}>
          <h2 className="font-display text-2xl text-ink">{section.heading}</h2>
          {section.body.map((paragraph) => (
            <p key={paragraph} className="mt-3">
              {paragraph}
            </p>
          ))}
        </section>
      ))}
    </Subpage>
  );
}
