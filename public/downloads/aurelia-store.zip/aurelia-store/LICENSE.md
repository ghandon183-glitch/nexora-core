# License information

This file points to the applicable Nexora commercial license; it is not a replacement for the complete legal terms.

Review the license and refund terms shown on Nexora at purchase before using this package:
- Commercial license: https://nexora-core.nxora.workers.dev/en/license
- Refund policy: https://nexora-core.nxora.workers.dev/en/refunds

The official terms applicable to your purchase control if this summary and those terms differ. Third-party assets may have separate conditions; review ASSET-LICENSES.md where included.
