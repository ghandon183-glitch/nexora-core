"use client";

import { useState } from "react";
import { Reveal } from "@/components/reveal";

export function Newsletter() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitted(true);
  }

  return (
    <section className="mx-auto max-w-7xl px-6 py-20">
      <Reveal>
        <div className="rounded-[28px] bg-sand-deep px-8 py-14 text-center md:px-16">
          <p className="label-eyebrow text-coral-deep">Stay close</p>
          <h2 className="font-display mx-auto mt-3 max-w-lg text-3xl text-ink md:text-4xl">
            New pieces, restocks, and studio notes — twice a month, at most.
          </h2>

          {submitted ? (
            <p className="mt-7 text-sm font-semibold text-forest">
              You're on the list. Look out for our next studio note.
            </p>
          ) : (
            <form
              onSubmit={handleSubmit}
              className="mx-auto mt-7 flex max-w-md flex-col gap-3 sm:flex-row"
            >
              <label htmlFor="newsletter-email" className="sr-only">
                Email address
              </label>
              <input
                id="newsletter-email"
                type="email"
                required
                placeholder="you@email.com"
                className="w-full rounded-full border border-ink/15 bg-sand px-5 py-3 text-sm text-ink placeholder:text-ink-soft focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral"
              />
              <button
                type="submit"
                className="shrink-0 rounded-full bg-ink px-6 py-3 text-sm font-semibold text-sand transition-colors hover:bg-forest"
              >
                Subscribe
              </button>
            </form>
          )}
        </div>
      </Reveal>
    </section>
  );
}
