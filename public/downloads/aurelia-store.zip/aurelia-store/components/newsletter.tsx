"use client";

import { useState } from "react";
import { Reveal } from "@/components/reveal";

export function Newsletter() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmitted(true);
  }

  return (
    <section id="newsletter" className="mx-auto max-w-7xl px-6 py-20">
      <Reveal>
        <div className="rounded-[28px] bg-sand-deep px-8 py-14 text-center md:px-16">
          <p className="label-eyebrow text-coral-text">Stay close</p>
          <h2 className="font-display mx-auto mt-3 max-w-lg text-3xl text-ink md:text-4xl">
            New pieces, restocks, and studio notes — twice a month, at most.
          </h2>

          {submitted ? (
            <div
              role="status"
              className="mx-auto mt-7 max-w-md rounded-2xl border border-forest/30 bg-sand px-5 py-4 text-left text-sm"
            >
              <p className="font-semibold text-forest">
                Demo form — nothing was sent or stored.
              </p>
              <p className="mt-1 text-ink-soft">
                This template has no newsletter backend, so the address you
                typed was not saved, emailed, or sent to a provider. To collect
                real sign-ups, connect one in{" "}
                <code className="rounded bg-sand-deep px-1.5 py-0.5 text-xs text-ink">
                  components/newsletter.tsx
                </code>{" "}
                — see the README section “Connecting a newsletter provider”.
              </p>
            </div>
          ) : (
            <>
              <form
                onSubmit={handleSubmit}
                className="mx-auto mt-7 flex max-w-md flex-col gap-3 sm:flex-row"
              >
                <label htmlFor="newsletter-email" className="sr-only">
                  Email address
                </label>
                <input
                  id="newsletter-email"
                  type="email"
                  required
                  autoComplete="email"
                  placeholder="you@email.com"
                  className="w-full rounded-full border border-ink/15 bg-sand px-5 py-3 text-sm text-ink placeholder:text-ink-soft focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral"
                />
                <button
                  type="submit"
                  className="shrink-0 rounded-full bg-ink px-6 py-3 text-sm font-semibold text-sand transition-colors hover:bg-forest"
                >
                  Subscribe
                </button>
              </form>
              <p role="note" className="mt-4 text-xs leading-relaxed text-ink-soft">
                Demo form — no email is sent or stored until you connect a
                newsletter provider. See the README for setup.
              </p>
            </>
          )}
        </div>
      </Reveal>
    </section>
  );
}
