"use client";

import { useEffect, useRef, useState } from "react";
import { Minus, Plus, ShoppingBag, Trash2, X } from "lucide-react";
import { useCart } from "@/lib/cart";

export function CartDrawer() {
  const { lines, count, subtotal, isOpen, closeCart, removeItem, setQty, clear } = useCart();
  const closeRef = useRef<HTMLButtonElement>(null);
  const [checkoutNote, setCheckoutNote] = useState(false);

  // Closing always drops the demo note, so the drawer opens clean next time.
  const handleClose = () => {
    setCheckoutNote(false);
    closeCart();
  };

  useEffect(() => {
    if (!isOpen) return;

    closeRef.current?.focus();

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setCheckoutNote(false);
        closeCart();
      }
    };

    window.addEventListener("keydown", onKeyDown);

    return () => window.removeEventListener("keydown", onKeyDown);
  }, [isOpen, closeCart]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[80] flex justify-end">
      <div
        className="absolute inset-0 bg-ink/40 backdrop-blur-sm"
        onClick={handleClose}
        aria-hidden="true"
      />

      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="cart-heading"
        className="relative flex h-full w-full max-w-md flex-col bg-sand shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-ink/10 px-6 py-5">
          <h2 id="cart-heading" className="font-display text-xl text-ink">
            Your bag {count > 0 && <span className="text-ink-soft">({count})</span>}
          </h2>
          <button
            ref={closeRef}
            type="button"
            onClick={handleClose}
            aria-label="Close bag"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-ink/15 text-ink-soft transition-colors hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral"
          >
            <X size={17} strokeWidth={1.75} aria-hidden="true" />
          </button>
        </div>

        {lines.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
            <ShoppingBag size={28} strokeWidth={1.5} className="text-ink-soft" aria-hidden="true" />
            <p className="text-sm text-ink-soft">
              Your bag is empty. Add a piece from the collection to see it here.
            </p>
          </div>
        ) : (
          <>
            <ul className="flex-1 overflow-y-auto px-6 py-5">
              {lines.map((line) => (
                <li
                  key={line.product.id}
                  className="flex items-start justify-between gap-4 border-b border-ink/10 py-4 last:border-b-0"
                >
                  <div>
                    <p className="text-sm font-semibold text-ink">{line.product.name}</p>
                    <p className="mt-0.5 text-xs text-ink-soft">{line.product.material}</p>

                    <div className="mt-3 flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setQty(line.product.id, line.qty - 1)}
                        aria-label={`Decrease quantity of ${line.product.name}`}
                        className="flex h-7 w-7 items-center justify-center rounded-full border border-ink/15 text-ink transition-colors hover:bg-sand-deep focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral"
                      >
                        <Minus size={13} aria-hidden="true" />
                      </button>
                      <span
                        aria-live="polite"
                        className="min-w-6 text-center text-sm tabular-nums text-ink"
                      >
                        {line.qty}
                      </span>
                      <button
                        type="button"
                        onClick={() => setQty(line.product.id, line.qty + 1)}
                        aria-label={`Increase quantity of ${line.product.name}`}
                        className="flex h-7 w-7 items-center justify-center rounded-full border border-ink/15 text-ink transition-colors hover:bg-sand-deep focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral"
                      >
                        <Plus size={13} aria-hidden="true" />
                      </button>

                      <button
                        type="button"
                        onClick={() => removeItem(line.product.id)}
                        aria-label={`Remove ${line.product.name} from bag`}
                        className="ml-2 flex items-center gap-1 text-xs text-ink-soft underline decoration-coral decoration-2 underline-offset-4 transition-colors hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral"
                      >
                        <Trash2 size={13} aria-hidden="true" />
                        Remove
                      </button>
                    </div>
                  </div>

                  <p className="text-sm font-semibold tabular-nums text-ink">
                    ${line.product.price * line.qty}
                  </p>
                </li>
              ))}
            </ul>

            <div className="border-t border-ink/10 px-6 py-5">
              <div className="flex items-center justify-between text-sm text-ink">
                <span className="font-semibold">Subtotal</span>
                <span className="font-semibold tabular-nums" data-testid="cart-subtotal">
                  ${subtotal}
                </span>
              </div>
              <p className="mt-1 text-xs text-ink-soft">Shipping and taxes calculated at checkout.</p>

              <button
                type="button"
                onClick={() => setCheckoutNote(true)}
                className="mt-4 w-full rounded-full bg-forest px-6 py-3 text-sm font-semibold text-sand transition-colors hover:bg-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral"
              >
                Checkout — ${subtotal}
              </button>

              {checkoutNote && (
                <p role="status" className="mt-3 rounded-xl bg-sand-deep px-4 py-3 text-xs leading-relaxed text-ink">
                  Demo storefront: no payment was taken and no order was created. Connect your
                  own checkout provider (Stripe, Shopify, or your backend) to complete real
                  purchases.
                </p>
              )}

              <button
                type="button"
                onClick={clear}
                className="mt-3 w-full text-xs text-ink-soft underline decoration-coral decoration-2 underline-offset-4 transition-colors hover:text-ink focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral"
              >
                Empty bag
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
