import { categories } from "@/lib/data";
import { Reveal } from "@/components/reveal";
import { ArrowUpRight } from "lucide-react";

const tints = ["bg-sand-deep", "bg-[#e9e0cf]", "bg-[#e3ded1]", "bg-[#efe3ce]"];

export function CategoryGrid() {
  return (
    <section id="categories" className="mx-auto max-w-7xl px-6 py-20">
      <Reveal>
        <div className="flex items-end justify-between">
          <div>
            <p className="label-eyebrow text-coral-deep">Shop by kind</p>
            <h2 className="font-display mt-3 text-3xl text-ink md:text-4xl">
              Four shelves, one workshop
            </h2>
          </div>
        </div>
      </Reveal>

      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {categories.map((category, i) => (
          <Reveal key={category.slug} delay={i * 0.08}>
            <a
              href="#featured"
              className={`group block rounded-2xl ${tints[i % tints.length]} p-6 transition-transform hover:-translate-y-1`}
            >
              <div className="flex items-start justify-between">
                <span className="font-display text-2xl text-ink">
                  {category.name}
                </span>
                <ArrowUpRight
                  size={18}
                  className="text-ink-soft transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                />
              </div>
              <p className="mt-3 text-sm leading-relaxed text-ink-soft">
                {category.description}
              </p>
              <p className="mt-5 text-xs font-semibold uppercase tracking-wide text-ink-soft">
                {category.count} pieces
              </p>
            </a>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
