"use client";

import { useCart, type CartProduct } from "@/lib/cart";

export function AddToBag({
  product,
  variant = "solid",
  className = "",
}: {
  product: CartProduct;
  variant?: "solid" | "ghost";
  className?: string;
}) {
  const { addItem, lastAddedId } = useCart();
  const justAdded = lastAddedId === product.id;

  const base =
    "rounded-full text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-coral";
  const styles =
    variant === "solid"
      ? "bg-coral px-3.5 py-1.5 text-sand hover:bg-coral-deep"
      : "border border-ink/15 px-3 py-1.5 text-ink hover:bg-sand-deep";

  return (
    <button
      type="button"
      onClick={() => addItem(product)}
      aria-label={`Add ${product.name} to bag`}
      className={`${base} ${styles} ${className}`}
    >
      {justAdded ? "Added ✓" : "Add to Bag"}
    </button>
  );
}
