import type { Product } from "@/lib/data";
import { assetPath } from "@/lib/base-path";

const badgeStyles: Record<string, string> = {
  New: "bg-forest text-sand",
  Sale: "bg-coral text-sand",
};

function CardBackdrop() {
  return (
    <>
      <defs>
        <radialGradient id="cardBg" cx="50%" cy="38%" r="75%">
          <stop offset="0%" stopColor="#f6ecd9" />
          <stop offset="100%" stopColor="#ecdcc0" />
        </radialGradient>
      </defs>
      <rect width="200" height="200" fill="url(#cardBg)" />
      <ellipse cx="100" cy="150" rx="54" ry="8" fill="#2a2420" opacity="0.06" />
    </>
  );
}

function ProductIllustration({ category }: { category: string }) {
  if (category === "Necklaces") {
    return (
      <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full transition-transform duration-500 group-hover:scale-105" aria-hidden="true">
        <CardBackdrop />
        <path
          d="M64 54 C 60 92, 66 118, 100 122 C 134 118, 140 92, 136 54"
          fill="none"
          stroke="#b8933e"
          strokeWidth="1.6"
          strokeLinecap="round"
        />
        <path
          d="M65 55 C 61 91, 67 116, 100 120"
          fill="none"
          stroke="#2a2420"
          strokeWidth="0.5"
          opacity="0.25"
        />
        <path d="M92 118 L100 134 L108 118 Z" fill="#e17a57" />
        <circle cx="100" cy="140" r="4.5" fill="#b8933e" />
      </svg>
    );
  }

  if (category === "Ceramics") {
    return (
      <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full transition-transform duration-500 group-hover:scale-105" aria-hidden="true">
        <CardBackdrop />
        <path
          d="M79 62 C 77 60, 123 60, 121 62 L 126 84 C 132 100, 130 132, 116 148 C 106 156, 94 156, 84 148 C 70 132, 68 100, 74 84 Z"
          fill="none"
          stroke="#2e4b3b"
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
        <path
          d="M77 90 C 84 96, 116 96, 123 90"
          fill="none"
          stroke="#2e4b3b"
          strokeWidth="1"
          opacity="0.4"
        />
        <ellipse cx="100" cy="61" rx="21" ry="5" fill="none" stroke="#b8933e" strokeWidth="1.6" />
      </svg>
    );
  }

  if (category === "Candles & Scent") {
    return (
      <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full transition-transform duration-500 group-hover:scale-105" aria-hidden="true">
        <CardBackdrop />
        <path
          d="M80 84 L82 148 C 82 154, 118 154, 118 148 L120 84"
          fill="none"
          stroke="#c85f3d"
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
        <path d="M80 84 C 80 80, 120 80, 120 84 C 120 88, 80 88, 80 84 Z" fill="none" stroke="#c85f3d" strokeWidth="1.4" />
        <path
          d="M100 50 C 94 62, 106 68, 100 78 C 94 68, 106 62, 100 50 Z"
          fill="#b8933e"
        />
        <line x1="100" y1="78" x2="100" y2="84" stroke="#2a2420" strokeWidth="1" opacity="0.4" />
      </svg>
    );
  }

  return (
    <svg viewBox="0 0 200 200" className="absolute inset-0 h-full w-full transition-transform duration-500 group-hover:scale-105" aria-hidden="true">
      <CardBackdrop />
      <ellipse cx="100" cy="112" rx="30" ry="26" fill="none" stroke="#b8933e" strokeWidth="6" />
      <ellipse cx="100" cy="112" rx="30" ry="26" fill="none" stroke="#2a2420" strokeWidth="0.5" opacity="0.2" />
      <path d="M88 76 L100 58 L112 76 Z" fill="none" stroke="#2a2420" strokeWidth="1.3" strokeLinejoin="round" />
      <path d="M91 76 L100 63 L109 76 Z" fill="#e17a57" opacity="0.9" />
    </svg>
  );
}

export function ProductCard({ product }: { product: Product }) {
  return (
    <div className="group">
      <div className="relative aspect-square overflow-hidden rounded-2xl bg-sand-deep">
        {product.image ? (
          <img
            src={assetPath(product.image)}
            alt={product.name}
            className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <ProductIllustration category={product.category} />
        )}

        {product.badge && (
          <span
            className={`absolute left-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-semibold ${badgeStyles[product.badge] ?? "bg-ink text-sand"}`}
          >
            {product.badge}
          </span>
        )}
      </div>

      <div className="mt-3.5 flex items-start justify-between gap-2">
        <div>
          <p className="text-sm font-semibold text-ink">{product.name}</p>
          <p className="mt-0.5 text-xs text-ink-soft">{product.material}</p>
        </div>
        <div className="whitespace-nowrap text-right">
          <span className="text-sm font-semibold text-ink">
            ${product.price}
          </span>
          {product.compareAt && (
            <span className="ml-1.5 text-xs text-ink-soft line-through">
              ${product.compareAt}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
