import { reviews } from "@/lib/data";
import { Reveal } from "@/components/reveal";
import { Star } from "lucide-react";

export function Reviews() {
  return (
    <section id="reviews" className="bg-forest py-20 text-sand">
      <div className="mx-auto max-w-7xl px-6">
        <Reveal>
          <p className="label-eyebrow text-sand/60">From the mailbox</p>
          <h2 className="font-display mt-3 text-3xl md:text-4xl">
            What people keep telling us
          </h2>
        </Reveal>

        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {reviews.map((review, i) => (
            <Reveal key={review.id} delay={i * 0.08}>
              <figure className="h-full rounded-2xl bg-sand/10 p-6">
                <div className="flex gap-0.5 text-gold">
                  {Array.from({ length: 5 }).map((_, star) => (
                    <Star
                      key={star}
                      size={15}
                      fill={star < review.rating ? "currentColor" : "none"}
                      strokeWidth={1.5}
                    />
                  ))}
                </div>
                <blockquote className="mt-4 text-sm leading-relaxed text-sand/90">
                  "{review.quote}"
                </blockquote>
                <figcaption className="mt-5 text-xs font-semibold uppercase tracking-wide text-sand/60">
                  {review.name} · {review.location}
                  <span className="mt-0.5 block text-sand/45">
                    on {review.product}
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
