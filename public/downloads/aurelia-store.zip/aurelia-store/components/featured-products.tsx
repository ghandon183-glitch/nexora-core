import { products } from "@/lib/data";
import { ProductCard } from "@/components/product-card";
import { Reveal } from "@/components/reveal";

export function FeaturedProducts() {
  return (
    <section id="featured" className="bg-sand-deep/60 py-20">
      <div className="mx-auto max-w-7xl px-6">
        <Reveal>
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="label-eyebrow text-coral-deep">Just landed</p>
              <h2 className="font-display mt-3 text-3xl text-ink md:text-4xl">
                New this month
              </h2>
            </div>
            <a
              href="#"
              className="text-sm font-semibold text-ink underline decoration-coral decoration-2 underline-offset-4"
            >
              View all pieces
            </a>
          </div>
        </Reveal>

        <div className="mt-10 grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-4">
          {products.map((product, i) => (
            <Reveal key={product.id} delay={(i % 4) * 0.06}>
              <ProductCard product={product} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
