import type { ReactNode } from "react";
import Link from "next/link";
import { Nav } from "@/components/nav";
import { Footer } from "@/components/footer";
import { Reveal } from "@/components/reveal";

export function Subpage({
  eyebrow,
  title,
  intro,
  sample = true,
  children,
}: {
  eyebrow: string;
  title: string;
  intro?: string;
  sample?: boolean;
  children: ReactNode;
}) {
  return (
    <>
      <Nav />
      <main className="mx-auto max-w-3xl px-6 py-16 md:py-24">
        <Reveal>
          <nav aria-label="Breadcrumb" className="text-xs text-ink-soft">
            <Link
              href="/"
              className="underline decoration-coral decoration-2 underline-offset-4 hover:text-ink"
            >
              Home
            </Link>
            <span aria-hidden="true"> / </span>
            <span aria-current="page">{title}</span>
          </nav>

          <p className="label-eyebrow mt-8 text-coral-text">{eyebrow}</p>
          <h1 className="font-display mt-3 text-4xl leading-tight text-ink md:text-5xl">
            {title}
          </h1>
          {intro && (
            <p className="mt-5 text-base leading-relaxed text-ink-soft">{intro}</p>
          )}

          {sample && (
            <p className="mt-8 rounded-2xl border border-coral/40 bg-sand-deep px-5 py-4 text-xs leading-relaxed text-ink">
              <strong className="font-semibold">Sample template content.</strong>{" "}
              This page exists so every footer link has a real destination.
              Replace the copy with your own before publishing — it has not been
              reviewed by a lawyer and is not legal advice.
            </p>
          )}
        </Reveal>

        <div className="mt-10 space-y-9 text-sm leading-relaxed text-ink-soft">
          {children}
        </div>
      </main>
      <Footer />
    </>
  );
}
