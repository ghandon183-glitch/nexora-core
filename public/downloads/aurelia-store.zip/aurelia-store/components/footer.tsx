const columns = [
  {
    title: "Shop",
    links: ["Rings", "Necklaces", "Ceramics", "Candles & Scent"],
  },
  {
    title: "Studio",
    links: ["Our process", "Materials", "Journal", "Wholesale"],
  },
  {
    title: "Support",
    links: ["Shipping", "Returns", "Care guide", "Contact"],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-ink/10 bg-sand">
      <div className="mx-auto max-w-7xl px-6 py-16">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <span className="font-display text-2xl text-ink">Aurelia</span>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-ink-soft">
              A small workshop casting rings and chains, and glazing vessels,
              one batch at a time.
            </p>
          </div>

          {columns.map((column) => (
            <div key={column.title}>
              <p className="text-sm font-semibold text-ink">{column.title}</p>
              <ul className="mt-4 space-y-2.5">
                {column.links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-sm text-ink-soft transition-colors hover:text-ink"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-ink/10 pt-6 text-xs text-ink-soft sm:flex-row sm:items-center sm:justify-between">
          <p>&copy; {new Date().getFullYear()} Aurelia Studio. All rights reserved.</p>
          <div className="flex gap-5">
            <a href="#" className="hover:text-ink">
              Privacy
            </a>
            <a href="#" className="hover:text-ink">
              Terms
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
