"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";

export function Hero() {
  const tagRef = useRef<HTMLDivElement>(null);
  const stringRef = useRef<SVGPathElement>(null);

  useEffect(() => {
    const reduceMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;
    if (reduceMotion || !tagRef.current) return;

    const ctx = gsap.context(() => {
      // Signature moment: the tag swings in and settles, like a real
      // price tag looped onto the piece — not a generic fade/slide.
      const tl = gsap.timeline({ delay: 0.3 });

      tl.fromTo(
        tagRef.current,
        { opacity: 0, y: -26, rotate: -14, transformOrigin: "top center" },
        {
          opacity: 1,
          y: 0,
          rotate: -14,
          duration: 0.01,
        },
      ).to(tagRef.current, {
        rotate: 3,
        duration: 1.1,
        ease: "elastic.out(1, 0.45)",
      });

      // A slow, near-imperceptible idle sway so it never fully rests,
      // as though it's hanging in still air.
      gsap.to(tagRef.current, {
        rotate: "+=2.4",
        duration: 3.4,
        ease: "sine.inOut",
        yoyo: true,
        repeat: -1,
        delay: 1.6,
      });
    });

    return () => ctx.revert();
  }, []);

  return (
    <section className="relative overflow-hidden">
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-6 py-16 md:grid-cols-2 md:py-24">
        <div>
          <p className="label-eyebrow text-coral-deep">Autumn Collection, 2026</p>
          <h1 className="font-display mt-5 text-5xl leading-[1.08] text-ink md:text-6xl">
            Small objects,
            <br />
            <span className="italic text-forest">held onto</span> for years.
          </h1>
          <p className="mt-6 max-w-md text-base leading-relaxed text-ink-soft">
            Aurelia casts, glazes, and pours each piece in small batches —
            rings and chains in recycled metal, vessels finished by hand. Made
            to be worn daily, not saved for an occasion.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a
              href="#categories"
              className="rounded-full bg-forest px-7 py-3.5 text-sm font-semibold text-sand transition-colors hover:bg-ink"
            >
              Shop the collection
            </a>
            <a
              href="#featured"
              className="text-sm font-semibold text-ink underline decoration-coral decoration-2 underline-offset-4"
            >
              See what's new
            </a>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-sm md:max-w-none">
          <div className="relative aspect-[4/5] w-full overflow-hidden rounded-[28px] bg-gradient-to-br from-sand-deep via-[#eee0c8] to-[#e7d3ae]">
            <svg
              viewBox="0 0 400 500"
              className="absolute inset-0 h-full w-full"
              aria-hidden="true"
            >
              <ellipse cx="200" cy="360" rx="130" ry="16" fill="#2a2420" opacity="0.07" />

              {/* Faceted stone, sketched in the same hand as the product cards */}
              <path
                d="M200 210 L246 250 L228 320 L172 320 L154 250 Z"
                fill="none"
                stroke="#2a2420"
                strokeWidth="1"
                opacity="0.22"
              />
              <path
                d="M200 210 L246 250 L228 320 L172 320 L154 250 Z"
                fill="none"
                stroke="#b8933e"
                strokeWidth="2"
                strokeLinejoin="round"
              />
              <path d="M154 250 L246 250" stroke="#b8933e" strokeWidth="1" opacity="0.5" />
              <path d="M172 320 L200 250 L228 320" stroke="#b8933e" strokeWidth="1" opacity="0.5" fill="none" />
              <path d="M200 210 L200 250" stroke="#b8933e" strokeWidth="1" opacity="0.5" />

              {/* Band */}
              <path
                d="M150 320 C 150 372, 250 372, 250 320"
                fill="none"
                stroke="#b8933e"
                strokeWidth="7"
                strokeLinecap="round"
              />
              <path
                d="M152 322 C 152 368, 248 368, 248 322"
                fill="none"
                stroke="#2a2420"
                strokeWidth="0.5"
                opacity="0.18"
              />

              <circle cx="200" cy="230" r="3" fill="#e17a57" />
              <path
                d="M120 400 C 160 380, 240 380, 280 400"
                stroke="#2e4b3b"
                strokeWidth="1.4"
                fill="none"
                opacity="0.3"
              />
            </svg>

            {/* Thread the tag hangs from */}
            <svg
              className="absolute left-8 top-0 h-24 w-8 md:left-10"
              viewBox="0 0 40 100"
              aria-hidden="true"
            >
              <path
                ref={stringRef}
                d="M20 0 C 18 30, 22 45, 20 60"
                stroke="#2a2420"
                strokeWidth="1.5"
                fill="none"
                opacity="0.4"
              />
            </svg>

            <div
              ref={tagRef}
              className="absolute left-4 top-14 w-52 rounded-2xl border border-ink/10 bg-sand p-5 shadow-xl md:left-6"
              style={{ transformOrigin: "top center" }}
            >
              <p className="label-eyebrow text-ink-soft">Featured piece</p>
              <p className="font-display mt-1.5 text-lg text-ink">
                Meridian Signet
              </p>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-base font-semibold text-ink">$168</span>
                <button className="rounded-full bg-coral px-3.5 py-1.5 text-xs font-semibold text-sand transition-colors hover:bg-coral-deep">
                  Add to Bag
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
