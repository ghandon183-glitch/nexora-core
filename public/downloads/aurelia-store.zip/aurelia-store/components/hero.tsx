"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { assetPath } from "@/lib/base-path";

export function Hero() {
  const tagRef = useRef<HTMLDivElement>(null);
  const stringRef = useRef<SVGPathElement>(null);

  useEffect(() => {
    const reduceMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;
    if (reduceMotion || !tagRef.current) return;

    const ctx = gsap.context(() => {
      // Signature moment: the tag swings in and settles, like a real
      // price tag looped onto the piece — not a generic fade/slide.
      const tl = gsap.timeline({ delay: 0.3 });

      tl.fromTo(
        tagRef.current,
        { opacity: 0, y: -26, rotate: -14, transformOrigin: "top center" },
        {
          opacity: 1,
          y: 0,
          rotate: -14,
          duration: 0.01,
        },
      ).to(tagRef.current, {
        rotate: 3,
        duration: 1.1,
        ease: "elastic.out(1, 0.45)",
      });

      // A slow, near-imperceptible idle sway so it never fully rests,
      // as though it's hanging in still air.
      gsap.to(tagRef.current, {
        rotate: "+=2.4",
        duration: 3.4,
        ease: "sine.inOut",
        yoyo: true,
        repeat: -1,
        delay: 1.6,
      });
    });

    return () => ctx.revert();
  }, []);

  return (
    <section className="relative overflow-hidden">
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-6 py-16 md:grid-cols-2 md:py-24">
        <div>
          <p className="label-eyebrow text-coral-deep">Autumn Collection, 2026</p>
          <h1 className="font-display mt-5 text-5xl leading-[1.08] text-ink md:text-6xl">
            Small objects,
            <br />
            <span className="italic text-forest">held onto</span> for years.
          </h1>
          <p className="mt-6 max-w-md text-base leading-relaxed text-ink-soft">
            Aurelia casts, glazes, and pours each piece in small batches —
            rings and chains in recycled metal, vessels finished by hand. Made
            to be worn daily, not saved for an occasion.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a
              href="#categories"
              className="rounded-full bg-forest px-7 py-3.5 text-sm font-semibold text-sand transition-colors hover:bg-ink"
            >
              Shop the collection
            </a>
            <a
              href="#featured"
              className="text-sm font-semibold text-ink underline decoration-coral decoration-2 underline-offset-4"
            >
              See what's new
            </a>
          </div>
        </div>

        <div className="relative mx-auto w-full max-w-sm md:max-w-none">
          <div className="relative aspect-[4/5] w-full overflow-hidden rounded-[28px] bg-gradient-to-br from-sand-deep via-[#eee0c8] to-[#e7d3ae]">
            <img
              src={assetPath("/images/ring-bee.jpg")}
              alt="Meridian Signet ring on natural linen"
              className="absolute inset-0 h-full w-full object-cover"
            />

            {/* Thread the tag hangs from */}
            <svg
              className="absolute left-8 top-0 h-24 w-8 md:left-10"
              viewBox="0 0 40 100"
              aria-hidden="true"
            >
              <path
                ref={stringRef}
                d="M20 0 C 18 30, 22 45, 20 60"
                stroke="#2a2420"
                strokeWidth="1.5"
                fill="none"
                opacity="0.4"
              />
            </svg>

            <div
              ref={tagRef}
              className="absolute left-4 top-14 w-52 rounded-2xl border border-ink/10 bg-sand p-5 shadow-xl md:left-6"
              style={{ transformOrigin: "top center" }}
            >
              <p className="label-eyebrow text-ink-soft">Featured piece</p>
              <p className="font-display mt-1.5 text-lg text-ink">
                Meridian Signet
              </p>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-base font-semibold text-ink">$168</span>
                <button className="rounded-full bg-coral px-3.5 py-1.5 text-xs font-semibold text-sand transition-colors hover:bg-coral-deep">
                  Add to Bag
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
