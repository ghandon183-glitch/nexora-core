"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X, Search, ShoppingBag } from "lucide-react";
import { useCart } from "@/lib/cart";

const links = [
  { label: "Rings", href: "/shop/rings" },
  { label: "Necklaces", href: "/shop/necklaces" },
  { label: "Ceramics", href: "/shop/ceramics" },
  { label: "Journal", href: "/journal" },
];

export function Nav() {
  const [open, setOpen] = useState(false);
  const { count, openCart } = useCart();

  return (
    <header className="sticky top-0 z-50 border-b border-ink/10 bg-sand/90 backdrop-blur">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">
        <Link
          href="/"
          className="font-display text-2xl tracking-tight text-ink"
          aria-label="Aurelia — home"
        >
          Aurelia
        </Link>

        <nav className="hidden items-center gap-9 md:flex">
          {links.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className="text-sm font-medium text-ink-soft transition-colors hover:text-ink"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-5 md:flex">
          <Link
            href="/#featured"
            aria-label="Browse the collection"
            className="text-ink-soft transition-colors hover:text-ink"
          >
            <Search size={19} strokeWidth={1.75} aria-hidden="true" />
          </Link>
          <button
            type="button"
            onClick={openCart}
            aria-label={`Open bag, ${count} ${count === 1 ? "item" : "items"}`}
            className="flex items-center gap-2 text-ink-soft transition-colors hover:text-ink"
          >
            <ShoppingBag size={19} strokeWidth={1.75} aria-hidden="true" />
            <span className="text-sm font-medium" aria-live="polite">
              {count}
            </span>
          </button>
        </div>

        <button
          className="md:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div id="mobile-menu" className="border-t border-ink/10 px-6 pb-6 md:hidden">
          <nav className="flex flex-col gap-4 pt-4">
            {links.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                onClick={() => setOpen(false)}
                className="text-sm font-medium text-ink-soft"
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="mt-5 flex items-center gap-6 border-t border-ink/10 pt-5">
            <Link
              href="/#featured"
              onClick={() => setOpen(false)}
              aria-label="Browse the collection"
              className="flex items-center gap-2 text-sm font-medium text-ink-soft"
            >
              <Search size={18} strokeWidth={1.75} aria-hidden="true" /> Browse
            </Link>
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                openCart();
              }}
              aria-label={`Open bag, ${count} ${count === 1 ? "item" : "items"}`}
              className="flex items-center gap-2 text-sm font-medium text-ink-soft"
            >
              <ShoppingBag size={18} strokeWidth={1.75} aria-hidden="true" /> Bag ({count})
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
