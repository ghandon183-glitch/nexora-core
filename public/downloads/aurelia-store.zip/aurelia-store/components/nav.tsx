"use client";

import { useState } from "react";
import { Menu, X, Search, ShoppingBag } from "lucide-react";

const links = [
  { label: "Rings", href: "#categories" },
  { label: "Necklaces", href: "#categories" },
  { label: "Ceramics", href: "#categories" },
  { label: "Journal", href: "#reviews" },
];

export function Nav() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-ink/10 bg-sand/90 backdrop-blur">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">
        <a href="#" className="font-display text-2xl tracking-tight text-ink">
          Aurelia
        </a>

        <nav className="hidden items-center gap-9 md:flex">
          {links.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm font-medium text-ink-soft transition-colors hover:text-ink"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-5 md:flex">
          <button
            aria-label="Search products"
            className="text-ink-soft transition-colors hover:text-ink"
          >
            <Search size={19} strokeWidth={1.75} />
          </button>
          <button
            aria-label="Open bag, 0 items"
            className="flex items-center gap-2 text-ink-soft transition-colors hover:text-ink"
          >
            <ShoppingBag size={19} strokeWidth={1.75} />
            <span className="text-sm font-medium">0</span>
          </button>
        </div>

        <button
          className="md:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="border-t border-ink/10 px-6 pb-6 md:hidden">
          <nav className="flex flex-col gap-4 pt-4">
            {links.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setOpen(false)}
                className="text-sm font-medium text-ink-soft"
              >
                {link.label}
              </a>
            ))}
          </nav>
          <div className="mt-5 flex items-center gap-6 border-t border-ink/10 pt-5">
            <button
              aria-label="Search products"
              className="flex items-center gap-2 text-sm font-medium text-ink-soft"
            >
              <Search size={18} strokeWidth={1.75} /> Search
            </button>
            <button
              aria-label="Open bag, 0 items"
              className="flex items-center gap-2 text-sm font-medium text-ink-soft"
            >
              <ShoppingBag size={18} strokeWidth={1.75} /> Bag (0)
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
