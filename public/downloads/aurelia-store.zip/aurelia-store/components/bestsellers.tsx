import { bestsellers } from "@/lib/data";
import { ProductCard } from "@/components/product-card";
import { Reveal } from "@/components/reveal";

export function Bestsellers() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-20">
      <Reveal>
        <p className="label-eyebrow text-coral-deep">Reordered the most</p>
        <h2 className="font-display mt-3 text-3xl text-ink md:text-4xl">
          Four we always restock
        </h2>
      </Reveal>

      <div className="mt-10 grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-4">
        {bestsellers.map((product, i) => (
          <Reveal key={product.id} delay={i * 0.06}>
            <ProductCard product={product} />
          </Reveal>
        ))}
      </div>
    </section>
  );
}
