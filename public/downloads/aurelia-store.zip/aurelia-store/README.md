# Aurelia — Boutique Storefront Template

Thanks for purchasing Aurelia! This is a complete, standalone Next.js 16
project for a boutique e-commerce storefront (jewelry, ceramics, home
objects).

## Stack

- Next.js 16 (App Router) + TypeScript
- Tailwind CSS v4
- Framer Motion (scroll reveals)
- GSAP (hero signature animation)
- Self-hosted fonts via @fontsource (Playfair Display, Manrope) — no external
  font requests at build or runtime

## Getting started

Requires Node.js 20+ and npm 10+.

```bash
npm ci
npm run dev
```

Open http://localhost:3000.

## Project structure

- `app/page.tsx` — assembles all homepage sections
- `components/` — Nav, Hero, CategoryGrid, FeaturedProducts, Bestsellers,
  Reviews, Newsletter, Footer, and a shared ProductCard / Reveal helper
- `lib/data.ts` — product, category, and review content — edit this to swap
  in your own catalog
- `app/globals.css` — color and type tokens (`--sand`, `--coral`, `--forest`,
  `--gold`, `--font-display`, `--font-body`)

## Environment variables

A single optional variable is read at build time:

- `NEXT_PUBLIC_BASE_PATH` — prefix for files under `/public` (images) and the
  Next.js `basePath`, used when the storefront is served from a sub-path such as
  `/demo/aurelia-store`. Leave it empty for a normal domain-root deployment.

Copy `.env.example` to `.env.local` and fill it in if you need it. No other
environment variables, API keys, or services are required.

## Customizing

- Swap the SVG product illustrations in `components/product-card.tsx` and
  `components/hero.tsx` for real product photography whenever you have it —
  they were built as placeholders that don't require any external image
  service.
- Product data lives entirely in `lib/data.ts`.

## Building for production

```bash
npm run build
```

The build produces a fully static site in `out/` (the template uses
`output: "export"`), so it can be hosted on any static host — Cloudflare Pages,
Netlify, S3, or a plain web server. Preview that output locally with:

```bash
npx serve out
```

If you build with `NEXT_PUBLIC_BASE_PATH` set, run `npx serve` from the same
sub-path layout the site will be deployed to so the asset URLs resolve.

## Storefront behaviour

The bag, quantity controls, and checkout button are a self-contained demo:
checkout explains that no payment is taken. Connect your own commerce backend
(Stripe, Shopify, or your API) in `lib/cart.tsx` and `components/cart-drawer.tsx`
before taking real orders.

## Support

If you run into an issue with the template, reach out via the support
channel listed on your purchase receipt.
