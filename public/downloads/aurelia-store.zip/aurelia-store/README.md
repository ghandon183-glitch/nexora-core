# Aurelia — Boutique Storefront Template

Thanks for purchasing Aurelia! This is a complete, standalone Next.js 16
project for a boutique e-commerce storefront (jewelry, ceramics, home
objects).

## Stack

- Next.js 16 (App Router) + TypeScript
- Tailwind CSS v4
- Framer Motion (scroll reveals)
- GSAP (hero signature animation)
- Self-hosted fonts via @fontsource (Playfair Display, Manrope) — no external
  font requests at build or runtime
- Static export (`output: "export"`) — deploy the generated `out/` folder to
  any static host

## Prerequisites

- Node.js **20 or newer** (tested on Node 20 and 26)
- npm 10 or newer (ships with Node 20)
- No database, API keys, or third-party accounts are required to run the demo

## Getting started

```bash
npm ci
npm run dev
```

Open http://localhost:3000.

`npm ci` installs the exact versions in `package-lock.json`. Use
`npm install` only when you intentionally add or upgrade a dependency.

## Project structure

- `app/page.tsx` — assembles the homepage sections
- `app/shop/[category]/page.tsx` — static category pages for the four shelves
- `app/[slug]/page.tsx` — the supporting pages linked from the footer
  (shipping, returns, care guide, contact, studio pages, privacy, terms)
- `components/` — Nav, Hero, CategoryGrid, FeaturedProducts, Bestsellers,
  Reviews, Newsletter, Footer, Subpage, and the shared ProductCard / Reveal
  helpers
- `lib/data.ts` — product, category, and review content — edit this to swap in
  your own catalog
- `lib/cart.tsx` — the demo shopping bag (context + localStorage)
- `lib/pages.ts` — copy for every page linked from the footer
- `app/globals.css` — color and type tokens (`--sand`, `--coral`, `--forest`,
  `--gold`, `--font-display`, `--font-body`)

## Routes

| Route | Purpose |
| --- | --- |
| `/` | Homepage: hero, categories, new arrivals, bestsellers, reviews, newsletter |
| `/shop/rings`, `/shop/necklaces`, `/shop/ceramics`, `/shop/candles-and-scent` | Category listings generated from `lib/data.ts` |
| `/shipping`, `/returns`, `/care-guide`, `/contact` | Support pages |
| `/our-process`, `/materials`, `/journal`, `/wholesale` | Studio pages |
| `/privacy`, `/terms` | Policy pages |

Every page except the homepage is generated from the content in `lib/pages.ts`
and is rewritten by the buyer. Replace the sample copy before publishing; it is
not legal advice and has not been reviewed by a lawyer.

## Environment variables

A single optional variable is read at build time:

- `NEXT_PUBLIC_BASE_PATH` — prefix for files under `/public` (images) and the
  Next.js `basePath`, used when the storefront is served from a sub-path such as
  `/demo/aurelia-store`. Leave it empty for a normal domain-root deployment.

Copy `.env.example` to `.env.local` and fill it in if you need it. No other
environment variables, API keys, or services are required.

## Building for production

```bash
npm run build
```

The build produces a fully static site in `out/`. Preview it locally with:

```bash
npx serve out
```

The `npm run start` script that scaffolding tools add is **not** used by this
template: a static export has no Node server. If you build with
`NEXT_PUBLIC_BASE_PATH` set, serve `out/` from the matching sub-path layout so
image and asset URLs resolve.

### Deploying

Upload the contents of `out/` to any static host — Cloudflare Pages, Netlify,
Vercel (as a static project), GitHub Pages, S3 + CloudFront, or a plain web
server. There is no server runtime, database, or environment configuration
beyond the optional base path above.

## Demo behaviour (read before selling)

Two storefront features are intentionally demos with no backend:

### Shopping bag and checkout

The bag, quantity controls, empty-bag action, and checkout button are a
self-contained client-side demo. The bag is stored in the visitor's own browser
(`localStorage` key `aurelia-cart-v1`) and never leaves the device. Pressing
**Checkout** shows a message stating that no payment was taken and no order was
created — there is no payment simulation and no success state.

To take real orders, connect a commerce backend in `lib/cart.tsx` and
`components/cart-drawer.tsx` (for example Stripe Checkout, Shopify's Storefront
API, or your own API) and replace the demo note with a redirect to that
provider's checkout.

### Newsletter

The newsletter form validates the address, then shows a clearly labelled demo
message: **nothing is sent or stored**. No email address is written to
localStorage or transmitted anywhere.

To collect real sign-ups, connect a provider in `components/newsletter.tsx`.
Two common patterns:

1. **Hosted form endpoint** — create a form in your provider (Buttondown,
   Mailchimp, ConvertKit, Beehiiv, Loops) and either use its hosted form action
   or POST the address to its endpoint with `fetch` in `handleSubmit`, replacing
   the demo message with the provider's success/error state.
2. **Your own API route** — if you move off static export, add a route handler
   that calls the provider's API with a server-side key, and keep the key in an
   environment variable that is not prefixed with `NEXT_PUBLIC_`.

Until one of those is wired up, keep the demo message visible: it tells visitors
honestly that their address is not being saved.

## Customizing

- Product data lives entirely in `lib/data.ts`; each product's `category` must
  match one of the names in `categories` for it to appear on that shelf.
- Swap the SVG product illustrations in `components/product-card.tsx` for real
  photography by adding the image path to the product's `image` field.
- Footer and support page copy lives in `lib/pages.ts`; the footer link list is
  in `components/footer.tsx`.
- Colors and fonts are CSS custom properties in `app/globals.css`.

## Accessibility notes

- All interactive controls are native buttons, links, or inputs with visible
  focus rings.
- The cart drawer is a labelled modal dialog that closes on Escape and restores
  focus to the page.
- Scroll reveals respect `prefers-reduced-motion`.
- Decorative SVG illustrations are marked `aria-hidden`.

## Troubleshooting

- **Images 404 after deploying to a sub-path** — build with
  `NEXT_PUBLIC_BASE_PATH` set to that sub-path.
- **`npm ci` fails** — make sure you are on Node 20+ and that
  `package-lock.json` was not edited by hand.
- **Blank page on a static host** — serve `out/` itself, not the project root,
  and make sure the host serves `index.html` for directory requests.

## Support

If you run into an issue with the template, reach out via the support channel
listed on your purchase receipt. `SUPPORT.md` in the package root summarises
what is included, and `LICENSE.md` covers usage terms.
