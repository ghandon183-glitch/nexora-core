# Aurelia — Boutique Storefront Template

Thanks for purchasing Aurelia! This is a complete, standalone Next.js 16
project for a boutique e-commerce storefront (jewelry, ceramics, home
objects).

## Stack

- Next.js 16 (App Router) + TypeScript
- Tailwind CSS v4
- Framer Motion (scroll reveals)
- GSAP (hero signature animation)
- Self-hosted fonts via @fontsource (Playfair Display, Manrope) — no external
  font requests at build or runtime

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Project structure

- `app/page.tsx` — assembles all homepage sections
- `components/` — Nav, Hero, CategoryGrid, FeaturedProducts, Bestsellers,
  Reviews, Newsletter, Footer, and a shared ProductCard / Reveal helper
- `lib/data.ts` — product, category, and review content — edit this to swap
  in your own catalog
- `app/globals.css` — color and type tokens (`--sand`, `--coral`, `--forest`,
  `--gold`, `--font-display`, `--font-body`)

## Customizing

- Swap the SVG product illustrations in `components/product-card.tsx` and
  `components/hero.tsx` for real product photography whenever you have it —
  they were built as placeholders that don't require any external image
  service.
- Product data lives entirely in `lib/data.ts`.

## Building for production

```bash
npm run build
npm run start
```

## Support

If you run into an issue with the template, reach out via the support
channel listed on your purchase receipt.
