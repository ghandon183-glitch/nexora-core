/**
 * Copy for the supporting pages reachable from the site footer.
 *
 * All of this text is SAMPLE TEMPLATE CONTENT. It exists so every footer link
 * has a real destination instead of `href="#"`. Buyers must replace it with
 * their own policies before publishing — nothing here has been legally
 * reviewed.
 */

export type PageSection = {
  heading: string;
  body: string[];
};

export type PageDetail = {
  label: string;
  value: string;
  href?: string;
};

export type StaticPage = {
  eyebrow: string;
  title: string;
  intro: string;
  sections: PageSection[];
  details?: PageDetail[];
  sample?: boolean;
};

export const pages: Record<string, StaticPage> = {
  shipping: {
    eyebrow: "Support",
    title: "Shipping",
    intro:
      "Sample shipping policy for the demo storefront. Replace these windows, rates, and terms with the ones your studio actually offers.",
    sections: [
      {
        heading: "Dispatch windows",
        body: [
          "Sample text: in-stock pieces leave the studio within two business days. Made-to-order rings and engraved items are cast in the following batch and ship within ten business days.",
          "If an order mixes in-stock and made-to-order pieces, the whole order ships together unless you ask us to split it.",
        ],
      },
      {
        heading: "Rates and delivery",
        body: [
          "Sample text: standard domestic shipping is a flat $8 and arrives in three to five business days. Express shipping is $22 and arrives in one to two business days.",
          "International shipping is calculated at checkout by destination. Delivery times depend on the carrier and local customs.",
        ],
      },
      {
        heading: "Tracking",
        body: [
          "Sample text: a tracking link is emailed as soon as the label is created. If tracking has not moved for five business days, contact the studio and we will open a carrier claim.",
        ],
      },
      {
        heading: "Duties and taxes",
        body: [
          "Sample text: international orders may be charged import duties and taxes by the destination country. Those charges are the buyer's responsibility and are not collected by the studio.",
        ],
      },
    ],
  },
  returns: {
    eyebrow: "Support",
    title: "Returns",
    intro:
      "Sample returns policy. Replace the window, exclusions, and refund timing with your own before selling.",
    sections: [
      {
        heading: "Return window",
        body: [
          "Sample text: unused pieces can be returned within 14 days of delivery for a refund or exchange. The piece must be unworn, in its original packaging, and include the packing slip.",
        ],
      },
      {
        heading: "What cannot be returned",
        body: [
          "Sample text: engraved, resized, and made-to-order pieces are final sale, as are candles that have been burned and ceramics that show use.",
        ],
      },
      {
        heading: "Starting a return",
        body: [
          "Sample text: email the studio with the order number and the reason for the return. We reply with a return label and instructions within one business day.",
        ],
      },
      {
        heading: "Refunds",
        body: [
          "Sample text: refunds are issued to the original payment method within five business days of the piece arriving back at the studio. Original shipping charges are not refunded unless the item arrived damaged.",
        ],
      },
    ],
  },
  "care-guide": {
    eyebrow: "Support",
    title: "Care guide",
    intro:
      "Sample care instructions for the materials shown in this demo. Adjust them to match how your pieces are actually made.",
    sections: [
      {
        heading: "Sterling silver and gold vermeil",
        body: [
          "Sample text: remove rings before washing hands, swimming, or applying lotion. Wipe with the supplied polishing cloth after wear and store pieces dry, away from direct sunlight.",
          "Vermeil is a thick gold layer over sterling silver. Avoid abrasive polishes, which can wear the gold layer faster than normal use.",
        ],
      },
      {
        heading: "Ceramics",
        body: [
          "Sample text: the tableware is food safe and dishwasher safe on a low-heat cycle. Vases and sculptural pieces should be hand washed only.",
          "Unglazed feet can mark untreated wood — use a felt pad under vessels that will sit on furniture.",
        ],
      },
      {
        heading: "Candles",
        body: [
          "Sample text: trim the wick to 5 mm before each burn and let the wax melt to the edge of the vessel on the first burn. Never burn for more than four hours at a time, and never leave a candle unattended.",
        ],
      },
    ],
  },
  contact: {
    eyebrow: "Visit",
    title: "Contact",
    intro:
      "Sample contact details for the demo storefront. Replace the address, phone number, and hours with your own.",
    sections: [
      {
        heading: "Studio visits",
        body: [
          "Sample text: the workshop is open Tuesday to Saturday, 10:00–18:00. Ring the bell at the side entrance — the front door is the loading bay.",
          "Resizing and repairs are handled at the bench on weekday mornings; no appointment needed for a quote.",
        ],
      },
      {
        heading: "Wholesale and press",
        body: [
          "Sample text: for line sheets, press requests, or stockist enquiries, email the studio with a short note about your shop or publication and we will reply within two business days.",
        ],
      },
    ],
    details: [
      {
        label: "Email",
        value: "hello@aurelia.studio",
        href: "mailto:hello@aurelia.studio",
      },
      {
        label: "Phone",
        value: "(503) 555-0142",
        href: "tel:+15035550142",
      },
      {
        label: "Address",
        value: "218 Alder Lane, Portland, OR 97209",
      },
      {
        label: "Hours",
        value: "Tuesday–Saturday, 10:00–18:00",
      },
    ],
  },
  "our-process": {
    eyebrow: "Studio",
    title: "Our process",
    intro:
      "Sample studio story. Swap it for how your own pieces are actually made.",
    sections: [
      {
        heading: "Wax to metal",
        body: [
          "Sample text: every ring starts as a hand-carved wax model. The models are invested, burned out, and cast in recycled sterling silver or gold vermeil in a small casting house two streets from the studio.",
          "Castings come back rough. Each one is filed, emery-finished, and tumbled before it ever reaches the bench for setting.",
        ],
      },
      {
        heading: "Glazing days",
        body: [
          "Sample text: vessels are thrown on Thursdays and glazed on Mondays. Glazes are mixed in-house from ash, feldspar, and clay, then fired to cone 6 in a shared kiln.",
          "Because the glazes are mixed by hand, colour shifts slightly between batches. That variation is part of the object, not a defect.",
        ],
      },
      {
        heading: "Small batches",
        body: [
          "Sample text: nothing is produced in runs longer than forty pieces. When a batch sells out, the next one is scheduled rather than rushed.",
        ],
      },
    ],
  },
  materials: {
    eyebrow: "Studio",
    title: "Materials",
    intro:
      "Sample material notes for the demo catalogue. Confirm your own sourcing before publishing claims about recycled content.",
    sections: [
      {
        heading: "Recycled sterling silver",
        body: [
          "Sample text: chain, sheet, and casting grain are bought from a refiner that supplies certified recycled silver. Scrap from the bench is collected and sent back with the next order.",
        ],
      },
      {
        heading: "Gold vermeil",
        body: [
          "Sample text: vermeil is 14k gold, at least 2.5 microns thick, plated over sterling silver. It is not solid gold and will wear with years of daily use.",
        ],
      },
      {
        heading: "Stoneware and glazes",
        body: [
          "Sample text: vessels use a warm-bodied stoneware and food-safe glazes. Liners are tested for lead and cadmium release by the clay supplier.",
        ],
      },
      {
        heading: "Soy and beeswax",
        body: [
          "Sample text: candles are poured with a soy and beeswax blend, cotton wicks, and phthalate-free fragrance oils.",
        ],
      },
    ],
  },
  journal: {
    eyebrow: "Studio",
    title: "Journal",
    intro:
      "Sample studio notes. Replace them with your own updates, or point the footer at a blog you already run.",
    sections: [
      {
        heading: "Why the studio closes for a week in August",
        body: [
          "Sample text: the kiln needs new elements every couple of years, and the quiet week is when the bench gets re-leveled, the wax tools get sharpened, and every mold gets checked for wear.",
        ],
      },
      {
        heading: "A note on sizing rings you already own",
        body: [
          "Sample text: the most reliable measurement is an existing ring that fits the intended finger. Bring it in and we will measure the inner diameter on the mandrel rather than guessing from a printed chart.",
        ],
      },
      {
        heading: "Seconds, samples, and the pieces that stay",
        body: [
          "Sample text: pieces with a glaze run or a casting pit are sold once a season at the studio, priced by the flaw. They are structurally sound and carry the same repair promise as everything else.",
        ],
      },
    ],
  },
  wholesale: {
    eyebrow: "Studio",
    title: "Wholesale",
    intro:
      "Sample wholesale terms. Replace minimums and lead times with the ones your studio can actually meet.",
    sections: [
      {
        heading: "Minimums",
        body: [
          "Sample text: opening orders start at twelve pieces across rings, chains, and ceramics, with a maximum of four units per style.",
        ],
      },
      {
        heading: "Lead times",
        body: [
          "Sample text: stock styles ship in two weeks. Made-to-order chains and engraved signets take six to eight weeks, confirmed in writing before the order is accepted.",
        ],
      },
      {
        heading: "How to apply",
        body: [
          "Sample text: email the studio with your shop name, address, website, and the styles you are interested in. Line sheets and images are sent as a PDF.",
        ],
      },
    ],
  },
  privacy: {
    eyebrow: "Legal",
    title: "Privacy",
    intro:
      "Sample privacy notice for the demo storefront. It describes what this template actually does — it is not a legal policy and has not been reviewed by a lawyer.",
    sections: [
      {
        heading: "What this demo stores",
        body: [
          "Sample text: the template has no backend, no analytics, and no third-party trackers. The shopping bag is stored only in your own browser using localStorage under the key `aurelia-cart-v1`, and it never leaves your device.",
          "The newsletter form is a demo: it does not send or store the email address you type in.",
        ],
      },
      {
        heading: "What you must document when you launch",
        body: [
          "Sample text: once you connect a checkout provider, a newsletter provider, analytics, or a contact form, you become responsible for describing what those services collect, why, and how long they keep it.",
        ],
      },
      {
        heading: "Your choices",
        body: [
          "Sample text: you can clear the saved bag at any time with the \"Empty bag\" button in the cart, or by clearing site data in your browser.",
        ],
      },
    ],
  },
  terms: {
    eyebrow: "Legal",
    title: "Terms",
    intro:
      "Sample store terms for the demo. Replace them with terms reviewed for your business and jurisdiction.",
    sections: [
      {
        heading: "Orders",
        body: [
          "Sample text: an order is accepted when the studio sends a confirmation email. If a piece turns out to be unavailable, the order is cancelled and refunded in full.",
        ],
      },
      {
        heading: "Pricing",
        body: [
          "Sample text: prices are listed in US dollars and exclude shipping, duties, and taxes unless stated otherwise. Prices can change without notice; confirmed orders are not repriced.",
        ],
      },
      {
        heading: "Intellectual property",
        body: [
          "Sample text: the designs, photographs, and copy on this site belong to the studio and may not be reproduced without permission.",
        ],
      },
      {
        heading: "Liability",
        body: [
          "Sample text: the studio is not liable for indirect losses arising from the use of this site. Nothing in these terms limits rights you have under consumer law.",
        ],
      },
    ],
  },
};

export const pageSlugs = Object.keys(pages);
