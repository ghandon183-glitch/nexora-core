// Used to prefix references to files under /public (e.g. <img src>) so they
// still resolve correctly when this app is built with a non-root basePath
// (as our marketplace demo build does). Buyers running the template
// standalone won't set this env var, so it's an empty string for them and
// paths behave normally.
export const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || "";

export function assetPath(path: string): string {
  return `${BASE_PATH}${path}`;
}
