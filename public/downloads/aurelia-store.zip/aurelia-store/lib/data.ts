export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  compareAt?: number;
  material: string;
  badge?: string;
  image?: string;
}

export const categories = [
  {
    slug: "rings",
    name: "Rings",
    count: 24,
    description: "Signet, stacking, and stone-set bands cast in-house.",
  },
  {
    slug: "necklaces",
    name: "Necklaces",
    count: 31,
    description: "Chain lengths from choker to opera, sold by the inch.",
  },
  {
    slug: "ceramics",
    name: "Ceramics",
    count: 18,
    description: "Wheel-thrown vessels glazed in clay and ash tones.",
  },
  {
    slug: "candles-and-scent",
    name: "Candles & Scent",
    count: 14,
    description: "Soy and beeswax blends poured into reclaimed vessels.",
  },
];

export const products: Product[] = [
  {
    id: "p1",
    name: "Meridian Signet Ring",
    category: "Rings",
    price: 168,
    material: "14k gold vermeil",
    badge: "New",
    image: "/images/ring-bee.jpg",
  },
  {
    id: "p2",
    name: "Low Tide Hoop, Pair",
    category: "Rings",
    price: 96,
    material: "Recycled sterling silver",
    image: "/images/rings-pair.jpg",
  },
  {
    id: "p3",
    name: "Amber Drop Necklace",
    category: "Necklaces",
    price: 214,
    compareAt: 260,
    material: "Citrine, gold vermeil",
    badge: "Sale",
    image: "/images/necklace-heart.jpg",
  },
  {
    id: "p4",
    name: "Field Notes Chain, 18\"",
    category: "Necklaces",
    price: 128,
    material: "Sterling silver",
    image: "/images/chain-macro.jpg",
  },
  {
    id: "p5",
    name: "Ash-Glaze Table Vase",
    category: "Ceramics",
    price: 88,
    material: "Stoneware, ash glaze",
    image: "/images/vase-dried-flowers.jpg",
  },
  {
    id: "p6",
    name: "Dune Pillar Candle",
    category: "Candles & Scent",
    price: 42,
    material: "Soy wax, cedar & clay",
    badge: "New",
    image: "/images/candles-lit.jpg",
  },
  {
    id: "p7",
    name: "Terracotta Nesting Bowls",
    category: "Ceramics",
    price: 74,
    material: "Terracotta, food-safe glaze",
    image: "/images/ceramic-vases-colorful.jpg",
  },
  {
    id: "p8",
    name: "Solstice Cuff",
    category: "Rings",
    price: 142,
    material: "Brushed gold vermeil",
    image: "/images/ring-cluster.jpg",
  },
];

export const bestsellers = [products[2], products[0], products[5], products[4]];

export interface Review {
  id: string;
  name: string;
  location: string;
  rating: number;
  quote: string;
  product: string;
}

export const reviews: Review[] = [
  {
    id: "r1",
    name: "Marguerite S.",
    location: "Lisbon, PT",
    rating: 5,
    quote:
      "The signet ring is heavier than I expected in the best way. It reads handmade, not stamped out.",
    product: "Meridian Signet Ring",
  },
  {
    id: "r2",
    name: "Owen T.",
    location: "Austin, US",
    rating: 5,
    quote:
      "Bought the vase as a gift and kept it for myself. The glaze catches light differently every hour.",
    product: "Ash-Glaze Table Vase",
  },
  {
    id: "r3",
    name: "Priya N.",
    location: "Melbourne, AU",
    rating: 4,
    quote:
      "Packaging alone felt worth the price. The candle burns evenly and the scent isn't overpowering.",
    product: "Dune Pillar Candle",
  },
];
