"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
  useSyncExternalStore,
  type ReactNode,
} from "react";

export type CartProduct = {
  id: string;
  name: string;
  price: number;
  material: string;
};

export type CartLine = {
  product: CartProduct;
  qty: number;
};

type CartContextValue = {
  lines: CartLine[];
  count: number;
  subtotal: number;
  isOpen: boolean;
  lastAddedId: string | null;
  addItem: (product: CartProduct) => void;
  removeItem: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  openCart: () => void;
  closeCart: () => void;
};

const STORAGE_KEY = "aurelia-cart-v1";

/* --------------------------------------------------------------------------
 * The bag lives in a tiny external store so the prerendered HTML stays stable
 * and the saved bag is read after hydration without a setState-in-effect.
 * ------------------------------------------------------------------------ */

const EMPTY_LINES: CartLine[] = [];

let linesSnapshot: CartLine[] = EMPTY_LINES;
let storageRestored = false;
const listeners = new Set<() => void>();

function readStoredLines(): CartLine[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return EMPTY_LINES;

    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return EMPTY_LINES;

    const cleaned = parsed
      .filter((line): line is CartLine => {
        if (!line || typeof line !== "object") return false;
        const candidate = line as Partial<CartLine>;
        return (
          typeof candidate.qty === "number" &&
          candidate.qty > 0 &&
          !!candidate.product &&
          typeof candidate.product.id === "string" &&
          typeof candidate.product.name === "string" &&
          typeof candidate.product.price === "number"
        );
      })
      .map((line) => ({ product: line.product, qty: Math.min(99, Math.floor(line.qty)) }));

    return cleaned.length ? cleaned : EMPTY_LINES;
  } catch {
    return EMPTY_LINES;
  }
}

function subscribe(listener: () => void) {
  listeners.add(listener);

  return () => {
    listeners.delete(listener);
  };
}

function getSnapshot(): CartLine[] {
  if (!storageRestored) {
    storageRestored = true;
    linesSnapshot = readStoredLines();
  }

  return linesSnapshot;
}

function getServerSnapshot(): CartLine[] {
  return EMPTY_LINES;
}

function writeLines(update: (current: CartLine[]) => CartLine[]) {
  linesSnapshot = update(linesSnapshot);

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(linesSnapshot));
  } catch {
    // Private browsing can refuse storage; the bag still works for this visit.
  }

  for (const listener of listeners) listener();
}

const CartContext = createContext<CartContextValue | null>(null);

export function useCart() {
  const context = useContext(CartContext);

  if (!context) {
    throw new Error("useCart must be used inside <CartProvider>");
  }

  return context;
}

export function CartProvider({ children }: { children: ReactNode }) {
  const lines = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const [isOpen, setIsOpen] = useState(false);
  const [lastAddedId, setLastAddedId] = useState<string | null>(null);

  const addItem = useCallback((product: CartProduct) => {
    writeLines((current) => {
      const existing = current.find((line) => line.product.id === product.id);

      if (existing) {
        return current.map((line) =>
          line.product.id === product.id
            ? { ...line, qty: Math.min(99, line.qty + 1) }
            : line,
        );
      }

      return [...current, { product, qty: 1 }];
    });

    setLastAddedId(product.id);
    setIsOpen(true);
  }, []);

  const removeItem = useCallback((id: string) => {
    writeLines((current) => current.filter((line) => line.product.id !== id));
  }, []);

  const setQty = useCallback((id: string, qty: number) => {
    writeLines((current) =>
      qty <= 0
        ? current.filter((line) => line.product.id !== id)
        : current.map((line) =>
            line.product.id === id ? { ...line, qty: Math.min(99, qty) } : line,
          ),
    );
  }, []);

  const clear = useCallback(() => writeLines(() => EMPTY_LINES), []);
  const openCart = useCallback(() => setIsOpen(true), []);
  const closeCart = useCallback(() => setIsOpen(false), []);

  const value = useMemo<CartContextValue>(() => {
    const count = lines.reduce((total, line) => total + line.qty, 0);
    const subtotal = lines.reduce((total, line) => total + line.qty * line.product.price, 0);

    return {
      lines,
      count,
      subtotal,
      isOpen,
      lastAddedId,
      addItem,
      removeItem,
      setQty,
      clear,
      openCart,
      closeCart,
    };
  }, [lines, isOpen, lastAddedId, addItem, removeItem, setQty, clear, openCart, closeCart]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
