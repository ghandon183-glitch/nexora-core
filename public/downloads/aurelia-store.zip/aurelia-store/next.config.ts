import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  basePath: "/demo/aurelia-store",
  images: {
    unoptimized: true,
  },
};

export default nextConfig;
