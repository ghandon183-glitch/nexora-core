# Changelog

## 1.2.0
- Every footer link now points at a real static page: shop categories
  (`/shop/rings`, `/shop/necklaces`, `/shop/ceramics`,
  `/shop/candles-and-scent`), studio pages (`/our-process`, `/materials`,
  `/journal`, `/wholesale`), support pages (`/shipping`, `/returns`,
  `/care-guide`, `/contact`), plus `/privacy` and `/terms`. Sample copy lives
  in `lib/pages.ts` and is labelled as template content to replace.
- Added `app/icon.svg` so the site ships a favicon; the static export no longer
  requests a missing `/favicon.ico`.
- Hero and product photography now use `next/image` (`fill` +
  `images.unoptimized`), removing both `@next/next/no-img-element` warnings
  without disabling the rule.
- Newsletter form no longer implies a successful signup: it states that nothing
  is sent or stored and links to README setup instructions for a real provider.
- README rewritten with prerequisites, route map, static-export deployment,
  demo-only behaviour, provider setup, and troubleshooting.

## 1.1.0
- Updated Next.js to 16.4.5 to address the published security advisories in
  16.0.0–16.4.0 (cache poisoning, image-optimisation SSRF/RCE, Server Actions
  denial of service).
- Updated `eslint-config-next` to 16.4.5 and pinned `minimatch` ^11.0.1 for the
  TypeScript ESLint toolchain (dev-only advisory).
- Added `.env.example` documenting the optional `NEXT_PUBLIC_BASE_PATH`.
- README: documented the environment variable, replaced `npm run start` with
  static-export instructions for `out/`, and clarified that checkout is a demo.
- Regenerated `package-lock.json` so `npm ci` installs reproducibly.

## 1.0.0
- Customer-ready commercial package.
- Standard license and support documentation.
- Installation and production checklist included.
