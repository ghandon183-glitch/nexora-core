# Changelog

## 1.1.0
- Updated Next.js to 16.4.5 to address the published security advisories in
  16.0.0–16.4.0 (cache poisoning, image-optimisation SSRF/RCE, Server Actions
  denial of service).
- Updated `eslint-config-next` to 16.4.5 and pinned `minimatch` ^11.0.1 for the
  TypeScript ESLint toolchain (dev-only advisory).
- Added `.env.example` documenting the optional `NEXT_PUBLIC_BASE_PATH`.
- README: documented the environment variable, replaced `npm run start` with
  static-export instructions for `out/`, and clarified that checkout is a demo.
- Regenerated `package-lock.json` so `npm ci` installs reproducibly.

## 1.0.0
- Customer-ready commercial package.
- Standard license and support documentation.
- Installation and production checklist included.
