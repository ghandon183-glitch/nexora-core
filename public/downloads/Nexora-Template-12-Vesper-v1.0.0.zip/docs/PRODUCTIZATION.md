# Vesper Productization Guide

## Positioning

Vesper should be sold as a premium **AI Creative SaaS / Creative Studio front-end system**, not as a functioning AI generation service.

## Included package

- Vite project source
- React + TypeScript components
- Tailwind CSS 4 styling
- Auralis WebGL visual hero
- Marketing landing page
- Studio Workspace application mock
- Reusable UI Kit
- Local demo imagery
- Responsive and reduced-motion patterns
- Installation and customization documentation

## Before a customer ships it

- Replace Vesper branding, copy, demo testimonials, and sample company names.
- Replace demo pricing with the customer's real offer.
- Connect authentication, database, storage, billing, and AI APIs if required.
- Replace demonstration infrastructure/status labels with real service telemetry.
- Review image and font licensing for the customer's distribution model.
- Run `npm run lint` and `npm run build` after customization.

## Suggested product tiers

The template can be marketed with a regular license and an extended license according to the marketplace's licensing system. The demo pricing section inside Vesper is intentionally example content and is not the template's license price.

## Quality bar for release

A release candidate should have:

- zero TypeScript errors
- successful production build
- no broken internal anchors
- no fake customer claims
- no secret/API keys in the repository
- local assets for the included preview
- clear documentation for all major customization points
- mobile and reduced-motion QA
