# Vesper — Premium AI Creative SaaS Template 12

Vesper is a production-minded React + TypeScript + Tailwind template for AI products, creative SaaS, media tools, studios, and premium digital experiences.

## What makes this a premium template

- Cinematic Auralis WebGL hero with graceful visual fallback
- Full marketing system: hero, social-proof strip, capabilities, workflow, showcase, use cases, pricing, testimonials, FAQ, and conversion CTA
- Interactive Studio Workspace mock with timeline, inspector, render states, media controls, and responsive application chrome
- Reusable UI Kit demonstrating buttons, forms, cards, status states, tables, notifications, and design tokens
- Responsive-first layout with reduced-motion-aware patterns
- React 19 + TypeScript + Vite + Tailwind CSS 4
- Demo assets included locally — no required external image CDN
- Clean separation of content/data from UI components
- Documentation covering setup, customization, architecture, deployment, and replacing demo content

## Quick start

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Production checks

```bash
npm run lint
npm run build
```

## Customize the template

1. Start with `src/data/vesperData.ts` for copy, features, use cases, pricing, testimonials, and FAQ content.
2. Replace images in `src/assets/images/` and update `src/data/assets.ts`.
3. Adjust visual tokens in `src/index.css`.
4. Connect the Studio Workspace controls to your own API, auth, storage, and persistence layer.
5. Replace demo-only product claims and sample customer content before shipping a real product.

## Important

Vesper is a front-end template. Interactive product surfaces are intentionally demonstrations and do not claim to provide an AI generation backend, GPU infrastructure, enterprise certification, or third-party service integration by themselves.

See `docs/PRODUCTIZATION.md` for the complete buyer-facing packaging checklist.
