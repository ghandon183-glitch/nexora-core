# Vesper — Premium AI Creative SaaS Template 12

Vesper is a production-minded React + TypeScript + Tailwind template for AI products, creative SaaS, media tools, studios, and premium digital experiences.

## What makes this a premium template

- Cinematic Auralis WebGL hero with graceful visual fallback
- Full marketing system: hero, social-proof strip, capabilities, workflow, showcase, use cases, pricing, testimonials, FAQ, and conversion CTA
- Interactive Studio Workspace mock with timeline, inspector, render states, media controls, and responsive application chrome
- Reusable UI Kit demonstrating buttons, forms, cards, status states, tables, notifications, and design tokens
- Responsive-first layout with reduced-motion-aware patterns
- React 19 + TypeScript + Vite + Tailwind CSS 4
- Demo assets included locally — no required external image CDN
- Clean separation of content/data from UI components
- Documentation covering setup, customization, architecture, deployment, and replacing demo content

## Quick start

Requires Node.js 20.19+ or 22.12+ and npm (Vite 8 requirement).

```bash
npm ci
npm run dev
```

Open `http://localhost:3000`. `npm ci` installs exactly the versions in the
included `package-lock.json`.

## Production checks

```bash
npm run lint
npm run build
```

## Customize the template

1. Start with `src/data/vesperData.ts` for copy, features, use cases, pricing, testimonials, and FAQ content.
2. Replace images in `src/assets/images/` and update `src/data/assets.ts`.
3. Adjust visual tokens in `src/index.css`.
4. Connect the Studio Workspace controls to your own API, auth, storage, and persistence layer.
5. Replace demo-only product claims and sample customer content before shipping a real product.

## Environment variables

Vesper needs no environment variables to build, start or deploy: `npm run build`
produces static files. `.env.example` documents the one development switch and
the two placeholders that this template does not read.

`DISABLE_HMR` turns off hot module replacement and the dev-server file watcher.
Set it in the process environment when a tool rewrites files under `src/` while
`npm run dev` runs, so its reloads do not fight that tool:

```bash
DISABLE_HMR=true npm run dev
```

Vite resolves `vite.config.ts` before it loads `.env` files, so a value written
only in `.env` does not reach this switch; use the environment itself. Leaving
the variable unset (or set to anything other than `true`) keeps HMR enabled.
It has no effect on `npm run build` or `npm run preview`.

`GEMINI_API_KEY` and `APP_URL` appear in `.env.example` as placeholders only;
no file under `src/` reads them and the package contains no server code.

## Important

Vesper is a front-end template. Interactive product surfaces are intentionally demonstrations and do not claim to provide an AI generation backend, GPU infrastructure, enterprise certification, or third-party service integration by themselves.

The access and request forms are demonstrations too: they create no account, provision no workspace, issue no credits or API tokens, and send no email. Every confirmation message says so. The package ships no server-side code, so wiring those forms to your own auth, billing or email endpoint is the buyer's integration step. No Gemini or other AI integration is included (`metadata.json` lists no server capabilities).

See `docs/PRODUCTIZATION.md` for the complete buyer-facing packaging checklist.
