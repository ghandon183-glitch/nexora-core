# Changelog

## 1.0.1
- `.env.example` now documents `DISABLE_HMR`, the single variable the package
  actually reads, with its accepted values, default behaviour and the fact that
  Vite only sees it from the process environment, not from `.env`.
- Corrected the `GEMINI_API_KEY` / `APP_URL` entries, which are not read by this
  front-end template.
- Added an SVG favicon and declared it in `index.html`, so browsers no longer
  request a missing `/favicon.ico` and log a 404.
- README and QUICKSTART: Node.js 20.19+ / 22.12+, `npm ci`, and an environment
  variable section that matches the code.

## 1.0.0
- Customer-ready commercial package.
- Standard license and support documentation.
- Installation and production checklist included.
