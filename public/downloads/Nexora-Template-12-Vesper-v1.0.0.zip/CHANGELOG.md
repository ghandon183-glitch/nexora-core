# Changelog

## 1.0.2
- Studio inspector: the fixed 320px inspector pane is now stacked below the
  canvas on narrow viewports and fully scrollable, so every control (including
  Randomize) is reachable at 320px without horizontal scrolling. Desktop keeps
  the side-by-side layout.
- Honest demo messaging: the access modal and the final CTA no longer claim
  provisioning, tenants, "6,000 compute credits", private keys or dispatched
  tokens. They state that no account, workspace, credit, token or email is
  created, and that the forms stay in the browser.
- Removed the unsupported server-side Gemini capability from `metadata.json`,
  labelled the demo telemetry in the footer and the inspector, and documented
  the no-backend limitation in the README.

## 1.0.1
- `.env.example` now documents `DISABLE_HMR`, the single variable the package
  actually reads, with its accepted values, default behaviour and the fact that
  Vite only sees it from the process environment, not from `.env`.
- Corrected the `GEMINI_API_KEY` / `APP_URL` entries, which are not read by this
  front-end template.
- Added an SVG favicon and declared it in `index.html`, so browsers no longer
  request a missing `/favicon.ico` and log a 404.
- README and QUICKSTART: Node.js 20.19+ / 22.12+, `npm ci`, and an environment
  variable section that matches the code.

## 1.0.0
- Customer-ready commercial package.
- Standard license and support documentation.
- Installation and production checklist included.
