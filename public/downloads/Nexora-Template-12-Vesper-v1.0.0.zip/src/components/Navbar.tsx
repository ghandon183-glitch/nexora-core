import React, { useState, useEffect } from 'react';
import { Sparkles, Terminal, SlidersHorizontal } from 'lucide-react';

interface NavbarProps {
  onOpenStudio: () => void;
  onRequestAccess: () => void;
  isStudioActive?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenStudio,
  onRequestAccess,
  isStudioActive = false,
}) => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 24);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#050507]/90 backdrop-blur-md border-b border-white/[0.08] shadow-2xl py-3.5'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-8 flex items-center justify-between">
        {/* Zone 1: Single element brand wordmark */}
        <a
          href="#"
          className="group flex items-center gap-2.5 text-xl font-bold tracking-widest uppercase font-['Syne',sans-serif] text-white hover:text-red-400 transition-colors"
        >
          <div className="w-2.5 h-2.5 rounded-full bg-red-600 shadow-[0_0_12px_#dc2626] group-hover:scale-125 transition-transform" />
          <span>VESPER</span>
        </a>

        {/* Zone 2: 4-5 clean single-line nav links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-neutral-400">
          <a
            href="#capabilities"
            className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:w-0 after:h-px after:bg-red-500 hover:after:w-full after:transition-all whitespace-nowrap"
          >
            Capabilities
          </a>
          <a
            href="#process"
            className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:w-0 after:h-px after:bg-red-500 hover:after:w-full after:transition-all whitespace-nowrap"
          >
            Workflow
          </a>
          <a
            href="#showcase"
            className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:w-0 after:h-px after:bg-red-500 hover:after:w-full after:transition-all whitespace-nowrap"
          >
            Studio Demo
          </a>
          <a
            href="#use-cases"
            className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:w-0 after:h-px after:bg-red-500 hover:after:w-full after:transition-all whitespace-nowrap"
          >
            Use Cases
          </a>
          <a
            href="#ui-kit"
            className="hover:text-white transition-colors relative py-1 after:absolute after:bottom-0 after:left-0 after:w-0 after:h-px after:bg-red-500 hover:after:w-full after:transition-all whitespace-nowrap"
          >
            UI Kit
          </a>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onOpenStudio}
            className={`hidden sm:inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium rounded-md border transition-all whitespace-nowrap ${
              isStudioActive
                ? 'bg-red-950/60 border-red-600/50 text-red-200 shadow-[0_0_15px_rgba(220,38,38,0.3)]'
                : 'bg-white/[0.04] border-white/10 text-neutral-300 hover:text-white hover:border-white/25 hover:bg-white/[0.08]'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-red-400" />
            <span>{isStudioActive ? 'Landing View' : 'Launch OS Workspace'}</span>
          </button>

          <button
            type="button"
            onClick={onRequestAccess}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold tracking-wide uppercase font-['Syne',sans-serif] text-white bg-gradient-to-r from-red-700 via-red-600 to-rose-700 hover:from-red-600 hover:to-rose-600 rounded-md shadow-[0_0_20px_rgba(220,38,38,0.4)] hover:shadow-[0_0_30px_rgba(225,29,72,0.6)] transition-all whitespace-nowrap"
          >
            <span>Request Access</span>
          </button>
        </div>
      </div>
    </header>
  );
};
