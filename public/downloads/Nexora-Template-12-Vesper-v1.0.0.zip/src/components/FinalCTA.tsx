import React, { useState } from 'react';
import { ArrowRight, Sparkles, CheckCircle2, Shield } from 'lucide-react';

interface FinalCTAProps {
  onDirectEnter: () => void;
}

export const FinalCTA: React.FC<FinalCTAProps> = ({ onDirectEnter }) => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setError('Please provide a valid studio or professional email address.');
      return;
    }
    setError('');
    setSubmitted(true);
  };

  return (
    <section className="relative py-32 bg-[#050507] border-t border-white/[0.06] overflow-hidden">
      {/* Intense blood-red ambient core glow */}
      <div 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[450px] bg-red-900/35 rounded-full blur-[170px] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="relative max-w-4xl mx-auto px-6 sm:px-8 text-center">
        {/* Subtle kicker */}
        <div className="flex items-center justify-center gap-2 text-xs uppercase tracking-widest text-red-400 font-mono mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
          <span>Vesper Studio Allocation</span>
          <span aria-hidden="true">·</span>
          <span>Batch 04 Now Open</span>
        </div>

        {/* Master headline */}
        <h2 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight text-white font-['Syne',sans-serif] leading-[1.08] mb-6">
          DIRECT THE NEXT ERA{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-rose-300 to-red-500">
            OF CINEMA.
          </span>
        </h2>

        {/* Description */}
        <p className="text-base sm:text-lg text-neutral-300 max-w-2xl mx-auto leading-relaxed mb-10 font-normal">
          Build a cinematic product experience for creative teams, AI products, studios, and ambitious digital tools.
        </p>

        {/* Form or Success State */}
        {submitted ? (
          <div className="p-8 rounded-2xl bg-[#120d18] border border-red-500/50 shadow-[0_0_40px_rgba(220,38,38,0.35)] max-w-md mx-auto text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-red-950/80 border border-red-500/60 flex items-center justify-center text-red-400 mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-['Syne',sans-serif]">
              Studio Credentials Dispatched
            </h3>
            <p className="text-xs text-neutral-300 leading-relaxed font-mono">
              An invitation vector and temporary API token have been transmitted to <span className="text-red-400 font-semibold">{email}</span>.
            </p>
            <button
              type="button"
              onClick={onDirectEnter}
              className="mt-4 px-6 py-2.5 text-xs font-mono font-bold tracking-wider uppercase bg-red-600 hover:bg-red-500 text-white rounded-lg shadow-[0_0_15px_rgba(220,38,38,0.5)] transition-all"
            >
              Enter Live OS Workspace
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-3">
            <div className="flex flex-col sm:flex-row gap-2.5">
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (error) setError('');
                }}
                placeholder="director@studio.com"
                className="flex-1 px-4 py-3.5 rounded-lg bg-[#0e0c15] border border-white/15 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-red-500/80 focus:ring-1 focus:ring-red-500/60 transition-all font-mono"
              />
              <button
                type="submit"
                className="px-6 py-3.5 text-xs font-bold uppercase tracking-wider font-mono text-white bg-gradient-to-r from-red-700 via-red-600 to-rose-700 hover:from-red-600 hover:to-rose-600 rounded-lg shadow-[0_0_25px_rgba(220,38,38,0.5)] hover:shadow-[0_0_35px_rgba(225,29,72,0.7)] transition-all shrink-0 flex items-center justify-center gap-2"
              >
                <span>Request Key</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
            {error && (
              <p className="text-xs font-mono text-rose-400 text-left pl-1">
                {error}
              </p>
            )}
            <div className="flex items-center justify-center gap-4 text-[11px] font-mono text-neutral-400 pt-2">
              <span className="flex items-center gap-1.5">
                <Shield className="w-3 h-3 text-red-500" />
                <span>Enterprise-ready UI patterns</span>
              </span>
              <span>·</span>
              <span>100% Commercial IP Rights</span>
            </div>
          </form>
        )}
      </div>
    </section>
  );
};
