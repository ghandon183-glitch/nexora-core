import React, { useState } from 'react';
import { PRICING_PLANS } from '../data/vesperData';
import { Check, Sparkles, Zap, ArrowRight } from 'lucide-react';

interface PricingProps {
  onSelectPlan: (planId: string) => void;
}

export const Pricing: React.FC<PricingProps> = ({ onSelectPlan }) => {
  const [isAnnual, setIsAnnual] = useState(true);

  return (
    <section id="pricing" className="relative py-28 bg-[#050507] border-t border-white/[0.06] overflow-hidden">
      {/* Background crimson ambient bloom */}
      <div 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[500px] bg-red-950/20 rounded-full blur-[180px] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="relative max-w-7xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 text-xs uppercase tracking-widest text-red-500 font-mono mb-3">
            <span>Transparent Compute Tiers</span>
            <span aria-hidden="true">·</span>
            <span>Zero Hidden Ingress</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white font-['Syne',sans-serif] leading-tight mb-5">
            DEDICATED NEURAL COMPUTE.
          </h2>
          <p className="text-base sm:text-lg text-neutral-400 leading-relaxed font-normal mb-8">
            Predictable GPU clusters configured for independent directors, visual effects studios, and enterprise production networks.
          </p>

          {/* Billing Interval Switcher */}
          <div className="inline-flex items-center gap-3 p-1.5 rounded-xl bg-[#0e0c14] border border-white/10">
            <button
              type="button"
              onClick={() => setIsAnnual(false)}
              className={`px-4 py-2 text-xs font-mono rounded-lg transition-all ${
                !isAnnual
                  ? 'bg-neutral-800 text-white font-bold shadow'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Monthly Billing
            </button>
            <button
              type="button"
              onClick={() => setIsAnnual(true)}
              className={`px-4 py-2 text-xs font-mono rounded-lg transition-all flex items-center gap-2 ${
                isAnnual
                  ? 'bg-red-900/70 border border-red-500/40 text-white font-bold shadow-[0_0_15px_rgba(220,38,38,0.4)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <span>Annual Commitment</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-600/60 text-red-100 uppercase tracking-wider font-semibold">
                Save 20%
              </span>
            </button>
          </div>
        </div>

        {/* 3 Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {PRICING_PLANS.map((plan) => {
            const price = isAnnual ? plan.annualPrice : plan.monthlyPrice;

            return (
              <div
                key={plan.id}
                className={`relative rounded-2xl p-8 flex flex-col justify-between transition-all duration-300 ${
                  plan.popular
                    ? 'bg-[#0f0c18] border-2 border-red-600/70 shadow-[0_0_60px_-10px_rgba(220,38,38,0.35)] scale-[1.02] z-10'
                    : 'bg-[#09080d]/90 border border-white/[0.08] hover:border-white/20'
                }`}
              >
                {/* Popular Pill Label */}
                {plan.popular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-to-r from-red-600 to-rose-600 text-white text-[11px] font-mono uppercase tracking-widest font-bold shadow-[0_0_15px_rgba(220,38,38,0.6)]">
                    Studio Choice
                  </div>
                )}

                <div>
                  {/* Plan Name & Tagline */}
                  <h3 className="text-2xl font-bold text-white font-['Syne',sans-serif] mb-2">
                    {plan.name}
                  </h3>
                  <p className="text-xs text-neutral-400 mb-6 font-normal min-h-[36px]">
                    {plan.tagline}
                  </p>

                  {/* Price */}
                  <div className="flex items-baseline gap-2 mb-6 pb-6 border-b border-white/[0.08]">
                    <span className="text-4xl sm:text-5xl font-extrabold text-white font-['Syne',sans-serif] tabular-nums">
                      ${price}
                    </span>
                    <span className="text-xs font-mono text-neutral-400">
                      / month {isAnnual ? '(billed annually)' : ''}
                    </span>
                  </div>

                  {/* High level specs */}
                  <div className="space-y-2 mb-8 text-xs font-mono">
                    <div className="flex items-center gap-2 text-neutral-300">
                      <Zap className="w-3.5 h-3.5 text-red-400 shrink-0" />
                      <span>{plan.credits}</span>
                    </div>
                    <div className="flex items-center gap-2 text-neutral-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 shrink-0" />
                      <span>{plan.concurrency}</span>
                    </div>
                    <div className="flex items-center gap-2 text-neutral-400">
                      <span className="w-1.5 h-1.5 rounded-full bg-neutral-500 shrink-0" />
                      <span>{plan.resolution}</span>
                    </div>
                  </div>

                  {/* Detailed Feature List */}
                  <div className="space-y-3 mb-8">
                    {plan.features.map((feature, fIdx) => (
                      <div key={fIdx} className="flex items-start gap-2.5 text-xs text-neutral-300">
                        <Check className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CTA Button */}
                <button
                  type="button"
                  onClick={() => onSelectPlan(plan.id)}
                  className={`w-full group inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-bold font-mono tracking-wider uppercase rounded-lg transition-all ${
                    plan.popular
                      ? 'bg-gradient-to-r from-red-700 via-red-600 to-rose-700 text-white shadow-[0_0_25px_rgba(220,38,38,0.5)] hover:shadow-[0_0_35px_rgba(225,29,72,0.7)]'
                      : 'bg-white/[0.06] hover:bg-white/[0.12] text-white border border-white/10 hover:border-red-500/40'
                  }`}
                >
                  <span>{plan.ctaLabel}</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
