import React from 'react';
import { LOGO_STUDIOS } from '../data/vesperData';

export const LogoCloud: React.FC = () => {
  return (
    <section className="relative z-10 py-12 border-y border-white/[0.06] bg-[#050507]/60 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <p className="text-center text-xs uppercase tracking-widest text-neutral-400 font-mono mb-8">
          Demo brand strip — replace with your customers or partners
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6 sm:gap-8 items-center justify-center">
          {LOGO_STUDIOS.map((studio, idx) => (
            <div
              key={idx}
              className="group flex flex-col items-center justify-center p-3 rounded-lg border border-transparent hover:border-red-900/30 hover:bg-red-950/10 transition-all duration-300"
            >
              <span className="text-sm sm:text-base font-bold tracking-widest text-neutral-400 group-hover:text-white font-['Syne',sans-serif] transition-colors">
                {studio.name}
              </span>
              <span className="text-[10px] text-neutral-400 group-hover:text-red-400 tracking-wider font-mono mt-0.5 transition-colors">
                {studio.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
