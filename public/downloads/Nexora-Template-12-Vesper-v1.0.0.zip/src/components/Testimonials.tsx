import React from 'react';
import { TESTIMONIALS_DATA } from '../data/vesperData';
import { Quote } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section className="relative py-28 bg-[#07060a] border-t border-white/[0.06] overflow-hidden">
      {/* Background ambient crimson spot */}
      <div 
        className="absolute top-1/2 right-1/4 w-96 h-96 bg-red-950/20 rounded-full blur-[160px] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="relative max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="max-w-2xl mb-16">
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-red-500 font-mono mb-3">
            <span>Directorial Endorsements</span>
            <span aria-hidden="true">·</span>
            <span>Production Record</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white font-['Syne',sans-serif] leading-tight mb-5">
            PROVEN ON ACTUAL SOUNDSTAGES.
          </h2>
          <p className="text-base sm:text-lg text-neutral-400 leading-relaxed font-normal">
            Hear from the cinematographers, VFX supervisors, and sound architects who deploy Vesper daily.
          </p>
        </div>

        {/* 3 Testimonials Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS_DATA.map((t) => (
            <div
              key={t.id}
              className="p-8 rounded-2xl bg-[#09080e] border border-white/[0.08] hover:border-red-900/40 hover:bg-[#0f0c16] transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                <Quote className="w-8 h-8 text-red-600/40 mb-6 group-hover:text-red-500/70 transition-colors" />
                <p className="text-sm sm:text-base text-neutral-300 leading-relaxed font-normal mb-8 italic">
                  "{t.quote}"
                </p>
              </div>

              {/* Attribution */}
              <div className="pt-6 border-t border-white/[0.06]">
                <div className="font-bold text-white font-['Syne',sans-serif] text-base">
                  {t.author}
                </div>
                <div className="text-xs text-red-400 font-mono mt-0.5">
                  {t.role} · {t.studio}
                </div>
                <div className="text-[11px] text-neutral-500 font-mono mt-1">
                  {t.credits}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
