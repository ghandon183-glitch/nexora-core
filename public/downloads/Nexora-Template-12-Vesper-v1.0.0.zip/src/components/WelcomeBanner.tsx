import React, { useState, useEffect } from 'react';
import { X, Package, Sparkles, Layers, Code2 } from 'lucide-react';

/**
 * Welcome / About This Template notice.
 *
 * This used to be a full-screen modal overlay. Because it opened 800ms after
 * load and covered the viewport, it intercepted every click on the page until a
 * visitor dismissed it — the landing page looked frozen. It is now a compact
 * corner card: still shown once, still dismissible, but it never blocks the
 * page and it can be closed with the keyboard.
 */
export const WelcomeBanner: React.FC = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const dismissed = localStorage.getItem('vesper-welcome-dismissed');
    if (!dismissed) {
      const t = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(t);
    }
  }, []);

  const handleDismiss = () => {
    setVisible(false);
    try {
      localStorage.setItem('vesper-welcome-dismissed', '1');
    } catch {
      // Private browsing can reject storage writes; the notice simply reappears.
    }
  };

  if (!visible) return null;

  return (
    <aside
      aria-label="About this template"
      className="fixed bottom-6 left-4 sm:left-6 z-[90] w-[min(20rem,calc(100vw-2rem))] rounded-xl border border-red-500/25 bg-[#0c0b10]/95 shadow-[0_0_40px_rgba(220,38,38,0.2)] backdrop-blur-md"
    >
      <div className="h-0.5 w-full rounded-t-xl bg-gradient-to-r from-red-700 via-rose-500 to-red-700" />

      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-red-500/30 bg-red-500/10">
              <Package className="h-4 w-4 text-red-400" aria-hidden="true" />
            </span>
            <div>
              <p className="font-mono text-[10px] uppercase tracking-widest text-red-400/80">
                Premium Template
              </p>
              <h2 className="text-sm font-semibold text-white">Welcome to Vesper</h2>
            </div>
          </div>
          <button
            type="button"
            onClick={handleDismiss}
            className="rounded-md p-1 text-neutral-500 transition-colors hover:bg-white/5 hover:text-white"
            aria-label="Dismiss welcome notice"
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>

        <p className="mt-3 text-xs leading-relaxed text-neutral-400">
          A dark cinematic landing page with a real WebGL ambient hero, a studio console demo,
          and a reusable UI kit.
        </p>

        <ul className="mt-3 space-y-1.5 text-[11px] text-neutral-300">
          {[
            { icon: Sparkles, text: 'WebGL Auralis hero' },
            { icon: Layers, text: '11 complete sections' },
            { icon: Code2, text: 'React 19 · TypeScript · Vite' },
          ].map(({ icon: Icon, text }) => (
            <li key={text} className="flex items-center gap-2">
              <Icon className="h-3.5 w-3.5 shrink-0 text-red-400/80" aria-hidden="true" />
              <span>{text}</span>
            </li>
          ))}
        </ul>

        <button
          type="button"
          onClick={handleDismiss}
          className="mt-4 w-full rounded-lg bg-gradient-to-r from-red-700 via-red-600 to-rose-700 py-2 text-xs font-semibold text-white transition-shadow hover:shadow-[0_0_24px_rgba(225,29,72,0.45)]"
        >
          Explore the template
        </button>
      </div>
    </aside>
  );
};
