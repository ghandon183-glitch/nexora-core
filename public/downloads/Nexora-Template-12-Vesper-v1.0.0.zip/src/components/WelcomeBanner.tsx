import React, { useState, useEffect } from 'react';
import { X, Package, Sparkles, Code2, Layers, CheckCircle2 } from 'lucide-react';

/**
 * Welcome / About This Template banner
 * Shows once when the buyer opens the template so they understand what they got.
 * Does not affect the Hero or any other section.
 */
export const WelcomeBanner: React.FC = () => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Show only if not dismissed before (localStorage)
    const dismissed = localStorage.getItem('vesper-welcome-dismissed');
    if (!dismissed) {
      // small delay so page loads first
      const t = setTimeout(() => setVisible(true), 800);
      return () => clearTimeout(t);
    }
  }, []);

  const handleDismiss = () => {
    setVisible(false);
    localStorage.setItem('vesper-welcome-dismissed', '1');
  };

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={handleDismiss}
        aria-hidden="true"
      />

      {/* Card */}
      <div className="relative w-full max-w-lg rounded-2xl border border-red-500/20 bg-[#0c0b10] shadow-[0_0_60px_rgba(220,38,38,0.15)] overflow-hidden">
        {/* Top accent line */}
        <div className="h-1 w-full bg-gradient-to-r from-red-700 via-rose-500 to-red-700" />

        <div className="p-6 sm:p-8">
          {/* Header */}
          <div className="flex items-start justify-between gap-4 mb-5">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-500/10 border border-red-500/30">
                <Package className="h-5 w-5 text-red-400" />
              </div>
              <div>
                <p className="text-xs font-mono uppercase tracking-widest text-red-400/80">
                  Premium Template
                </p>
                <h2 className="text-lg font-semibold text-white tracking-tight">
                  Welcome to Vesper
                </h2>
              </div>
            </div>
            <button
              type="button"
              onClick={handleDismiss}
              className="rounded-lg p-1.5 text-neutral-500 hover:text-white hover:bg-white/5 transition-colors"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Body */}
          <p className="text-sm text-neutral-300 leading-relaxed mb-6">
            You now own a complete, production-ready dark cinematic template built for
            AI creative tools. The hero uses a real WebGL ambient shader (Auralis) with
            layered noise, glowing crimson light, and film grain.
          </p>

          {/* What's included */}
          <div className="space-y-2.5 mb-6">
            <p className="text-xs font-mono uppercase tracking-wider text-neutral-500 mb-3">
              What&apos;s included
            </p>
            {[
              { icon: Sparkles, text: 'Full-screen WebGL Auralis hero' },
              { icon: Layers, text: '11 complete sections (Features → FAQ)' },
              { icon: Code2, text: 'React 19 + TypeScript + Tailwind + Vite' },
              { icon: CheckCircle2, text: 'Commercial license · One-time purchase' },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-3 text-sm text-neutral-200">
                <Icon className="h-4 w-4 shrink-0 text-red-400/80" />
                <span>{text}</span>
              </div>
            ))}
          </div>

          {/* CTA */}
          <button
            type="button"
            onClick={handleDismiss}
            className="w-full rounded-xl bg-gradient-to-r from-red-700 via-red-600 to-rose-700 py-3 text-sm font-semibold text-white shadow-[0_0_25px_rgba(220,38,38,0.35)] hover:shadow-[0_0_35px_rgba(225,29,72,0.5)] transition-shadow"
          >
            Explore the template
          </button>

          <p className="mt-4 text-center text-[11px] text-neutral-600 font-mono">
            This message appears only once
          </p>
        </div>
      </div>
    </div>
  );
};
