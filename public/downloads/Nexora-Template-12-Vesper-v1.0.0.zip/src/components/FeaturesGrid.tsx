import React, { useState } from 'react';
import { FEATURES_DATA } from '../data/vesperData';
import { Layers, Activity, Music, Sparkles, GitBranch, Lock, ArrowUpRight } from 'lucide-react';

const FEATURE_ICONS: Record<string, React.FC<{ className?: string }>> = {
  'latent-canvas': Layers,
  'temporal-coherence': Activity,
  'harmonic-audio': Music,
  'neural-grading': Sparkles,
  'seed-branching': GitBranch,
  'private-weights': Lock,
};

export const FeaturesGrid: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState<string | null>(null);

  return (
    <section id="capabilities" className="relative py-28 bg-[#050507] overflow-hidden">
      {/* Background ambient crimson lighting spot */}
      <div 
        className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-red-950/20 rounded-full blur-[140px] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="relative max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-20">
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-red-500 font-mono mb-3">
            <span>Directorial Capabilities</span>
            <span aria-hidden="true">·</span>
            <span>Neural Architecture</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white font-['Syne',sans-serif] leading-tight mb-5">
            ENGINEERED FOR RIGID PRODUCTION PIPELINES.
          </h2>
          <p className="text-base sm:text-lg text-neutral-400 leading-relaxed font-normal">
            Move past toy generators. Vesper gives directors, VFX leads, and sound designers deterministic control across every layer of the moving image.
          </p>
        </div>

        {/* 6 Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {FEATURES_DATA.map((feat) => {
            const IconComponent = FEATURE_ICONS[feat.id] || Layers;
            const isHovered = activeFeature === feat.id;

            return (
              <div
                key={feat.id}
                onMouseEnter={() => setActiveFeature(feat.id)}
                onMouseLeave={() => setActiveFeature(null)}
                className={`group relative p-8 rounded-xl border transition-all duration-300 flex flex-col justify-between ${
                  isHovered
                    ? 'bg-[#0e0a12] border-red-600/50 shadow-[0_0_35px_rgba(220,38,38,0.2)]'
                    : 'bg-[#09080d]/80 border-white/[0.08] hover:border-white/20'
                }`}
              >
                <div>
                  {/* Top line: Number index & Functional Category */}
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-xs font-mono font-bold tracking-wider text-red-400">
                      {feat.number}
                    </span>
                    <span className="text-[11px] font-mono tracking-wider uppercase text-neutral-500 group-hover:text-neutral-400 transition-colors">
                      {feat.tag}
                    </span>
                  </div>

                  {/* Icon */}
                  <div className="w-10 h-10 rounded-lg bg-red-950/40 border border-red-900/40 flex items-center justify-center text-red-400 mb-6 group-hover:scale-110 group-hover:bg-red-900/50 group-hover:text-red-300 transition-all">
                    <IconComponent className="w-5 h-5" />
                  </div>

                  {/* Title */}
                  <h3 className="text-xl font-bold text-white font-['Syne',sans-serif] mb-2 group-hover:text-red-100 transition-colors">
                    {feat.title}
                  </h3>

                  {/* Tagline */}
                  <p className="text-xs font-medium text-red-300/80 mb-4 font-mono">
                    {feat.tagline}
                  </p>

                  {/* Description */}
                  <p className="text-sm text-neutral-400 leading-relaxed font-normal mb-6">
                    {feat.description}
                  </p>
                </div>

                {/* Footer metric / proof anchor */}
                <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between text-xs font-mono text-neutral-400">
                  <span>{feat.metrics}</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-neutral-400 group-hover:text-red-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
