import React, { useState, useEffect } from 'react';
import { 
  Play, Pause, RotateCcw, Sparkles, Sliders, Dices, 
  Maximize2, Eye, Download, Layers, Volume2, Film, CheckCircle2,
  Tv, Compass, Crosshair
} from 'lucide-react';
import { ASSETS } from '../data/assets';

type StudioMode = 'video' | 'image' | 'audio' | 'canvas';

interface PresetPrompt {
  id: string;
  mode: StudioMode;
  label: string;
  prompt: string;
  image: string;
  ratio: string;
  fps: number;
  motion: number;
  guidance: number;
  seed: number;
  emulsion: string;
}

const PRESETS: PresetPrompt[] = [
  {
    id: 'monolith-gate',
    mode: 'video',
    label: 'Monolith Gateway (Video)',
    prompt: 'Cinematic sci-fi film still, solitary figure in heavy silhouette standing before an immense glowing blood-red monolithic structure in dense mist, wide anamorphic format, dark atmospheric volumetric lighting, 35mm film grain',
    image: ASSETS.videoFrame,
    ratio: '16:9',
    fps: 24,
    motion: 7.2,
    guidance: 8.5,
    seed: 4920183,
    emulsion: 'Kodak Vision3 5219',
  },
  {
    id: 'cyber-android',
    mode: 'image',
    label: 'Cybernetic Portrait (Still)',
    prompt: 'Dark editorial portrait of an ethereal cybernetic android with delicate crimson luminescent circuits and obsidian porcelain skin, cinematic chiaroscuro lighting, deep shadows, high-end creative studio render',
    image: ASSETS.showcasePortrait,
    ratio: '1:1',
    fps: 24,
    motion: 1.0,
    guidance: 9.0,
    seed: 7104291,
    emulsion: 'Fuji Eterna 8553',
  },
  {
    id: 'harmonic-cymatics',
    mode: 'audio',
    label: 'Cymatic Resonance (Audio)',
    prompt: 'Abstract dark ruby-red cymatic soundwave sculpture suspended in zero gravity, surrounded by subtle glowing particles and deep crimson smoke, volumetric studio lighting, minimalist dark aesthetic',
    image: ASSETS.audioVisual,
    ratio: '16:9',
    fps: 48,
    motion: 6.0,
    guidance: 7.8,
    seed: 1928472,
    emulsion: 'Spectral Resonator v2',
  },
  {
    id: 'fashion-editorial',
    mode: 'canvas',
    label: 'Haute Runway (Canvas)',
    prompt: 'High-fashion editorial model wearing structured obsidian silk and deep crimson sculptural garments, dark studio backdrop with dramatic red rim lighting, luxury cinematic mood, 8k editorial photography',
    image: ASSETS.fashionPrevis,
    ratio: '4:3',
    fps: 24,
    motion: 4.5,
    guidance: 8.2,
    seed: 5820194,
    emulsion: 'Eastman Double-X',
  },
];

export const ShowcaseDemo: React.FC = () => {
  const [activePreset, setActivePreset] = useState<PresetPrompt>(PRESETS[0]);
  const [currentPrompt, setCurrentPrompt] = useState<string>(PRESETS[0].prompt);
  const [motionScale, setMotionScale] = useState<number>(PRESETS[0].motion);
  const [guidanceScale, setGuidanceScale] = useState<number>(PRESETS[0].guidance);
  const [seed, setSeed] = useState<number>(PRESETS[0].seed);
  const [activeRatio, setActiveRatio] = useState<string>(PRESETS[0].ratio);
  const [activeEmulsion, setActiveEmulsion] = useState<string>(PRESETS[0].emulsion);

  // Overlays
  const [showGrain, setShowGrain] = useState(true);
  const [showGrid, setShowGrid] = useState(false);
  const [showDepth, setShowDepth] = useState(false);

  // Playback / Timeline state
  const [isPlaying, setIsPlaying] = useState(true);
  const [timelineProgress, setTimelineProgress] = useState(38);

  // Render simulation state
  const [isRendering, setIsRendering] = useState(false);
  const [renderProgress, setRenderProgress] = useState(0);
  const [renderStep, setRenderStep] = useState('Idle');

  // Trigger render simulation
  const handleStartRender = () => {
    if (isRendering) return;
    setIsRendering(true);
    setRenderProgress(0);
    setRenderStep('Initializing Spatio-Temporal Tensor...');

    const steps = [
      { progress: 20, text: 'Sampling Latent Noise Distribution (Step 5/25)' },
      { progress: 45, text: 'Enforcing Recurrent Optical Flow Coherence (Step 12/25)' },
      { progress: 75, text: 'Calibrating ACEScg Highlight Roll-off (Step 19/25)' },
      { progress: 95, text: 'Injecting Photochemical Emulsion & Grain (Step 24/25)' },
      { progress: 100, text: 'Encoding ProRes export demo Stream (Ready)' },
    ];

    let currentIdx = 0;
    const interval = setInterval(() => {
      if (currentIdx < steps.length) {
        setRenderProgress(steps[currentIdx].progress);
        setRenderStep(steps[currentIdx].text);
        currentIdx++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setIsRendering(false);
          setIsPlaying(true);
        }, 400);
      }
    }, 450);
  };

  // Switch preset
  const handleSelectPreset = (p: PresetPrompt) => {
    setActivePreset(p);
    setCurrentPrompt(p.prompt);
    setMotionScale(p.motion);
    setGuidanceScale(p.guidance);
    setSeed(p.seed);
    setActiveRatio(p.ratio);
    setActiveEmulsion(p.emulsion);
  };

  const handleRandomizeSeed = () => {
    setSeed(Math.floor(1000000 + Math.random() * 9000000));
  };

  // Timeline scrub simulation loop
  useEffect(() => {
    if (!isPlaying || isRendering) return;
    const interval = setInterval(() => {
      setTimelineProgress((prev) => (prev >= 100 ? 0 : prev + 1));
    }, 80);
    return () => clearInterval(interval);
  }, [isPlaying, isRendering]);

  return (
    <section id="showcase" className="relative py-28 bg-[#050507] border-t border-white/[0.06] overflow-hidden">
      {/* Background crimson ambient glow */}
      <div 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[850px] h-[600px] bg-red-950/20 rounded-full blur-[160px] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="relative max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-red-500 font-mono mb-3">
              <span>Live Demonstration</span>
              <span aria-hidden="true">·</span>
              <span>Vesper Studio Console</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white font-['Syne',sans-serif] leading-tight">
              INTERACTIVE DIRECTORIAL CONSOLE.
            </h2>
          </div>
          <p className="text-sm text-neutral-400 max-w-md font-normal">
            Experience the actual interface. Adjust spatial prompts, optical physics, and neural film stocks with sub-second feedback.
          </p>
        </div>

        {/* Studio Console Outer Frame */}
        <div className="rounded-2xl border border-white/10 bg-[#09080d] shadow-[0_0_60px_-15px_rgba(220,38,38,0.3)] overflow-hidden">
          {/* Studio Top Control Strip */}
          <div className="px-6 py-4 bg-[#0d0b13] border-b border-white/[0.08] flex flex-wrap items-center justify-between gap-4">
            {/* Mode selection segmented control */}
            <div className="flex items-center gap-1.5 p-1 bg-black/50 border border-white/[0.08] rounded-lg">
              {PRESETS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => handleSelectPreset(p)}
                  className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition-all whitespace-nowrap ${
                    activePreset.id === p.id
                      ? 'bg-red-900/60 text-white border border-red-500/40 shadow-[0_0_12px_rgba(220,38,38,0.4)]'
                      : 'text-neutral-400 hover:text-white hover:bg-white/[0.05]'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Status indicators */}
            <div className="flex items-center gap-4 text-xs font-mono text-neutral-400">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse shadow-[0_0_8px_#ef4444]" />
                <span className="text-white font-medium">GPU NODE / DEMO</span>
              </div>
              <span aria-hidden="true" className="text-neutral-700">|</span>
              <span>INTERACTIVE PREVIEW</span>
              <span aria-hidden="true" className="text-neutral-700">|</span>
              <span className="text-neutral-300">PRORES EXPORT</span>
            </div>
          </div>

          {/* Main Console Workspace Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[620px]">
            {/* Left Control Column (Parameters & Prompt) */}
            <div className="lg:col-span-5 p-6 border-b lg:border-b-0 lg:border-r border-white/[0.08] bg-[#07060b] flex flex-col justify-between space-y-6">
              <div className="space-y-6">
                {/* Prompt Directive Input */}
                <div>
                  <div className="flex items-center justify-between text-xs font-mono mb-2">
                    <span className="text-neutral-300 font-semibold uppercase tracking-wider">
                      Cinematic Latent Prompt
                    </span>
                    <span className="text-neutral-500">{currentPrompt.length} chars</span>
                  </div>
                  <textarea
                    rows={4}
                    value={currentPrompt}
                    onChange={(e) => setCurrentPrompt(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg bg-[#0e0d14] border border-white/10 text-xs text-neutral-200 focus:outline-none focus:border-red-500/80 focus:ring-1 focus:ring-red-500/50 transition-all font-mono leading-relaxed resize-none"
                    placeholder="Describe scene composition, optical perspective, lighting, and camera motion..."
                  />
                </div>

                {/* Param 1: Motion / Velocity Scale */}
                <div>
                  <div className="flex items-center justify-between text-xs font-mono mb-2">
                    <span className="text-neutral-400">Camera Velocity Vector</span>
                    <span className="text-red-400 font-bold tabular-nums">{motionScale.toFixed(1)}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="10.0"
                    step="0.1"
                    value={motionScale}
                    onChange={(e) => setMotionScale(parseFloat(e.target.value))}
                    className="w-full accent-red-600 cursor-pointer h-1.5 bg-neutral-800 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[10px] text-neutral-600 font-mono mt-1">
                    <span>Static Tripod (0.5x)</span>
                    <span>Kinetic Chase (10.0x)</span>
                  </div>
                </div>

                {/* Param 2: Guidance / Latent Coherence */}
                <div>
                  <div className="flex items-center justify-between text-xs font-mono mb-2">
                    <span className="text-neutral-400">Latent Guidance (CFG)</span>
                    <span className="text-red-400 font-bold tabular-nums">{guidanceScale.toFixed(1)}</span>
                  </div>
                  <input
                    type="range"
                    min="1.0"
                    max="15.0"
                    step="0.1"
                    value={guidanceScale}
                    onChange={(e) => setGuidanceScale(parseFloat(e.target.value))}
                    className="w-full accent-red-600 cursor-pointer h-1.5 bg-neutral-800 rounded-lg appearance-none"
                  />
                  <div className="flex justify-between text-[10px] text-neutral-600 font-mono mt-1">
                    <span>Abstract Flow (1.0)</span>
                    <span>Strict Direction (15.0)</span>
                  </div>
                </div>

                {/* Param 3: Seed & Randomize */}
                <div>
                  <div className="flex items-center justify-between text-xs font-mono mb-2">
                    <span className="text-neutral-400">Deterministic Seed</span>
                    <button
                      type="button"
                      onClick={handleRandomizeSeed}
                      className="flex items-center gap-1.5 text-neutral-400 hover:text-white transition-colors"
                    >
                      <Dices className="w-3.5 h-3.5 text-red-400" />
                      <span>Randomize</span>
                    </button>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={seed}
                      onChange={(e) => setSeed(parseInt(e.target.value) || 0)}
                      className="w-full px-3 py-1.5 bg-[#0e0d14] border border-white/10 rounded-md text-xs font-mono text-neutral-200 tabular-nums focus:outline-none focus:border-red-500/60"
                    />
                  </div>
                </div>

                {/* Param 4: Film Stock Emulsion & Aspect Ratio */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-[11px] font-mono text-neutral-400 mb-1.5">
                      Film Emulsion
                    </label>
                    <select
                      value={activeEmulsion}
                      onChange={(e) => setActiveEmulsion(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-[#0e0d14] border border-white/10 rounded-md text-xs font-mono text-neutral-300 focus:outline-none focus:border-red-500/60"
                    >
                      <option value="Kodak Vision3 5219">Kodak Vision3 5219</option>
                      <option value="Fuji Eterna 8553">Fuji Eterna 8553</option>
                      <option value="Eastman Double-X">Eastman Double-X</option>
                      <option value="Spectral Resonator v2">Spectral Resonator</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-neutral-400 mb-1.5">
                      Aspect Ratio
                    </label>
                    <div className="flex gap-1">
                      {['16:9', '1:1', '4:3', '9:16'].map((r) => (
                        <button
                          key={r}
                          type="button"
                          onClick={() => setActiveRatio(r)}
                          className={`flex-1 py-1.5 text-[11px] font-mono rounded border transition-colors ${
                            activeRatio === r
                              ? 'bg-red-950/60 border-red-500/60 text-white'
                              : 'bg-[#0e0d14] border-white/10 text-neutral-400 hover:text-white'
                          }`}
                        >
                          {r}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Render Action Button */}
              <div className="pt-4 border-t border-white/[0.08]">
                {isRendering ? (
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-red-400 animate-pulse">{renderStep}</span>
                      <span className="text-white font-bold tabular-nums">{renderProgress}%</span>
                    </div>
                    <div className="w-full h-2 bg-neutral-900 rounded-full overflow-hidden border border-white/10">
                      <div
                        className="h-full bg-gradient-to-r from-red-600 via-rose-500 to-red-400 transition-all duration-300 shadow-[0_0_12px_#dc2626]"
                        style={{ width: `${renderProgress}%` }}
                      />
                    </div>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={handleStartRender}
                    className="w-full group relative inline-flex items-center justify-center gap-2.5 px-6 py-3 text-xs font-bold tracking-wider uppercase font-mono text-white bg-gradient-to-r from-red-700 via-red-600 to-rose-700 hover:from-red-600 hover:to-rose-600 rounded-lg shadow-[0_0_25px_rgba(220,38,38,0.4)] hover:shadow-[0_0_35px_rgba(225,29,72,0.6)] transition-all"
                  >
                    <Sparkles className="w-4 h-4 text-red-200 group-hover:rotate-12 transition-transform" />
                    <span>Compile Neural Pass</span>
                  </button>
                )}
              </div>
            </div>

            {/* Right Display Viewport */}
            <div className="lg:col-span-7 p-6 bg-[#040306] flex flex-col justify-between relative">
              {/* Top Viewport Toolbar */}
              <div className="flex items-center justify-between mb-4 z-10">
                <div className="flex items-center gap-2 text-xs font-mono text-neutral-400">
                  <span className="px-2 py-0.5 rounded bg-black/60 border border-white/10 text-white font-bold">
                    CANVAS 01
                  </span>
                  <span>{activePreset.ratio}</span>
                  <span aria-hidden="true" className="text-neutral-700">·</span>
                  <span>{activePreset.fps} FPS</span>
                </div>

                {/* Layer toggle buttons */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setShowGrain(!showGrain)}
                    className={`px-2.5 py-1 text-[11px] font-mono rounded border transition-colors ${
                      showGrain
                        ? 'bg-red-950/50 border-red-500/40 text-red-300'
                        : 'bg-black/40 border-white/10 text-neutral-500 hover:text-neutral-300'
                    }`}
                  >
                    Grain
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowGrid(!showGrid)}
                    className={`px-2.5 py-1 text-[11px] font-mono rounded border transition-colors ${
                      showGrid
                        ? 'bg-red-950/50 border-red-500/40 text-red-300'
                        : 'bg-black/40 border-white/10 text-neutral-500 hover:text-neutral-300'
                    }`}
                  >
                    Framing
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowDepth(!showDepth)}
                    className={`px-2.5 py-1 text-[11px] font-mono rounded border transition-colors ${
                      showDepth
                        ? 'bg-red-950/50 border-red-500/40 text-red-300'
                        : 'bg-black/40 border-white/10 text-neutral-500 hover:text-neutral-300'
                    }`}
                  >
                    Depth Map
                  </button>
                </div>
              </div>

              {/* Main Visual Display Frame */}
              <div className="relative flex-1 min-h-[360px] rounded-xl overflow-hidden border border-white/10 bg-black flex items-center justify-center group">
                <img
                  src={activePreset.image}
                  alt={activePreset.label}
                  referrerPolicy="no-referrer"
                  className={`w-full h-full object-cover transition-transform duration-700 ${
                    isPlaying ? 'scale-[1.03]' : 'scale-100'
                  } ${showDepth ? 'invert hue-rotate-180 contrast-200' : ''}`}
                />

                {/* Film grain overlay */}
                {showGrain && (
                  <div className="absolute inset-0 bg-grain opacity-75 mix-blend-overlay pointer-events-none" />
                )}

                {/* Cinematic Framing Grid Overlay */}
                {showGrid && (
                  <div className="absolute inset-0 border border-red-500/30 grid grid-cols-3 grid-rows-3 pointer-events-none">
                    <div className="border-r border-b border-red-500/20" />
                    <div className="border-r border-b border-red-500/20" />
                    <div className="border-b border-red-500/20" />
                    <div className="border-r border-b border-red-500/20" />
                    <div className="border-r border-b border-red-500/20" />
                    <div className="border-b border-red-500/20" />
                    <div className="border-r border-red-500/20" />
                    <div className="border-r border-red-500/20" />
                    <div />
                  </div>
                )}

                {/* Bottom Left Frame Timecode */}
                <div className="absolute bottom-4 left-4 z-10 px-2.5 py-1 rounded bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-mono text-white flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                  <span>00:03:14:{(timelineProgress % 24).toString().padStart(2, '0')}</span>
                </div>

                {/* Bottom Right Emulsion Tag */}
                <div className="absolute bottom-4 right-4 z-10 px-2.5 py-1 rounded bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-mono text-red-300">
                  {activeEmulsion}
                </div>
              </div>

              {/* Viewport Playback & Timeline Scrubber Bar */}
              <div className="mt-4 pt-4 border-t border-white/[0.08] flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-8 h-8 rounded-lg bg-neutral-900 border border-white/10 flex items-center justify-center text-white hover:text-red-400 hover:border-red-500/40 transition-colors"
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 translate-x-0.5" />}
                </button>

                {/* Timeline Scrubber */}
                <div className="flex-1 flex items-center gap-3">
                  <span className="text-[11px] font-mono text-neutral-500 tabular-nums">00:00</span>
                  <div
                    onClick={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      const clickX = e.clientX - rect.left;
                      setTimelineProgress(Math.round((clickX / rect.width) * 100));
                    }}
                    className="relative flex-1 h-2 bg-neutral-900 rounded-full cursor-pointer overflow-hidden border border-white/10"
                  >
                    <div
                      className="h-full bg-red-600 transition-all duration-75"
                      style={{ width: `${timelineProgress}%` }}
                    />
                  </div>
                  <span className="text-[11px] font-mono text-neutral-400 tabular-nums">00:05</span>
                </div>

                {/* Download / Export Action */}
                <a
                  href={activePreset.image}
                  download="vesper-master-render.jpg"
                  className="p-2 rounded-lg bg-neutral-900 border border-white/10 text-neutral-400 hover:text-white hover:border-red-500/40 transition-colors"
                  title="Export Current Master Frame"
                >
                  <Download className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
