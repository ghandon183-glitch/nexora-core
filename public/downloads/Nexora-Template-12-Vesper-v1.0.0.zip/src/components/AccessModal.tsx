import React, { useState } from 'react';
import { X, CheckCircle2, Key, Sparkles, Download, ArrowRight, ShieldCheck } from 'lucide-react';

interface AccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPlan?: string;
  onLaunchStudio: () => void;
}

export const AccessModal: React.FC<AccessModalProps> = ({
  isOpen,
  onClose,
  selectedPlan = 'Studio Master',
  onLaunchStudio,
}) => {
  const [email, setEmail] = useState('');
  const [studioName, setStudioName] = useState('');
  const [pipelineRole, setPipelineRole] = useState('Director / Cinematographer');
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div 
        className="relative w-full max-w-lg rounded-2xl bg-[#0b0a11] border border-red-600/40 p-6 sm:p-8 shadow-[0_0_80px_rgba(220,38,38,0.35)] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Ambient background bloom */}
        <div 
          className="absolute -top-20 -right-20 w-60 h-60 bg-red-900/30 rounded-full blur-[90px] pointer-events-none" 
          aria-hidden="true" 
        />

        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-lg bg-white/[0.05] border border-white/10 text-neutral-400 hover:text-white hover:border-red-500/40 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {submitted ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-14 h-14 rounded-full bg-red-950/80 border border-red-500/60 flex items-center justify-center text-red-400 mx-auto shadow-[0_0_20px_rgba(220,38,38,0.4)]">
              <CheckCircle2 className="w-7 h-7" />
            </div>

            <h3 className="text-xl font-bold text-white font-['Syne',sans-serif]">
              Studio Provisioning Complete
            </h3>

            <p className="text-xs text-neutral-300 font-mono leading-relaxed max-w-sm mx-auto">
              Your dedicated tenant enclave for <span className="text-red-400 font-semibold">{studioName || 'Your Studio'}</span> ({selectedPlan}) is primed with 6,000 initial compute credits.
            </p>

            <div className="pt-4 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onLaunchStudio();
                }}
                className="w-full py-3 text-xs font-mono font-bold uppercase tracking-wider bg-gradient-to-r from-red-700 via-red-600 to-rose-700 hover:from-red-600 hover:to-rose-600 text-white rounded-lg shadow-[0_0_25px_rgba(220,38,38,0.5)] transition-all"
              >
                Launch Studio Workspace Now
              </button>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 text-xs font-mono text-neutral-400 hover:text-white transition-colors"
              >
                Return to Product Overview
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-red-400 uppercase tracking-widest mb-2">
              <Key className="w-3.5 h-3.5" />
              <span>Production Key Request</span>
            </div>

            <h3 className="text-2xl font-bold text-white font-['Syne',sans-serif] mb-2">
              Access Vesper Operating System
            </h3>

            <p className="text-xs text-neutral-400 mb-6 font-normal">
              Configure dedicated compute for <span className="text-red-300 font-mono font-medium">{selectedPlan}</span>.
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1.5">
                  Studio / Production Company
                </label>
                <input
                  type="text"
                  required
                  value={studioName}
                  onChange={(e) => setStudioName(e.target.value)}
                  placeholder="e.g. Obscura Cinematics"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#07060b] border border-white/10 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500/80 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1.5">
                  Professional Email Address
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="lead@studio.com"
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#07060b] border border-white/10 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-red-500/80 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-neutral-300 mb-1.5">
                  Pipeline Role
                </label>
                <select
                  value={pipelineRole}
                  onChange={(e) => setPipelineRole(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg bg-[#07060b] border border-white/10 text-xs text-neutral-200 focus:outline-none focus:border-red-500/80 font-mono"
                >
                  <option value="Director / Cinematographer">Director / Cinematographer</option>
                  <option value="VFX Supervisor">VFX Supervisor</option>
                  <option value="Creative Director (Agency)">Creative Director (Agency)</option>
                  <option value="Virtual Production TD">Virtual Production TD</option>
                  <option value="Sound Architect / Composer">Sound Architect / Composer</option>
                </select>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full group inline-flex items-center justify-center gap-2 py-3.5 text-xs font-mono font-bold uppercase tracking-wider text-white bg-gradient-to-r from-red-700 via-red-600 to-rose-700 hover:from-red-600 hover:to-rose-600 rounded-lg shadow-[0_0_25px_rgba(220,38,38,0.5)] transition-all"
                >
                  <span>Authorize & Issue Private Key</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              <div className="flex items-center justify-center gap-2 text-[10px] font-mono text-neutral-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-red-500" />
                <span>Instant provisioning · Zero training retention contract</span>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
