import React from 'react';
import { HOW_IT_WORKS_STEPS } from '../data/vesperData';
import { Sliders, GitMerge, Video } from 'lucide-react';

const STEP_ICONS = [Sliders, GitMerge, Video];

export const HowItWorks: React.FC = () => {
  return (
    <section id="process" className="relative py-28 bg-[#07060a] border-t border-white/[0.06] overflow-hidden">
      {/* Ambient background glows */}
      <div 
        className="absolute top-1/2 -right-32 w-96 h-96 bg-red-950/25 rounded-full blur-[120px] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="relative max-w-7xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="max-w-2xl mb-20">
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-red-500 font-mono mb-3">
            <span>Directorial Workflow</span>
            <span aria-hidden="true">·</span>
            <span>Three-Tier Conduction</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white font-['Syne',sans-serif] leading-tight mb-5">
            FROM SCRIPT VECTOR TO CINEMA MASTER.
          </h2>
          <p className="text-base sm:text-lg text-neutral-400 leading-relaxed font-normal">
            Eliminate non-deterministic chaos. Work with spatial precision across every step of your production timeline.
          </p>
        </div>

        {/* 3 Steps */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {HOW_IT_WORKS_STEPS.map((item, idx) => {
            const Icon = STEP_ICONS[idx];
            return (
              <div
                key={item.step}
                className="relative p-8 rounded-xl bg-[#0b0a0f] border border-white/[0.08] hover:border-red-900/40 hover:bg-[#100d17] transition-all duration-300 flex flex-col justify-between group"
              >
                <div>
                  {/* Step Index & Icon */}
                  <div className="flex items-center justify-between mb-8">
                    <span className="text-3xl font-extrabold font-['Syne',sans-serif] text-neutral-700 group-hover:text-red-500 transition-colors">
                      {item.step}
                    </span>
                    <div className="w-10 h-10 rounded-lg bg-neutral-900 border border-white/10 group-hover:border-red-600/40 flex items-center justify-center text-neutral-400 group-hover:text-red-400 transition-colors">
                      <Icon className="w-5 h-5" />
                    </div>
                  </div>

                  {/* Title & Subtitle */}
                  <h3 className="text-xl font-bold text-white font-['Syne',sans-serif] mb-1.5">
                    {item.title}
                  </h3>
                  <div className="text-xs font-mono text-red-400 mb-4">
                    {item.subtitle}
                  </div>

                  {/* Description */}
                  <p className="text-sm text-neutral-400 leading-relaxed font-normal mb-8">
                    {item.description}
                  </p>
                </div>

                {/* Highlight anchor */}
                <div className="pt-4 border-t border-white/[0.06] text-xs font-mono text-neutral-400 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500" />
                  <span>{item.highlight}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
