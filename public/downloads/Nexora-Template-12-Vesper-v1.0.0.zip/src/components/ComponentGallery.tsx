import React, { useState } from 'react';
import { Activity, Bell, Check, ChevronRight, Command, Copy, Download, Search, Sparkles } from 'lucide-react';

const navItems = ['Buttons', 'Forms', 'Cards', 'Status', 'Tables'];

export function ComponentGallery() {
  const [active, setActive] = useState('Buttons');
  const [copied, setCopied] = useState(false);

  function copyToken() {
    navigator.clipboard?.writeText('--vesper-accent: #e11d48;');
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1400);
  }

  return (
    <section id="ui-kit" className="relative border-y border-white/[0.07] bg-[#07070b] py-28 sm:py-36">
      <div className="mx-auto max-w-7xl px-6 sm:px-8">
        <div className="max-w-3xl">
          <div className="mb-4 flex items-center gap-2 text-xs font-mono uppercase tracking-[0.2em] text-red-400"><Command size={14} /> UI / 01</div>
          <h2 className="font-['Syne',sans-serif] text-4xl font-bold tracking-tight text-white sm:text-6xl">A product-grade UI kit.</h2>
          <p className="mt-6 text-base leading-8 text-neutral-400 sm:text-lg">Vesper is not only a landing page. This section demonstrates the reusable interaction language shipped with the template: controls, states, cards, forms, tables, notifications, and application chrome.</p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-[220px_1fr]">
          <aside className="rounded-2xl border border-white/[0.08] bg-white/[0.025] p-3">
            {navItems.map((item) => (
              <button key={item} type="button" onClick={() => setActive(item)} className={`mb-1 flex w-full items-center justify-between rounded-xl px-4 py-3 text-left text-sm transition ${active === item ? 'bg-red-500/10 text-white ring-1 ring-red-500/30' : 'text-neutral-500 hover:bg-white/[0.04] hover:text-neutral-200'}`}>
                {item}<ChevronRight size={14} />
              </button>
            ))}
            <div className="mt-6 rounded-xl border border-white/[0.06] bg-black/30 p-4 text-xs text-neutral-500"><div className="mb-2 flex items-center gap-2 text-neutral-300"><Sparkles size={14} /> Design tokens</div><code className="break-all text-red-300/80">--vesper-accent: #e11d48;</code><button onClick={copyToken} type="button" className="mt-3 flex items-center gap-2 text-neutral-400 hover:text-white">{copied ? <Check size={13} /> : <Copy size={13} />}{copied ? 'Copied' : 'Copy token'}</button></div>
          </aside>

          <div className="min-h-[420px] rounded-2xl border border-white/[0.08] bg-[#0a090f] p-6 sm:p-8">
            {active === 'Buttons' && <div className="space-y-8"><div><p className="mb-4 text-xs font-mono uppercase tracking-widest text-neutral-500">Primary actions</p><div className="flex flex-wrap gap-3"><button className="rounded-lg bg-gradient-to-r from-red-700 to-rose-700 px-5 py-3 text-xs font-bold uppercase tracking-wider text-white">Generate preview</button><button className="rounded-lg border border-white/10 bg-white/[0.04] px-5 py-3 text-xs font-bold uppercase tracking-wider text-neutral-200">Secondary action</button><button className="rounded-lg border border-red-500/20 px-5 py-3 text-xs font-bold uppercase tracking-wider text-red-300">Destructive</button></div></div><div className="grid gap-4 sm:grid-cols-3"><div className="rounded-xl border border-white/[0.07] p-4"><Activity size={16} className="text-red-400" /><p className="mt-3 text-sm text-white">Live state</p><p className="mt-1 text-xs text-neutral-500">Interaction-ready status treatment.</p></div><div className="rounded-xl border border-white/[0.07] p-4"><Bell size={16} className="text-amber-300" /><p className="mt-3 text-sm text-white">Notification</p><p className="mt-1 text-xs text-neutral-500">Operational feedback without noise.</p></div><div className="rounded-xl border border-white/[0.07] p-4"><Download size={16} className="text-cyan-300" /><p className="mt-3 text-sm text-white">Export</p><p className="mt-1 text-xs text-neutral-500">Clear utility actions.</p></div></div></div>}
            {active === 'Forms' && <div className="max-w-2xl space-y-5"><label className="block"><span className="mb-2 block text-xs text-neutral-500">Project name</span><div className="flex items-center gap-3 rounded-xl border border-white/10 bg-black/30 px-4 py-3"><Search size={16} className="text-neutral-600" /><input className="w-full bg-transparent text-sm text-white outline-none" defaultValue="Midnight Campaign" /></div></label><label className="block"><span className="mb-2 block text-xs text-neutral-500">Creative direction</span><textarea className="min-h-32 w-full resize-none rounded-xl border border-white/10 bg-black/30 p-4 text-sm leading-6 text-neutral-200 outline-none focus:border-red-500/50" defaultValue="Cinematic, tactile, restrained contrast, slow camera movement..." /></label><div className="flex items-center justify-between rounded-xl border border-red-500/20 bg-red-500/[0.04] p-4"><div><p className="text-sm text-white">Autosave enabled</p><p className="mt-1 text-xs text-neutral-500">Demo state — connect your persistence layer.</p></div><div className="h-6 w-11 rounded-full bg-red-600 p-1"><div className="ml-5 h-4 w-4 rounded-full bg-white" /></div></div></div>}
            {active === 'Cards' && <div className="grid gap-4 md:grid-cols-2"><div className="rounded-2xl border border-white/10 bg-black/20 p-5"><div className="aspect-video rounded-xl bg-gradient-to-br from-red-950/70 via-neutral-900 to-black" /><div className="mt-5 flex items-start justify-between"><div><p className="text-sm font-medium text-white">Sequence / 04</p><p className="mt-1 text-xs text-neutral-500">12 shots · Draft</p></div><span className="rounded-full border border-amber-400/20 bg-amber-400/10 px-2.5 py-1 text-[10px] font-mono uppercase text-amber-300">Review</span></div></div><div className="rounded-2xl border border-white/10 bg-black/20 p-5"><div className="flex items-center justify-between"><div><p className="text-sm text-white">Render queue</p><p className="mt-1 text-xs text-neutral-500">3 active jobs</p></div><span className="text-xs font-mono text-emerald-300">84%</span></div><div className="mt-6 h-2 rounded-full bg-white/[0.06]"><div className="h-2 w-[84%] rounded-full bg-gradient-to-r from-red-700 to-rose-500" /></div><div className="mt-6 space-y-3 text-xs"><div className="flex justify-between text-neutral-400"><span>Sequence 04</span><span>Rendering</span></div><div className="flex justify-between text-neutral-500"><span>Sequence 05</span><span>Queued</span></div></div></div></div>}
            {active === 'Status' && <div className="space-y-4"><div className="flex items-center justify-between rounded-xl border border-white/[0.07] p-4"><div><p className="text-sm text-white">Inference gateway</p><p className="mt-1 text-xs text-neutral-500">Demo service status</p></div><span className="flex items-center gap-2 text-xs text-emerald-300"><span className="h-2 w-2 rounded-full bg-emerald-400" />Operational</span></div><div className="flex items-center justify-between rounded-xl border border-white/[0.07] p-4"><div><p className="text-sm text-white">Asset storage</p><p className="mt-1 text-xs text-neutral-500">Demo service status</p></div><span className="flex items-center gap-2 text-xs text-amber-300"><span className="h-2 w-2 rounded-full bg-amber-400" />Degraded</span></div><div className="rounded-xl border border-red-500/20 bg-red-500/[0.04] p-4 text-sm text-red-200">This is demonstration UI. Connect real health checks to your backend.</div></div>}
            {active === 'Tables' && <div className="overflow-x-auto rounded-xl border border-white/[0.07]"><table className="w-full min-w-[560px] text-left text-sm"><thead className="bg-white/[0.025] text-xs uppercase tracking-wider text-neutral-500"><tr><th className="p-4">Asset</th><th className="p-4">Status</th><th className="p-4">Updated</th><th className="p-4">Owner</th></tr></thead><tbody className="divide-y divide-white/[0.06]"><tr><td className="p-4 text-white">campaign-master.mov</td><td className="p-4 text-emerald-300">Ready</td><td className="p-4 text-neutral-500">2m ago</td><td className="p-4 text-neutral-400">Creative</td></tr><tr><td className="p-4 text-white">lookdev-v03.exr</td><td className="p-4 text-amber-300">Review</td><td className="p-4 text-neutral-500">14m ago</td><td className="p-4 text-neutral-400">Art</td></tr><tr><td className="p-4 text-white">audio-stems.zip</td><td className="p-4 text-cyan-300">Queued</td><td className="p-4 text-neutral-500">31m ago</td><td className="p-4 text-neutral-400">Sound</td></tr></tbody></table></div>}
          </div>
        </div>
      </div>
    </section>
  );
}
