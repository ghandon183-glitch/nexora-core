import React from 'react';
import { ArrowRight, Play, Film, ShieldCheck } from 'lucide-react';
import { Auralis } from './Auralis';

interface HeroProps {
  onEnterStudio: () => void;
  onExploreSpecs: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onEnterStudio, onExploreSpecs }) => {
  return (
    <section className="relative min-h-[92vh] lg:min-h-screen flex items-center justify-center overflow-hidden pt-20 pb-16">
      {/* Fullscreen Auralis WebGL Ambient Background */}
      <div className="absolute inset-0 z-0">
        <Auralis 
          intensity={1.15}
          speed={0.28}
          grain={0.58}
          colors={["#ef4444", "#dc2626", "#7f1d1d"]}
          height="100%"
        />
      </div>

      {/* Atmospheric center vignette scrim for high contrast legibility */}
      <div 
        className="absolute inset-0 z-0 pointer-events-none bg-radial from-transparent via-[#050507]/40 to-[#050507]/90" 
        aria-hidden="true" 
      />

      {/* Hero Content Container - Perfectly Centered */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 sm:px-8 text-center flex flex-col items-center justify-center">
        {/* Editorial Trust Kicker (clean unboxed text with typographic separators) */}
        <div className="flex items-center justify-center gap-2 text-xs uppercase tracking-widest text-neutral-400 mb-6 font-mono">
          <span className="text-red-400 font-semibold">Vesper 3.0</span>
          <span aria-hidden="true" className="text-neutral-600">·</span>
          <span>Next-Gen Neural Cinema</span>
          <span aria-hidden="true" className="text-neutral-600">·</span>
          <span>GPU render demo</span>
        </div>

        {/* Master Cinematic Display Headline */}
        <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-bold tracking-tight text-white font-['Syne',sans-serif] leading-[1.05] max-w-4xl text-balance mb-6 drop-shadow-2xl">
          THE GENERATIVE DIRECTING SYSTEM FOR{' '}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-rose-300 to-red-500">
            CINEMATIC REALITY.
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-base sm:text-lg md:text-xl text-neutral-300 max-w-2xl mx-auto leading-relaxed mb-10 font-normal">
          Synthesize high-fidelity moving pictures, neural spatial acoustics, and multi-layered latent worlds with absolute director control. Zero character drift. Photochemical grain precision.
        </p>

        {/* Dual CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto mb-12">
          {/* Primary CTA */}
          <button
            type="button"
            onClick={onEnterStudio}
            className="w-full sm:w-auto group relative inline-flex items-center justify-center gap-3 px-8 py-3.5 text-sm font-semibold tracking-wide text-white bg-gradient-to-r from-red-700 via-red-600 to-rose-700 rounded-lg shadow-[0_0_35px_rgba(220,38,38,0.5)] hover:shadow-[0_0_50px_rgba(225,29,72,0.7)] hover:scale-[1.02] active:scale-[0.98] transition-all duration-200"
          >
            <span>Enter Creative Studio</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Secondary CTA */}
          <button
            type="button"
            onClick={onExploreSpecs}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm font-medium text-neutral-200 hover:text-white bg-neutral-900/60 hover:bg-neutral-800/80 border border-white/10 hover:border-red-500/40 rounded-lg backdrop-blur-sm transition-all duration-200"
          >
            <Film className="w-4 h-4 text-red-400" />
            <span>Explore the showreel</span>
          </button>
        </div>

        {/* Technical Specification Badges / Adjacency */}
        <div className="flex flex-wrap items-center justify-center gap-y-2 gap-x-6 text-xs text-neutral-400 font-mono">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
            <span>ProRes export demo</span>
          </div>
          <span aria-hidden="true" className="text-neutral-700">|</span>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]" />
            <span>ACES color workflow demo</span>
          </div>
          <span aria-hidden="true" className="text-neutral-700">|</span>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-neutral-400" />
            <span>Multi-stem export demo</span>
          </div>
        </div>
      </div>

      {/* Subtle gradient fade at the bottom of the hero to blend seamlessly into next section */}
      <div 
        className="absolute bottom-0 left-0 right-0 h-36 bg-gradient-to-t from-[#050507] via-[#050507]/75 to-transparent pointer-events-none z-10" 
        aria-hidden="true" 
      />
    </section>
  );
};
