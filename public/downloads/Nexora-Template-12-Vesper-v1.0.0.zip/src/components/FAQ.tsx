import React, { useState } from 'react';
import { FAQ_DATA } from '../data/vesperData';
import { Plus, Minus, HelpCircle } from 'lucide-react';

export const FAQ: React.FC = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIdx(openIdx === idx ? null : idx);
  };

  return (
    <section className="relative py-28 bg-[#050507] border-t border-white/[0.06] overflow-hidden">
      {/* Background crimson ambient lighting */}
      <div 
        className="absolute bottom-1/4 -right-20 w-80 h-80 bg-red-950/20 rounded-full blur-[140px] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="relative max-w-4xl mx-auto px-6 sm:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-2 text-xs uppercase tracking-widest text-red-500 font-mono mb-3">
            <span>Engineering Architecture</span>
            <span aria-hidden="true">·</span>
            <span>Production Clarity</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white font-['Syne',sans-serif] leading-tight mb-4">
            FREQUENTLY CLARIFIED SPECIFICATIONS.
          </h2>
          <p className="text-sm sm:text-base text-neutral-400 font-normal">
            Everything your technical director and legal team need to verify before deployment.
          </p>
        </div>

        {/* Accordion List */}
        <div className="space-y-4">
          {FAQ_DATA.map((faq, idx) => {
            const isOpen = openIdx === idx;

            return (
              <div
                key={idx}
                className={`rounded-xl border transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'bg-[#0c0a13] border-red-600/40 shadow-[0_0_20px_rgba(220,38,38,0.15)]'
                    : 'bg-[#08070c] border-white/[0.08] hover:border-white/20'
                }`}
              >
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="w-full px-6 py-5 flex items-center justify-between text-left gap-4 transition-colors"
                >
                  <span className="text-base sm:text-lg font-semibold text-white font-['Syne',sans-serif]">
                    {faq.question}
                  </span>
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center border transition-all shrink-0 ${
                    isOpen 
                      ? 'bg-red-950/70 border-red-500/50 text-red-300' 
                      : 'bg-white/[0.04] border-white/10 text-neutral-400'
                  }`}>
                    {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  </div>
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 pt-1 text-sm text-neutral-400 leading-relaxed font-normal border-t border-white/[0.04]">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
