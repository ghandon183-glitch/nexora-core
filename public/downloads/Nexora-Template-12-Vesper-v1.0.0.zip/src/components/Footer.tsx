import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="relative py-16 bg-[#040306] border-t border-white/[0.08] text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10 mb-14">
          {/* Brand Column */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5 text-lg font-bold tracking-widest uppercase font-['Syne',sans-serif] text-white">
              <div className="w-2 h-2 rounded-full bg-red-600 shadow-[0_0_10px_#dc2626]" />
              <span>VESPER</span>
            </div>
            <p className="text-neutral-400 text-xs leading-relaxed max-w-sm font-normal">
              The high-fidelity generative directing system. Deterministic temporal consistency, neural photochemical emulation, and lossless spatial acoustics.
            </p>
            <div className="flex items-center gap-2 font-mono text-[11px] text-neutral-400 pt-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>Global Compute Clusters Nominal · 12.8ms Latency</span>
            </div>
          </div>

          {/* Column 1: Platform */}
          <div className="space-y-3 font-mono">
            <div className="text-white font-semibold text-xs tracking-wider uppercase">
              Platform
            </div>
            <ul className="space-y-2">
              <li><a href="#capabilities" className="hover:text-red-400 transition-colors">Temporal Coherence</a></li>
              <li><a href="#capabilities" className="hover:text-red-400 transition-colors">Neural Emulsion</a></li>
              <li><a href="#capabilities" className="hover:text-red-400 transition-colors">Harmonic Audio</a></li>
              <li><a href="#showcase" className="hover:text-red-400 transition-colors">Studio Console</a></li>
              <li><a href="#pricing" className="hover:text-red-400 transition-colors">Compute / infrastructure UI</a></li>
            </ul>
          </div>

          {/* Column 2: Pipelines */}
          <div className="space-y-3 font-mono">
            <div className="text-white font-semibold text-xs tracking-wider uppercase">
              Pipelines
            </div>
            <ul className="space-y-2">
              <li><a href="#use-cases" className="hover:text-red-400 transition-colors">NLE integration placeholder</a></li>
              <li><a href="#use-cases" className="hover:text-red-400 transition-colors">ProRes export demo</a></li>
              <li><a href="#use-cases" className="hover:text-red-400 transition-colors">OpenEXR multi-pass demo</a></li>
              <li><a href="#use-cases" className="hover:text-red-400 transition-colors">ACES 1.3 Color Space</a></li>
              <li><a href="#use-cases" className="hover:text-red-400 transition-colors">Realtime integration placeholder</a></li>
            </ul>
          </div>

          {/* Column 3: Governance */}
          <div className="space-y-3 font-mono">
            <div className="text-white font-semibold text-xs tracking-wider uppercase">
              Governance
            </div>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-red-400 transition-colors">License & ownership notes</a></li>
              <li><a href="#" className="hover:text-red-400 transition-colors">Data policy placeholder</a></li>
              <li><a href="#" className="hover:text-red-400 transition-colors">Security documentation placeholder</a></li>
              <li><a href="#" className="hover:text-red-400 transition-colors">Security Architecture</a></li>
              <li><a href="#" className="hover:text-red-400 transition-colors">Terms of Production</a></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/[0.06] flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] font-mono text-neutral-400">
          <div>
            © {new Date().getFullYear()} Vesper Template All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <span className="text-neutral-400">Designed for cinematic color workflows</span>
            <span aria-hidden="true" className="text-neutral-700">·</span>
            <span className="text-neutral-400">Demo brand · replace with yours</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
