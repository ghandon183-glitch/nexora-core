import React, { useState, useEffect } from 'react';
import { 
  Play, Pause, Sliders, Sparkles, Layers, Video, Music, Image as ImageIcon,
  RotateCcw, Download, Eye, Film, Camera, SplitSquareVertical, 
  ChevronRight, ArrowLeft, Volume2, ShieldCheck, Check, Settings
} from 'lucide-react';
import { ASSETS } from '../data/assets';

interface StudioWorkspaceProps {
  onBackToLanding: () => void;
}

type ToolTab = 'video' | 'camera' | 'emulsion' | 'audio' | 'layers';

export const StudioWorkspace: React.FC<StudioWorkspaceProps> = ({ onBackToLanding }) => {
  const [activeTool, setActiveTool] = useState<ToolTab>('video');
  const [selectedAsset, setSelectedAsset] = useState<string>(ASSETS.videoFrame);
  const [isPlaying, setIsPlaying] = useState(true);
  const [timelineSec, setTimelineSec] = useState(3.4);
  const [compareMode, setCompareMode] = useState(false);
  const [compareSlider, setCompareSlider] = useState(50);
  
  // Directorial parameters
  const [prompt, setPrompt] = useState(
    'Wide anamorphic 35mm tracking shot, solitary protagonist walking toward ancient glowing ruby-red monolith in obsidian rain, Kodak Vision3 5219 grain, volumetric crimson lighting.'
  );
  const [cameraVector, setCameraVector] = useState('Dolly Forward + Slow Dutch Tilt (15°)');
  const [focalLength, setFocalLength] = useState('35mm Anamorphic');
  const [emulsionProfile, setEmulsionProfile] = useState('Kodak Vision3 5219');
  const [motionIntensity, setMotionIntensity] = useState(6.8);
  const [seed, setSeed] = useState(8492014);

  // Render status
  const [isCompiling, setIsCompiling] = useState(false);
  const [compileProgress, setCompileProgress] = useState(0);
  const [compileLog, setCompileLog] = useState('');

  // Handle compile simulation
  const handleCompile = () => {
    if (isCompiling) return;
    setIsCompiling(true);
    setCompileProgress(0);
    setCompileLog('Allocating Tensor Nodes on Cluster #4...');

    const logs = [
      { progress: 25, msg: 'Evaluating Recurrent Temporal Vectors...' },
      { progress: 55, msg: 'Denoising Latent Latice (Step 14/25)...' },
      { progress: 85, msg: 'Conforming Photochemical Halation & ACEScg LUT...' },
      { progress: 100, msg: 'Master Ready (ProRes export demo)' },
    ];

    let i = 0;
    const interval = setInterval(() => {
      if (i < logs.length) {
        setCompileProgress(logs[i].progress);
        setCompileLog(logs[i].msg);
        i++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setIsCompiling(false);
        }, 500);
      }
    }, 450);
  };

  // Timeline playback simulation
  useEffect(() => {
    if (!isPlaying || isCompiling) return;
    const interval = setInterval(() => {
      setTimelineSec((prev) => (prev >= 10.0 ? 0.0 : +(prev + 0.08).toFixed(2)));
    }, 80);
    return () => clearInterval(interval);
  }, [isPlaying, isCompiling]);

  return (
    <div className="fixed inset-0 z-50 bg-[#050507] text-[#e2e2e8] flex flex-col font-sans select-none overflow-hidden">
      {/* Top Header Bar */}
      <header className="h-14 bg-[#0a090f] border-b border-white/[0.08] px-4 flex items-center justify-between z-20">
        <div className="flex items-center gap-4">
          <button
            type="button"
            onClick={onBackToLanding}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/[0.04] border border-white/10 text-xs font-mono text-neutral-300 hover:text-white hover:bg-white/[0.08] transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Landing</span>
          </button>

          <div className="h-4 w-px bg-white/10" />

          {/* Project Title */}
          <div className="flex items-center gap-2.5">
            <div className="w-2 h-2 rounded-full bg-red-600 shadow-[0_0_10px_#dc2626]" />
            <span className="font-['Syne',sans-serif] font-bold text-white text-sm tracking-wider uppercase">
              VESPER OS
            </span>
            <span className="text-xs font-mono text-neutral-400">/ SEQ_08_MONOLITH_DAWN</span>
          </div>
        </div>

        {/* Top Center: View Modes */}
        <div className="hidden md:flex items-center gap-1 p-1 bg-black/60 border border-white/[0.08] rounded-lg text-xs font-mono">
          <button
            type="button"
            onClick={() => {
              setSelectedAsset(ASSETS.videoFrame);
              setActiveTool('video');
            }}
            className={`px-3 py-1 rounded transition-colors ${
              selectedAsset === ASSETS.videoFrame ? 'bg-red-950/70 border border-red-500/50 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Cinema Video
          </button>
          <button
            type="button"
            onClick={() => {
              setSelectedAsset(ASSETS.showcasePortrait);
              setActiveTool('camera');
            }}
            className={`px-3 py-1 rounded transition-colors ${
              selectedAsset === ASSETS.showcasePortrait ? 'bg-red-950/70 border border-red-500/50 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Cybernetic Still
          </button>
          <button
            type="button"
            onClick={() => {
              setSelectedAsset(ASSETS.fashionPrevis);
              setActiveTool('emulsion');
            }}
            className={`px-3 py-1 rounded transition-colors ${
              selectedAsset === ASSETS.fashionPrevis ? 'bg-red-950/70 border border-red-500/50 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Haute Drape
          </button>
          <button
            type="button"
            onClick={() => {
              setSelectedAsset(ASSETS.audioVisual);
              setActiveTool('audio');
            }}
            className={`px-3 py-1 rounded transition-colors ${
              selectedAsset === ASSETS.audioVisual ? 'bg-red-950/70 border border-red-500/50 text-white' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Acoustic Synth
          </button>
        </div>

        {/* Top Right: Status & Actions */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-neutral-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>GPU node online · demo</span>
          </div>

          <button
            type="button"
            onClick={handleCompile}
            className="flex items-center gap-2 px-3.5 py-1.5 bg-gradient-to-r from-red-700 to-rose-700 hover:from-red-600 hover:to-rose-600 text-white rounded-md text-xs font-mono font-bold uppercase shadow-[0_0_15px_rgba(220,38,38,0.4)] transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isCompiling ? 'Rendering...' : 'Compile Master'}</span>
          </button>
        </div>
      </header>

      {/* Main Studio Body Workspace */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Vertical Tool Rail */}
        <div className="w-14 bg-[#08070c] border-r border-white/[0.08] flex flex-col items-center py-4 gap-4 z-10 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTool('video')}
            className={`p-2.5 rounded-lg transition-colors ${
              activeTool === 'video' ? 'bg-red-950/80 text-red-400 border border-red-600/50' : 'text-neutral-500 hover:text-white'
            }`}
            title="Video Synthesis"
          >
            <Video className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => setActiveTool('camera')}
            className={`p-2.5 rounded-lg transition-colors ${
              activeTool === 'camera' ? 'bg-red-950/80 text-red-400 border border-red-600/50' : 'text-neutral-500 hover:text-white'
            }`}
            title="Camera Vectors"
          >
            <Camera className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => setActiveTool('emulsion')}
            className={`p-2.5 rounded-lg transition-colors ${
              activeTool === 'emulsion' ? 'bg-red-950/80 text-red-400 border border-red-600/50' : 'text-neutral-500 hover:text-white'
            }`}
            title="Neural Emulsion & Color"
          >
            <Film className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => setActiveTool('audio')}
            className={`p-2.5 rounded-lg transition-colors ${
              activeTool === 'audio' ? 'bg-red-950/80 text-red-400 border border-red-600/50' : 'text-neutral-500 hover:text-white'
            }`}
            title="Harmonic Audio Scoring"
          >
            <Music className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={() => setActiveTool('layers')}
            className={`p-2.5 rounded-lg transition-colors ${
              activeTool === 'layers' ? 'bg-red-950/80 text-red-400 border border-red-600/50' : 'text-neutral-500 hover:text-white'
            }`}
            title="Multi-Layer Passes"
          >
            <Layers className="w-5 h-5" />
          </button>

          <div className="mt-auto">
            <button
              type="button"
              className="p-2.5 rounded-lg text-neutral-500 hover:text-white transition-colors"
              title="Pipeline Preferences"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Center Main Stage (Viewport + Timeline) */}
        <div className="flex-1 flex flex-col bg-[#030305] overflow-hidden">
          {/* Viewport Top Ribbon */}
          <div className="h-10 border-b border-white/[0.06] bg-[#07060b] px-4 flex items-center justify-between text-xs font-mono text-neutral-400">
            <div className="flex items-center gap-3">
              <span className="text-white font-semibold">VIEWPORT 01</span>
              <span>·</span>
              <span>3840 × 1608 (2.39:1 Anamorphic)</span>
              <span>·</span>
              <span>24.000 FPS</span>
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setCompareMode(!compareMode)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded border transition-colors ${
                  compareMode ? 'bg-red-950/60 border-red-500/50 text-red-300' : 'bg-black/40 border-white/10 text-neutral-400'
                }`}
              >
                <SplitSquareVertical className="w-3.5 h-3.5" />
                <span>A/B Compare</span>
              </button>

              <span className="text-neutral-600">|</span>

              <a
                href={selectedAsset}
                download="vesper_shot_export.jpg"
                className="flex items-center gap-1.5 text-neutral-400 hover:text-white transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Frame</span>
              </a>
            </div>
          </div>

          {/* Canvas Display Viewport */}
          <div className="flex-1 relative flex items-center justify-center p-6 overflow-hidden bg-black group">
            {/* Ambient subtle crimson halo */}
            <div 
              className="absolute inset-0 bg-radial from-red-950/20 via-transparent to-transparent pointer-events-none" 
              aria-hidden="true" 
            />

            {/* Asset Visual Frame */}
            <div className="relative max-h-full max-w-full aspect-[2.39/1] rounded-lg overflow-hidden border border-white/15 shadow-2xl bg-neutral-950 flex items-center justify-center">
              <img
                src={selectedAsset}
                alt="Active Cinematic Frame"
                className="w-full h-full object-cover select-none"
              />

              {/* Compare Mode Split */}
              {compareMode && (
                <div
                  className="absolute inset-0 overflow-hidden border-r-2 border-red-500 shadow-2xl"
                  style={{ width: `${compareSlider}%` }}
                >
                  <img
                    src={selectedAsset}
                    alt="Compare Pass"
                    className="w-full h-full object-cover max-w-none grayscale contrast-125"
                    style={{ width: '100%', height: '100%' }}
                  />
                  <div className="absolute top-3 left-3 px-2 py-0.5 rounded bg-black/80 font-mono text-[10px] text-white">
                    RAW LOG
                  </div>
                </div>
              )}

              {/* Film Grain Texture */}
              <div className="absolute inset-0 bg-grain opacity-60 mix-blend-overlay pointer-events-none" />

              {/* Viewport Meta Overlays */}
              <div className="absolute top-4 left-4 z-10 px-2.5 py-1 rounded bg-black/70 backdrop-blur-md border border-white/10 font-mono text-[11px] text-neutral-300">
                REC 709 · {emulsionProfile}
              </div>

              <div className="absolute bottom-4 left-4 z-10 px-2.5 py-1 rounded bg-black/70 backdrop-blur-md border border-white/10 font-mono text-[11px] text-white flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
                <span>TC 01:04:12:{Math.floor(timelineSec * 2.4).toString().padStart(2, '0')}</span>
              </div>

              {/* Compiling banner */}
              {isCompiling && (
                <div className="absolute inset-0 bg-black/80 backdrop-blur-sm z-20 flex flex-col items-center justify-center p-6 space-y-4">
                  <div className="w-12 h-12 rounded-full border-2 border-red-600 border-t-transparent animate-spin" />
                  <div className="text-sm font-mono font-bold text-white tracking-wider uppercase">
                    {compileLog}
                  </div>
                  <div className="w-64 h-1.5 bg-neutral-800 rounded-full overflow-hidden border border-white/10">
                    <div
                      className="h-full bg-gradient-to-r from-red-600 to-rose-500 transition-all duration-300"
                      style={{ width: `${compileProgress}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Timeline and Scrubber Panel */}
          <div className="h-44 bg-[#08070c] border-t border-white/[0.08] flex flex-col">
            {/* Timeline Controls Header */}
            <div className="h-10 px-4 border-b border-white/[0.06] flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-7 h-7 rounded bg-white/[0.06] border border-white/10 flex items-center justify-center text-white hover:text-red-400 transition-colors"
                >
                  {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 translate-x-0.5" />}
                </button>

                <div className="text-white font-mono font-bold tabular-nums">
                  00:00:{timelineSec < 10 ? `0${timelineSec.toFixed(2)}` : timelineSec.toFixed(2)} / 00:00:10.00
                </div>
              </div>

              <div className="flex items-center gap-4 text-neutral-400">
                <span>In: 00:00:00</span>
                <span>Out: 00:00:10</span>
                <span>Handles: +12 frames</span>
              </div>
            </div>

            {/* Multi-Track Sequencer Rows */}
            <div className="flex-1 p-2 space-y-1.5 overflow-y-auto font-mono text-[11px]">
              {/* Track 1: Video */}
              <div className="h-7 bg-neutral-900/60 rounded flex items-center px-3 border border-white/[0.05] relative overflow-hidden">
                <span className="w-20 text-neutral-400 font-bold shrink-0">V1 VIDEO</span>
                <div className="flex-1 h-5 bg-red-950/60 border border-red-500/40 rounded flex items-center px-2 text-white relative">
                  <span className="truncate">Seq_08_Monolith_Shot_A.mov (ProRes 4444)</span>
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_8px_#ffffff]"
                    style={{ left: `${(timelineSec / 10) * 100}%` }}
                  />
                </div>
              </div>

              {/* Track 2: Depth Map / Flow */}
              <div className="h-7 bg-neutral-900/60 rounded flex items-center px-3 border border-white/[0.05] relative overflow-hidden">
                <span className="w-20 text-neutral-400 font-bold shrink-0">D1 DEPTH</span>
                <div className="flex-1 h-5 bg-neutral-800/80 border border-white/10 rounded flex items-center px-2 text-neutral-300">
                  <span className="truncate">OpticalFlow_Recurrent_DepthPass.exr</span>
                </div>
              </div>

              {/* Track 3: Audio Stem */}
              <div className="h-7 bg-neutral-900/60 rounded flex items-center px-3 border border-white/[0.05] relative overflow-hidden">
                <span className="w-20 text-neutral-400 font-bold shrink-0">A1 SCORE</span>
                <div className="flex-1 h-5 bg-rose-950/50 border border-rose-500/30 rounded flex items-center px-2 text-rose-200">
                  <span className="truncate">audio-stems-demo.wav</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Inspector Panel */}
        <div className="w-80 bg-[#09080e] border-l border-white/[0.08] p-5 overflow-y-auto space-y-6 shrink-0">
          <div>
            <div className="text-xs font-mono uppercase tracking-widest text-red-500 mb-1">
              Parameters & Optics
            </div>
            <h3 className="text-lg font-bold text-white font-['Syne',sans-serif]">
              Director Inspector
            </h3>
          </div>

          {/* Prompt Directive */}
          <div className="space-y-2">
            <label className="block text-xs font-mono text-neutral-400">
              Prompt Directive
            </label>
            <textarea
              rows={4}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full p-2.5 rounded-lg bg-[#050507] border border-white/10 text-xs text-neutral-200 font-mono focus:outline-none focus:border-red-500/80 resize-none leading-relaxed"
            />
          </div>

          {/* Camera Motion Vector */}
          <div className="space-y-2">
            <label className="block text-xs font-mono text-neutral-400">
              Camera Motion Choreography
            </label>
            <select
              value={cameraVector}
              onChange={(e) => setCameraVector(e.target.value)}
              className="w-full p-2 rounded-lg bg-[#050507] border border-white/10 text-xs font-mono text-neutral-200 focus:outline-none focus:border-red-500/80"
            >
              <option value="Dolly Forward + Slow Dutch Tilt (15°)">Dolly Forward + Slow Dutch Tilt (15°)</option>
              <option value="Orbit 360° Clockwise (Continuous)">Orbit 360° Clockwise (Continuous)</option>
              <option value="Crane Pedestal Drop to Eye-Level">Crane Pedestal Drop to Eye-Level</option>
              <option value="Handheld 35mm Subtle Drift">Handheld 35mm Subtle Drift</option>
            </select>
          </div>

          {/* Optical Focal Length */}
          <div className="space-y-2">
            <label className="block text-xs font-mono text-neutral-400">
              Optical Lens Profile
            </label>
            <select
              value={focalLength}
              onChange={(e) => setFocalLength(e.target.value)}
              className="w-full p-2 rounded-lg bg-[#050507] border border-white/10 text-xs font-mono text-neutral-200 focus:outline-none focus:border-red-500/80"
            >
              <option value="35mm Anamorphic">35mm Anamorphic (2.0x Squeeze)</option>
              <option value="50mm Master Prime">50mm Master Prime T1.3</option>
              <option value="18mm Ultra-Wide Cine">18mm Ultra-Wide Cine</option>
              <option value="85mm Portrait Telephoto">85mm Portrait Telephoto</option>
            </select>
          </div>

          {/* Film Emulsion Stock */}
          <div className="space-y-2">
            <label className="block text-xs font-mono text-neutral-400">
              Photochemical Emulsion
            </label>
            <select
              value={emulsionProfile}
              onChange={(e) => setEmulsionProfile(e.target.value)}
              className="w-full p-2 rounded-lg bg-[#050507] border border-white/10 text-xs font-mono text-neutral-200 focus:outline-none focus:border-red-500/80"
            >
              <option value="Kodak Vision3 5219">Kodak Vision3 5219 (500T)</option>
              <option value="Fuji Eterna 8553">Fuji Eterna 8553 (250D)</option>
              <option value="Eastman Double-X 5222">Eastman Double-X 5222</option>
              <option value="Agfa Vista Red Halation">Agfa Vista Red Halation</option>
            </select>
          </div>

          {/* Motion Intensity Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-neutral-400">Temporal Velocity</span>
              <span className="text-red-400 font-bold">{motionIntensity}x</span>
            </div>
            <input
              type="range"
              min="1.0"
              max="10.0"
              step="0.1"
              value={motionIntensity}
              onChange={(e) => setMotionIntensity(parseFloat(e.target.value))}
              className="w-full accent-red-600 h-1.5 bg-neutral-800 rounded-lg appearance-none cursor-pointer"
            />
          </div>

          {/* Seed */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-neutral-400">Deterministic Seed</span>
              <button
                type="button"
                onClick={() => setSeed(Math.floor(1000000 + Math.random() * 9000000))}
                className="text-red-400 hover:text-red-300"
              >
                Randomize
              </button>
            </div>
            <input
              type="number"
              value={seed}
              onChange={(e) => setSeed(parseInt(e.target.value) || 0)}
              className="w-full p-2 bg-[#050507] border border-white/10 rounded-lg text-xs font-mono text-white tabular-nums"
            />
          </div>

          {/* Hardware Metadata Info */}
          <div className="pt-4 border-t border-white/[0.08] text-[11px] font-mono text-neutral-400 space-y-2">
            <div className="flex justify-between">
              <span>Color Space</span>
              <span className="text-neutral-200">ACEScg / ACES 1.3</span>
            </div>
            <div className="flex justify-between">
              <span>Export Codec</span>
              <span className="text-neutral-200">ProRes export</span>
            </div>
            <div className="flex justify-between">
              <span>Cluster Latency</span>
              <span className="text-emerald-400">12.8ms</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
