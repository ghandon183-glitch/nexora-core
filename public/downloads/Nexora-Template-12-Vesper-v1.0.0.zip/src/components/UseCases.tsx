import React, { useState } from 'react';
import { USE_CASES_DATA } from '../data/vesperData';
import { Clapperboard, Sparkles, Compass, Music, ArrowRight } from 'lucide-react';

const CATEGORY_ICONS: Record<string, React.FC<{ className?: string }>> = {
  'Motion Picture': Clapperboard,
  'Haute Couture': Sparkles,
  'AAA Interactive': Compass,
  'Acoustic Scoring': Music,
};

export const UseCases: React.FC = () => {
  const [selectedCase, setSelectedCase] = useState<string>(USE_CASES_DATA[0].id);

  return (
    <section id="use-cases" className="relative py-28 bg-[#07060a] border-t border-white/[0.06] overflow-hidden">
      {/* Background ambient light */}
      <div 
        className="absolute bottom-10 -left-40 w-96 h-96 bg-red-950/20 rounded-full blur-[140px] pointer-events-none" 
        aria-hidden="true" 
      />

      <div className="relative max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-red-500 font-mono mb-3">
            <span>Production Domains</span>
            <span aria-hidden="true">·</span>
            <span>Real-World Directorship</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-white font-['Syne',sans-serif] leading-tight mb-5">
            WHERE UNCOMPROMISED VISION SHAPES REALITY.
          </h2>
          <p className="text-base sm:text-lg text-neutral-400 leading-relaxed font-normal">
            From Hollywood soundstages to Parisian fashion houses and AAA virtual production volumes.
          </p>
        </div>

        {/* 4 Cards Bento / Alternate Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {USE_CASES_DATA.map((item) => {
            const Icon = CATEGORY_ICONS[item.category] || Clapperboard;
            const isSelected = selectedCase === item.id;

            return (
              <div
                key={item.id}
                onClick={() => setSelectedCase(item.id)}
                className={`group relative rounded-2xl overflow-hidden border transition-all duration-300 cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'border-red-600/50 bg-[#0e0c14] shadow-[0_0_40px_rgba(220,38,38,0.25)]'
                    : 'border-white/[0.08] bg-[#09080d]/80 hover:border-white/20'
                }`}
              >
                {/* Media Image Container with Scrim & Grain */}
                <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-black">
                  <img
                    src={item.image}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-90"
                  />
                  {/* Contrast scrim */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#09080d] via-[#09080d]/40 to-transparent" />
                  <div className="absolute inset-0 bg-grain opacity-50 mix-blend-overlay pointer-events-none" />

                  {/* Category Pill Tag */}
                  <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1 rounded-md bg-black/70 backdrop-blur-md border border-white/10 text-xs font-mono text-white">
                    <Icon className="w-3.5 h-3.5 text-red-400" />
                    <span>{item.category}</span>
                  </div>

                  {/* Outcome Highlight Metric */}
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="text-xs font-mono text-red-400 font-semibold uppercase tracking-wider mb-1">
                      Production Impact
                    </div>
                    <div className="text-sm sm:text-base font-bold text-white font-['Syne',sans-serif]">
                      {item.outcome}
                    </div>
                  </div>
                </div>

                {/* Content Body */}
                <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl sm:text-2xl font-bold text-white font-['Syne',sans-serif] mb-2 group-hover:text-red-100 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-xs font-mono text-neutral-400 mb-4">
                      {item.tagline}
                    </p>
                    <p className="text-sm text-neutral-400 leading-relaxed font-normal mb-6">
                      {item.description}
                    </p>
                  </div>

                  {/* Specifications Footer */}
                  <div className="pt-4 border-t border-white/[0.08] flex flex-wrap gap-2">
                    {item.specs.map((spec, sIdx) => (
                      <span
                        key={sIdx}
                        className="px-2.5 py-1 rounded bg-white/[0.04] border border-white/[0.06] text-[11px] font-mono text-neutral-300"
                      >
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
