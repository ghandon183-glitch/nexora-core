import { ASSETS } from './assets';
import { FeatureItem, UseCaseItem, PricingPlan, TestimonialItem, FaqItem } from '../types';

export const LOGO_STUDIOS = [
  { name: 'NOVA /01', label: 'Creative Technology' },
  { name: 'FRAME /02', label: 'Virtual Production' },
  { name: 'ATLAS /03', label: 'Design Systems' },
  { name: 'MOTION /04', label: 'Post Production' },
  { name: 'ORBIT /05', label: 'Interactive Media' },
  { name: 'FIELD /06', label: 'Creative Direction' },
];

export const FEATURES_DATA: FeatureItem[] = [
  { id: 'latent-canvas', number: '01', title: 'Infinite Creative Canvas', tagline: 'Spatial multi-prompt direction on an unbounded workspace', description: 'A premium canvas pattern for visual products: arrange scenes, references, prompts, and production notes across a flexible 2D workspace.', metrics: 'Responsive workspace pattern', tag: 'Spatial UI' },
  { id: 'temporal-coherence', number: '02', title: 'Timeline Direction', tagline: 'Cinematic sequencing with clear motion and state feedback', description: 'A production-inspired timeline UI demonstrates how a creative product can expose shots, keyframes, progress states, and playback controls without feeling like a generic dashboard.', metrics: 'Interactive timeline demo', tag: 'Motion UI' },
  { id: 'harmonic-audio', number: '03', title: 'Multimodal Workspace', tagline: 'Visual, audio, and metadata panels in one system', description: 'Combine media previews, waveform-inspired controls, metadata, and inspector panels into a cohesive application shell ready for your own product logic.', metrics: 'Reusable panel architecture', tag: 'Product UI' },
  { id: 'neural-grading', number: '04', title: 'Cinematic Visual System', tagline: 'Atmosphere, glow, grain, and restrained contrast', description: 'A complete dark visual language built from reusable surfaces, borders, typography, ambient lighting, motion, and accent tokens.', metrics: 'Token-driven styling', tag: 'Visual System' },
  { id: 'seed-branching', number: '05', title: 'Version & Lineage Patterns', tagline: 'Make complex creative states feel understandable', description: 'Branch cards, status badges, activity rows, and revision controls give your application the structure needed for real creative workflows.', metrics: 'State-rich components', tag: 'Workflow UI' },
  { id: 'private-weights', number: '06', title: 'Enterprise-Ready Patterns', tagline: 'Permissions, settings, alerts, and audit-friendly UI', description: 'The template includes visual patterns for team settings, access controls, notifications, empty states, and operational feedback.', metrics: 'Production-minded UI kit', tag: 'SaaS Patterns' },
];

export const HOW_IT_WORKS_STEPS = [
  { step: '01', title: 'Shape the Intent', subtitle: 'Prompt, Reference, & Framing', description: 'Start with a polished creative brief interface and replace the demo controls with your own product logic.', highlight: 'Clear creative input patterns' },
  { step: '02', title: 'Compose the Workspace', subtitle: 'Canvas, Timeline, & Inspector', description: 'Use the included workspace shell as the foundation for an AI studio, media editor, design tool, or premium SaaS product.', highlight: 'Reusable application shell' },
  { step: '03', title: 'Ship the Experience', subtitle: 'Responsive UI & Production Polish', description: 'Customize content, connect your APIs, replace demo assets, and keep the visual system consistent across marketing and product surfaces.', highlight: 'Ready for real product integration' },
];

export const USE_CASES_DATA: UseCaseItem[] = [
  { id: 'previs', category: 'AI Products', title: 'Generative Media & AI Studios', tagline: 'Give an AI product a premium creative direction layer.', outcome: 'Marketing + product UI in one system', description: 'Use the cinematic landing page for acquisition and the included Studio Workspace as a starting point for your actual application.', image: ASSETS.videoFrame, specs: ['Creative dashboard shell', 'Prompt & media patterns', 'Responsive application UI'] },
  { id: 'fashion', category: 'Creative Agencies', title: 'High-End Agency & Portfolio', tagline: 'Present campaigns, capabilities, and case studies with cinematic polish.', outcome: 'Premium editorial presentation', description: 'Swap the demo imagery and copy for client work while keeping the atmosphere, motion, and component system intact.', image: ASSETS.fashionPrevis, specs: ['Case-study storytelling', 'Image-led layouts', 'Motion-ready sections'] },
  { id: 'worldbuilding', category: 'SaaS', title: 'Next-Generation SaaS Launches', tagline: 'Move beyond the standard SaaS landing page formula.', outcome: 'Distinctive product positioning', description: 'Combine marketing sections, pricing, FAQs, social proof, and an application preview to create a cohesive product launch site.', image: ASSETS.heroCinematic, specs: ['Pricing & conversion UI', 'Product preview', 'Reusable content sections'] },
  { id: 'soundtrack', category: 'Creative Tools', title: 'Design, Audio & Production Tools', tagline: 'Build a believable creative application shell without starting from zero.', outcome: 'Workspace-first product storytelling', description: 'Use the Studio Workspace, timeline, inspector, and status patterns as a visual foundation for a real creative tool.', image: ASSETS.audioVisual, specs: ['Timeline patterns', 'Inspector panels', 'Export/status states'] },
];

export const PRICING_PLANS: PricingPlan[] = [
  { id: 'creator', name: 'Creator', tagline: 'A compact creative-product demo for solo builders and designers.', monthlyPrice: 29, annualPrice: 19, credits: '1 production-ready marketing system', concurrency: '1 responsive Studio Workspace', resolution: 'Desktop + mobile layouts', features: ['Full cinematic landing page', 'Auralis WebGL hero', 'Studio Workspace mock', 'Responsive components', 'React + TypeScript + Tailwind source', 'Demo imagery included'], ctaLabel: 'Preview Template' },
  { id: 'studio', name: 'Studio', tagline: 'A larger demo configuration for teams building premium creative products.', monthlyPrice: 79, annualPrice: 59, credits: 'Full UI system + marketing demo', concurrency: 'Expanded application shell', resolution: 'Responsive + reduced-motion patterns', popular: true, features: ['Everything in Creator, plus:', 'Reusable UI kit section', 'Workspace, timeline & inspector patterns', 'Loading, empty & status states', 'Documentation starter', 'Customization token guide', 'Commercial-template-ready structure'], ctaLabel: 'Explore Studio' },
  { id: 'enterprise', name: 'Custom', tagline: 'Demo copy for products that want to show a larger enterprise offering.', monthlyPrice: 149, annualPrice: 119, credits: 'Multi-team product architecture', concurrency: 'Advanced workflow modules', resolution: 'Custom delivery requirements', features: ['Everything in Studio, plus:', 'Custom product integration', 'Team permissions patterns', 'Audit/activity UI patterns', 'Extended component library', 'Custom implementation roadmap'], ctaLabel: 'Contact Sales' },
];

export const TESTIMONIALS_DATA: TestimonialItem[] = [
  { id: 'test-1', quote: 'The combination of the cinematic marketing site and the product workspace makes the template feel like a real product launch system rather than another landing page.', author: 'Demo Customer', role: 'Creative Technology Lead', studio: 'Sample Studio', credits: 'Replace with your own customer story' },
  { id: 'test-2', quote: 'The visual system gave our product a strong point of view before we connected any backend functionality. It was easy to replace the demo content with our own.', author: 'Demo Customer', role: 'Product Designer', studio: 'Sample Company', credits: 'Replace with your own customer story' },
  { id: 'test-3', quote: 'The workspace shell is the standout: it gives a SaaS product enough depth to demonstrate the actual experience instead of only showing a hero and pricing cards.', author: 'Demo Customer', role: 'Founder', studio: 'Sample Product', credits: 'Replace with your own customer story' },
];

export const FAQ_DATA: FaqItem[] = [
  { question: 'Is the AI functionality included?', answer: 'Vesper is a front-end template. The creative controls and workspace are interactive UI demonstrations; connect them to your preferred AI APIs, database, auth, storage, or generation backend.' },
  { question: 'Can I replace the Vesper branding?', answer: 'Yes. Branding, copy, colors, imagery, navigation labels, pricing content, and product terminology are intentionally easy to customize.' },
  { question: 'Is the Studio Workspace a real application?', answer: 'It is a front-end application mock designed to demonstrate product UX. It includes interactive states such as rendering progress, timeline controls, panels, and media actions, but no external generation service is required.' },
  { question: 'Can I use the template for an agency or SaaS client?', answer: 'Use the license terms attached to your Nexora purchase. The source is structured so you can adapt the UI to your own project and replace all demo assets and copy.' },
  { question: 'Does the template support reduced motion and mobile layouts?', answer: 'The visual system is designed for responsive layouts and includes reduced-motion-aware patterns where animation is used. You should still test the final customized experience on your target devices.' },
  { question: 'What is included in the download?', answer: 'The package contains the Vite project source, React components, TypeScript types, Tailwind styling, demo assets, and documentation covering installation, customization, structure, and deployment.' },
];
