import heroCinematic from '@/src/assets/images/vesper_hero_cinematic_1790162202012.webp';
import videoFrame from '@/src/assets/images/vesper_video_frame_1790162217348.webp';
import showcasePortrait from '@/src/assets/images/vesper_showcase_portrait_1790162229168.webp';
import audioVisual from '@/src/assets/images/vesper_audio_visual_1790162242624.webp';
import fashionPrevis from '@/src/assets/images/vesper_fashion_previs_1790162254947.webp';

export const ASSETS = {
  heroCinematic,
  videoFrame,
  showcasePortrait,
  audioVisual,
  fashionPrevis,
};
