import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { LogoCloud } from './components/LogoCloud';
import { FeaturesGrid } from './components/FeaturesGrid';
import { HowItWorks } from './components/HowItWorks';
import { ShowcaseDemo } from './components/ShowcaseDemo';
import { UseCases } from './components/UseCases';
import { Pricing } from './components/Pricing';
import { Testimonials } from './components/Testimonials';
import { FAQ } from './components/FAQ';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';
import { AccessModal } from './components/AccessModal';
import { StudioWorkspace } from './components/StudioWorkspace';
import { WelcomeBanner } from './components/WelcomeBanner';
import { ComponentGallery } from './components/ComponentGallery';

export default function App() {
  const [studioOpen, setStudioOpen] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('Studio Master');

  const handleOpenStudio = () => {
    setStudioOpen(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRequestAccess = (planName: string = 'Studio Master') => {
    setSelectedPlan(planName);
    setModalOpen(true);
  };

  const handleExploreSpecs = () => {
    const showcaseEl = document.getElementById('showcase');
    if (showcaseEl) {
      showcaseEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#050507] text-[#e2e2e8] selection:bg-red-900/60 selection:text-white font-sans overflow-x-hidden">
      {/* If full studio mode is active, render full-screen Studio Workspace */}
      {studioOpen ? (
        <StudioWorkspace onBackToLanding={() => setStudioOpen(false)} />
      ) : (
        <>
          <WelcomeBanner />

          {/* Top Bar Navigation */}
          <Navbar
            onOpenStudio={handleOpenStudio}
            onRequestAccess={() => handleRequestAccess('Studio Master')}
            isStudioActive={false}
          />

          <main className="relative z-0">
            {/* 1. Hero with WebGL Auralis background */}
            <Hero
              onEnterStudio={handleOpenStudio}
              onExploreSpecs={handleExploreSpecs}
            />

            {/* 2. Logo Cloud */}
            <LogoCloud />

            {/* 3. Features Grid */}
            <FeaturesGrid />

            {/* 4. How It Works */}
            <HowItWorks />

            {/* 5. Live Demo / Showcase */}
            <ShowcaseDemo />

            {/* 6. Use Cases */}
            <UseCases />

            {/* 7. Reusable UI system */}
            <ComponentGallery />

            {/* 8. Pricing */}
            <Pricing
              onSelectPlan={(planId) => {
                const planTitles: Record<string, string> = {
                  creator: 'Creator Demo',
                  studio: 'Studio Demo',
                  enterprise: 'Custom Demo',
                };
                handleRequestAccess(planTitles[planId] || 'Studio Demo');
              }}
            />

            {/* 9. Testimonials */}
            <Testimonials />

            {/* 10. FAQ */}
            <FAQ />

            {/* 11. Final CTA */}
            <FinalCTA onDirectEnter={handleOpenStudio} />
          </main>

          {/* 12. Footer */}
          <Footer />

          {/* Floating Studio Workspace Quick-Launch Pill on Mobile/Desktop */}
          <div className="fixed bottom-6 right-6 z-40">
            <button
              type="button"
              onClick={handleOpenStudio}
              className="group flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-[#120d18]/90 hover:bg-[#1a1322] border border-red-600/50 hover:border-red-500 text-white text-xs font-mono font-medium shadow-[0_0_25px_rgba(220,38,38,0.45)] hover:shadow-[0_0_35px_rgba(225,29,72,0.6)] backdrop-blur-md transition-all duration-200"
            >
              <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse shadow-[0_0_8px_#ef4444]" />
              <span>Launch Studio OS</span>
            </button>
          </div>

          {/* Access / Provisioning Modal */}
          <AccessModal
            isOpen={modalOpen}
            onClose={() => setModalOpen(false)}
            selectedPlan={selectedPlan}
            onLaunchStudio={handleOpenStudio}
          />
        </>
      )}
    </div>
  );
}
