export interface FeatureItem {
  id: string;
  number: string;
  title: string;
  tagline: string;
  description: string;
  metrics?: string;
  tag: string;
}

export interface UseCaseItem {
  id: string;
  category: string;
  title: string;
  tagline: string;
  outcome: string;
  description: string;
  image: string;
  specs: string[];
}

export interface PricingPlan {
  id: string;
  name: string;
  tagline: string;
  monthlyPrice: number;
  annualPrice: number;
  credits: string;
  concurrency: string;
  resolution: string;
  popular?: boolean;
  features: string[];
  ctaLabel: string;
}

export interface TestimonialItem {
  id: string;
  quote: string;
  author: string;
  role: string;
  studio: string;
  credits: string;
}

export interface FaqItem {
  id?: string;
  question: string;
  answer: string;
}
