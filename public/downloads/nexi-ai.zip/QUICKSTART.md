# Quick Start

1. Extract the package.
2. Read README.md and the project documentation.
3. Install dependencies with the package manager used by the project.
4. Start the development server using the documented command.
5. Replace demo content, branding, links, and assets.
6. Configure environment variables and third-party services.
7. Run the production build before launch.

## Production checklist
- Replace demo content.
- Review asset licenses.
- Configure environment variables.
- Test responsive states, forms, navigation, and accessibility.
- Run the production build.
- Deploy and verify the live site.

## Commands for this package

Node.js 20.9 or newer is required (Next.js 16).

```bash
npm ci                            # install dependencies
npm run dev                       # http://localhost:3000
npm run lint                      # eslint
npm run build                     # production build
npm run start                     # serve the production build
STATIC_EXPORT=true npm run build  # static demo export into out/
```

`STATIC_EXPORT=true` builds a static export in `out/` with `basePath`
`/demo/nexi-ai` and unoptimised images. Without it the build targets a normal
Next.js deployment at the site root.
