import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: process.env.STATIC_EXPORT === "true" ? "export" : undefined,
  basePath: process.env.STATIC_EXPORT === "true" ? "/demo/nexi-ai" : undefined,
  images: {
    unoptimized: process.env.STATIC_EXPORT === "true",
  },
};

export default nextConfig;
