import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: process.env.STATIC_EXPORT === "true" ? "export" : undefined,
  basePath: process.env.STATIC_EXPORT === "true" ? "/demo/nexi-ai" : undefined,
  images: {
    unoptimized: process.env.STATIC_EXPORT === "true",
  },
  // Pin the Turbopack workspace root to this project. Without it, Next.js walks
  // up looking for a lockfile and can pick a *parent* project's root when this
  // folder is extracted inside another repository — it then compiles the
  // parent's middleware and i18n files instead of these, and the build fails.
  // `process.cwd()` is the project directory for `next dev` and `next build`,
  // so this keeps working after moving or renaming the folder.
  turbopack: {
    root: process.cwd(),
  },
};

export default nextConfig;
