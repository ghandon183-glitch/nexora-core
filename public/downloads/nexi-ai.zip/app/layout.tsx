import "@fontsource-variable/sora";
import "@fontsource/jetbrains-mono/500.css";
import "@fontsource/jetbrains-mono/400.css";
import "@fontsource-variable/inter";
import type { Metadata } from "next";
import "./globals.css";







export const metadata: Metadata = {
  title: "Nexi AI | AI Support Product Landing Page Template",
  description:
    "An editable Next.js landing-page template for AI support, chatbot, and automation products. It ships sample UI and copy, not a hosted AI backend.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`   h-full overflow-x-hidden antialiased`}
    >
      <body className="min-h-full flex flex-col overflow-x-hidden bg-[#07070B] text-white">{children}</body>
    </html>
  );
}
