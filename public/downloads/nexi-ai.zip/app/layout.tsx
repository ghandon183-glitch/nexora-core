import "@fontsource/jetbrains-mono/500.css";
import "@fontsource/jetbrains-mono/400.css";
import "@fontsource-variable/inter";
import type { Metadata } from "next";
import "@fontsource-variable/sora";
import "./globals.css";







export const metadata: Metadata = {
  title: "Nexi AI | Deploy an AI Agent Your Customers Trust",
  description:
    "Ship a production-ready AI support agent in a weekend — trained on your docs, wired to your tools, live on your site by tonight.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`   h-full overflow-x-hidden antialiased`}
    >
      <body className="min-h-full flex flex-col overflow-x-hidden bg-[#07070B] text-white">{children}</body>
    </html>
  );
}
