const TESTIMONIALS = [
  {
    quote:
      "We swapped a 6-person support rotation for Nexi and first-response time dropped from four hours to under a minute.",
    name: "Priya Nandakumar",
    role: "Head of Support, Loopline",
  },
  {
    quote:
      "The reasoning trace is what sold our team. We can see exactly why the agent said what it said, every time.",
    name: "Marcus Webb",
    role: "CTO, Fieldstack",
  },
  {
    quote:
      "Setup took one afternoon. Two weeks later it was resolving 70% of tickets without touching a human.",
    name: "Ana Torres",
    role: "Founder, Portside",
  },
];

export default function Testimonials() {
  return (
    <section className="relative py-28 lg:py-36">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex rounded-full border border-fuchsia-400/25 bg-fuchsia-500/10 px-4 py-2 text-sm font-semibold text-fuchsia-300">
            Teams already shipping
          </span>
          <h2 className="mt-6 font-display text-4xl font-extrabold text-white sm:text-5xl">
            Support teams trust what they can verify
          </h2>
        </div>

        <div className="mt-16 grid gap-5 lg:grid-cols-3">
          {TESTIMONIALS.map((t) => (
            <figure
              key={t.name}
              className="rounded-2xl border border-white/10 bg-white/[0.02] p-7"
            >
              <blockquote className="text-[15px] leading-relaxed text-slate-300">
                &ldquo;{t.quote}&rdquo;
              </blockquote>
              <figcaption className="mt-5 border-t border-white/5 pt-5">
                <p className="text-sm font-semibold text-white">{t.name}</p>
                <p className="text-xs text-slate-500">{t.role}</p>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
