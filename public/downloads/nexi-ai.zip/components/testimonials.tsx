const ITEMS = [
  {
    title: "Verified outcomes",
    body: "Publish measurable results only when you can substantiate them.",
    note: "Add an approved metric and its source",
  },
  {
    title: "Real customer voices",
    body: "Use customer quotes only with permission and accurate attribution.",
    note: "Add the customer's approved name and role",
  },
  {
    title: "Transparent workflows",
    body: "Show how your product handles data, safeguards, and human escalation.",
    note: "Link to your real product documentation",
  },
];

export default function Testimonials() {
  return (
    <section className="relative py-28 lg:py-36">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex rounded-full border border-fuchsia-400/25 bg-fuchsia-500/10 px-4 py-2 text-sm font-semibold text-fuchsia-300">
            Evidence customers can verify
          </span>
          <h2 className="mt-6 font-display text-4xl font-extrabold text-white sm:text-5xl">
            Build trust with proof, not placeholder claims
          </h2>
        </div>
        <div className="mt-16 grid gap-5 lg:grid-cols-3">
          {ITEMS.map((item) => (
            <article key={item.title} className="rounded-2xl border border-white/10 bg-white/[0.02] p-7">
              <p className="text-[15px] leading-relaxed text-slate-300">{item.body}</p>
              <div className="mt-5 border-t border-white/5 pt-5">
                <h3 className="text-sm font-semibold text-white">{item.title}</h3>
                <p className="text-xs text-slate-300">{item.note}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
