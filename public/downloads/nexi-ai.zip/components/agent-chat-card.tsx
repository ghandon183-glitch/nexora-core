"use client";

import { motion } from "framer-motion";
import { CheckCircle2, Search, ShieldCheck, PenLine } from "lucide-react";

const STEPS = [
  { icon: Search, label: "Checked order #4821" },
  { icon: ShieldCheck, label: "Verified return policy" },
  { icon: PenLine, label: "Drafted reply" },
];

export default function AgentChatCard() {
  return (
    <div className="relative mx-auto w-full max-w-[560px]">
      <div className="overflow-hidden rounded-3xl border border-white/10 bg-[#0F0F17]/90 shadow-[0_40px_100px_rgba(0,0,0,0.5)] backdrop-blur-xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/5 bg-white/[0.02] px-6 py-5">
          <div className="flex items-center gap-3">
            <span className="h-10 w-10 rounded-full bg-gradient-to-br from-violet-500 to-cyan-400" />
            <div>
              <p className="text-sm font-semibold text-white">Nexi Assistant</p>
              <p className="flex items-center gap-1.5 text-xs text-slate-500">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                Online — replies instantly
              </p>
            </div>
          </div>
          <span className="rounded-full bg-emerald-400/10 px-2.5 py-1 text-xs font-semibold text-emerald-400">
            ● Live
          </span>
        </div>

        {/* Body */}
        <div className="flex flex-col gap-4 p-6">
          <Bubble fromUser>Hi! Can I get a refund on order #4821? It arrived damaged.</Bubble>

          {/* Signature: visible reasoning trace, not just a chat bubble */}
          <div className="flex flex-col gap-2 rounded-2xl border border-white/5 bg-black/20 p-3">
            {STEPS.map((step, i) => (
              <motion.div
                key={step.label}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.3 + i * 0.15 }}
                className="flex items-center gap-2.5 text-xs text-slate-400"
              >
                <step.icon size={13} className="shrink-0 text-cyan-400" />
                <span>{step.label}</span>
                <CheckCircle2 size={13} className="ml-auto shrink-0 text-emerald-400" />
              </motion.div>
            ))}
          </div>

          <Bubble>
            So sorry about that! I&apos;ve checked order #4821 — I can issue a full refund
            right now, or send a free replacement. Which works better?
          </Bubble>
          <Bubble fromUser>A replacement would be great, thanks!</Bubble>

          <div className="flex w-fit items-center gap-1.5 rounded-2xl border border-white/5 bg-[#1A1A24] px-4 py-3">
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                className="h-1.5 w-1.5 rounded-full bg-slate-400"
                animate={{ opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
              />
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center gap-3 border-t border-white/5 bg-white/[0.02] px-6 py-5">
          <div className="flex-1 rounded-full border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-500">
            Type a message...
          </div>
          <span className="h-10 w-10 shrink-0 rounded-full bg-gradient-to-br from-violet-500 to-cyan-400" />
        </div>
      </div>

      {/* Floating stat pill */}
      <div className="absolute -bottom-6 left-6 flex items-center gap-2.5 rounded-2xl border border-white/10 bg-[#0F0F17]/95 px-4.5 py-3.5 shadow-[0_20px_50px_rgba(0,0,0,0.4)]">
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-400/15">
          <CheckCircle2 size={16} className="text-emerald-400" />
        </span>
        <div>
          <p className="text-xs font-semibold text-white">Resolved in 12s</p>
          <p className="text-[11px] text-slate-500">No human handoff needed</p>
        </div>
      </div>
    </div>
  );
}

function Bubble({ children, fromUser = false }: { children: React.ReactNode; fromUser?: boolean }) {
  return (
    <div className={`flex ${fromUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
          fromUser
            ? "bg-violet-600/85 text-white"
            : "border border-white/5 bg-[#1A1A24] text-slate-100"
        }`}
      >
        {children}
      </div>
    </div>
  );
}
