"use client";

import { motion } from "framer-motion";

const STEPS = [
  {
    step: "01",
    title: "Connect your sources",
    description: "Link your docs, help center, and APIs. Nexi indexes everything automatically.",
  },
  {
    step: "02",
    title: "Set the guardrails",
    description: "Define what the agent can do, say, and escalate — in plain language, no code.",
  },
  {
    step: "03",
    title: "Embed one script tag",
    description: "Drop a single snippet into your site. The agent is live and learning immediately.",
  },
  {
    step: "04",
    title: "Watch it resolve tickets",
    description: "Track every conversation, reasoning step, and outcome from the live dashboard.",
  },
];

export default function HowItWorks() {
  return (
    <section id="how-it-works" className="relative border-y border-white/5 bg-white/[0.015] py-28 lg:py-36">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex rounded-full border border-cyan-400/25 bg-cyan-400/10 px-4 py-2 text-sm font-semibold text-cyan-300">
            How it works
          </span>
          <h2 className="mt-6 font-display text-4xl font-extrabold text-white sm:text-5xl">
            Live in an afternoon, not a quarter
          </h2>
        </div>

        <div className="mt-16 grid gap-8 lg:grid-cols-4">
          {STEPS.map((item, i) => (
            <motion.div
              key={item.step}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="relative"
            >
              <span className="font-mono-ui text-sm font-medium text-cyan-400/70">
                {item.step}
              </span>
              <h3 className="mt-3 font-display text-xl font-bold text-white">{item.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{item.description}</p>
              {i < STEPS.length - 1 && (
                <div className="mt-8 hidden h-px bg-gradient-to-r from-white/10 to-transparent lg:block" />
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
