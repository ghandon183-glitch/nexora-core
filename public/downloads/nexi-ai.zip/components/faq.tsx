"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

const FAQS = [
  {
    q: "Does it need my engineering team to set up?",
    a: "No. Connecting sources and setting guardrails is done through the dashboard in plain language. Embedding on your site is one script tag.",
  },
  {
    q: "What happens when it doesn't know the answer?",
    a: "It says so, and hands off to a human with the full conversation and reasoning trace attached — no dead ends for your customers.",
  },
  {
    q: "Can I see why the agent gave a specific answer?",
    a: "Yes. Every reply comes with a visible reasoning trace showing which sources it checked and which policy it applied.",
  },
  {
    q: "Which channels does it support?",
    a: "Website chat out of the box, plus Slack, email, and a REST API for any channel you build yourself.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-28 lg:py-36">
      <div className="mx-auto max-w-3xl px-6 lg:px-10">
        <div className="text-center">
          <h2 className="font-display text-4xl font-extrabold text-white sm:text-5xl">
            Questions, answered
          </h2>
        </div>

        <div className="mt-12 flex flex-col gap-3">
          {FAQS.map((item, i) => {
            const isOpen = open === i;
            return (
              <div
                key={item.q}
                className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]"
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  aria-expanded={isOpen}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
                >
                  <span className="font-display text-base font-semibold text-white">
                    {item.q}
                  </span>
                  <ChevronDown
                    size={18}
                    className={`shrink-0 text-slate-400 transition-transform ${isOpen ? "rotate-180" : ""}`}
                  />
                </button>
                {isOpen && (
                  <p className="px-6 pb-5 text-sm leading-relaxed text-slate-400">{item.a}</p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
