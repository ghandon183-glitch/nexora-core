"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

const FAQS = [
  {
    q: "Does this ZIP include a working AI agent backend?",
    a: "No. This package contains a front-end landing-page template and sample UI. Connect your own AI service, data sources, authentication, and support workflows.",
  },
  {
    q: "Can I publish the included metrics and testimonials?",
    a: "They are illustrative placeholders. Replace them with verified performance data and customer quotes you have permission to publish.",
  },
  {
    q: "Are the listed integrations and capabilities included?",
    a: "The page is a marketing template; it does not connect the services shown. Update the copy to match your real integrations and tested capabilities.",
  },
  {
    q: "Can I customize pricing and calls to action?",
    a: "Yes. Edit the sample plans and replace every placeholder link with your own signup, booking, or contact destination before publishing.",
  },
  {
    q: "What does one purchase cover?",
    a: "One purchase covers one end product under LICENSE.md. Review the included license before using the template for client work or multiple products.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-28 lg:py-36">
      <div className="mx-auto max-w-3xl px-6 lg:px-10">
        <div className="text-center">
          <h2 className="font-display text-4xl font-extrabold text-white sm:text-5xl">
            Questions, answered
          </h2>
        </div>
        <div className="mt-12 flex flex-col gap-3">
          {FAQS.map((item, i) => {
            const isOpen = open === i;
            return (
              <div key={item.q} className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  aria-expanded={isOpen}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left"
                >
                  <span className="font-display text-base font-semibold text-white">{item.q}</span>
                  <ChevronDown size={18} className={isOpen ? "shrink-0 text-slate-300 transition-transform rotate-180" : "shrink-0 text-slate-300 transition-transform"} />
                </button>
                {isOpen && <p className="px-6 pb-5 text-sm leading-relaxed text-slate-300">{item.a}</p>}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
