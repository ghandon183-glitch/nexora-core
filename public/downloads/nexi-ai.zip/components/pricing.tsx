import { Check } from "lucide-react";

const PLANS = [
  {
    name: "Starter",
    price: "$0",
    period: "forever",
    description: "Try it on a side project or small site.",
    features: ["500 conversations / mo", "1 data source", "Email support", "Nexi branding"],
    cta: "Start free",
    highlight: false,
  },
  {
    name: "Growth",
    price: "$79",
    period: "/month",
    description: "For teams putting the agent in front of real customers.",
    features: [
      "10,000 conversations / mo",
      "Unlimited data sources",
      "20+ integrations",
      "Remove Nexi branding",
      "Priority support",
    ],
    cta: "Start 14-day trial",
    highlight: true,
  },
  {
    name: "Scale",
    price: "Custom",
    period: "",
    description: "For high-volume support and multi-brand deployments.",
    features: [
      "Unlimited conversations",
      "Dedicated infrastructure",
      "SSO & audit logs",
      "Custom SLAs",
      "Solutions engineer",
    ],
    cta: "Talk to sales",
    highlight: false,
  },
];

export default function Pricing() {
  return (
    <section id="pricing" className="relative border-y border-white/5 bg-white/[0.015] py-28 lg:py-36">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex rounded-full border border-amber-400/25 bg-amber-400/10 px-4 py-2 text-sm font-semibold text-amber-300">
            Pricing
          </span>
          <h2 className="mt-6 font-display text-4xl font-extrabold text-white sm:text-5xl">
            Start free. Scale when it&apos;s working.
          </h2>
        </div>

        <div className="mt-16 grid gap-6 lg:grid-cols-3">
          {PLANS.map((plan) => (
            <div
              key={plan.name}
              className={`flex flex-col rounded-2xl border p-8 ${
                plan.highlight
                  ? "border-violet-400/40 bg-gradient-to-b from-violet-500/10 to-transparent"
                  : "border-white/10 bg-white/[0.02]"
              }`}
            >
              {plan.highlight && (
                <span className="mb-4 w-fit rounded-full bg-gradient-to-r from-violet-600 to-cyan-400 px-3 py-1 text-xs font-bold text-white">
                  Most popular
                </span>
              )}
              <h3 className="font-display text-xl font-bold text-white">{plan.name}</h3>
              <p className="mt-2 text-sm text-slate-400">{plan.description}</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="font-display text-4xl font-extrabold text-white">
                  {plan.price}
                </span>
                {plan.period && <span className="text-sm text-slate-500">{plan.period}</span>}
              </div>

              <ul className="mt-7 flex-1 space-y-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2.5 text-sm text-slate-300">
                    <Check size={16} className="shrink-0 text-cyan-400" />
                    {f}
                  </li>
                ))}
              </ul>

              <a
                href="#"
                className={`mt-8 rounded-xl px-6 py-3.5 text-center text-sm font-bold transition-transform hover:-translate-y-0.5 ${
                  plan.highlight
                    ? "bg-gradient-to-r from-violet-600 to-cyan-400 text-white shadow-[0_8px_30px_rgba(124,58,237,0.35)]"
                    : "border border-white/15 bg-white/5 text-white"
                }`}
              >
                {plan.cta}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
