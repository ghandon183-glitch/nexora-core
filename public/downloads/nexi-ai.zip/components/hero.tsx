"use client";

import { motion } from "framer-motion";
import { Play, Zap } from "lucide-react";
import AgentChatCard from "./agent-chat-card";

const STATS = [
  { value: "2.4M+", label: "Conversations handled" },
  { value: "99.9%", label: "Uptime SLA" },
  { value: "<200ms", label: "Avg response time" },
];

export default function Hero() {
  return (
    <section className="relative overflow-hidden pt-40 pb-24 lg:pt-48 lg:pb-32">
      {/* Ambient glow — contained so it can never cause horizontal overflow */}
      <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden" aria-hidden="true">
        <div className="absolute -left-32 -top-48 h-[620px] w-[620px] rounded-full bg-violet-600/25 blur-[150px]" />
        <div className="absolute -right-32 -top-10 h-[560px] w-[560px] rounded-full bg-cyan-400/20 blur-[150px]" />
        <div className="absolute bottom-0 left-1/3 h-[500px] w-[500px] rounded-full bg-fuchsia-500/10 blur-[160px]" />
      </div>

      <div className="mx-auto grid max-w-7xl items-center gap-16 px-6 lg:grid-cols-2 lg:gap-12 lg:px-10">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="flex flex-col items-start gap-7"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-cyan-400/25 bg-cyan-400/10 px-4 py-2 text-sm font-semibold text-cyan-300">
            <Zap size={14} className="fill-cyan-300" />
            Live AI Agent Platform
          </span>

          <h1 className="font-display text-5xl font-extrabold leading-[1.08] tracking-tight text-white sm:text-6xl lg:text-[60px]">
            Deploy an AI agent
            <br />
            your customers
            <br />
            actually trust.
          </h1>

          <p className="max-w-xl text-lg leading-relaxed text-slate-400">
            Ship a production-ready AI support agent in a weekend — trained on your docs,
            wired to your tools, and live on your site by tonight. No ML team required.
          </p>

          <div className="flex flex-wrap items-center gap-3.5">
            <a
              href="#pricing"
              className="rounded-xl bg-gradient-to-r from-violet-600 to-cyan-400 px-7 py-4 text-base font-bold text-white shadow-[0_8px_30px_rgba(124,58,237,0.4)] transition-transform hover:-translate-y-0.5"
            >
              Start Building Free
            </a>
            <a
              href="#how-it-works"
              className="flex items-center gap-2 rounded-xl border border-white/15 bg-white/5 px-7 py-4 text-base font-semibold text-white transition-colors hover:bg-white/10"
            >
              <Play size={16} className="fill-white" />
              Watch Demo
            </a>
          </div>

          <div className="mt-2 flex flex-wrap gap-8">
            {STATS.map((stat) => (
              <div key={stat.label} className="flex flex-col gap-0.5">
                <span className="font-display text-2xl font-extrabold text-white">
                  {stat.value}
                </span>
                <span className="max-w-[140px] text-xs text-slate-500">{stat.label}</span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15, ease: "easeOut" }}
        >
          <AgentChatCard />
        </motion.div>
      </div>
    </section>
  );
}
