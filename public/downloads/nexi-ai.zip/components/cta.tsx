export default function CTA() {
  return (
    <section id="contact" className="relative overflow-hidden py-24 lg:py-32">
      <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden" aria-hidden="true">
        <div className="absolute left-1/2 top-0 h-[500px] w-[900px] -translate-x-1/2 rounded-full bg-violet-600/20 blur-[160px]" />
      </div>

      <div className="mx-auto max-w-3xl px-6 text-center lg:px-10">
        <h2 className="font-display text-4xl font-extrabold text-white sm:text-5xl">
          Ready to make this template yours?
        </h2>
        <p className="mt-4 text-lg text-slate-300">
          Connect your real signup, contact, or demo destination here before publishing.
        </p>
        <a
          href="#pricing"
          className="mt-8 inline-block rounded-xl bg-gradient-to-r from-violet-600 to-cyan-400 px-9 py-4 text-base font-bold text-white shadow-[0_8px_30px_rgba(124,58,237,0.4)] transition-transform hover:-translate-y-0.5"
        >
          Explore sample pricing
        </a>
      </div>
    </section>
  );
}
