const STACK = ["Next.js", "OpenAI", "Anthropic", "Slack", "Zendesk", "Stripe"];

export default function LogoStrip() {
  return (
    <section className="border-y border-white/5 bg-white/[0.015] py-10">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-12 gap-y-4 px-6">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">
          Connects with
        </span>
        {STACK.map((name) => (
          <span key={name} className="font-display text-sm font-semibold text-slate-400">
            {name}
          </span>
        ))}
      </div>
    </section>
  );
}
