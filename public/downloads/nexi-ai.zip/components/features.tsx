"use client";

import { motion } from "framer-motion";
import { Brain, Plug, Gauge, ShieldCheck, LineChart, Languages } from "lucide-react";

const FEATURES = [
  {
    icon: Brain,
    title: "Trained on your docs",
    description:
      "Point it at your help center, PDFs, or a Notion workspace. It learns your product in minutes, not weeks.",
    span: "lg:col-span-2",
    accent: "from-violet-500/20 to-transparent",
  },
  {
    icon: Plug,
    title: "20+ integrations",
    description: "Slack, Zendesk, Stripe, and your own API — connect in a few clicks.",
    span: "",
    accent: "from-cyan-400/20 to-transparent",
  },
  {
    icon: Gauge,
    title: "Sub-200ms replies",
    description: "Edge-deployed inference keeps conversations feeling instant.",
    span: "",
    accent: "from-fuchsia-500/20 to-transparent",
  },
  {
    icon: ShieldCheck,
    title: "Guardrails built in",
    description:
      "Set boundaries on tone, topics, and actions the agent can take — with a human handoff for anything outside them.",
    span: "lg:col-span-2",
    accent: "from-emerald-400/20 to-transparent",
  },
  {
    icon: LineChart,
    title: "Live analytics",
    description: "Resolution rate, sentiment, and drop-off, updated in real time.",
    span: "",
    accent: "from-amber-400/20 to-transparent",
  },
  {
    icon: Languages,
    title: "40+ languages",
    description: "Detects and replies in the customer's language automatically.",
    span: "",
    accent: "from-violet-500/20 to-transparent",
  },
];

export default function Features() {
  return (
    <section id="product" className="relative py-28 lg:py-36">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex rounded-full border border-violet-400/25 bg-violet-500/10 px-4 py-2 text-sm font-semibold text-violet-300">
            Product
          </span>
          <h2 className="mt-6 font-display text-4xl font-extrabold text-white sm:text-5xl">
            Everything an agent needs to actually help
          </h2>
          <p className="mt-4 text-lg text-slate-400">
            Not a chatbot that reads from a script — an agent that checks real data before it answers.
          </p>
        </div>

        <div className="mt-16 grid gap-5 lg:grid-cols-3">
          {FEATURES.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.1 }}
              className={`group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02] p-7 transition-colors hover:border-white/20 ${feature.span}`}
            >
              <div
                className={`absolute inset-0 -z-10 bg-gradient-to-br opacity-0 transition-opacity duration-500 group-hover:opacity-100 ${feature.accent}`}
              />
              <feature.icon size={22} className="text-cyan-300" />
              <h3 className="mt-5 font-display text-lg font-bold text-white">{feature.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-400">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
