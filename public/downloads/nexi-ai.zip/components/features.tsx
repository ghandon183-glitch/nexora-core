"use client";

import { motion } from "framer-motion";
import { Brain, Plug, Gauge, ShieldCheck, LineChart, Languages } from "lucide-react";

const FEATURES = [
  {
    icon: Brain,
    title: "Knowledge sources",
    description:
      "Describe the sources your implementation can actually ingest and the setup steps required.",
    span: "lg:col-span-2",
    accent: "from-violet-500/20 to-transparent",
  },
  {
    icon: Plug,
    title: "Your integrations",
    description: "List only integrations your product really supports and that you have tested.",
    span: "",
    accent: "from-cyan-400/20 to-transparent",
  },
  {
    icon: Gauge,
    title: "Measured response times",
    description: "Add response-time benchmarks only after measuring them in your own deployment.",
    span: "",
    accent: "from-fuchsia-500/20 to-transparent",
  },
  {
    icon: ShieldCheck,
    title: "Configurable controls",
    description:
      "Explain the controls, permissions, and human-escalation paths your implementation really provides.",
    span: "lg:col-span-2",
    accent: "from-emerald-400/20 to-transparent",
  },
  {
    icon: LineChart,
    title: "Operational analytics",
    description: "Show only metrics your deployed product actually measures and can substantiate.",
    span: "",
    accent: "from-amber-400/20 to-transparent",
  },
  {
    icon: Languages,
    title: "Language support",
    description: "List supported languages only after validating answer quality in each language.",
    span: "",
    accent: "from-violet-500/20 to-transparent",
  },
];

export default function Features() {
  return (
    <section id="product" className="relative py-28 lg:py-36">
      <div className="mx-auto max-w-7xl px-6 lg:px-10">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-flex rounded-full border border-violet-400/25 bg-violet-500/10 px-4 py-2 text-sm font-semibold text-violet-300">
            Product
          </span>
          <h2 className="mt-6 font-display text-4xl font-extrabold text-white sm:text-5xl">
            Everything an agent needs to actually help
          </h2>
          <p className="mt-4 text-lg text-slate-300">
            Use this section to describe verified product capabilities, integrations, and safeguards.
          </p>
        </div>

        <div className="mt-16 grid gap-5 lg:grid-cols-3">
          {FEATURES.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.1 }}
              className={`group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02] p-7 transition-colors hover:border-white/20 ${feature.span}`}
            >
              <div
                className={`absolute inset-0 -z-10 bg-gradient-to-br opacity-0 transition-opacity duration-500 group-hover:opacity-100 ${feature.accent}`}
              />
              <feature.icon size={22} className="text-cyan-300" />
              <h3 className="mt-5 font-display text-lg font-bold text-white">{feature.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-slate-300">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
