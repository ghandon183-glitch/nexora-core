# Nexi AI — AI Agent Landing Page Template

A customizable front-end landing page template for AI agent, chatbot, and automation products. It does not include a hosted AI agent or backend service.
Built with Next.js 16, Tailwind CSS v4, TypeScript, and Framer Motion.

## What's inside

- Dramatic hero with a live "agent chat" mockup showing a visible reasoning trace
  (not just chat bubbles — the agent's steps are shown, which is the template's
  signature detail).
- Bento-grid feature section
- 4-step "How it works" section
- Testimonials
- 3-tier pricing section
- Accordion FAQ
- Final CTA + footer

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Requirements

- Node.js **20.9 or newer** (Next.js 16 requires `>=20.9.0`; Node.js 22 LTS is
  what this package is tested with).
- npm, which ships with Node.js.

## Commands

```bash
npm ci          # install exactly the versions in package-lock.json
npm run dev     # development server on http://localhost:3000
npm run lint    # eslint
npm run build   # production build
npm run start   # serve the production build (script: next start)
```

### Static demo export

`next.config.ts` reads the `STATIC_EXPORT` environment variable:

```bash
STATIC_EXPORT=true npm run build
```

With `STATIC_EXPORT=true` the build writes a static export to `out/`, sets
`basePath` to `/demo/nexi-ai` and disables Next.js image optimisation, which is
exactly how the marketplace demo is produced. Serve `out/` from a directory that
keeps that prefix, for example `python3 -m http.server --directory .` next to a
`demo/nexi-ai/` folder, and the page is available at `/demo/nexi-ai/`. Without
the variable the template builds and runs normally at the site root.

## Customizing

- **Copy**: all text lives directly in each component under `components/` —
  edit the arrays at the top of each file (`FEATURES`, `STEPS`, `TESTIMONIALS`,
  `PLANS`, `FAQS`) to swap in your own product's content.
- **Colors**: the violet → cyan gradient is defined via Tailwind utility classes
  (`from-violet-600 to-cyan-400`, etc.) directly in each component — search and
  replace to re-theme.
- **Fonts**: Sora (display/headings), Inter (body) and JetBrains Mono
  (numbered steps) are bundled locally from `@fontsource*` and imported in
  `app/layout.tsx`, so the build needs no network access. Swap those imports
  and the `--font-*` variables in `app/globals.css` to change the typography.

## Tech stack

Next.js 16 (App Router) · TypeScript · Tailwind CSS v4 · Framer Motion · lucide-react

## License

Commercial license included with purchase — one end product per purchase. Client work is allowed within the included single-end-product license. Redistribution or resale of the template source is not permitted.


## Before publishing

This ZIP is a front-end template, not a hosted AI agent, model, backend, or integration service. Replace all sample metrics, testimonials, customer names, pricing, integration labels, and links with accurate information for your own product. Publish performance claims and customer proof only when you can substantiate them and have permission to use them. Connect and test your own backend, authentication, data sources, and support workflows.
