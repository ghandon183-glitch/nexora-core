# Nexi AI — AI Agent Landing Page Template

A production-ready landing page template for AI agent, chatbot, and automation products.
Built with Next.js 16, Tailwind CSS v4, TypeScript, and Framer Motion.

## What's inside

- Dramatic hero with a live "agent chat" mockup showing a visible reasoning trace
  (not just chat bubbles — the agent's steps are shown, which is the template's
  signature detail).
- Bento-grid feature section
- 4-step "How it works" section
- Testimonials
- 3-tier pricing section
- Accordion FAQ
- Final CTA + footer

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Customizing

- **Copy**: all text lives directly in each component under `components/` —
  edit the arrays at the top of each file (`FEATURES`, `STEPS`, `TESTIMONIALS`,
  `PLANS`, `FAQS`) to swap in your own product's content.
- **Colors**: the violet → cyan gradient is defined via Tailwind utility classes
  (`from-violet-600 to-cyan-400`, etc.) directly in each component — search and
  replace to re-theme.
- **Fonts**: configured in `app/layout.tsx` — Sora (display/headings), Inter
  (body), JetBrains Mono (used for the numbered steps). Swap any of the three
  `next/font/google` imports to change the whole site's typography.

## Tech stack

Next.js 16 (App Router) · TypeScript · Tailwind CSS v4 · Framer Motion · lucide-react

## License

Commercial license included with purchase — use in unlimited personal or client
projects. Redistribution or resale of the template itself is not permitted.
