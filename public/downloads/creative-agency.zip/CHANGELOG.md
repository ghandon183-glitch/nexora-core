# Changelog

## 1.1.0
- Updated Next.js and `eslint-config-next` to 16.4.5 to clear the published
  production advisories, pinned `minimatch` ^11.0.1 for the lint toolchain, and
  shipped a `package-lock.json` so `npm ci` is reproducible.
- Configured `output: "export"` plus optional `NEXT_PUBLIC_BASE_PATH`, and
  documented the static deployment flow (`.env.example` included).
- Fixed dead controls: “Start a project” buttons and the footer now link to a
  real `/contact` page with studio details and a demo enquiry form.
- Added an accessible mobile navigation menu with `aria-expanded` and
  `aria-controls`; navigation now points at real routes.
- Footer rebuilt with working links, an email link, and explicit sample-content
  labelling.
- Accessibility: focus-visible styles, reduced-motion handling that stops the
  marquee, and duplicated marquee words hidden from screen readers.
- Removed internal `AGENTS.md`/`CLAUDE.md` notes and unused Next.js starter SVGs
  from the shipped package.
- README rewritten with prerequisites, route map, environment variable, static
  build/preview/deploy steps, demo-only behaviour, and form-connection guide.

## 1.0.0
- Customer-ready commercial package.
- Standard license and support documentation.
- Installation and production checklist included.
