export interface Project {
  slug: string;
  title: string;
  client: string;
  categories: string[];
  year: string;
  summary: string;
  gradient: string;
  challenge: string;
  approach: string;
  outcome: string;
  stats: { label: string; value: string }[];
}

export const projects: Project[] = [
  {
    slug: "amber-and-oat",
    title: "A pantry brand that doesn't look like a pantry brand",
    client: "Amber & Oat",
    categories: ["Branding", "Packaging"],
    year: "2026",
    summary: "Full rebrand and packaging system for a small-batch grain and oat producer.",
    gradient: "from-[#8B5CF6] to-[#FF5A5F]",
    challenge: "Amber & Oat made genuinely great small-batch grains, but their packaging looked like every other \"rustic craft\" brand on the shelf — kraft paper, a hand-drawn wheat sprig, done. Nothing stopped a shopper's eye.",
    approach: "We moved away from rustic-craft cliches entirely and built a bold, graphic identity around oversized type and a two-color system that could scale from a jar label to a delivery van. Every SKU got its own accent color within one consistent system.",
    outcome: "Shelf test scans showed a 41% increase in stopping power versus the old packaging, and the brand picked up two regional retail listings within the first quarter after relaunch.",
    stats: [
      { label: "Stopping power", value: "+41%" },
      { label: "New retail listings", value: "2" },
      { label: "SKUs redesigned", value: "14" },
    ],
  },
  {
    slug: "fernbank",
    title: "Turning a 40-person clinic into a digital-first practice",
    client: "Fernbank Health",
    categories: ["Web Design", "Branding"],
    year: "2025",
    summary: "Brand refresh and a booking-first website for a multi-location physiotherapy practice.",
    gradient: "from-[#FF5A5F] to-[#8B5CF6]",
    challenge: "Fernbank had five clinic locations and a website that still listed a fax number as the primary contact method. Patients were calling to book, waiting on hold, and going elsewhere.",
    approach: "We designed a calm, credible visual identity and rebuilt the site around a single job: get a patient to a confirmed booking in under 90 seconds, from any device, without creating an account first.",
    outcome: "Online bookings went from effectively zero to 63% of all new appointments within four months of launch.",
    stats: [
      { label: "Bookings now online", value: "63%" },
      { label: "Avg. time to book", value: "74s" },
      { label: "Locations", value: "5" },
    ],
  },
  {
    slug: "loop-transit",
    title: "Making public transit maps people actually enjoy reading",
    client: "Loop Transit Co-op",
    categories: ["Branding", "Web Design", "Motion"],
    year: "2025",
    summary: "Wayfinding system, route maps, and a companion site for a city bike-share and transit co-op.",
    gradient: "from-[#8B5CF6] to-[#FFB020]",
    challenge: "Loop's routes covered a growing city, but their maps hadn't kept up — riders regularly got lost transferring between the bike-share and bus network.",
    approach: "We redesigned the entire wayfinding system around a single color-coded logic that carries through printed signage, the website's live map, and the mobile app, tested with actual riders at three stations before rollout.",
    outcome: "Support tickets tagged \"couldn't find my stop\" dropped by 58% in the two months following rollout.",
    stats: [
      { label: "Wayfinding tickets", value: "-58%" },
      { label: "Stations redesigned", value: "22" },
      { label: "Routes mapped", value: "9" },
    ],
  },
];

export const services = [
  {
    title: "Brand identity",
    body: "Naming, visual identity, and the guidelines to keep it consistent as you grow.",
  },
  {
    title: "Web design & build",
    body: "Marketing sites and product sites designed and shipped by the same team.",
  },
  {
    title: "Packaging design",
    body: "Structural and graphic packaging design, from concept to print-ready files.",
  },
  {
    title: "Motion & art direction",
    body: "Launch films, social motion systems, and ongoing art direction.",
  },
];

export const process = [
  { title: "Listen", body: "Two weeks embedded with your team to understand the real problem, not just the brief." },
  { title: "Diverge", body: "Wide, fast exploration — multiple genuinely different directions, not one safe option with variations." },
  { title: "Converge", body: "One direction, refined until every detail earns its place." },
  { title: "Ship & support", body: "Launch support and a system your team can actually run without us." },
];

export const testimonials = [
  {
    quote: "Kiln didn't just make us look better. They made the whole team more confident about what we're actually building.",
    name: "Renata Osei",
    role: "Founder, Amber & Oat",
  },
  {
    quote: "Every other agency pitched us a mood board. Kiln pitched us a plan for cutting our booking time in half — and then delivered it.",
    name: "Dr. James Okafor",
    role: "Operations Lead, Fernbank Health",
  },
];
