import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // The template ships as a fully static site: `npm run build` writes `out/`,
  // which can be hosted anywhere (Cloudflare Pages, Netlify, S3, nginx).
  output: "export",
  // Optional sub-path support, e.g. building the marketplace demo at
  // /demo/creative-agency. Empty for a normal domain-root deployment.
  basePath: process.env.NEXT_PUBLIC_BASE_PATH || undefined,
  images: {
    // Required for static export; this template ships no remote images.
    unoptimized: true,
  },
};

export default nextConfig;
