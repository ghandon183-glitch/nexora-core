import type { Metadata } from "next";
import Navbar from "@/components/sections/navbar";
import Footer from "@/components/sections/footer";
import ContactForm from "@/components/contact-form";

export const metadata: Metadata = {
  title: "Start a project — Kiln",
  description:
    "Contact page for the Creative Agency template. Sample content with a demo-only enquiry form.",
};

export default function ContactPage() {
  return (
    <>
      <Navbar />
      <main className="py-20">
        <div className="mx-auto max-w-4xl px-6">

          <p className="font-mono text-xs tracking-[0.3em] text-violet uppercase">
            Contact
          </p>

          <h1 className="mt-4 max-w-xl font-display text-5xl font-extrabold text-text">
            Start a project
          </h1>

          <p className="mt-6 max-w-xl text-lg text-text-muted">
            Tell us what you are building and what is in the way. This page is
            sample template content — replace the studio details and connect the
            form to your own inbox before publishing.
          </p>

          <dl className="mt-10 grid gap-4 rounded-2xl border border-line p-6 text-sm sm:grid-cols-[8rem_1fr]">
            <dt className="font-semibold text-text">Email</dt>
            <dd>
              <a
                href="mailto:hello@kiln.studio"
                className="text-text-muted underline decoration-violet decoration-2 underline-offset-4 hover:text-text"
              >
                hello@kiln.studio
              </a>
            </dd>
            <dt className="font-semibold text-text">Phone</dt>
            <dd className="text-text-muted">(503) 555-0142</dd>
            <dt className="font-semibold text-text">Studio</dt>
            <dd className="text-text-muted">218 Alder Lane, Portland, OR 97209</dd>
            <dt className="font-semibold text-text">Hours</dt>
            <dd className="text-text-muted">Monday–Friday, 09:00–17:00</dd>
          </dl>

          <div className="mt-12">
            <ContactForm />
          </div>

        </div>
      </main>
      <Footer />
    </>
  );
}
