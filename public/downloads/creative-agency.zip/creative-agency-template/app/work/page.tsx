import Navbar from "@/components/sections/navbar";
import Footer from "@/components/sections/footer";
import WorkGrid from "@/components/sections/work-grid";

export default function WorkPage() {
  return (
    <>
      <Navbar />
      <main className="py-20">
        <div className="mx-auto max-w-7xl px-6">

          <p className="font-mono text-xs tracking-[0.3em] text-violet uppercase">
            Work
          </p>

          <h1 className="mt-4 max-w-xl font-display text-5xl font-extrabold text-text">
            Everything we&apos;ve shipped
          </h1>

          <div className="mt-14">
            <WorkGrid />
          </div>

        </div>
      </main>
      <Footer />
    </>
  );
}
