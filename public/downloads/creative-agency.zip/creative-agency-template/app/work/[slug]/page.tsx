import { notFound } from "next/navigation";
import Navbar from "@/components/sections/navbar";
import Footer from "@/components/sections/footer";
import { projects } from "@/lib/data";

export function generateStaticParams() {
  return projects.map((p) => ({ slug: p.slug }));
}

export default async function CaseStudyPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const project = projects.find((p) => p.slug === slug);

  if (!project) {
    notFound();
  }

  return (
    <>
      <Navbar />

      <main>

        <section className="pt-16 pb-10">
          <div className="mx-auto max-w-4xl px-6">

            <div className="flex flex-wrap items-center gap-2">
              {project.categories.map((cat) => (
                <span
                  key={cat}
                  className="rounded-full border border-line px-3 py-1 font-mono text-[11px] text-text-muted uppercase"
                >
                  {cat}
                </span>
              ))}

              <span className="font-mono text-[11px] text-text-muted">
                {project.year}
              </span>
            </div>

            <h1 className="mt-6 font-display text-4xl font-extrabold text-text sm:text-5xl">
              {project.title}
            </h1>

            <p className="mt-4 text-lg text-text-muted">
              {project.client}
            </p>

          </div>
        </section>

        <div className={`mx-6 aspect-[16/7] max-w-6xl rounded-3xl bg-gradient-to-br sm:mx-auto ${project.gradient}`} />

        <section className="py-20">
          <div className="mx-auto grid max-w-4xl gap-16 px-6 sm:grid-cols-3">

            <div className="sm:col-span-2 space-y-12">

              <div>
                <h2 className="font-display text-xl font-bold text-text">
                  The challenge
                </h2>
                <p className="mt-3 leading-7 text-text-muted">
                  {project.challenge}
                </p>
              </div>

              <div>
                <h2 className="font-display text-xl font-bold text-text">
                  Our approach
                </h2>
                <p className="mt-3 leading-7 text-text-muted">
                  {project.approach}
                </p>
              </div>

              <div>
                <h2 className="font-display text-xl font-bold text-text">
                  The outcome
                </h2>
                <p className="mt-3 leading-7 text-text-muted">
                  {project.outcome}
                </p>
              </div>

            </div>

            <aside className="space-y-6">
              {project.stats.map((stat) => (
                <div key={stat.label} className="border-t border-line pt-4">
                  <p className="font-display text-3xl font-extrabold text-violet">
                    {stat.value}
                  </p>
                  <p className="mt-1 text-sm text-text-muted">
                    {stat.label}
                  </p>
                </div>
              ))}
            </aside>

          </div>
        </section>

      </main>

      <Footer />
    </>
  );
}
