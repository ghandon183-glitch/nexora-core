import Navbar from "@/components/sections/navbar";
import Hero from "@/components/sections/hero";
import WorkGrid from "@/components/sections/work-grid";
import Services from "@/components/sections/services";
import Process from "@/components/sections/process";
import Testimonials from "@/components/sections/testimonials";
import Cta from "@/components/sections/cta";
import Footer from "@/components/sections/footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />

        <section className="py-24">
          <div className="mx-auto max-w-7xl px-6">
            <p className="font-mono text-xs tracking-[0.3em] text-violet uppercase">
              Selected work
            </p>

            <h2 className="mt-4 max-w-xl font-display text-4xl font-extrabold text-text">
              A few things we&apos;re proud of
            </h2>

            <div className="mt-14">
              <WorkGrid limit={3} />
            </div>
          </div>
        </section>

        <Services />
        <Process />
        <Testimonials />
        <Cta />
      </main>
      <Footer />
    </>
  );
}
