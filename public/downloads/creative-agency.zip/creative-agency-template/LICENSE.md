# Single End Product Commercial License

This package is licensed for building and launching one personal, commercial, or client-facing end product. Keep the reusable template source protected from redistribution.

## You may

- Use the purchased source in one personal, commercial, or client-facing end product.
- Modify, extend, restyle, refactor, and combine it with your own code.
- Deploy the finished product publicly, including hosted and SaaS applications.

## Client work

You may build a finished website or application for a client. The client receives the finished end product, not the reusable template source as a separate product.

## You may not

- Resell, redistribute, sublicense, publish, or share the source package itself.
- Offer the source as a template, UI kit, boilerplate, starter kit, or competing marketplace product.

## Multiple end products

One purchase covers one end product. Independent products, separate client deliverables, or separate brands require additional licenses unless a written agreement says otherwise.

## Third-party assets

Fonts, photographs, icons, illustrations, logos, and other third-party materials remain subject to their own licenses. Review ASSET-LICENSES.md and replace demo assets when necessary.

## Updates and support

Future updates are included while the purchased template is maintained. Support covers installation and documented template behavior; custom development, hosting, third-party configuration, and bespoke integrations are outside standard support.

## Warranty and liability

The package is provided as source code for development use. To the maximum extent permitted by law, Nexora Core disclaims warranties for uninterrupted operation, third-party services, framework changes, and fitness for a particular purpose. Nothing in this license limits rights that cannot lawfully be excluded in your jurisdiction.

Read the current purchase policy and support information: https://nexora-core.nxora.workers.dev/en/license, https://nexora-core.nxora.workers.dev/en/refunds, and https://nexora-core.nxora.workers.dev/en/support. This document is not legal advice.
