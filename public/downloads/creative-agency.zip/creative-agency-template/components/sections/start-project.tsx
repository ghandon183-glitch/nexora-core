"use client";

import { useEffect, useState } from "react";
import Button from "@/components/ui/button";

export default function StartProject({ className = "" }: { className?: string }) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <>
      <Button className={className} onClick={() => setOpen(true)} aria-haspopup="dialog">
        Start a project
      </Button>
      {open ? (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/60 p-6"
          onClick={() => setOpen(false)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="start-project-title"
            className="w-full max-w-md rounded-2xl border border-line bg-bg p-8"
            onClick={(event) => event.stopPropagation()}
          >
            <h2 id="start-project-title" className="font-display text-2xl font-bold text-text">
              Start a project
            </h2>
            <p className="mt-3 text-sm text-text-muted">
              This demo has no contact backend. Add your own form, scheduling link, or email
              address here before publishing.
            </p>
            <div className="mt-6 flex justify-end">
              <Button onClick={() => setOpen(false)}>Close</Button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
