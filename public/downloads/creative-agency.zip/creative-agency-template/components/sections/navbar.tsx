import Link from "next/link";
import ThemeToggle from "@/components/ui/theme-toggle";
import Button from "@/components/ui/button";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-line bg-bg/85 backdrop-blur-xl">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">

        <Link href="/" className="font-display text-xl font-extrabold tracking-tight text-text">
          Kiln
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          <Link href="/work" className="text-sm text-text-muted transition hover:text-text">
            Work
          </Link>
          <Link href="/#services" className="text-sm text-text-muted transition hover:text-text">
            Services
          </Link>
          <Link href="/#process" className="text-sm text-text-muted transition hover:text-text">
            Process
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Button className="hidden sm:inline-flex">Start a project</Button>
        </div>

      </div>
    </header>
  );
}
