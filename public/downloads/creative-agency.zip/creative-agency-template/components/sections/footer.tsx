export default function Footer() {
  return (
    <footer className="border-t border-line py-16">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-6 sm:flex-row sm:items-center sm:justify-between">

        <span className="font-display text-lg font-extrabold text-text">
          Kiln
        </span>

        <p className="text-sm text-text-muted">
          © 2026 Kiln Studio. This is placeholder demo content for the
          Creative Agency template.
        </p>

      </div>
    </footer>
  );
}
