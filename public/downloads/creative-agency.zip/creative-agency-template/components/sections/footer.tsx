import Link from "next/link";

const links = [
  { label: "Work", href: "/work" },
  { label: "Services", href: "/#services" },
  { label: "Process", href: "/#process" },
  { label: "Contact", href: "/contact" },
];

export default function Footer() {
  return (
    <footer className="border-t border-line py-16">
      <div className="mx-auto max-w-7xl px-6">

        <div className="flex flex-col gap-8 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <Link href="/" className="font-display text-lg font-extrabold text-text">
              Kiln
            </Link>
            <p className="mt-2 max-w-xs text-sm text-text-muted">
              A small brand and digital design studio. Placeholder demo content
              for the Creative Agency template.
            </p>
          </div>

          <nav aria-label="Footer" className="flex flex-wrap gap-x-6 gap-y-2">
            {links.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="text-sm text-text-muted transition hover:text-text"
              >
                {link.label}
              </Link>
            ))}
            <a
              href="mailto:hello@kiln.studio"
              className="text-sm text-text-muted transition hover:text-text"
            >
              hello@kiln.studio
            </a>
          </nav>
        </div>

        <div className="mt-10 border-t border-line pt-6">
          <p className="text-sm text-text-muted">
            © {new Date().getFullYear()} Kiln Studio. Sample content — replace
            the studio name, projects, and contact details before publishing.
          </p>
        </div>

      </div>
    </footer>
  );
}
