import { testimonials } from "@/lib/data";

export default function Testimonials() {
  return (
    <section className="border-y border-line bg-bg-raised py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="grid gap-12 lg:grid-cols-2">
          {testimonials.map((t) => (
            <figure key={t.name}>
              <blockquote className="font-display text-2xl leading-snug font-medium text-text">
                &ldquo;{t.quote}&rdquo;
              </blockquote>

              <figcaption className="mt-6 font-mono text-xs tracking-wide text-text-muted uppercase">
                {t.name} — {t.role}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}
