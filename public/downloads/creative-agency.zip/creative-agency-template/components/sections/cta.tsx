import Button from "@/components/ui/button";

export default function Cta() {
  return (
    <section className="py-32">
      <div className="mx-auto max-w-7xl px-6 text-center">

        <h2 className="mx-auto max-w-2xl font-display text-5xl font-extrabold text-text sm:text-6xl">
          Got something worth
          <span className="bg-gradient-to-r from-violet to-coral bg-clip-text text-transparent"> making noise</span> about?
        </h2>

        <div className="mt-10 flex justify-center">
          <Button>Start a project</Button>
        </div>

      </div>
    </section>
  );
}
