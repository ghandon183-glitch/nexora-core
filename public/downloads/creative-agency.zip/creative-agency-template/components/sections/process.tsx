import { process } from "@/lib/data";

export default function Process() {
  return (
    <section id="process" className="py-24">
      <div className="mx-auto max-w-7xl px-6">

        <p className="font-mono text-xs tracking-[0.3em] text-violet uppercase">
          How we work
        </p>

        <h2 className="mt-4 max-w-xl font-display text-4xl font-extrabold text-text">
          Four steps. No mystery.
        </h2>

        <div className="mt-14 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {process.map((step, i) => (
            <div key={step.title}>
              <span className="font-display text-5xl font-extrabold text-violet/30">
                {String(i + 1).padStart(2, "0")}
              </span>

              <h3 className="mt-4 font-display text-lg font-bold text-text">
                {step.title}
              </h3>

              <p className="mt-2 text-sm leading-6 text-text-muted">
                {step.body}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
