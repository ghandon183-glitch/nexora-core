import { services } from "@/lib/data";

export default function Services() {
  return (
    <section id="services" className="border-y border-line py-24">
      <div className="mx-auto max-w-7xl px-6">

        <p className="font-mono text-xs tracking-[0.3em] text-violet uppercase">
          Services
        </p>

        <h2 className="mt-4 max-w-xl font-display text-4xl font-extrabold text-text">
          What we actually do
        </h2>

        <div className="mt-14 grid gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-2">
          {services.map((service) => (
            <div key={service.title} className="bg-bg p-8">
              <h3 className="font-display text-xl font-bold text-text">
                {service.title}
              </h3>

              <p className="mt-3 text-sm leading-6 text-text-muted">
                {service.body}
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
