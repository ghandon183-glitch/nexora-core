const words = ["Branding", "Web Design", "Packaging", "Motion", "Art Direction"];

export default function Hero() {
  return (
    <section className="relative overflow-hidden pt-20 pb-16">

      <div className="mx-auto max-w-7xl px-6">
        <p className="font-mono text-xs tracking-[0.3em] text-text-muted uppercase">
          Brand &amp; digital design studio
        </p>

        <h1 className="mt-6 max-w-4xl font-display text-6xl leading-[0.95] font-extrabold tracking-tight text-text sm:text-7xl lg:text-8xl">
          We make brands
          <br />
          people <span className="bg-gradient-to-r from-violet to-coral bg-clip-text text-transparent">actually notice.</span>
        </h1>

        <p className="mt-8 max-w-lg text-lg text-text-muted">
          Kiln is a small studio that builds bold identities and the
          websites, packaging, and motion systems that carry them —
          for brands willing to look different.
        </p>
      </div>

      <div className="mt-16 overflow-hidden border-y border-line py-6">
        <div className="marquee-track">
          {[...words, ...words, ...words].map((word, i) => (
            <span
              key={i}
              className="mx-6 flex shrink-0 items-center gap-6 font-display text-3xl font-extrabold text-text-muted/50"
            >
              {word}
              <span className="text-violet">✦</span>
            </span>
          ))}
        </div>
      </div>

    </section>
  );
}
