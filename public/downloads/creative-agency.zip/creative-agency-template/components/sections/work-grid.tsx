"use client";

import { useState } from "react";
import Link from "next/link";
import { projects } from "@/lib/data";

const allCategories = ["All", ...Array.from(new Set(projects.flatMap((p) => p.categories)))];

export default function WorkGrid({ limit }: { limit?: number }) {
  const [active, setActive] = useState("All");

  const filtered = projects.filter(
    (p) => active === "All" || p.categories.includes(active)
  );

  const shown = limit ? filtered.slice(0, limit) : filtered;

  return (
    <div>

      <div className="flex flex-wrap gap-2">
        {allCategories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActive(cat)}
            className={`rounded-full border px-4 py-2 text-sm font-medium transition ${
              active === cat
                ? "border-violet bg-violet/10 text-violet"
                : "border-line text-text-muted hover:border-violet/50"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="mt-10 grid gap-6 sm:grid-cols-2">
        {shown.map((project, i) => (
          <Link
            key={project.slug}
            href={`/work/${project.slug}`}
            className={`group block ${i % 3 === 0 ? "sm:col-span-2" : ""}`}
          >
            <div
              className={`relative aspect-[16/10] overflow-hidden rounded-2xl bg-gradient-to-br ${project.gradient} ${
                i % 3 === 0 ? "sm:aspect-[32/13]" : ""
              }`}
            >
              <div className="absolute inset-0 flex items-end p-6">
                <span className="rounded-full bg-black/30 px-3 py-1 font-mono text-xs text-white backdrop-blur-sm">
                  {project.year}
                </span>
              </div>

              <div className="absolute top-6 right-6 flex h-10 w-10 items-center justify-center rounded-full bg-white/90 opacity-0 transition group-hover:opacity-100">
                →
              </div>
            </div>

            <div className="mt-4 flex items-start justify-between gap-4">
              <div>
                <h3 className="font-display text-lg font-bold text-text">
                  {project.client}
                </h3>

                <p className="mt-1 text-sm text-text-muted">
                  {project.summary}
                </p>
              </div>

              <div className="flex shrink-0 flex-wrap justify-end gap-1.5">
                {project.categories.map((cat) => (
                  <span
                    key={cat}
                    className="rounded-full border border-line px-2.5 py-1 font-mono text-[10px] text-text-muted uppercase"
                  >
                    {cat}
                  </span>
                ))}
              </div>
            </div>
          </Link>
        ))}
      </div>

    </div>
  );
}
