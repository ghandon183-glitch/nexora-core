"use client";

import { useState } from "react";

export default function ContactForm() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <div>
      <h2 className="font-display text-2xl font-bold text-text">
        Project enquiry
      </h2>

      {submitted ? (
        <div
          role="status"
          className="mt-5 rounded-2xl border border-line bg-bg-raised p-6 text-sm"
        >
          <p className="font-semibold text-text">
            Demo form — nothing was sent or stored.
          </p>
          <p className="mt-2 text-text-muted">
            This template has no form backend, so the details you typed were not
            emailed, saved, or sent anywhere. To receive real enquiries, connect
            a form service in{" "}
            <code className="rounded bg-line px-1.5 py-0.5 text-xs text-text">
              components/contact-form.tsx
            </code>{" "}
            or point the form at an API route — see the README section
            “Connecting a contact form”.
          </p>
          <button
            type="button"
            onClick={() => setSubmitted(false)}
            className="mt-4 text-sm font-semibold text-violet underline decoration-2 underline-offset-4 hover:text-violet-bright"
          >
            Back to the form
          </button>
        </div>
      ) : (
        <form
          onSubmit={(event) => {
            event.preventDefault();
            setSubmitted(true);
          }}
          className="mt-5 grid gap-4"
        >
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="contact-name" className="text-sm font-semibold text-text">
                Your name
              </label>
              <input
                id="contact-name"
                name="name"
                type="text"
                required
                autoComplete="name"
                className="mt-2 w-full rounded-xl border border-line bg-bg px-4 py-3 text-sm text-text placeholder:text-text-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet"
                placeholder="Alex Rivera"
              />
            </div>

            <div>
              <label htmlFor="contact-email" className="text-sm font-semibold text-text">
                Email address
              </label>
              <input
                id="contact-email"
                name="email"
                type="email"
                required
                autoComplete="email"
                className="mt-2 w-full rounded-xl border border-line bg-bg px-4 py-3 text-sm text-text placeholder:text-text-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet"
                placeholder="you@company.com"
              />
            </div>
          </div>

          <div>
            <label htmlFor="contact-message" className="text-sm font-semibold text-text">
              What are you building?
            </label>
            <textarea
              id="contact-message"
              name="message"
              required
              rows={5}
              className="mt-2 w-full rounded-xl border border-line bg-bg px-4 py-3 text-sm text-text placeholder:text-text-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet"
              placeholder="A short paragraph about the project, timeline, and budget."
            />
          </div>

          <button
            type="submit"
            className="mt-2 inline-flex items-center justify-center rounded-full bg-violet px-6 py-3 text-sm font-semibold text-white transition-all duration-200 hover:bg-violet-bright focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet focus-visible:ring-offset-2 focus-visible:ring-offset-bg"
          >
            Send enquiry
          </button>
        </form>
      )}

      <p role="note" className="mt-4 text-xs leading-relaxed text-text-muted">
        Demo form — no message is sent or stored until you connect a form
        provider. See the README for setup.
      </p>
    </div>
  );
}
