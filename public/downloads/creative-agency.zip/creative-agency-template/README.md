# Creative Agency — Nexora Core Template

A bold, portfolio-driven agency site built with Next.js (App Router),
Tailwind CSS v4, and TypeScript. Ships with a filterable work grid,
individual case-study pages, a scrolling marquee, a subtle grain texture,
and a working light/dark theme toggle.

## What's inside

- `app/page.tsx` — homepage: hero, marquee, selected work, services,
  process, testimonials, CTA
- `app/work/page.tsx` — the full, filterable work grid
- `app/work/[slug]/page.tsx` — individual case study pages
  (challenge / approach / outcome / stats)
- `components/sections/` — Navbar, Hero, WorkGrid, Services, Process,
  Testimonials, CTA, Footer
- `lib/data.ts` — all project/case-study, services, process, and
  testimonial content
- `lib/use-theme.ts` — the light/dark theme hook

## Getting started

```bash
npm install
npm run dev
```

Open `http://localhost:3000` to see it running.

## Customizing

1. **Projects**: Edit the `projects` array in `lib/data.ts` — each entry
   powers both its work-grid card and its full case study page
   automatically (via `app/work/[slug]/page.tsx`).
2. **Colors & fonts**: Design tokens live in `app/globals.css` under
   `:root`, `[data-theme="dark"]`, and `[data-theme="light"]`. Fonts are
   loaded via `next/font/google` in `app/layout.tsx`.
3. **Grain texture**: The subtle noise overlay is a CSS-only effect
   (`.grain` in `globals.css`) — remove the class from `<body>` in
   `app/layout.tsx` to turn it off.
4. **Marquee speed**: Controlled by the `animation` duration on
   `.marquee-track` in `globals.css`.

## License

This template is licensed for use in your own personal or commercial
projects, including client work. You may not resell or redistribute the
source code itself as a standalone template or product.
