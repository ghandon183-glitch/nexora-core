
import { notFound } from "next/navigation";

import Navbar from "@/components/navigation/navbar";
import Sidebar from "@/components/navigation/sidebar";
import FloatingDock from "@/components/navigation/floating-dock";

import Section from "@/components/ui/section";
import Container from "@/components/ui/container";

import ProductGallery from "@/components/product/product-gallery";
import ProductHeader from "@/components/product/product-header";
import ProductSpecifications from "@/components/product/product-specifications";
import PurchaseCard from "@/components/product/purchase-card";

import RelatedTemplates from "@/components/sections/related-templates";

import { getTemplate } from "@/lib/data/get-template";

interface PageProps {
  params: Promise<{
    slug: string;
  }>;
}

export default async function TemplateDetailsPage({
  params,
}: PageProps) {
  const { slug } = await params;

  const template = getTemplate(slug);

  if (!template) {
    notFound();
  }

  return (
    <>
      <Navbar />
      <Sidebar />
      <FloatingDock />

      <Section>
        <Container className="space-y-24">

          <div className="grid items-start gap-16 xl:grid-cols-[minmax(0,1fr)_380px]">

            <div className="space-y-16">

              <ProductGallery
                images={[
                  template.image,
                  template.image,
                  template.image,
                  template.image,
                ]}
              />

              <ProductHeader
                title={template.title}
                description={template.description}
                badge={template.badge}
                price={template.price}
              />

              <ProductSpecifications
                framework={template.framework}
                styling={template.styling}
                components={template.components}
              />

            </div>

            <PurchaseCard
              price={template.price}
            />

          </div>

          <RelatedTemplates />

        </Container>
      </Section>
    </>
  );
}