import Navbar from "@/components/navigation/navbar";
import Sidebar from "@/components/navigation/sidebar";
import FloatingDock from "@/components/navigation/floating-dock";

import Section from "@/components/ui/section";
import Input from "@/components/ui/input";
import TemplateCard from "@/components/ui/template-card";

import TemplateFilters from "@/components/sections/template-filters";

import { templates } from "@/lib/data/templates";

export default function TemplatesPage() {
  return (
    <>
      <Navbar />
      <Sidebar />
      <FloatingDock />

      <Section>
        <div className="mb-16 text-center">
          <h1 className="text-5xl font-black text-white">
            Browse Templates
          </h1>

          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-400">
            Premium Next.js templates crafted for startups,
            SaaS, agencies and modern businesses.
          </p>

          <div className="mx-auto mt-10 max-w-xl">
            <Input placeholder="Search templates..." />
          </div>
        </div>

        <TemplateFilters />

        <div className="grid gap-8 md:grid-cols-2 xl:grid-cols-3">
          {templates.map((template) => (
            <TemplateCard
              key={template.id}
              slug={template.slug}
              title={template.title}
              description={template.description}
              image={template.image}
              badge={template.badge}
              price={template.price}
            />
          ))}
        </div>
      </Section>
    </>
  );
}